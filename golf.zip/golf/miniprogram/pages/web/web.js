// pages/web/web.js
import {
    httpPost, 
    publicPath,
    webUrl
} from "../../utils/http";
import GState from "../../utils/GState";


Page({

    /**
     * 页面的初始数据
     */
    data: {
        url: '',
        token:'',
        showUrl:false,
        shareUrl:'',
        sharePath:''
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log(options);
        
        this.login();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function (shareData) {
        console.log(shareData)
        const webViewUrl = shareData.webViewUrl.match(`https://.*?/#(.*)`)
        let tempUrl = ''
        if(webViewUrl !== null ){
            let fullpath = webViewUrl[1].match(/([^\?]+)/g)
            let path = fullpath[0]
            let query = fullpath[1]

            const queryReg = new RegExp(/([^\&]+)=([^\&]*)/g)
            let queryExec = queryReg.exec(query)
            let queryParams = []
            while(queryExec !== null){
                if(queryExec[1] !== 'token'){
                    queryParams.push(queryExec[1] + "=" + queryExec[2])
                }
                queryExec = queryReg.exec(query)
            }
            tempUrl = `${path}?${queryParams.join('&')}`
        }else{
            tempUrl = '/?from=miniProgram&match_id=1'
        }

        const shareCfg = {
            title: "贵州省高尔夫球协会",
            path: '/pages/shareWeb/shareWeb?redirect=' + encodeURIComponent(tempUrl),
            
        }
        console.log(shareCfg)
        return shareCfg
    },

    bindMessage(data) {
        console.log(data.detail.data[0]);
        let url=data.detail.data[0].url;
        this.setData({
            shareUrl:url
        })
    },

    dealUrl() {
        let webUrlA = webUrl;
        console.log(GState.userData);
        if (GState.h5.path) {
            webUrlA = webUrlA + "&path=" + GState.h5.path;
        }
        if (GState.userData.token) {
            webUrlA = webUrlA + "&token=" + GState.userData.token;
        }
/*        let timestamp = new Date().getTime();
            webUrlA=webUrlA+'&timestamp='+timestamp*/
        console.log(webUrlA);
      return webUrlA;

    },


    login() {
        // 登录
        let that = this;
        if(GState.userData.token){
            let webUrl = that.dealUrl();
            that.setData({url: webUrl,showUrl:true});
        }else{
            wx.login({
                success: res => {
                    console.log(res.code);
                    // 发送 res.code 到后台换取 openId, sessionKey, unionId
                    httpPost("/rest/golf_asso/wxLogin", {
                        type: "login",	//否	string	默认login 可传phone
                        code: res.code,//	是	string	type=login的时候必传
                    }).then(r => {
                        console.log(r);
                        let data = r.data;
                        GState.userData = {...data};
                        console.log('log');
                        let webUrl = that.dealUrl();
                        console.log(webUrl)
                        that.setData({url: webUrl,showUrl:true})
                    }).catch(e => {
                        console.log(e);
                        let webUrl = that.dealUrl();
                        that.setData({url: webUrl,showUrl:true});
                    })
                },
            });
        }

    }

});