// pages/login/login.js
import {httpPost, httpPostWithToken} from "../../utils/http";
import GState from "../../utils/GState";

Page({

    /**
     * 页面的初始数据
     */
    data: {
        showNick: false,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log(options);
        GState.h5 = {...options}
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function (e) {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    getPhoneNumber(e) {
        console.log(e);
        let that=this;
        if (e.detail.errMsg === 'getPhoneNumber:ok') {
            let data = {
                type: 'phone',//	否	string	默认login 可传phone
                iv: e.detail.iv,//	是	string	type=phone的时候必传
                encryptedData: e.detail.encryptedData,//	是	string	type=phone的时候必传
                session_key: GState.userData.session_key,	//是	string	type=phone的时候必传 调用登录接口可得到该参数
                open_id: GState.userData.openid,
            };
            wx.showLoading({mask: true,title:'loading...'});
            httpPost("/rest/golf_asso/wxLogin", data).then(res => {
                wx.hideLoading()
                console.log(res);
                GState.userData = {...res.data};
                that.setData({
                    showNick: true
                })
            }).catch(e=>{
                wx.hideLoading()
            }).finally(() => {
                wx.hideLoading()
            })
        }
        else{
           wx.hideLoading()
        }
    },
    getUserInfo(e) {
        console.log(e);
        let that=this;
        if (e.detail.errMsg === 'getUserInfo:ok') {
            that.setData({
                showNick: false
            });
            GState.userInfo = {...e.detail.userInfo};
            if (GState.userData.token) {
                let data = {
                    nickName: GState.userInfo.nickName,//	是	int	昵称
                    avatarUrl: GState.userInfo.avatarUrl,//	是	int	头像
                    province: GState.userInfo.province,//	否	int	省份
                    city: GState.userInfo.city,//	否	int	城市
                    gender: GState.userInfo.gender,//	否	int	性别
                };
                httpPostWithToken('/rest/golf_asso/saveWxData', data).then(r => {
                    console.log(r)
                });
            }

            let path='/pages/web/web';
            if(GState.h5.path==='sports'){
                path='/pages/sports/sports'
            }
            wx.redirectTo({
                url: path
            });
        }
    },

});