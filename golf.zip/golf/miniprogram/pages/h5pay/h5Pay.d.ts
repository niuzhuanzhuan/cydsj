interface payInfoData {
    appId: string,
    timeStamp: string,
    nonceStr: string,
    package: string,
    signType: "MD5",
    paySign: string,
    info: payOrderData
}
interface payOrderData {
    title: string,
    price: string,
    order: string
}