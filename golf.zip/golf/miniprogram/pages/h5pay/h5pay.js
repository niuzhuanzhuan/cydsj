// pages/h5pay/h5pay.js
import { httpPostWithToken} from "../../utils/http";
import GState from "../../utils/GState";

Page({

  /**
   * 页面的初始数据
   */
  data: {
        payInfo:'',
        showO:false,//弹框
        showC:"",//弹框内容
        buttons: [{text: '取消'}, {text: '确定'}],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
          let data= JSON.parse(decodeURI(options.payData));
              console.log(data)
              data.data.open_id=GState.userData.openid; //带上open_id 生成订单
              this.generateOrder(data);

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //拉起支付
  wxPay(){
    let that=this;
    if(that.data.payInfo){
      wx.requestPayment({
        ...that.data.payInfo,
        success (res) {
          that.setData({
            showO:true,
            showC:"恭喜您，支付成功！"
          })
        },
        fail (res) {
          that.setData({
            showO:true,
            showC:"很抱歉，支付失败！"
          })
        }
      })
    }else{
      wx.navigateBack()
    }

  },
  //生成订单
  generateOrder(d){
        wx.showLoading({
          title: "订单生成中...",
          /** 接口调用结束的回调函数（调用成功、失败都会执行） */
         // complete?: ShowLoadingCompleteCallback
          /** 接口调用失败的回调函数 */
          //fail?: ShowLoadingFailCallback
          /** 是否显示透明蒙层，防止触摸穿透 */
          mask: true
          /** 接口调用成功的回调函数 */
         // success?: ShowLoadingSuccessCallback
        })
        let that=this;
        httpPostWithToken(d.url,d.data).then(res=>{
          wx.hideLoading();
          if(res.xcode===0){
            if(res.data.info.state===2){//订单为2 无需支付
              that.setData( { showO:true,showC:"支付成功！"})
            }
            else if (res.data.info.state===1) {//订单为1 需支付
              that.setData({payInfo:res.data})
              that.wxPay()
            }else {
              that.setData( { showO:true,showC:"订单生成失败，请重试！"})
            }
          }
          else{
            that.setData( { showO:true,showC:"订单生成失败，请重试！"})
          }
        }).catch(e=>{
          console.log(e);
          wx.hideLoading();
          this.setData( { showO:true,showC:"订单生成失败，请重试！"})
        })
  },
  //弹窗控制函数
  tapDialogButton(){
    this.setData( { showO:false})
    wx.navigateBack();
  }
})