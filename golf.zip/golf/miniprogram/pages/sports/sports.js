// pages/sports/sports.js
import {httpPost, sportsUrl} from "../../utils/http";
import GState from "../../utils/GState";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: '',
    token:'',
    showUrl:false,
    match_id:1,//赛事id,
    title:'赛事title'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
        console.log(options);
        if(options.match_id){
          GState.sports={...options};
        }
        this.sportsLogin()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    let path='/pages/sports/sports?a=1';
    if(GState.sports.match_id){
      path=path+'&match_id='+GState.sports.match_id
    }
    if(GState.sports.title){
      path=path+'&title='+GState.sports.title
    }
    let data={
      title: GState.sports.title,        // 默认是小程序的名称(可以写slogan等)
      path: path,        // 默认是当前页面，必须是以‘/’开头的完整路径
      imageUrl: '../../img/logo.png',     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
    }
    return data;
  },

  dealSportsUrl() {
    let webUrlA = sportsUrl;
    if(GState.sports.match_id){
      webUrlA = webUrlA + "&match_id=" + GState.sports.match_id;
    }
    if (GState.userData.token) {
      webUrlA = webUrlA + "&token=" + GState.userData.token;
    }
/*    let timestamp = new Date().getTime();
    webUrlA=webUrlA+'&timestamp='+timestamp
    console.log(webUrlA);*/
    return webUrlA;
  },


  sportsLogin() {
    // 登录
    let that = this;
    if(GState.userData.token){
      let webUrl = that.dealSportsUrl();
      that.setData({url: webUrl,showUrl:true});
    }else{
      wx.login({
        success: res => {
          console.log(res.code);
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          httpPost("/rest/golf_asso/wxLogin", {
            type: "login",	//否	string	默认login 可传phone
            code: res.code,//	是	string	type=login的时候必传
          }).then(r => {
            console.log(r);
            let data = r.data;
            GState.userData = {...data};
            console.log('log');
            let webUrl = that.dealSportsUrl();
            that.setData({url: webUrl,showUrl:true})
          }).catch(e => {
            console.log(e);
            let webUrl = that.dealSportsUrl();
            that.setData({url: webUrl,showUrl:true});
          })
        },
      });
    }

  }



})