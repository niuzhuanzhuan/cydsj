"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GState = {
    userData: {
        session_key: "",
        openid: "",
        phone: "",
        token: "",
    },
    userInfo: {
        nickName: "",
        gender: null,
        language: "",
        city: "",
        province: "",
        country: "",
        avatarUrl: ""
    },
    h5: {
        path: ''
    },
    sports: {
        match_id: '',
        title: ''
    }
};
exports.default = GState;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR1N0YXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiR1N0YXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0EsSUFBTSxNQUFNLEdBQUM7SUFDVCxRQUFRLEVBQUM7UUFDTCxXQUFXLEVBQUUsRUFBRTtRQUNmLE1BQU0sRUFBRSxFQUFFO1FBQ1YsS0FBSyxFQUFFLEVBQUU7UUFDVCxLQUFLLEVBQUUsRUFBRTtLQUNaO0lBQ0QsUUFBUSxFQUFDO1FBQ0wsUUFBUSxFQUFFLEVBQUU7UUFDWixNQUFNLEVBQUUsSUFBSTtRQUNaLFFBQVEsRUFBRSxFQUFFO1FBQ1osSUFBSSxFQUFFLEVBQUU7UUFDUixRQUFRLEVBQUUsRUFBRTtRQUNaLE9BQU8sRUFBRSxFQUFFO1FBQ1gsU0FBUyxFQUFDLEVBQUU7S0FDZjtJQUNELEVBQUUsRUFBQztRQUNDLElBQUksRUFBQyxFQUFFO0tBQ1Y7SUFDRCxNQUFNLEVBQUM7UUFDSCxRQUFRLEVBQUMsRUFBRTtRQUNYLEtBQUssRUFBQyxFQUFFO0tBQ1g7Q0FFSixDQUFBO0FBQ0Qsa0JBQWUsTUFBTSxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNvbnN0IEdTdGF0ZT17XHJcbiAgICB1c2VyRGF0YTp7XHJcbiAgICAgICAgc2Vzc2lvbl9rZXk6IFwiXCIsXHJcbiAgICAgICAgb3BlbmlkOiBcIlwiLFxyXG4gICAgICAgIHBob25lOiBcIlwiLFxyXG4gICAgICAgIHRva2VuOiBcIlwiLFxyXG4gICAgfSxcclxuICAgIHVzZXJJbmZvOntcclxuICAgICAgICBuaWNrTmFtZTogXCJcIiwvL+aYteensFxyXG4gICAgICAgIGdlbmRlcjogbnVsbCwvL+aAp+WIq1xyXG4gICAgICAgIGxhbmd1YWdlOiBcIlwiLC8v6K+t6KiAXHJcbiAgICAgICAgY2l0eTogXCJcIiwvL+WfjuW4glxyXG4gICAgICAgIHByb3ZpbmNlOiBcIlwiLC8v55yB5Lu9XHJcbiAgICAgICAgY291bnRyeTogXCJcIiwvL+WbveexjVxyXG4gICAgICAgIGF2YXRhclVybDpcIlwiLy/lpLTlg49cclxuICAgIH0sXHJcbiAgICBoNTp7XHJcbiAgICAgICAgcGF0aDonJ1xyXG4gICAgfSxcclxuICAgIHNwb3J0czp7XHJcbiAgICAgICAgbWF0Y2hfaWQ6JycsIC8v6LWb5LqLaWRcclxuICAgICAgICB0aXRsZTonJyAvLyDotZvkuot0aXRsZVxyXG4gICAgfVxyXG5cclxufVxyXG5leHBvcnQgZGVmYXVsdCBHU3RhdGUiXX0=