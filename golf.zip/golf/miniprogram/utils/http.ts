import GState from "./GState";

// export const host='https://api.live.yongdongli.net';
// export const publicPath='/golf/asso';
// export const webUrl=host+'/golf/asso/#/?from=miniProgram&match_id=1' //协会url

export const host='https://api.live.sportbd.cn';
export const publicPath='/golf';
export const webUrl=host+'/golf/#/?from=miniProgram&asso_id=1' //协会url

export const sportsUrl=host+'/golf/user/#/?from=miniProgram' //赛事
export interface resData {
    msg:string,
    data:any
}
export const httpPost= (url: string, data: any,)=>{
        return new Promise((resolve:(res:any)=>void, reject) => {
            wx.request({
                url: host+url,
                data: data,
                header: {
                    'content-type': 'application/json', // 默认值
                    'XX-Device-Type': 'web'
                },
                method: 'post',
                success: (res => {
                    if (res.statusCode === 200) {
                        //200: 服务端业务处理正常结束
                        resolve(res.data)
                    } else {
                        reject(res.data)
                    }
                }),
                fail: (res => {
                    reject(res)
                })
            })
        })
    }
export const httpPostWithToken= (url: string, data: any,)=>{
    return new Promise((resolve:(res:any)=>void, reject) => {
        wx.request({
            url: host+url,
            data: data,
            header: {
                'content-type': 'application/json', // 默认值
                'XX-Token':GState.userData.token,
                'XX-Device-Type': 'web',
            },
            method: 'post',
            success: (res => {
                if (res.statusCode === 200) {
                    //200: 服务端业务处理正常结束
                    resolve(res.data)
                } else {
                    reject(res.data)
                }
            }),
            fail: (res => {
                reject(res)
            })
        })
    })
}
