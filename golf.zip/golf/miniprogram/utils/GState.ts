
const GState={
    userData:{
        session_key: "",
        openid: "",
        phone: "",
        token: "",
    },
    userInfo:{
        nickName: "",//昵称
        gender: null,//性别
        language: "",//语言
        city: "",//城市
        province: "",//省份
        country: "",//国籍
        avatarUrl:""//头像
    },
    h5:{
        path:''
    },
    sports:{
        match_id:'', //赛事id
        title:'' // 赛事title
    }

}
export default GState