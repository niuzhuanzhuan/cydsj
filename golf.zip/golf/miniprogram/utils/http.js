"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GState_1 = require("./GState");
// exports.host = 'https://api.live.yongdongli.net';
// exports.publicPath = '/golf/asso';
// exports.webUrl = exports.host + '/golf/asso/#/?from=miniProgram&match_id=1';

exports.host = 'https://api.live.sportbd.cn';
exports.publicPath = '/golf';
exports.webUrl = exports.host + '/golf/#/?from=miniProgram&asso_id=1';

exports.sportsUrl = exports.host + '/golf/user/#/?from=miniProgram';
exports.httpPost = function (url, data) {
    return new Promise(function (resolve, reject) {
        wx.request({
            url: exports.host + url,
            data: data,
            header: {
                'content-type': 'application/json',
                'XX-Device-Type': 'web'
            },
            method: 'post',
            success: (function (res) {
                if (res.statusCode === 200) {
                    resolve(res.data);
                }
                else {
                    reject(res.data);
                }
            }),
            fail: (function (res) {
                reject(res);
            })
        });
    });
};
exports.httpPostWithToken = function (url, data) {
    return new Promise(function (resolve, reject) {
        wx.request({
            url: exports.host + url,
            data: data,
            header: {
                'content-type': 'application/json',
                'XX-Token': GState_1.default.userData.token,
                'XX-Device-Type': 'web',
            },
            method: 'post',
            success: (function (res) {
                if (res.statusCode === 200) {
                    resolve(res.data);
                }
                else {
                    reject(res.data);
                }
            }),
            fail: (function (res) {
                reject(res);
            })
        });
    });
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHR0cC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImh0dHAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxtQ0FBOEI7QUFFakIsUUFBQSxJQUFJLEdBQUMsaUNBQWlDLENBQUM7QUFDdkMsUUFBQSxVQUFVLEdBQUMsWUFBWSxDQUFDO0FBQ3hCLFFBQUEsTUFBTSxHQUFDLFlBQUksR0FBQywyQ0FBMkMsQ0FBQTtBQUN2RCxRQUFBLFNBQVMsR0FBQyxZQUFJLEdBQUMsZ0NBQWdDLENBQUE7QUFLL0MsUUFBQSxRQUFRLEdBQUUsVUFBQyxHQUFXLEVBQUUsSUFBUztJQUN0QyxPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBdUIsRUFBRSxNQUFNO1FBQy9DLEVBQUUsQ0FBQyxPQUFPLENBQUM7WUFDUCxHQUFHLEVBQUUsWUFBSSxHQUFDLEdBQUc7WUFDYixJQUFJLEVBQUUsSUFBSTtZQUNWLE1BQU0sRUFBRTtnQkFDSixjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyxnQkFBZ0IsRUFBRSxLQUFLO2FBQzFCO1lBQ0QsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPLEVBQUUsQ0FBQyxVQUFBLEdBQUc7Z0JBQ1QsSUFBSSxHQUFHLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtvQkFFeEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtpQkFDcEI7cUJBQU07b0JBQ0gsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtpQkFDbkI7WUFDTCxDQUFDLENBQUM7WUFDRixJQUFJLEVBQUUsQ0FBQyxVQUFBLEdBQUc7Z0JBQ04sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBQ2YsQ0FBQyxDQUFDO1NBQ0wsQ0FBQyxDQUFBO0lBQ04sQ0FBQyxDQUFDLENBQUE7QUFDTixDQUFDLENBQUE7QUFDUSxRQUFBLGlCQUFpQixHQUFFLFVBQUMsR0FBVyxFQUFFLElBQVM7SUFDbkQsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLE9BQXVCLEVBQUUsTUFBTTtRQUMvQyxFQUFFLENBQUMsT0FBTyxDQUFDO1lBQ1AsR0FBRyxFQUFFLFlBQUksR0FBQyxHQUFHO1lBQ2IsSUFBSSxFQUFFLElBQUk7WUFDVixNQUFNLEVBQUU7Z0JBQ0osY0FBYyxFQUFFLGtCQUFrQjtnQkFDbEMsVUFBVSxFQUFDLGdCQUFNLENBQUMsUUFBUSxDQUFDLEtBQUs7Z0JBQ2hDLGdCQUFnQixFQUFFLEtBQUs7YUFDMUI7WUFDRCxNQUFNLEVBQUUsTUFBTTtZQUNkLE9BQU8sRUFBRSxDQUFDLFVBQUEsR0FBRztnQkFDVCxJQUFJLEdBQUcsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO29CQUV4QixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO2lCQUNwQjtxQkFBTTtvQkFDSCxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO2lCQUNuQjtZQUNMLENBQUMsQ0FBQztZQUNGLElBQUksRUFBRSxDQUFDLFVBQUEsR0FBRztnQkFDTixNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7WUFDZixDQUFDLENBQUM7U0FDTCxDQUFDLENBQUE7SUFDTixDQUFDLENBQUMsQ0FBQTtBQUNOLENBQUMsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBHU3RhdGUgZnJvbSBcIi4vR1N0YXRlXCI7XHJcblxyXG5leHBvcnQgY29uc3QgaG9zdD0naHR0cHM6Ly9hcGkubGl2ZS55b25nZG9uZ2xpLm5ldCc7XHJcbmV4cG9ydCBjb25zdCBwdWJsaWNQYXRoPScvZ29sZi9hc3NvJztcclxuZXhwb3J0IGNvbnN0IHdlYlVybD1ob3N0KycvZ29sZi9hc3NvLyMvP2Zyb209bWluaVByb2dyYW0mbWF0Y2hfaWQ9MScgLy/ljY/kvJp1cmxcclxuZXhwb3J0IGNvbnN0IHNwb3J0c1VybD1ob3N0KycvZ29sZi91c2VyLyMvP2Zyb209bWluaVByb2dyYW0nIC8v6LWb5LqLXHJcbmV4cG9ydCBpbnRlcmZhY2UgcmVzRGF0YSB7XHJcbiAgICBtc2c6c3RyaW5nLFxyXG4gICAgZGF0YTphbnlcclxufVxyXG5leHBvcnQgY29uc3QgaHR0cFBvc3Q9ICh1cmw6IHN0cmluZywgZGF0YTogYW55LCk9PntcclxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmU6KHJlczphbnkpPT52b2lkLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgd3gucmVxdWVzdCh7XHJcbiAgICAgICAgICAgICAgICB1cmw6IGhvc3QrdXJsLFxyXG4gICAgICAgICAgICAgICAgZGF0YTogZGF0YSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcjoge1xyXG4gICAgICAgICAgICAgICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIC8vIOm7mOiupOWAvFxyXG4gICAgICAgICAgICAgICAgICAgICdYWC1EZXZpY2UtVHlwZSc6ICd3ZWInXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAncG9zdCcsXHJcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiAocmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzLnN0YXR1c0NvZGUgPT09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLzIwMDog5pyN5Yqh56uv5Lia5Yqh5aSE55CG5q2j5bi457uT5p2fXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzLmRhdGEpXHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KHJlcy5kYXRhKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgZmFpbDogKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KHJlcylcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuZXhwb3J0IGNvbnN0IGh0dHBQb3N0V2l0aFRva2VuPSAodXJsOiBzdHJpbmcsIGRhdGE6IGFueSwpPT57XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmU6KHJlczphbnkpPT52b2lkLCByZWplY3QpID0+IHtcclxuICAgICAgICB3eC5yZXF1ZXN0KHtcclxuICAgICAgICAgICAgdXJsOiBob3N0K3VybCxcclxuICAgICAgICAgICAgZGF0YTogZGF0YSxcclxuICAgICAgICAgICAgaGVhZGVyOiB7XHJcbiAgICAgICAgICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCAvLyDpu5jorqTlgLxcclxuICAgICAgICAgICAgICAgICdYWC1Ub2tlbic6R1N0YXRlLnVzZXJEYXRhLnRva2VuLFxyXG4gICAgICAgICAgICAgICAgJ1hYLURldmljZS1UeXBlJzogJ3dlYicsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ3Bvc3QnLFxyXG4gICAgICAgICAgICBzdWNjZXNzOiAocmVzID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChyZXMuc3RhdHVzQ29kZSA9PT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8yMDA6IOacjeWKoeerr+S4muWKoeWkhOeQhuato+W4uOe7k+adn1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzLmRhdGEpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChyZXMuZGF0YSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIGZhaWw6IChyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KHJlcylcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9KVxyXG4gICAgfSlcclxufVxyXG4iXX0=