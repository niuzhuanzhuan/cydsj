<template>
	<div class="miananv">
		<div class="mianlist" v-if="datalist.length > 0">
			<div class="kueall">
				<div class="navlift">组别</div>
				<div class="navs">出发洞</div>
				<div class="qiunav">球队</div>
				<div class="rigths">分组人员详情</div>
			</div>
			<div class="initmian" v-for="(item, index) in datalist" :key="index">
				<div class="initleft">
					<div class="lihert">{{ item.group_name }}</div>
					<div>{{ item.datetime }}</div>
				</div>
				<div class="initnavs">{{ item.start_hole }}</div>
				<div class="qiumian">
					<div class="lians" v-for="(jitem, jindex) in item.teams" :key="jindex">
						<div class="inmatile">
							<van-image round width="38px" fit="cover" height="38px" :src="jitem.avatar" />
							<div class="inlims">{{ jitem.name }}</div>
						</div>
					</div>
				</div>
				<div class="initriogth" v-if="item.teams">
					<div class="mianinit" v-for="(jtem, mindex) in item.teams" :key="mindex">
						<div class="initall" v-for="(jtems, indexs) in jtem.members" :key="indexs">
							<div class="mianrigth">
								<div><van-image round fit="cover" width="38px" height="38px" :src="jtems.avatar" /></div>
								<div>{{jtems.name}}</div>
							</div>
						</div>
					</div>
				</div>
				<div v-else class="initriogth" style="display: flex;align-items: center;">暂无对阵信息</div>
			</div>
		</div>
		<van-empty v-else description="暂无该场信息,请点击上方更换组别或场次查看数据" />
	</div>
</template>

<script>
import api from '@/utils/api';
export default {
	data() {
		return {
			datalist: []
		};
	},
	created() {},
	watch: {},
	methods: {}
};
</script>
<style scoped></style>
<style scoped lang="scss">
$cocrs: #fff;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #fff;
$coba78: #78ac06;
$fs12: 12px;
.miananv {
	width: 100%;
	padding: 3% 0 0 0;
	.mianlist {
		width: 100%;
		background: #d1d1d1;
		color: $cocrs;
		font-size: $fs12;
		.kueall {
			display: flex;
			.navlift {
				display: flex;
				align-items: center;
				justify-content: center;
				padding: 4% 0;
				width: 20%;
				text-align: center;
				background: $coba78;
			}
			.navs {
				display: flex;
				align-items: center;
				justify-content: center;
				margin-left: 1px;
				width: 18%;
				text-align: center;
				background: $coba78;
			}
			.qiunav {
				display: flex;
				align-items: center;
				justify-content: center;
				margin-left: 1px;
				width: 26%;
				text-align: center;
				background: $coba78;
			}
			.rigths {
				display: flex;
				align-items: center;
				justify-content: center;
				margin-left: 1px;
				width: 40%;
				text-align: center;
				background: $coba78;
			}
		}
		.initmian {
			margin-top: 1px;
			display: flex;
			border-bottom: 1px solid #d1d1d1;
			.initleft {
				width: 20%;
				height: inherit;
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				color: $cofs;
				background: $cobadi;
			}
			.initnavs {
				margin-left: 1px;
				width: 18%;
				color: $cofs;
				background: $cobadi;
				height: inherit;
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
			}
			.qiumian {
				margin-left: 1px;
				width: 26%;
				color: $cofs;
				background: $cobadi;
				height: inherit;
				display: flex;
				flex-direction: column;
				.lians {
					width: 100%;
					height: 50%;
					display: flex;
					justify-content: center;
					align-items: center;
					.inmatile {
						width: 100%;
						display: flex;
						flex-direction: column;
						align-items: center;
						.inlims {
							width: 100%;
							padding: 5% 0;
							display: flex;
							justify-content: center;
						}
					}
					&:nth-child(2) {
						border-top: 1px solid #d1d1d1;
					}
				}
			}
			.initriogth {
				margin-left: 1px;
				width: 40%;
				color: $cofs;
				background: $cobadi;
				.mianinit {
					&:nth-child(2) {
						border-top: 1px solid #d1d1d1;
					}
					.initall {
						width: 96%;
						height: 45px;
						padding: 7px 2%;
						display: flex;
						justify-content: space-between;
						.mianrigth {
							width: 100%;
							height: 100%;
							display: flex;
							font-size: 0.875rem;
							align-items: center;
							justify-content: center;
							div {
								width: 40%;
								display: flex;
								justify-content: flex-end;
								&:nth-child(2) {
									display: flex;
									justify-content: flex-start;
									width: 55%;
									padding-left: 5%;
								}
							}
						}
					}
				}
			}
		}
	}
}
</style>
