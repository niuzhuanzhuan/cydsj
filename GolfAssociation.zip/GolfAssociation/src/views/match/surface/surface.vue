<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar title="比赛分组表" left-arrow @click-left="$router.back(-1)" />
			<van-tabs type="card" v-if="navlist.length > 0" @click="onClick" v-model="cardNames" title-active-color="#ffffff" title-inactive-color="#78ac09" color="#78ac09">
				<van-tab v-for="(item, index) in navlist" :key="index" :title="item.name"></van-tab>
			</van-tabs>

			<van-tabs v-if="navinit.length > 0" v-model="acstives" @click="inits" :ellipsis="false" animated>
				<van-tab v-for="(item, index) in navinit" :key="index" :name="item.key" :title="item.name"></van-tab>
			</van-tabs>
			<div class="miananv">
				<personal ref="personal" v-if="active" v-show="fromdata == 1 || fromdata == 2" />
				<team ref="teams" v-if="active" v-show="fromdata == 3 || fromdata == 4" />
				<van-empty v-else description="暂无该场信息" />
			</div>
			<div style="height: 30px;"></div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import team from './team.vue';
import personal from './personal.vue';
export default {
	data() {
		return {
			active: true,
			acstives: '',
			navlist: [],
			navinit: [],
			namesinit: '',
			cardNames: '',
			titlelist: [],
			fromdata: '',
			initmach: true
		};
	},
	activated() {
		this.gettitle();
	},
	watch: {
		namesinit(newval, val) {
			if (newval != val) {
				if(newval=="")return false
				this.navinit.forEach(item => {
					if (item.key == newval) {
						this.getdata(item);
					}
				});
			}
		},
		match_id(newval, val) {
			if (newval != val) {
				this.cardNames = '';
				this.acstives = '';
			}
		}
	},
	components: {
		team,
		personal
	},
	computed: {
		match_id() {
			return this.$store.state.match_id;
		}
	},
	methods: {
		onClick(name, title) {
			this.namesinit="";
			this.navlist.forEach(item => {
				if (item.name == title) {
					this.navinit = item.list;
					if (this.navinit.length > 0) {
						this.acstives = this.navinit[0].name;
						this.namesinit = this.navinit[0].key;
						this.active = true;
					} else {
						this.active = false;
					}
				}
			});
		},
		inits(name) {
			this.namesinit = name;
		},
		async gettitle() {
			const datalist = await this.$api.match_lattice_header({ match_id: this.$store.state.match_id });
			datalist && (this.navlist = datalist);
			if (this.cardNames == '') {
				if (this.acstives == '') {
					if (this.navlist[0].list.length > 0) {
						this.navinit = this.navlist[0].list;
						this.acstives = this.navinit[0].name;
						this.getdata(this.navinit[0]);
						this.active = true;
					} else {
						this.active = false;
					}
				} else {
					this.navinit.forEach(item => {
						if (item.key == this.acstives) {
							this.getdata(item);
						}
					});
				}
			} else {
				this.navinit.length > 0 &&
					this.navinit.forEach(item => {
						if (item.key == this.acstives) {
							this.active = true;
							this.getdata(item);
						}
					});
			}
		},
		getdata(fromdata) {
			api.match_queue({
				match_id: this.$store.state.match_id,
				key: fromdata.key
			}).then(res => {
				if (res) {
					this.$nextTick(() => {
						this.fromdata = res.type;
						if (res.type == 1 || res.type == 2) {
							this.$refs.personal.datalist = res.list;
						} else {
							this.$refs.teams.datalist = res.list;
						}
					});
				}
			});
		}
	}
};
</script>
<style>
.van-tabs__line {
	background-color: #78ac06;
}
.van-tab--active {
	color: #78ac06;
}
.van-tabs--card > .van-tabs__wrap {
	height: 40px !important;
}
.van-tabs__nav--card {
	margin: 0;
	height: 40px !important;
}
</style>
<style scoped lang="scss">
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;
.tab {
	height: 40px;
	line-height: 40px;
	width: 100%;
	display: flex;
	flex-direction: row;
}

.tab1 {
	flex: 1;
	text-align: center;
	border: solid 1px #79aa0a;
	color: #79aa0a;
}

.tab-active {
	color: white;
	background: #79aa0a;
}

@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
