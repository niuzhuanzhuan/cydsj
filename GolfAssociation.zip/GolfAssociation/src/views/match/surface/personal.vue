<template>
	<div class="miananv">
		<div class="mianlist" v-if="datalist.length > 0">
			<div class="kueall">
				<div class="navlift">组别</div>
				<div class="navs">出发洞</div>
				<div class="rigths">分组人员详情</div>
			</div>
			<div class="initmian" v-for="(item, index) in datalist" :key="index">
				<div class="initleft">
					<div class="lihert">{{ item.group_name }}</div>
					<div>{{ item.datetime }}</div>
				</div>
				<div class="initnavs">{{ item.start_hole }}</div>
				<div class="initriogth" v-if="item.enrolls">
					<div class="initall" v-for="(item, index) in item.enrolls" :key="index">
						<div class="inital_lleeft">
							<van-image round width="34px" height="34px" fit="contain" :src="item.avatar ? item.avatar : imgque" />
							<div class="initname">{{ item.name }}</div>
						</div>
					</div>
				</div>
				<div v-else class="initriogth" style="display: flex;align-items: center;">暂无对阵信息</div>
			</div>
		</div>
		<van-empty v-else description="暂无该场信息,请点击上方更换组别或场次查看数据" />
	</div>
</template>

<script>
import api from '@/utils/api';
export default {
	data() {
		return {
			datalist: []
		};
	},
	created() {},
	watch: {},
	methods: {}
};
</script>
<style scoped></style>
<style scoped lang="scss">
$cocrs: #ffffff;
$cofs: #333333;
$coba: #ffffff;
$cobadi: #ffffff;
$coba78: #78AC06;
$fs12: 12px;
.lihert{
	margin-bottom: 10px;
}
.miananv {
	width: 100%;
	padding: 2% 0;
	.mianlist {
		width: 100%;
		background: #D1D1D1;
		color: $cocrs;
		font-size: $fs12;
		border-bottom: 1px solid #D1D1D1;
		.kueall {
			display: flex;
			.navlift {
				display: flex;
				align-items: center;
				justify-content: center;
				padding: 4% 0;
				width: 30%;
				text-align: center;
				background: $coba78;
			}
			.navs {
				display: flex;
				align-items: center;
				justify-content: center;
				margin-left: 1px;
				width: 20%;
				text-align: center;
				background: $coba78;
			}
			.rigths {
				display: flex;
				align-items: center;
				justify-content: center;
				margin-left: 1px;
				width: 50%;
				text-align: center;
				background: $coba78;
			}
		}
		.initmian {
			margin-top: 1px;
			display: flex;
			.initleft {
				width: 30%;
				height: inherit;
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				color: $cofs;
				background: $cobadi;
			}
			.initnavs {
				margin-left: 1px;
				width: 20%;
				color: $cofs;
				background: $cobadi;
				height: inherit;
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
			}
			.initriogth {
				margin-left: 1px;
				width: 50%;
				color: $cofs;
				background: $cobadi;
				.initall {
					width: 96%;
					height: 34px;
					padding: 7px 2%;
					display: flex;
					justify-content: center;
					&:nth-child(odd) {
						background: $cobadi;
					}
					&:nth-child(even) {
						background: $cobadi;
					}
					.inital_lleeft {
						width: 50%;
						height: 100%;
						display: flex;
						img {
							width: 40px;
							height: 36px;
							border-radius: 8px;
							background: $cofs;
						}
						.initname {
							margin-left: 4px;
							height: inherit;
							display: flex;
							align-items: center;
						}
					}
					.inital_lirgth {
						width: 60%;
						height: 100%;
						display: flex;
						justify-content: space-around;
						align-items: center;
						.fromluis {
							color: $cocrs;
						}
					}
				}
			}
		}
	}
}
</style>
