<template>
	<div class="page">
		<div class="indexall" ref="pages">
			<div class="mianimg">
				<van-nav-bar title="赛事信息" left-arrow @click-left="$router.back(-1)" />
				<van-image width="100%" fit="cover" height="200px" :src="fromsmian.cover" />
				<div class="fonstmian">{{ fromsmian.title }}</div>
				<div class="inittops"><div @click="$router.push('/match/details')">赛事详情</div></div>
				<div class="mianall">
					<div class="lingnav">
						<div class="lino">
							<div class="itemss" @click="options(1)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/cj.png" /></div>
								<div class="topsb">成绩展示</div>
							</div>
							<div class="itemss" @click="options(2)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/zb.png" /></div>
								<div class="topsb">图片视频</div>
							</div>
							<div class="itemss" @click="options(3)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/phb.png" /></div>
								<div class="topsb">排行榜</div>
							</div>
							<div class="itemss" @click="options(4)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/qd.png" /></div>
								<div class="topsb">球道介绍</div>
							</div>
						</div>
						<div class="lino">
							<div class="itemss" @click="options(5)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/fenzu.png" /></div>
								<div class="topsb">比赛分组表</div>
							</div>
							<div class="itemss" @click="options(6)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/geren.png" /></div>
								<div class="topsb">个人列表</div>
							</div>
							<div class="itemss" @click="options(7)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/qiud.png" /></div>
								<div class="topsb">球队列表</div>
							</div>
							<div class="itemss" @click="options(8)">
								<div class="topsk"><img src="@/assets/imgamo/hemo/my.png" /></div>
								<div class="topsb">我的</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="mianinit">
				<div class="tilsitmian">{{ fromsmian.title }}</div>
				<div class="lisnmian">
					<img src="@/assets/imgamo/hemo/time.png" />
					时间：{{ fromsmian.date }}
				</div>
				<div class="lisnmian" @click="address">
					<img src="@/assets/imgamo/hemo/di.png" />
					地点：{{ fromsmian.address }}
				</div>
			</div>

			<div class="miancimglis">
				<div class="tiols">
					<div class="tiltea">热门图片推荐</div>
					<div class="bonst" @click="$router.push('/match/live')">查看更多</div>
				</div>
				<div class="linaimg" v-for="(item, index) in fromsmian.images" :key="index">
					<div class="litops" @click="imgkey(item)">
						<div class="imnlist"><van-image fit="cover" width="100%" height="186" :src="item.src" /></div>
						<div class="lisnt">
							<div class="lisnmain">
								<van-icon name="eye-o" />
								{{ item.visit }}
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="miangong">
				<div class="tiols">
					<div class="tiltea">最新公告</div>
					<div class="bonst" @click="$router.push('/match/notice')">查看更多</div>
				</div>
				<div class="linsw" v-for="(item, index) in fromsmian.notice" :key="index" @click="notice_details(item)">
					<div class="linls" :style="{ background: item.color }">{{ item.type_text }}</div>
					<div class="lisnmlis">
						<div>{{ item.title }}</div>
					</div>
					<div class="tisnlie">{{ item.create_time }}</div>
				</div>
			</div>
			<div style="width: 100%;height: 20px;"></div>
		</div>
	</div>
</template>

<script>
import bus from '@/components/bus.js';
import api from '@/utils/api';
import share from '@/components/share.js';
import { mapActions } from 'vuex';
import wx from 'weixin-js-sdk';
export default {
	data() {
		return {
			fromsmian: {
				notice: [],
				images: []
			}
		};
	},
	activated() {
		this.mc_id();
		document.body.scrollTop = document.documentElement.scrollTop = 0
		if (this.$route.query.from) {
			sessionStorage['WeChat'] = 1; //代表微信状态
		} else {
			sessionStorage['WeChat'] = 0; //代表h5状态
		}
	},
	methods: {
		...mapActions(['displayimgs', 'displayimgsindex']),
		async mc_id() {
			const datalist = await this.$api.match_index({ match_id: this.$store.state.match_id });
			datalist && (this.fromsmian = datalist);
			// console.log(this.fromsmian);
		},
		imgkey(data) {
			let arrlist = [];
			this.fromsmian.images.forEach(item => {
				arrlist.push(item.src);
			});
			arrlist.forEach((item, index) => {
				if (item === data.src) {
					this.displayimgsindex(index);
				}
			});
			this.displayimgs(arrlist);
			this.$router.push('/match/displayimg');
			api.imghits({ id: data.id });
		},
		address() {
			this.fromsmian.location && this.$router.push('/match/address');
		},
		options(data) {
			switch (data) {
				case 1:
					this.$router.push('/match/achievement');
					break;
				case 2:
					this.$router.push('/match/live');
					break;
				case 3:
					this.$router.push('/match/Ranking');
					break;
				case 4:
					this.$router.push('/match/Fairway');
					break;
				case 5:
					this.$router.push('/match/surface');
					break;
				case 6:
					this.$router.push('/match/personal');
					break;
				case 7:
					this.$router.push('/match/team');
					break;
				case 8:
					this.$router.push('/match/my');
					break;
			}
		},
		notice_details(data) {
			data.notice_id &&
				this.$router.push({
					path: '/match/notice_details',
					query: {
						id: data.notice_id
					}
				});
		}
	}
};
</script>
<style lang="scss" scoped>
.miancimglis {
	margin-top: 10px;
	width: 100%;
	background: #ffffff;
	padding: 5% 0;
	height: auto;
	.linaimg {
		margin-top: 10px;
		width: 90%;
		height: 224px;
		padding: 0 5%;
		.litops {
			width: 100%;
			height: 100%;
			border-radius: 0 0 10px 10px;
			box-shadow: 0px 4px 5px 0px rgba(233, 233, 233, 0.6);
			.imnlist {
				border-radius: 10px 10px 0 0;
				overflow: hidden;
			}
			.lisnt {
				width: 100%;
				height: 38px;
				display: flex;
				align-items: center;
				justify-content: flex-end;
				.lisnmain {
					height: 38px;
					display: flex;
					align-items: center;
					margin-right: 34px;
					color: #999999;
					font-size: 12px;
					i {
						font-size: 16px;
						margin-right: 5px;
					}
				}
			}
		}
	}
}
.tiols {
	width: 90%;
	height: 30%;
	padding: 0 5%;
	display: flex;
	align-items: center;
	justify-content: space-between;
	.tiltea {
		font-weight: bold;
		font-size: 15px;
		color: #333333;
	}
}
.bonst {
	height: 20px;
	border: 1px solid #999999;
	padding: 5px 15px;
	font-size: 12px;
	display: flex;
	align-items: center;
	color: #999999;
	border-radius: 20px;
	cursor: pointer;
}
.miangong {
	margin-top: 10px;
	height: auto;
	width: 100%;
	padding: 10px 0;
	background: #ffffff;
	.linsw {
		width: 90%;
		height: 48px;
		border-bottom: 1px solid #f7f7f7;
		display: flex;
		padding: 0 5%;
		align-items: center;
		justify-content: space-between;
		.linls {
			display: flex;
			align-items: center;
			height: 60%;
			font-size: 12px;
			border-radius: 8px;
			color: #ffffff;
			width: 20%;
			justify-content: center;
		}
		.lisnmlis {
			width: 55%;
			display: flex;
			align-items: center;
			font-size: 13px;
			div {
				width: 100%;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
			}
		}
		.tisnlie {
			width: 20%;
			height: 100%;
			display: flex;
			align-items: center;
			color: #999999;
			font-size: 11px;
		}
	}
}
.mianinit {
	margin-top: 120px;
	width: 100%;
	height: 130px;
	background: #ffffff;
	.tilsitmian {
		overflow: hidden;
		width: 90%;
		height: 50%;
		color: #333333;
		font-size: 0.875rem;
		display: flex;
		padding: 0 5%;
		align-items: center;
	}
	.lisnmian {
		width: 90%;
		height: 22%;
		display: flex;
		padding: 0 5%;
		color: #999999;
		font-size: 13px;
		align-items: center;
		img {
			margin-right: 10px;
		}
	}
}
.mianimg {
	width: 100%;
	position: relative;
	.mianall {
		width: 90%;
		height: 150px;
		padding: 0 5%;
		position: absolute;
		top: 70%;
		.lingnav {
			width: 96%;
			padding: 5% 2% 4% 2%;
			height: 91%;
			background: #ffffff;
			border-radius: 10px;
			color: #666666;
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			.lino {
				width: 100%;
				height: 45%;
				display: flex;
				justify-content: space-between;
				.itemss {
					width: 25%;
					height: 100%;
					user-select: none;
					cursor: pointer;
					&:active {
						background: #f5f5f5;
					}
					.topsk {
						width: 100%;
						display: flex;
						justify-content: center;
						align-items: center;
						height: 70%;
						img {
							width: 28px;
							height: 25px;
						}
					}
					.topsb {
						width: 100%;
						height: 30%;
						display: flex;
						justify-content: center;
						align-items: center;
						font-size: 13px;
					}
				}
			}
		}
	}
	.fonstmian {
		position: absolute;
		top: 20%;
		width: 90%;
		color: #ffffff;
		font-weight: 500;
		padding: 0 5%;
		font-size: 1rem;
	}
	.inittops {
		position: absolute;
		width: 100%;
		height: 100%;
		top: 0;
		display: flex;
		justify-content: flex-end;
		align-items: center;
		color: #ffffff;
		font-size: 0.875rem;
		div {
			user-select: none;
			padding: 8px 20px 8px 30px;
			background: #ff5932;
			border-radius: 20px 0 0 20px;
			cursor: pointer;
			&:active {
				background: #fc4e4e;
			}
		}
	}
}
.page {
	display: flex;
	flex-direction: row;
	justify-content: center;
}
@media screen and (max-width: 768px) {
	.indexall {
		width: 100vw;
		// height: 100vh;
		background: #f6f6f6;
	}
}

@media screen and (min-width: 768px) {
	.indexall {
		width: 768px;
		// height: 100vh;
		background: #f6f6f6;
		border-radius: 10px;
		.mianimg {
			height: 250px;
		}
		.mianinit {
			margin-top: 190px;
		}
		.fonstmian {
			font-size: 30px;
		}
		.mianall {
			height: 200px;
		}
		.topsb {
			font-size: 1rem;
		}
		.inittops {
			font-size: 1rem;
		}
		.topsk {
			width: 100%;
			display: flex;
			justify-content: center;
			height: 80%;
			img {
				width: 56px !important;
				height: 50px !important;
			}
		}
	}
}
</style>
