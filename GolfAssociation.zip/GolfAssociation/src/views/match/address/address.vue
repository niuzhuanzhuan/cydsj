<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar title="赛事地点" left-arrow @click-left="$router.go(-1)" />
			<div id="mapkeys"></div>
		</div>
	</div>
</template>

<script>
import Vue from 'vue';
import VueAMap from 'vue-amap';
Vue.use(VueAMap);
VueAMap.initAMapApiLoader({
	key: 'ab5a6a5b5dd62730ed7e9bb0c84b3599',
	// 插件集合 （插件按需引入）
	plugin: ['AMap.Geocoder', 'AMap.PlaceSearch', 'AMap.container']
});
export default {
	data() {
		return{
			mapkey:{}
		}
	},
	methods: {
		getinit() {
			let that = this;
			let Maps = new AMap.Map('mapkeys', {
				zoom: this.zoom //初始化地图层级
			});

			that.mapkey = Maps;
			that.markers = new AMap.Marker({
				position: []
			});
			that.mapkey.on('click', e => {
				that.mapkey.remove(that.markers);
				that.markers = new AMap.Marker({
					position: [e.lnglat.lng, e.lnglat.lat],
					offset: new AMap.Pixel(-10, -20)
				});
				that.setclick([e.lnglat.lng, e.lnglat.lat]);
				that.mapkey.add([that.markers]);
			});
		}
	},
	mounted() {
		this.$nextTick(()=>{
			this.getinit();
		})
	}
};
</script>

<style scoped lang="scss">
#mapkeys {
	width: 100%;
	height: 400px;
}
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
