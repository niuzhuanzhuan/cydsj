<template>
	<!-- 公告详情页开始 -->
	<div>
		<van-nav-bar left-text="返回" left-arrow @click-left="$router.back(-1)" />
		<div class="notice_details">
			<div class="notice_details_title">{{ notice_info.title }}</div>
			<div class="notice_details_info" v-html="notice_info.content"></div>
		</div>
	</div>
</template>
<script>
import api from '@/utils/api';
import bus from '@/components/bus.js';
export default {
	data() {
		return {
			notice_info: {}, //公告详情数据
		};
	},
	activated() {
		if (this.$route.query) {
			this.getData(this.$route.query.id);
		} else {
			this.$toast.fail('非法操作');
			this.$router.go(-1);
		}
	},
	created() {},
	methods: {
		//后去公告详情数据
		getData(data) {
			api.match_notice_info({
				notice_id: data,
				match_id: this.$store.state.match_id
			}).then(res => {
				res&&(this.notice_info = res.notice);
			});
		}
	}
};
</script>
<style>
	.notice_details_info {
		width: 100%;
	}
	.notice_details_info >p table {
		width: 100%;
		overflow: auto;
	}
	.notice_details_info >p video {
		width: 100%;
	}
	.notice_details_info >p img {
		width: 100%;
	}
	
	.notice_details_info >>> p {
		padding: 0 !important;
	}
</style>
<style lang="scss" scoped>
.notice_details {
	//头部标题
	width: 94%;
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	padding: 0 3%;
	.notice_details_title {
		padding: 15px 0 0 0;
		font-size: 21px;
		color: #1c2127;
		font-size: 400;
	}
	//文本内容
	.notice_details_info {
		padding: 15px 0;
		font-size: 14px;
		color: #1d2228;
	}
	//图片
	.notice_details_img {
		width: 100%;
		background-color: aquamarine;
	}
}
</style>
