<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar left-text="我的信息" left-arrow @click-left="$router.back(-1)" />
			<madatas />
		</div>
	</div>
</template>

<script>
import madatas from '../components/mydata/mydata.vue';
export default {
	components: {
		madatas
	}
};
</script>

<style scoped lang="scss">
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
