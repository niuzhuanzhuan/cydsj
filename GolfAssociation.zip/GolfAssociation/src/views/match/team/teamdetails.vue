<template>
	<div class="miansall">
		<div class="answer">
			<div class="lisfromdata">
				<van-nav-bar title="球队信息" left-arrow @click-left="$router.back(-1)" />
				<div class="mytitle">
					<div class="titlekey">
						<van-image round width="30px" height="30px" :src="team.avatar" />
						<div class="tililis">{{ team.name }}</div>
					</div>
				</div>
				<div class="contns">
					<div class="topcontns">
						<div class="mianleft dja">序号</div>
						<div class="miaconas dja">球员头像</div>
						<div class="mianright dja">球员</div>
					</div>
					<div class="topcontnsling" v-for="(item, index) in team_member" :key="index">
						<div class="mianleft dja">{{ (index += 1) }}</div>
						<div class="miaconas dja"><van-image round width="32px" height="32px" :src="item.avatar" /></div>
						<div class="mianright dja">{{ item.name }}</div>
					</div>
				</div>
				<div style="height: 20px;"></div>
				<!-- <van-empty  description="暂无球队信息" /> -->
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
export default {
	data() {
		return {
			team: {},
			team_member: []
		};
	},
	activated() {
		if (this.$route.query.id) {
			this.getdata(this.$route.query.id);
		} else {
			this.$toast('非法操作');
		}
	},
	created() {},
	watch: {},
	methods: {
		getdata(data) {
			api.match_team_info({
				match_id: this.$store.state.match_id,
				team_id: data
			}).then(res => {
				res&&(this.team = res.team,this.team_member = res.team_member)
			});
		}
	}
};
</script>
<style scoped></style>
<style scoped lang="scss">
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;
.dja {
	display: flex;
	justify-content: center;
	align-items: center;
}
.lisfromdata {
	width: 100%;
	height: 100vh;
	background: #f5f5f5;
	.contns {
		width: 100%;
		.topcontns {
			width: 100%;
			display: flex;
			height: 44px;
			justify-content: space-between;
			color: #ffffff;
			background: #c1c1c1;
			.mianleft {
				width: 20%;
				height: 100%;
				background: #a4b0c6;
			}
			.miaconas {
				width: calc(40% - 1px);
				height: 100%;
				background: #a4b0c6;
			}
			.mianright {
				width: calc(40% - 1px);
				height: 100%;
				background: #a4b0c6;
			}
		}
		.topcontnsling {
			width: 100%;
			display: flex;
			height: 49px;
			justify-content: space-between;
			background: #c1c1c1;
			color: #404a4e;
			&:nth-child(even) {
				.miaconas {
					background: #ebeff5 !important;
				}
				.mianright {
					background: #ebeff5 !important;
				}
				.mianleft {
					background: #cbd4e1 !important;
				}
			}
			.mianleft {
				width: 20%;
				height: 100%;
				background: #e9e9e9;
			}
			.miaconas {
				width: calc(40% - 1px);
				height: 100%;
				background: #f7f7f7;
			}
			.mianright {
				width: calc(40% - 1px);
				height: 100%;
				background: #f7f7f7;
			}
		}
	}
	.mytitle {
		width: 100%;
		padding: 15px 0;
		.titlekey {
			width: 100%;
			background: #ffffff;
			height: 50px;
			display: flex;
			justify-content: center;
			align-items: center;
			.tililis {
				margin-left: 20px;
				font-size: 1rem;
				color: #1e2228;
			}
		}
	}
}
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
