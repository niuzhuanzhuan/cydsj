<template>
	<div class="miansall">
		<div class="answer">
			<div class="lisfromdata">
				<van-nav-bar title="球队列表" left-arrow @click-left="$router.back(-1)" />
				<div class="listfrom" v-for="(item, index) in datalist" :key="index" @click="obtain(item.id)">
					<div class="lifeimg"><van-image width="44" height="44" fit="cover" :src="item.avatar" /></div>
					<div class="fonmian">{{ item.name }}</div>
					<div class="lirigth"><van-icon name="arrow" /></div>
				</div>
				<van-empty v-if="datalist.length == 0" description="暂无球队信息" />
			</div>
		</div>
	</div>
</template>

<script>
export default {
	data() {
		return {
			datalist: []
		};
	},
	activated() {
		this.getdata();
	},
	methods: {
		async getdata() {
			const datalist = await this.$api.match_team({ match_id: this.$store.state.match_id });
			datalist && (this.datalist = datalist.list);
		},
		obtain(data) {
			this.$router.push({
				path: '/match/teamdetails',
				query: {
					id: data
				}
			});
		}
	}
};
</script>
<style scoped></style>
<style scoped lang="scss">
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;
.lisfromdata {
	width: 100%;
	height: 100vh;
	background: #ffffff;
	.listfrom {
		width: 90%;
		padding: 17px 5%;
		height: 44px;
		display: flex;
		justify-content: space-around;
		cursor: pointer;
		.lifeimg {
			width: 44px;
			height: 100%;
			border-radius: 4px;
			overflow: hidden;
		}
		.fonmian {
			width: calc(85% - 44px);
			height: 100%;
			line-height: 44px;
			font-size: 0.875rem;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.lirigth {
			width: 4%;
			height: 100%;
			display: flex;
			align-items: center;
			i {
				font-size: 16px;
			}
		}
	}
}
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
