<template>
	<div class="miansall">
		<van-nav-bar title="精彩回放" left-arrow @click-left="$router.back(-1)" />
		<div class="bas"></div>
		<div id="videonum"></div>
		<div class="miantitle">
			<img src="@/assets/imgamo/hemo/dong.gif" />
			<div>{{ match.title }}</div>
		</div>
		<div class="bas"></div>
		<div class="mianli">
			<div class="initkey" v-for="(item, index) in datalist" :key="index">
				<div class="mialikey" @click="hits(item)">
					<div class="lileft">
						<div class="linst">
							<div class="inittlie">{{ item.title }}</div>
						</div>
						<div class="listbonst">
							<div>{{ item.create_time }}</div>
							<div>
								<img src="@/assets/imgamo/hemo/esoo.png" />
								{{ item.hits }}
							</div>
						</div>
					</div>
					<div class="inimgs">
						<van-image width="100" height="70" fit="contain" :src="item.img" />
						<div class="mianlit"><img src="@/assets/asso/home/play.png" /></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import 'xgplayer';
import HlsJsPlayer from 'xgplayer-hls.js';
import Player from 'xgplayer';
export default {
	data() {
		return {
			match: {},
			XGvideo: null,
			datalist:[]
		};
	},
	activated() {
		this.getdata();
		this.getdatamian();
	},
	methods: {
		getdata() {
			const datalist = JSON.parse(sessionStorage['pczhi']);
			this.match = datalist;
			let ketvideo = '';
			const that = this;
			this.$nextTick(() => {
				if (datalist.iszhi) {
					ketvideo = HlsJsPlayer;
				} else {
					ketvideo = Player;
				}
				that.XGvideo = new ketvideo({
					id: 'videonum',
					url: datalist.url,
					poster: datalist.img,
					isLive: true,
					fitVideoSize: 'false', //自适应视频内容宽高
					closeVideoTouch: false, //移动端下默认video触发touchend事件后视频切换播放/暂停状态
					currentTime: false, //设置/返回视频当前播放时间
					fluid: true, //跟随父元素的宽度大小变化
					autoplay: false, //自动播放
					networkState: true, //返回视频的当前网络状态
					readyState: true, //返回视频的就绪状态
					ignores: ['progress', 'error', 'fullscreen'], //关闭组件
					lang: 'zh-cn',
					playsinline: true, // IOS 不调用原生播放器（全屏会调用）
					// cssFullscreen: true, // 样式全屏
					// 'x5-video-player-type': 'h5', //微信同层播放
					hasStart: true
					// "rotate": {
					// 	"clockwise": true,
					//  "innerRotate": true,
					//  "times": 1,
					// }
				});
				this.XGvideo.reload();
				that.XGvideo.on('pause', () => {
					that.$emit('pause', that.XGvideo);
				});
				that.XGvideo.on('play', () => {
					that.$emit('play', that.XGvideo);
				});
				that.XGvideo.on('exitCssFullscreen', () => {
					that.$emit('exitCssFullscreen', that.plays);
				});
				that.XGvideo.start(datalist.url);
			});
		},
		plays() {
			//播放
			this.XGvideo.play();
		},
		async getdatamian() {
			const datalist = await this.$api.video({ match_id: this.$store.state.match_id });
			datalist && (this.datalist = datalist);
		},
		async hits(data) {
			const datalist = await this.$api.video_hits({
				match_id: this.$store.state.match_id,
				id: data.id
			});
			data.hits += 1;
			this.$router.push('/match/pcvideo');
			sessionStorage['pczhi'] = JSON.stringify(data);
		}
	}
};
</script>
<style scoped></style>
<style scoped lang="scss">
.miantitle {
	display: flex;
	color: #333333;
	font-size: 15px;
	padding: 2% 5%;
	width: 90%;
	img {
		height: 20px;
		margin-right: 5px;
	}
}
.mianli {
	width: 90%;
	padding: 0 5%;
	.initkey {
		width: 100%;
		height: 100px;
		border-bottom: 1px solid #f0f0f0;
		display: flex;
		align-items: center;
		cursor: pointer;
		.mialikey {
			width: 100%;
			height: 70px;
			display: flex;
			.lileft {
				width: calc(100% - 100px);
				height: 100%;
				.listbonst {
					width: 100%;
					height: 25px;
					color: #666666;
					display: flex;
					align-items: flex-end;
					font-size: 12px;
					div {
						&:nth-child(2) {
							margin-left: 60px;
							display: flex;
							align-items: center;
							img {
								margin-right: 5px;
							}
						}
					}
				}
				.linst {
					width: 95%;
					padding-right: 5;
					height: 45px;
					display: flex;
					align-items: center;
					.inittlie {
						font-size: 14px;
						color: #333333;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
						overflow: hidden;
					}
				}
			}
			.inimgs {
				width: 100px;
				height: 70px;
				border-radius: 8px;
				overflow: hidden;
				position: relative;
				.mianlit {
					position: absolute;
					width: 100%;
					top: 0;
					height: 100%;
					display: flex;
					justify-content: center;
					align-items: center;
					z-index: 99;
					img {
						width: 18px;
						height: 18px;
					}
				}
			}
		}
	}
}
#videonum {
	padding: 0;
}
.miansall {
	width: 100%;
	height: 100vh;
}
video {
	width: 100%;
}
.bas {
	background: #f5f5f5;
	width: 100%;
	height: 10px;
}
</style>
