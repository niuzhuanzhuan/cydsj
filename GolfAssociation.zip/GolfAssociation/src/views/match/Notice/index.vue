<template>
	<!-- 公告开始 -->
	<div class="miansall">
		<div class="answer">
			<div class="lisfromdata">
				<van-nav-bar left-text="公告列表" left-arrow @click-left="$router.back(-1)" />
				<div v-if="loading" style="width: 100vw; height: 100vh;  display: flex;justify-content: center;align-items: center;z-index: 99999;">
					<van-loading type="spinner" color="#78AC09" />
				</div>
				<div class="listfrom" v-for="(item, index) in notice_list" :key="index" @click="getNoticeDetails(item.notice_id)">
					<div class="mianlist">
						<div class="lifeimg">
							<span class="fonst" :style="{ background: item.color }">{{ item.type_text }}</span>
						</div>
						<div class="fonmian">{{ item.title }}</div>
						<div class="lirigth">{{ item.datetime }}</div>
					</div>
				</div>
				<van-empty v-if="notice_list.length == 0" description="暂无公告信息" />
			</div>
		</div>
	</div>
</template>
<script>
import api from '@/utils/api';
import bus from '@/components/bus.js';
export default {
	data() {
		return {
			notice_list: [], //公告列表数据
			loading: false
		};
	},
	activated() {
		this.getData();
	},
	created() {
		bus.$on('loading', msg => {
			this.loading = msg.msg;
		});
	},
	methods: {
		//获取列表数据
		getData() {
			api.match_notice({
				match_id: this.$store.state.match_id
			}).then(res => {
				res && (this.notice_list = res.list);
			});
		},
		//点击跳转公告详情页面
		getNoticeDetails(id) {
			id &&
				this.$router.push({
					path: 'notice_details',
					query: {
						id: id
					}
				});
		}
	}
};
</script>
<style lang="scss" scoped>
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;
.lisfromdata {
	width: 100%;
	height: 100vh;
	background: #ffffff;
	.listfrom {
		width: 90%;
		padding: 17px 5%;
		height: 44px;
		.mianlist {
			width: 100%;
			height: 100%;
			display: flex;
			justify-content: space-around;
			cursor: pointer;
			border-bottom: 1px solid #f6f6f6;
			.lifeimg {
				width: 15%;
				height: 100%;
				display: flex;
				align-items: flex-start;
				.fonst {
					color: #ffffff;
					padding: 3px 8px;
					font-size: 0.875rem;
				}
			}
			.fonmian {
				width: 55%;
				height: 100%;
				font-size: 0.875rem;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				padding: 3px 0;
			}
			.lirigth {
				width: 28%;
				height: calc(100% - 8px);
				display: flex;
				font-size: $fs12;
				align-items: flex-end;
				color: #d3d3d3;
				padding-bottom: 8px;
			}
		}
	}
}
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
