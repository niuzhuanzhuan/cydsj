<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar title="赛事详情" left-arrow @click-left="$router.back(-1)" />
			<div style="width: 100%;height: 10px;background: #F6F6F6;"></div>
			<van-tabs v-model="active" animated>
				<van-tab v-for="(item, index) in datalist" :key="index" :title="item.title">
					<div class="mianlist">
						<div v-show="active == 0" class="mianfs"><div class="limcont" v-html="fromdata.match.introduce"></div></div>
						<div v-show="active == 1" class="mianfs">
							<div class="mianlisto">
								<div class="huodong">赛事活动日程表</div>
								<div class="titilemian" v-for="(item, index) in fromdata.schedule" :key="index">
									<div class="mianlitop">
										<div class="fslis">{{ item.date }}</div>
										<div class="yuan1"><div class="y8uan"></div></div>
										<div class="lifpis">{{ item.group }}</div>
									</div>
									<div class="mianrigths">{{ item.type }}</div>
								</div>
							</div>
						</div>
						<div v-show="active == 2" class="mianfs">
							<div class="frokis" v-for="(item, index) in fromdata.rule" :key="index">
								<div class="frokis_tops">
									<div class="shuli"></div>
									<div class="fonst_title">{{ item.name }}</div>
								</div>
								<div class="chlins" v-for="(jtem, jindex) in item.list" :key="jindex">
									<div class="mian_title">
										<div class="lisng">{{ jtem.name }}</div>
										<div class="fonslui" v-for="(kety, kindex) in jtem.value" :key="kindex">{{ kety }}</div>
									</div>
								</div>
								<div class="fonst_mian" v-if="item.value" v-html="item.value"></div>
							</div>
						</div>
						<div class="mianfs" v-show="active == 3">
							<div class="mianfsli" v-for="(item, index) in fromdata.notice" :key="index">
								<div class="tilis">{{ item.datetime }}</div>
								<div class="fonslis">
									<span></span>
									<div>{{ item.title }}</div>
								</div>
								<div class="frins">
									<div class="inmian" v-html="item.content"></div>
								</div>
							</div>
							<van-empty v-if="fromdata.notice.length === 0" description="暂无比赛日志,待会再来查看吧" />
						</div>
					</div>
				</van-tab>
			</van-tabs>
		</div>
	</div>
</template>

<script>
export default {
	data() {
		return {
			active: 0,
			datalist: [{ title: '赛事介绍' }, { title: '赛事日程' }, { title: '赛事规则' }, { title: '比赛日志' }],
			fromdata: {
				match: {},
				notice: []
			}
		};
	},
	activated() {
		this.getdata();
	},
	methods: {
		async getdata() {
			const datalist = await this.$api.match_details({ match_id: this.$store.state.match_id });
			datalist && (this.fromdata = datalist);
		}
	}
};
</script>
<style>
.van-tabs__line {
	background-color: #78ac06;
}
.van-tab--active {
	color: #78ac06;
}
.limcont {
	width: 100%;
}
.limcont >p table {
	width: 100%;
	overflow: auto;
}
.limcont >p video {
	width: 100%;
}
.limcont >p img {
	width: 100%;
}

.limcont >>> p {
	padding: 0 !important;
}
.inmian {
	width: 100%;
}
.inmian >p table {
	width: 100%;
	overflow: auto;
}
.inmian >p video {
	width: 100%;
}
.inmian >p img {
	width: 100%;
}

.inmian >>> p {
	padding: 0 !important;
}
</style>
<style scoped lang="scss">
$fs18: 18px;
$fs14: 14px;
$fs12: 12px;
$baf5: #f5f5f5;
$co: #9f9f9f;
$ba28: #041728;
$co1B: #78ac09;
$baEE: #eeeeee;
$ba: #041728;
$corles: #77aa09;
$hui: #838799;
.mianfs {
	width: 100%;
	.frokis {
		margin-top: 2.5%;

		.chlins {
			width: 96%;
			padding: 1% 2%;
		}

		.frokis_tops {
			display: flex;
			height: 25px;
			align-items: center;

			.fonst_title {
				font-size: $fs14;
				margin-left: 5px;
				margin-top: -2px;
			}
		}

		.chlins {
			font-size: $fs14;
			width: 96%;
			padding: 1% 2%;

			.mian_title {
				.lisng {
					height: 30px;
					line-height: 30px;
				}

				.fonslui {
					color: $co;
					height: 30px;
					line-height: 30px;
				}
			}
		}

		.fonst_mian {
			font-size: $fs14;
			color: $co;
			width: 96%;
			padding: 1% 2%;

			.mian_title {
				.fonslui {
					color: $co;
					height: 30px;
					line-height: 30px;
				}
			}
		}
	}

	.mianfsli {
		background: #ffffff;
		width: 92%;
		padding: 0 4% 4% 4%;

		.tilis {
			font-size: $fs12;
			color: $co;
			height: 30px;
			display: flex;
			align-items: flex-end;
		}

		.fonslis {
			min-height: 30px;
			padding: 5px 0;
			font-size: $fs14;
			display: flex;
			align-items: center;

			span {
				display: flex;
				align-items: center;
				display: inline-block;
				width: 10px;
				height: 10px;
				background: #fa5b46;
				border-radius: 50%;
			}

			div {
				margin-left: 5px;
			}
		}

		.frins {
			font-size: $fs14;
			color: $co;
		}
	}
}

.mianlist {
	width: 96%;
	padding: 2%;
}
.mianlisto {
	width: 100%;

	.huodong {
		width: 92%;
		padding: 5% 4%;
		background: #78ac09;
		border-radius: 8px;
		color: #ffffff;
		font-size: $fs18;
	}

	.titilemian {
		width: 92%;
		padding: 5% 4%;

		.mianlitop {
			display: flex;

			.fslis {
				width: 60px;
				font-size: $fs14;
				color: #808080;
				height: inherit;
				display: flex;
				justify-content: flex-end;
				align-items: flex-end;
			}

			.lifpis {
				font-size: $fs14;
			}

			.yuan1 {
				width: 40px;
				height: inherit;
				display: flex;
				justify-content: center;
				align-items: center;

				.y8uan {
					width: 10px;
					height: 10px;
					border-radius: 50%;
					background: #61596e;
				}
			}
		}

		.mianrigths {
			padding: 1% 0;
			width: 220px;
			display: flex;
			justify-content: flex-end;
			margin-right: 43px;
			font-size: $fs12;
		}
	}
}

@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
