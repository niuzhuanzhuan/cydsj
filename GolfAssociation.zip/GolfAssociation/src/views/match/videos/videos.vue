<template>
	<div class="initall">
		<div class="indexall">
			<van-nav-bar title="视频直播专区" left-arrow @click-left="$router.back(-1)" />
			<div class="fnost">{{ videos.name }}</div>
			<div id="videonum"></div>
			<div class="mianall" ref="miankey" id="miankey">
				<div class="lingt" v-for="(item, index) in datalist" :key="index">
					<div class="limage"><van-image round width="38px" height="38px" :src="item.head_photo_url" /></div>
					<div class="rilist">
						<div class="itenmane">{{ item.name }}</div>
						<div class="itemian">{{ item.content }}</div>
					</div>
				</div>
			</div>
			<div class="bonts">
				<van-field v-model="content" @keyup.enter="sends" center clearable shape="round" placeholder="我也来说两句...">
					<template #button>
						<van-button size="small" type="primary" @click="sends">发 送</van-button>
					</template>
				</van-field>
			</div>
		</div>
	</div>
</template>

<script>
import Player from 'xgplayer';
import 'xgplayer';
import HlsJsPlayer from 'xgplayer-hls.js';
import { mapActions } from 'vuex';
export default {
	data() {
		return {
			videos: {},
			XGvideo: {},
			content: '',
			datalist: [],
			timer: null,
			lingskey: true
		};
	},
	deactivated() {
		sessionStorage.removeItem('videos');
		this.videos = {};
		this.XGvideo.destroy();
		clearInterval(this.timer);
		this.displays(1);
	},
	activated() {
		this.getmian();
		if (!!sessionStorage['videos']) {
			this.videos = JSON.parse(sessionStorage['videos']);
			this.getchat_list();
			this.getdata();
			this.displays(2);
		} else {
			this.$toast('非法操作');
			this.$router.go(-1);
		}
	},
	methods: {
		...mapActions(['actionsSetGoPath', 'displays']),
		async sends() {
			if (this.$store.state.token == '') {
				this.$dialog
					.confirm({
						title: '提示',
						message: '您当前未登录，是否前去登录'
					})
					.then(() => {
						if (sessionStorage['WeChat'] == 1) {
							wx.miniProgram.navigateTo({ url: '/pages/login/login?path=sports' });
						} else {
							this.actionsSetGoPath('/match/videos');
							this.$router.push('/match/userLogin');
						}
					})
					.catch(() => {
						// on cancel
					});
			} else {
				if (this.content != '') {
					let pops = 0;
					if (this.datalist.length > 0) {
						pops = this.datalist.pop().id;
					}
					await this.$api.chat_add({ live_id: this.videos.id, content: this.content, id: pops });
					this.content = '';
					this.getchat_list();
				}
			}
		},
		getmian() {
			this.$nextTick(() => {
				this.$refs.miankey.addEventListener('touchstart', this.touchStart);
				this.$refs.miankey.addEventListener('touchend', this.touchendlist);
			});
		},
		touchStart() {
			//手指在屏幕
			this.lingskey = false;
		},
		touchendlist() {
			//手指离开屏幕
			this.lingskey = true;
		},
		getinits() {
			let miankey = document.getElementById('miankey');
			if (miankey) {
				let scrollTop = miankey.scrollTop;
				let windowHeight = miankey.clientHeight;
				let scrollHeight = miankey.scrollHeight;
				if (scrollHeight > windowHeight) {
					if (this.lingskey) {
						//判断用户手指是否在屏幕
						setTimeout(() => {
							miankey.scrollTop = scrollHeight;
						}, 50);
					}
				}
			}
		},
		async getchat_list() {
			const datalist = await this.$api.chat_list({ live_id: this.videos.id });
			if (datalist.length > 0 || datalist.length <= 20) {
				this.datalist = datalist;
			} else {
				datalist.forEach(item => {
					this.datalist.push(item);
				});
			}
			this.getinits();
		},
		getdata() {
			let that = this;
			that.timer = setInterval(() => {
				that.getchat_list();
			}, 3000);
			that.$nextTick(() => {
				that.XGvideo = new Player({
					id: 'videonum',
					url: that.videos.url1 ? that.videos.url1 : that.videos.url2,
					poster: that.videos.img ? that.videos.img : '',
					isLive: true,
					fitVideoSize: 'false', //自适应视频内容宽高
					closeVideoTouch: false, //移动端下默认video触发touchend事件后视频切换播放/暂停状态
					currentTime: false, //设置/返回视频当前播放时间
					fluid: true, //跟随父元素的宽度大小变化
					autoplay: false, //自动播放
					networkState: true, //返回视频的当前网络状态
					readyState: true, //返回视频的就绪状态
					ignores: ['progress', 'error', 'fullscreen', 'time', 'play'], //关闭组件
					lang: 'zh-cn',
					playsinline: true, // IOS 不调用原生播放器（全屏会调用）
					cssFullscreen: true, // 样式全屏
					'x5-video-player-type': 'h5', //微信同层播放
					hasStart: true,
					useHls: true
				});
				setTimeout(()=>{
					that.XGvideo.reload();
					that.XGvideo.on('pause', () => {
						that.$emit('pause', that.XGvideo);
					});
					that.XGvideo.on('play', () => {
						that.$emit('play', that.XGvideo);
					});
					that.XGvideo.on('exitCssFullscreen', () => {
						that.$emit('exitCssFullscreen', that.plays);
					});
					that.XGvideo.start(that.videos.url1 ? that.videos.url1 : that.videos.url2);
				},0)
			});
		},
		suspend() {
			//暂停
			this.$nextTick(() => {
				this.XGvideo.pause();
			});
		},
		plays() {
			//播放
			this.XGvideo.play();
		}
	}
};
</script>
<style scoped>
.indexall >>> .van-nav-bar {
	background-color: #2e5160;
}
.indexall >>> .van-nav-bar__title {
	color: #ffffff !important;
}
.indexall >>> .van-hairline--bottom::after {
	border: none;
}
.indexall >>> .van-field__control {
	color: #ffffff !important;
}
</style>
<style lang="scss" scoped>
.mianall {
	width: 90%;
	height: calc(100% - 375px);
	padding: 10px 5%;
	overflow: auto;
	.lingt {
		width: fit-content;
		max-width: 80%;
		background: #294956;
		color: #ffffff;
		border-radius: 30px;
		display: flex;
		padding: 5px 10px 5px 4px;
		margin-bottom: 10px;
		.limage {
			width: 40px;
			height: 40px;
			display: flex;
			align-items: center;
		}
		.rilist {
			margin-left: 10px;
			.itenmane {
				color: #78ac06;
				font-size: 13px;
				height: 20px;
				display: flex;
				align-items: center;
			}
			.itemian {
				font-size: 12px;
				color: #ffffff;
				width: 100%;
				word-break: break-word;
			}
		}
	}
}
.bonts {
	width: 94%;
	height: 40px;
	padding: 0 3%;
	position: absolute;
	bottom: 0;
	background: #2e5160;
	display: flex;
	justify-content: space-between;
	align-items: center;
	.van-cell {
		background-color: #294956;
		padding: 0 0 0 10px;
		border-radius: 15px;
		color: #ffffff;
	}
	// .bontsrigth {
	// 	width: 12%;
	// }
}
.fnost {
	font-size: 15px;
	color: #ffffff;
	width: 90%;
	padding: 2% 5%;
}
#videonum {
	width: 100%;
	height: 210px;
	background: #ffffff;
}
.initall {
	width: 100%;
	display: flex;
	justify-content: center;
	overflow: hidden;
	height: 100vh;
}
@media screen and (max-width: 768px) {
	.indexall {
		width: 100vw;
		min-height: 100vh;
		background: #2e5160;
		overflow: hidden;
	}
}

@media screen and (min-width: 768px) {
	.indexall {
		width: 768px;
		min-height: 100vh;
		background: #2e5160;
		overflow: hidden;
	}
	.mianall {
		width: 90%;
		height: calc(100% - 580px);
	}
	.bonts {
		width: 748px;
		padding: 0 10px;
	}
}
</style>
