<template>
	<div class="pall">
		<div class="answer">
			<van-nav-bar title="排行榜" left-arrow @click-left="$router.back(-1)" />
			<van-tabs type="card" v-if="config.list.length > 0" @click="onClick" v-model="cardNames" title-active-color="#ffffff" title-inactive-color="#78ac09" color="#78ac09">
				<van-tab v-for="(item, index) in config.list" :key="index" :title="item.name"></van-tab>
			</van-tabs>
			<van-tabs v-model="acstives" @click="inits" animated :ellipsis="false" class="miantitie" :line-height="0" v-if="navinit.length > 0">
				<van-tab v-for="(item, index) in navinit" :key="index" :name="item.key" :title="item.name">
					<template #title>
						<div class="miansinit">{{ item.name }}</div>
						<div class="miansinit">{{ item.tname }}</div>
					</template>
				</van-tab>
			</van-tabs>
			<div class="pallall">
				<teamRank v-if="activemian" ref="team" />
				<van-empty v-else description="暂无数据" />
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import { mapActions } from 'vuex';
import teamRank from './teamRank.vue';
let timer = null;
export default {
	data() {
		return {
			config: {
				list: []
			},
			navlist: [],
			navinit: [],
			namesinit: '',
			cardNames: '',
			acstives: '',
			activemian: true
		};
	},
	components: {
		teamRank
	},
	computed: {
		match_id() {
			return this.$store.state.match_id;
		}
	},
	watch: {
		namesinit(newval, val) {
			if (newval != val) {
				if (newval == '') return false;
				this.navinit.forEach(item => {
					if (item.key == newval) {
						this.setdata(item);
					}
				});
			}
		},
		match_id(newval, val) {
			if (newval != val) {
				this.cardNames = '';
				this.acstives = '';
			}
		}
	},
	activated() {
		this.get_title();
	},
	methods: {
		async get_title() {
			const datalist = await this.$api.match_rank_header({ match_id: this.$store.state.match_id });
			datalist && ((this.config = datalist), (this.navlist = datalist.list));
			if (this.cardNames == '') {
				if (this.acstives == '') {
					if (this.navlist[0].list.length > 0) {
						this.navinit = this.navlist[0].list;
						this.acstives = this.navinit[0].name;
						this.setdata(this.navinit[0]);
					} else {
						this.active = false;
					}
				} else {
					this.navinit.forEach(item => {
						if (item.key == this.acstives) {
							this.setdata(item);
						}
					});
				}
			} else {
				this.navinit.length > 0 &&
					this.navinit.forEach(item => {
						if (item.key == this.acstives) {
							this.setdata(item);
						}
					});
			}
		},
		inits(name) {
			this.namesinit = name;
		},
		onClick(name, title) {
			this.namesinit = '';
			this.navlist.forEach(item => {
				if (item.name == title) {
					this.navinit = item.list;
					if (this.navinit.length > 0) {
						this.acstives = this.navinit[0].name;
						this.namesinit = this.navinit[0].key;
						this.activemian = true;
					} else {
						this.activemian = false;
					}
				}
			});
		},
		setdata(data) {
			api.match_rank({
				match_id: this.$store.state.match_id,
				key: data.key
			}).then(res => {
				if (res) {
					this.$nextTick(() => {
						this.$refs.team.fromdata = res;
					});
				}
			});
		},
		fnThrottle(fn, delay) {
			if (timer) {
				clearTimeout(timer);
			}
			timer = setTimeout(() => {
				fn();
				timer = undefined;
			}, delay);
		}
	}
};
</script>
<style>
.miansinit {
	width: 100%;
	display: flex;
	justify-content: center;
}
.van-tabs__line {
	background-color: #78ac06;
}
.van-tab--active {
	color: #78ac06;
}
.van-tabs__nav--card {
	margin: 0 !important;
}
.van-tab__text--ellipsis {
	width: max-content;
}
.van-tabs--card > .van-tabs__wrap {
	height: 40px !important;
}
.van-tabs__nav--card {
	margin: 0;
	height: 40px !important;
}
.van-tab span {
	display: table-footer-group;
}
.van-tabs--line .van-tabs__wrap {
	height: 60px !important;
}
.miantitie .van-tabs__nav .van-tab {
	background: #ebeff5 !important;
}
.miantitie .van-tabs__nav .van-tab {
	border-right: 1px solid #ffffff;
}
.van-tabs__wrap--scrollable .van-tabs__nav--complete {
	padding: 0 !important;
}
</style>
<style lang="scss" scoped>
.mianlsefts {
	width: 94%;
	padding: 3%;
	display: flex;
	justify-content: space-between;
	.miantops {
		border: 1px solid #79aa0a;
		color: #79aa0a;
		width: 30%;
		height: 25px;
		font-size: 14px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 5px;
	}
}
@media screen and (max-width: 600px) {
	.pall {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.pall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
.pall {
	width: 100%;
	height: 100vh;
	overflow: auto;

	.pallall {
		width: 100%;
		.frons {
			width: 90%;
			padding: 3% 5% 0 5%;
			.miankey {
				width: 100%;
				height: 42px;
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-size: 0.9375rem;
				.listmian {
					display: flex;
					align-items: center;
				}
				.miand {
					display: flex;
					align-items: center;
					div {
						color: #fa415f;
					}
				}
			}
		}
	}
}
</style>
