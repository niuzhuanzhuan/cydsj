<template>
	<div class="pallall">
		<div class="topcontns" v-if="fromdata.header.length > 0">
			<div class="mianleft cn" style="margin: 0 !important;">排名</div>
			<div class="miancont">{{ fromdata.config.type == 1 ? '姓名' : '所属球队' }}</div>
			<div class="const cn">
				<div class="numlit cn" v-for="(item, index) in fromdata.header" :key="index">{{ item }}</div>
			</div>
			<div class="mianright cn">总成绩</div>
		</div>
		<div class="frons" v-for="(item, index) in fromdata.rank" :key="index">
			<div class="miankey">
				<div class="numbers cn">{{ item.rank }}</div>
				<div class="imgmians cn"><van-image round width="50px" fit="cover" height="50px" :src="item.avatar" /></div>
				<div class="miantili">
					<div class="fonst">{{ item.name }}</div>
				</div>
				<div class="mianconst">
					<div class="inmtes" v-for="(jtem, jindex) in item.sc">{{ jtem }}</div>
				</div>
				<div class="nums cn">{{ item.total }}</div>
			</div>
		</div>
		<van-empty v-if="fromdata.rank.length === 0" description="暂无数据" />
		<div style="height: 70px;"></div>
	</div>
</template>

<script>
import api from '@/utils/api';
export default {
	data() {
		return {
			fromdata: {
				rank: [],
				header: [],
				config: {
					type: 1
				}
			}
		};
	}
};
</script>
<style></style>
<style lang="scss" scoped>
.cn {
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
}
.topcontns {
	width: 100%;
	display: flex;
	height: 44px;
	font-size: 12px;
	justify-content: space-between;
	color: #ffffff;
	background: #ffffff;
	.mianleft {
		margin-left: 1px;
		width: 10%;
		height: 100%;
		background: #a4b0c6;
	}
	.miancont {
		border-right: 1px solid #ffffff;
		width: 45%;
		height: 100%;
		background: #a4b0c6;
		line-height: 44px;
		text-align: center;
	}
	.mianright {
		width: 10%;
		height: 100%;
		background: #a4b0c6;
	}
	.const {
		width: 35%;
		height: 100%;
		background: #ffffff;
		display: flex;
		justify-content: space-between;
		.numlit {
			border-right: 1px solid #ffffff;
			height: 100%;
			flex: 1;
			background: #a4b0c6;
		}
	}
}
.pallall {
	width: 100%;
	.frons {
		width: 100%;
		// padding: 0 5%;
		.miankey {
			width: 100%;
			margin-top: 2%;
			height: 60px;
			display: flex;
			justify-content: flex-start;
			.numbers {
				width: 10%;
				font-size: 14px;
				color: #454545;
			}
			.nums {
				width: 10%;
				font-size: 14px;
				color: #ff8d98;
			}
			.imgmians {
				width: 20%;
			}
			.mianconst {
				width: 35%;
				height: 100%;
				font-size: 14px;
				display: flex;
				justify-content: space-between;
				color: #454545;
				.inmtes {
					width: 100%;
					display: flex;
					height: 100%;
					align-items: center;
					justify-content: center;
					flex: 1;
				}
			}
			.miantili {
				width: 25%;
				display: flex;
				align-items: center;
				font-size: 14px;
				color: #454545;
				.fonst {
					text-overflow: -o-ellipsis-lastline;
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 2;
					line-clamp: 2;
					-webkit-box-orient: vertical;
				}
			}
		}
	}
}
</style>
