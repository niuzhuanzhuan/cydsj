<template>
	<div class="page">
		<van-image-preview v-model="show" :images="imageslist" @change="onChange" :startPosition="$store.state.imgindex">
			<template v-slot:index>
				第{{ $store.state.imgindex + 1 }}张
			</template>
		</van-image-preview>
	</div>
</template>

<script>
import { mapActions, mapState } from 'vuex';
export default {
	name: 'displayimg',
	data() {
		return {
			show: true,
			index: 0
		};
	},
	computed: {
		...mapState(['imageslist'])
	},
	components: {},
	mounted() {},
	activated() {},
	watch: {
		show(newval) {
			if (!newval) {
				this.displayimgsindex(0);
				this.displayimgs([]);
				let url=window.location.href;
				if(url.includes('displayimg')){
				   this.$router.back(-1);
				}
			}
		},
		imageslist(newval) {
			if (newval.length != 0) {
				this.show = true;
			}
		}
	},
	methods: {
		...mapActions(['displayimgsindex', 'displayimgs']),
		onChange(index) {
			this.displayimgsindex(index);
		}
	}
};
</script>
<style lang="scss" scoped>
@media screen and (max-width: 768px) {
	.index {
		width: 100vw;
		min-height: 100vh;
		background: white;
	}
}

@media screen and (min-width: 768px) {
	.index {
		width: 768px;
		min-height: 100vh;
		background: white;
		border-radius: 10px;
	}
}
</style>
