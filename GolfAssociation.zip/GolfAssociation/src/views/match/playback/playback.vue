<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar left-text="返回直播" :title="fromdata.title ? tlist(fromdata.title) : ''" left-arrow @click-left="onClickLeft" />
			<div class="vidios" id="vidios"></div>
			<div v-if="fromdata.title" class="titelis">视频名称：{{ fromdata.title }}</div>
			<div v-if="fromdata.hits" class="hui_bonmet">
				播放量：{{ fromdata.hits }}
				<span style="margin-left: 10px;">上传时间：{{ fromdata.create_time }}</span>
			</div>
		</div>
	</div>
</template>

<script>
import Player from 'xgplayer';
import 'xgplayer';
import api from '@/utils/api';
export default {
	name: 'team',
	data() {
		return {
			fromdata: {}
		};
	},
	created() {
		let that = this;
		if (!sessionStorage['playback']) {
			this.$toast('非法操作');
			this.$router.go(-1);
		} else {
			this.fromdata = JSON.parse(sessionStorage['playback']);
			this.$nextTick(() => {
				that.XGvideo = new Player({
					id: 'vidios',
					url: this.fromdata.url,
					poster: this.fromdata.img,
					isLive: true,
					fitVideoSize: 'false', //自适应视频内容宽高
					closeVideoTouch: false, //移动端下默认video触发touchend事件后视频切换播放/暂停状态
					currentTime: false, //设置/返回视频当前播放时间
					fluid: true, //跟随父元素的宽度大小变化
					autoplay: false, //自动播放
					networkState: true, //返回视频的当前网络状态
					readyState: true, //返回视频的就绪状态
					ignores: ['progress', 'error', 'fullscreen'], //关闭组件
					lang: 'zh-cn',
					playsinline: true, // IOS 不调用原生播放器（全屏会调用）
					hasStart: true
				});
			});
		}
	},
	watch: {},
	methods: {
		tlist(data) {
			if (!data) return '';
			if (data.length > 10) {
				return data.substring(0, 10) + '...';
			} else {
				return data;
			}
		},
		onClickLeft() {
			this.$router.back(-1);
			sessionStorage.removeItem('playback');
		}
	}
};
</script>
<style scoped></style>
<style scoped lang="scss">
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;
.titelis {
	padding: 3% 3% 0 3%;
	color: #1e2228;
	font-size: 16px;
}
.hui_bonmet {
	padding: 3% 3% 0 3%;
	font-size: 16px;
	color: #808080;
}
#vidios {
	width: 100%;
	padding: 0;
	height: 300px;
}

@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
