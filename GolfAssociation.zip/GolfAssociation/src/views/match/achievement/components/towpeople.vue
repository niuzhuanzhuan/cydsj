<template>
	<div class="fons">
		<div class="tilslis" v-if="formdata.length!=0">
			<div class="mialeft">排名</div>
			<div class="mianimits"><span style="margin-left: 20%;">球队</span></div>
			<div class="miancont">球员</div>
			<div class="mianimit">成绩</div>
		</div>
		<van-empty v-else description="暂无比赛信息" />

		<div class="limianpost" v-for="(item, index) in formdata" :key="index">
			<div class="tilmian" @click="insetinto(index)" :class="indexkey === index ? 'mianactive' : ''">
				<div class="likmiand">
					<div class="mialeft">{{ item.rank }}</div>
					<div class="mianimits">
						<div class="leftkey"><van-image round fit="cover" width="30px" height="30px" lazy-load :src="item.avatar" /></div>
						<div class="rigthkey">{{ item.team_name | team_name }}</div>
					</div>
					<div class="miancont">{{ item.enroll_name }}</div>
					<div class="mianimit red">{{ item.total }}</div>
				</div>
			</div>
			<div v-if="indexkey === index" class="topsklig">
				<div class="miannav">
					<div class="miatops">
						<div class="mianlimt">
							<div class="mianleft ct">Hole</div>
							<div class="mianconst ct" v-for="item in 9" :key="item">{{ item }}</div>
						</div>
						<div class="mianrigth ct">out</div>
					</div>
					<div class="conlims">
						<div class="mianlimt">
							<div class="mianleft ct">Par</div>
							<div class="mianconst ct" v-for="(jitem, jindex) in item.stand" :key="jindex" v-if="jindex <= 8">{{ jitem }}</div>
						</div>
						<div class="mianrigth ct">{{ item.stand | stand9 }}</div>
					</div>
					<div class="miands">
						<div class="miandsleft">
							<div class="mianall">
								<div class="mianleft ct">{{ item.enroll_name }}</div>
								<div class="mianconst ct" v-for="(kitem, kindex) in item.score.hole_score" v-if="kindex <= 8" :key="kindex">
									<!-- 等于0的晴空下 -->
									<div v-if="parseInt(kitem) === 0">-</div>
									<!-- 标准杆 -->
									<div v-if="parseInt(item.stand[kindex]) === parseInt(kitem)">{{ kitem }}</div>
									<!-- 啪唧 -->
									<div class="paji1" v-if="parseInt(kitem) - parseInt(item.stand[kindex]) === 1">{{ kitem }}</div>
									<!-- 啪唧加 -->
									<div class="paji2" v-if="parseInt(kitem) - parseInt(item.stand[kindex]) === 2">
										<div>{{ kitem }}</div>
									</div>
									<div class="add3" v-if="parseInt(kitem) - parseInt(item.stand[kindex]) >= 3">{{ kitem }}</div>
									<!-- 小鸟 -->
									<div class="xiaoniao" v-if="parseInt(item.stand[kindex]) - parseInt(kitem) === 1">{{ kitem }}</div>
									<!-- 老鹰 -->
									<div class="laoying" v-if="parseInt(item.stand[kindex]) - parseInt(kitem) > 1 && kitem != 0">
										<div>{{ kitem }}</div>
									</div>
								</div>
							</div>
						</div>
						<div class="miandsrigth ct">{{ item.score.hole_score | stand9 }}</div>
					</div>
				</div>

				<div class="miannav">
					<div class="miatops">
						<div class="mianlimt">
							<div class="mianleft ct">Hole</div>
							<div class="mianconst ct" v-for="(item, index) in 18" :key="index" v-if="item > 9">{{ item }}</div>
						</div>
						<div class="mianrigth ct">In</div>
					</div>
					<div class="conlims">
						<div class="mianlimt">
							<div class="mianleft ct">Par</div>
							<div class="mianconst ct" v-for="(jitem, eindex) in item.stand" :key="eindex" v-if="eindex <= 17 && eindex >= 9">{{ jitem }}</div>
						</div>
						<div class="mianrigth ct">{{ item.stand | stand18 }}</div>
					</div>
					<div class="miands">
						<div class="miandsleft">
							<div class="mianall">
								<div class="mianleft ct">{{ item.enroll_name }}</div>
								<div class="mianconst ct" v-if="mindex <= 17 && mindex >= 9" v-for="(kitem, mindex) in item.score.hole_score" :key="mindex">
									<!-- 等于0的晴空下 -->
									<div v-if="parseInt(kitem) === 0">-</div>
									<!-- 标准杆 -->
									<div v-if="parseInt(item.stand[mindex]) === parseInt(kitem)">{{ kitem }}</div>
									<!-- 啪唧 -->
									<div class="paji1" v-if="parseInt(kitem) - parseInt(item.stand[mindex]) === 1">{{ kitem }}</div>
									<!-- 啪唧加 -->
									<div class="paji2" v-if="parseInt(kitem) - parseInt(item.stand[mindex]) === 2">
										<div>{{ kitem }}</div>
									</div>
									<div class="add3" v-if="parseInt(kitem) - parseInt(item.stand[mindex]) >= 3">{{ kitem }}</div>
									<!-- 小鸟 -->
									<div class="xiaoniao" v-if="parseInt(item.stand[mindex]) - parseInt(kitem) === 1">{{ kitem }}</div>
									<!-- 老鹰 -->
									<div class="laoying" v-if="parseInt(item.stand[mindex]) - parseInt(kitem) > 1 && kitem != 0">
										<div>{{ kitem }}</div>
									</div>
								</div>
							</div>
						</div>
						<div class="miandsrigth ct">{{ item.score.hole_score | stand18 }}</div>
					</div>
				</div>

				<div class="mianbont">
					<div class="liietm">
						<div class="laoying"><div></div></div>
						<div class="mins">老鹰</div>
					</div>
					<div class="liietm">
						<div class="xiaoniao"></div>
						<div class="mins">小鸟</div>
					</div>
					<div class="liietm">
						<div class="paji1"></div>
						<div class="mins">帕忌</div>
					</div>
					<div class="liietm">
						<div class="paji2"><div></div></div>
						<div class="mins">双帕忌</div>
					</div>
					<div class="liietm">
						<div class="yishang"></div>
						<div class="mins">+3以上</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import { mapActions } from 'vuex';
export default {
	name: 'page',
	data() {
		return {
			indexkey: '',
			formdata: [],
			formconfig:{
				header:[]
			}
		};
	},
	filters: {
		team_name(data) {
			if (!data) return '';
			if (data.length > 6) {
				return data.substring(0, 6) + '...';
			} else {
				return data;
			}
		},
		stand9(data) {
			let num = 0;
			data.map((item, index) => {
				if (index <= 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		},
		stand18(data) {
			let num = 0;
			data.map((item, index) => {
				if (index <= 17 && index > 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		}
	},
	methods: {
		insetinto(data) {
			if (data === this.indexkey) {
				this.indexkey = '';
			} else {
				this.indexkey = data;
			}
		}
	}
};
</script>
<style scoped></style>
<style lang="scss" scoped>
$fs18: 18px;
$fs14: 14px;
$fs12: 12px;
$baf5: #f5f5f5;
$co: #9f9f9f;
$ba28: #041728;
$co1B: #ffffff;
$baEE: #eeeeee;
$ba: #041728;
$corles: #77aa09;
$hui: #838799;
.red {
	color: #ff4b38;
}
.ct {
	display: flex;
	justify-content: center;
	align-items: center;
}
.laoying {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 14px;
		height: 14px;
		border: 1px solid #78ac0a;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.xiaoniao {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
}
.paji1 {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	display: flex;
	justify-content: center;
	align-items: center;
}
.add3 {
	width: 100%;
	height: 100%;
	background: #ffe96c;
	display: flex;
	justify-content: center;
	align-items: center;
}
.paji2 {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 14px;
		height: 14px;
		border: 1px solid #78ac0a;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.yishang {
	width: 18px;
	height: 18px;
	background: #ffe96c;
}
.mianbont {
	width: 100%;
	display: flex;
	height: 34px;
	background: #e9e9e9;
	color: #404a4e;
	font-size: 12px;
	.liietm {
		width: 20%;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		.mins {
			margin-left: 7px;
		}
	}
}
.miannav {
	width: 100%;
	.miatops {
		width: 100%;
		height: 34px;
		display: flex;
		justify-content: space-between;
		color: #ffffff;
		font-size: 10px !important;
		.mianlimt {
			width: calc(90% - 0.1px);
			display: flex;
			justify-content: space-between;
			.mianconst {
				width: calc(9.2% - 0.1px);
				height: 100%;
				background: #a4b0c6;
			}
			.mianleft {
				width: 15%;
				height: 34px;
				background: #a4b0c6;
			}
		}
		.mianrigth {
			width: 10%;
			height: 100%;
			background: #a4b0c6;
		}
	}
	.miands {
		width: 100%;
		display: flex;
		justify-content: space-between;
		background: #f0f3f7;
		color: #404a4e;
		font-size: 10px !important;
		min-height: 34px;
		.miandsleft {
			width: calc(90% - 0.1px);
			height: inherit;
			&:nth-child(odd) {
				.mianall {
					margin-top: 1px;
				}
			}
			.mianall {
				width: 100%;
				display: flex;
				justify-content: space-between;
				.mianconst {
					width: calc(9.2% - 0.1px);
					height: inherit;
					background: #ffffff;
				}
				.mianleft {
					width: 15%;
					height: inherit;
					background: #ffffff;
				}
			}
		}
		.miandsrigth {
			width: 10%;
			height: inherit;
			background: #ffffff;
		}
	}
	.conlims {
		width: 100%;
		height: 34px;
		display: flex;
		justify-content: space-between;
		color: #083054;
		font-size: 10px !important;
		.mianlimt {
			width: calc(90% - 0.1px);
			display: flex;
			justify-content: space-between;
			.mianconst {
				width: calc(9.2% - 0.1px);
				height: 100%;
				background: #cbd4e1;
			}
			.mianleft {
				width: 15%;
				height: 100%;
				background: #cbd4e1;
			}
		}
		.mianrigth {
			width: 10%;
			height: 100%;
			background: #cbd4e1;
		}
	}
}

.limianpost {
	width: 100%;
	&:nth-child(odd) {
		background: #f7f7f7;
		.tilmian {
			.likmiand {
				.mialeft {
					background: #e9e9e9;
				}
			}
		}
	}
	&:nth-child(even) {
		background: #ebeff5;
		.tilmian {
			.likmiand {
				.mialeft {
					background: #cbd4e1;
				}
			}
		}
	}
	.topsklig {
		width: 100%;
		padding: 2% 0 0 0;
		height: auto;
		background: #ffffff;
	}

	.tilmian {
		width: 100%;
		height: 50px;
		font-size: $fs12;
		color: #3f4a4e;
		display: flex;
		.likmiand {
			width: 100%;
			height: 100%;
			display: flex;
			.mialeft {
				width: 13%;
				display: flex;
				align-items: center;
				justify-content: center;
				border-right: 1px solid #f7f7f7;
			}
			.mianimit {
				width: 20%;
				display: flex;
				align-items: center;
				justify-content: center;
				border-right: 1px solid #f7f7f7;
			}
			.mianimits {
				width: 40%;
				height: 100%;
				display: flex;
				align-items: center;
				border-right: 1px solid #f7f7f7;
				.leftkey {
					width: 30%;
					height: 100%;
					display: flex;
					align-items: center;
					justify-content: center;
				}
				.rigthkey {
					width: 70%;
					height: 100%;
					display: flex;
					align-items: center;
					justify-content: flex-start;
					white-space: nowrap;
					text-overflow: ellipsis;
					overflow: hidden;
					word-break: break-all;
				}
			}
			.miancont {
				width: 27%;
				line-height: 50px;
				// display: flex;
				// justify-content: center;
				border-right: 1px solid #f7f7f7;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				text-align: center;
			}
		}

		.mialeft {
			width: 25%;
			display: flex;
			align-items: center;
			justify-content: center;
		}
	}
}

.tilslis {
	width: 100%;
	height: 44px;
	background: #a4b0c6;
	color: $co1B;
	font-size: $fs14;
	display: flex;
	font-weight: 500;

	.mialeft {
		width: 13%;
		display: flex;
		align-items: center;
		justify-content: center;
		border-right: 1px solid #f7f7f7;
	}
	.mianimit {
		width: 20%;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.mianimits {
		width: 40%;
		display: flex;
		align-items: center;
		border-right: 1px solid #f7f7f7;
	}
	.miancont {
		width: 27%;
		display: flex;
		align-items: center;
		justify-content: center;
		border-right: 1px solid #f7f7f7;
	}
}

.tab {
	height: 45px;
	line-height: 45px;
	width: 100%;
	display: flex;
	flex-direction: row;
	font-size: $fs14;
}

.fons {
	padding: 2% 0 0 0;
	width: 100%;
	overflow: auto;
	background: #ffffff;
}
</style>
