<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar title="成绩展示" left-arrow @click-left="$router.back(-1)" />
			<div class="bas"></div>
			<div class="miantilte">
				<div class="keytitle" v-if="config.status == 1">成绩公布</div>
				<div class="keytitle" v-else>
					<img src="@/assets/imgamo/hemo/dong.gif" />
					成绩直播
				</div>
			</div>
			<van-tabs type="card" v-if="config.list.length > 0" @click="onClick" v-model="cardNames" title-active-color="#ffffff" title-inactive-color="#78ac09" color="#78ac09">
				<van-tab v-for="(item, index) in config.list" :key="index" :title="item.name"></van-tab>
			</van-tabs>
			<van-tabs v-model="acstives" @click="inits" :ellipsis="false" animated v-if="navinit.length > 0" class="miantitie" :line-height="0">
				<van-tab v-for="(item, index) in navinit" :key="index" :name="item.key" :title="item.name">
					<template #title>
						<div class="miansinit">{{ item.name }}</div>
						<div class="miansinit">{{ item.tname }}</div>
					</template>
				</van-tab>
			</van-tabs>
			<perpublish v-show="activemian" ref="perpublish" v-if="fromdata.status === 1 && fromdata.type === 1" />
			<towpublish v-show="activemian" ref="towpublish" v-if="fromdata.status === 1 && fromdata.type === 3" />
			<Fourpublish v-show="activemian" ref="Fourpublish" v-if="fromdata.status === 1 && fromdata.type === 4" />
			<pertem v-show="activemian" ref="pertem" v-if="fromdata.status === 1 && fromdata.type === 2" />
			<personal v-show="activemian" ref="personal" v-if="fromdata.status === 0 && fromdata.type === 1" />
			<towpeople v-show="activemian" ref="towpeople" v-if="fromdata.status === 0 && fromdata.type === 3" />
			<fourpeople v-show="activemian" ref="fourpeople" v-if="fromdata.status === 0 && fromdata.type === 4" />
			<towteam v-show="activemian" ref="towteam" v-if="fromdata.status === 0 && fromdata.type === 2" />
			<van-empty v-show="activemian == false" description="暂无比赛信息" />
		</div>
	</div>
</template>

<script>
import perpublish from './components/perpublish.vue';
import personal from './components/personal';
import towpeople from './components/towpeople';
import Fourpeople from './components/Fourpeople';
import towpublish from './components/towpublish';
import Fourpublish from './components/Fourpublish';
import pertem from './components/pertem';
import towteam from './components/towteam';
export default {
	data() {
		return {
			activemian: true,
			acstives: '',
			navinit: [],
			namesinit: '',
			cardNames: '',
			config: {
				list: []
			},
			fromdata: {}
		};
	},
	activated() {
		this.get_title();
	},
	components: {
		perpublish,
		personal,
		towpeople,
		Fourpeople,
		towpublish,
		Fourpublish,
		pertem,
		towteam
	},
	watch: {
		namesinit(newval, val) {
			if (newval != val) {
				if(newval=="")return false
				this.navinit.forEach(item => {
					if (item.key == newval) {
						this.getdata(item);
					}
				});
			}
		},
		'config.status'(newval, val) {
			if (newval != val) {
				this.navinit.forEach(item => {
					if (item.name == this.namesinit) {
						this.getdata(item);
					}
				});
			}
		},
		match_id(newval, val) {
			if (newval != val) {
				this.cardNames = '';
				this.acstives = '';
			}
		}
	},
	computed: {
		match_id() {
			return this.$store.state.match_id;
		}
	},
	methods: {
		inits(name) {
			this.namesinit = name;
		},
		onClick(name, title) {
			this.acstives=""
			this.navlist.forEach(item => {
				if (item.name == title) {
					this.navinit = item.list;
					if (this.navinit.length > 0) {
						this.activemian = true;
						this.acstives = this.navinit[0].name;
						this.namesinit = this.navinit[0].key;
					} else {
						this.activemian = false;
					}
				}
			});
		},
		async get_title() {
			const datalist = await this.$api.match_score_header({ match_id: this.$store.state.match_id });
			datalist && ((this.config = datalist), (this.navlist = datalist.list));
			if (this.cardNames == '') {
				if (this.acstives == '') {
					if (this.navlist[0].list.length > 0) {
						this.navinit = this.navlist[0].list;
						this.acstives = this.navinit[0].name;
						this.getdata(this.navinit[0]);
						this.activemian = true;
					} else {
						this.activemian = false;
					}
				} else {
					this.navinit.forEach(item => {
						if (item.key == this.acstives) {
							this.getdata(item);
						}
					});
				}
			} else {
				this.navinit.length > 0 &&
					this.navinit.forEach(item => {
						if (item.key == this.acstives) {
							this.getdata(item);
						}
					});
			}
		},
		async getdata(fromman) {
			const datalist = await this.$api.match_score({
				match_id: this.$store.state.match_id,
				group_id: fromman.group_id,
				bout_id: fromman.bout,
				types_id: fromman.type
			});
			datalist && (this.fromdata = datalist.config);
			this.$nextTick(() => {
				if (this.fromdata.status === 1 && this.fromdata.type === 1) {
					this.$refs.perpublish.formdata = datalist;
					this.$refs.perpublish.group_id = fromman.group_id;
				}
				if (this.fromdata.status === 1 && this.fromdata.type === 3) {
					this.$refs.towpublish.formdata = datalist;
					this.$refs.towpublish.group_id = fromman.group_id;
				}
				if (this.fromdata.status === 1 && this.fromdata.type === 4) {
					this.$refs.Fourpublish.formdata = datalist;
					this.$refs.Fourpublish.group_id = fromman.group_id;
				}
				if (this.fromdata.status === 1 && this.fromdata.type === 2) {
					this.$refs.pertem.formdata = datalist;
					this.$refs.pertem.group_id = fromman.group_id;
				}
				if (this.fromdata.status === 0 && this.fromdata.type === 2) {
					this.$refs.towteam.formdata = datalist;
				}
				if (this.fromdata.status === 0 && this.fromdata.type === 1) {
					datalist.score_list.forEach(item => (item.stand = item.stand.split(',')));
					datalist.score_list.forEach(item => (item.score.hole_score = item.score.hole_score.split(',')));
					this.$refs.personal.formdata = datalist.score_list;
					this.$refs.personal.formconfig = datalist;
				}
				if (this.fromdata.status === 0 && this.fromdata.type === 3) {
					datalist.score_list.forEach(item => (item.stand = item.stand.split(',')));
					datalist.score_list.forEach(item => (item.score.hole_score = item.score.hole_score.split(',')));
					this.$refs.towpeople.formdata = datalist.score_list;
				}
				if (this.fromdata.status === 0 && this.fromdata.type === 4) {
					datalist.score_list.forEach(item => (item.stand = item.stand.split(',')));
					datalist.score_list.forEach(item => item.score.users.map(jtem => (jtem.score = jtem.score.split(','))));
					this.$refs.fourpeople.formdata = datalist.score_list;
				}
			});
		}
	}
};
</script>
<style>
.van-tabs__line {
	background-color: #78ac06;
}
.van-tab--active {
	color: #78ac06;
}
.van-tabs__nav--card {
	margin: 0 !important;
}
.van-tab__text--ellipsis {
	width: max-content;
}
.van-tabs--card > .van-tabs__wrap {
	height: 40px !important;
}
.van-tabs__nav--card {
	margin: 0;
	height: 40px !important;
}
.van-tab span {
	display: table-footer-group;
}
.van-tabs--line .van-tabs__wrap {
	height: 60px !important;
}
.miantitie .van-tabs__nav .van-tab{
	background: #ebeff5 !important;
}
.miantitie .van-tabs__nav .van-tab {
	border-right: 1px solid #ffffff;
}
.van-tabs__wrap--scrollable .van-tabs__nav--complete{
	padding: 0 !important;
}
</style>
<style scoped lang="scss">
.miansinit {
	width: 100%;
	display: flex;
	justify-content: center;
}
.miantilte {
	width: 100%;
	.keytitle {
		width: 92%;
		padding: 2% 4%;
		color: #ff5932;
		font-size: 15px;
		display: flex;
		align-items: center;
		img {
			height: 20px;
			margin-right: 10px;
		}
	}
}
.bas {
	background: #f5f5f5;
	width: 100%;
	height: 10px;
}
.tab {
	height: 40px;
	line-height: 40px;
	width: 100%;
	display: flex;
	flex-direction: row;
}

.tab1 {
	flex: 1;
	text-align: center;
	border: solid 1px #79aa0a;
	color: #79aa0a;
}

.tab-active {
	color: white;
	background: #79aa0a;
}
@media screen and (max-width: 600px) {
	.miansall {
		width: 100%;
		.answer {
			width: 100%;
			height: 100vh;
			overflow: auto;
		}
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
