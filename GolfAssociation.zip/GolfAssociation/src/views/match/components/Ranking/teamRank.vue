<template>
	<div class="pallall">
		<div class="frons" v-for="(item, index) in list" :key="index">
			<div class="miankey">
				<div class="listmian">
					<div>{{ (index += 1) }}</div>
					<van-image v-if="item.avatar" width="40" height="40" style="margin-left: 18px;" round :src="item.avatar ? item.avatar : imgque" />
					<div style="margin-left: 10px;">{{ item.name|username }}</div>
				</div>
				<div class="miand">
					{{ item.differ_name }}
					<div>{{ item.differ }}</div>
				</div>
			</div>
		</div>
		<van-empty v-if="list.length===0" description="暂无数据" />
		<div style="height: 70px;"></div>
	</div>
</template>

<script>
import api from '@/utils/api';
export default {
	data() {
		return {
			list:[]
		};
	},
	filters:{
		username(data){
			if(data=='') return ''
			if(data.length>=10){
				return data=data.substring(0,9)+'...'
			}
			return data
		}
	}
};
</script>
<style></style>
<style lang="scss" scoped>
.pallall {
	width: 100%;
	.frons {
		width: 80%;
		padding: 5% 10% 0 10%;
		.miankey {
			width: 100%;
			height: 42px;
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 0.9375rem;
			.listmian {
				display: flex;
				align-items: center;
			}
			.miand {
				display: flex;
				align-items: center;
				div {
					color: #fa415f;
				}
			}
		}
	}
}
</style>
