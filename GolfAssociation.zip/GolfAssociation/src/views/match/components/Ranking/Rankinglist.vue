<template>
	<div class="pall">
		<van-tabs type="card" v-model="cardNames" v-if="types.length==0?false:true" title-active-color="#ffffff" title-inactive-color="#78ac09" color="#78ac09">
			<van-tab v-for="(item, index) in types" :key="index" :title="item.name"></van-tab>
		</van-tabs>
		<div class="mianlsefts">
			<div class="miantops" v-if="titlekey" @click="showPicker = true">
				<div>{{ titlekey }}</div>
				<van-icon v-if="showPicker == false" name="arrow-down" />
				<van-icon v-else name="arrow-up" />
			</div>

			<div class="miantops" v-if="teamtitle" @click="showteamPicker = true">
				<div>{{ teamtitle }}</div>
				<van-icon v-if="showteamPicker == false" name="arrow-down" />
				<van-icon v-else name="arrow-up" />
			</div>
		</div>
		<div class="pallall"><teamRank ref="team" /></div>

		<van-popup v-model="showPicker" :key="kindexs" round position="bottom">
			<van-picker show-toolbar :columns="columnskey" @cancel="showPicker = false" @confirm="onConfirm" />
		</van-popup>
		<van-popup v-model="showteamPicker" :key="kindex" round position="bottom">
			<van-picker show-toolbar :columns="columnsteam" @cancel="showteamPicker = false" @confirm="onConteamfirm" />
		</van-popup>
	</div>
</template>

<script>
import api from '@/utils/api';
import { mapActions } from 'vuex';
import teamRank from './teamRank.vue';
let timer = null;
export default {
	name: 'Rankinglist',
	data() {
		return {
			teamtitle: '',
			titlekey: '',
			columnsteam: [],
			columnskey: [],
			showPicker: false,
			showteamPicker: false,
			types: [],
			cardNames: '',
			list: [],
			position: 0,
			kindex: 1,
			kindexs: 2,
			limt: 0,
			group_id: '',
			bout_id: ''
		};
	},
	components: {
		teamRank
	},
	watch: {
		cardNames(newval, val) {
			if (newval != val) {
				(this.kindex += 3), (this.kindexs += 3), (this.position = this.types[newval].value);
				this.titlekey = this.types[newval].groups[0].name;
				this.teamtitle = this.types[newval].bouts[0].name;
				this.limt = newval;
				this.columnskey = this.types[newval].groups.map(item => item.name);
				this.columnsteam = this.types[newval].bouts.map(item => item.name);
				this.group_id = this.types[newval].groups[0].value;
				this.bout_id = this.types[newval].bouts[0].value;
				this.setdata();
			}
		}
	},
	methods: {
		onConfirm(val) {
			this.types[this.limt].groups.map(item => {
				if (val === item.name) {
					this.group_id = item.value;
					this.titlekey = item.name;
				}
			});
			this.showPicker = false;
			this.setdata();
		},
		onConteamfirm(val) {
			this.types[this.limt].bouts.map(item => {
				if (val == item.name) {
					this.bout_id = item.value;
					this.teamtitle = item.name;
				}
			});
			this.showteamPicker = false;
			this.setdata();
		},
		getdata() {
			api.match_rank({
				match_id: this.$store.state.match_id
			}).then(res => {
				if (res.data.xcode === 0) {
					this.types = res.data.data.types;
					this.position = this.types[0].value;
					this.titlekey = this.types[0].groups[0].name;
					this.teamtitle = this.types[0].bouts[0].name;
					this.columnskey = this.types[0].groups.map(item => item.name);
					this.columnsteam = this.types[0].bouts.map(item => item.name);
					this.group_id = this.types[0].groups[0].value;
					this.bout_id = this.types[0].bouts[0].value;
					this.setdata();
				} else {
					this.$toast.fail(res.data.msg);
				}
			});
		},
		setdata() {
			api.match_rank({
				match_id: this.$store.state.match_id,
				group_id: this.group_id,
				bout_id: this.bout_id,
				type: this.position
			}).then(res => {
				if (res.data.xcode === 0) {
					this.$nextTick(() => {
						this.$refs.team.list = res.data.data.rank;
					});
				} else {
					this.$toast.fail(res.data.msg);
				}
			});
		},
		fnThrottle(fn, delay) {
			if (timer) {
				clearTimeout(timer);
			}
			timer = setTimeout(() => {
				fn();
				timer = undefined;
			}, delay);
		}
	}
};
</script>
<style>
.pall > .van-tabs .van-tabs__nav--card {
	margin: 0;
	height: 40px !important;
}
.pall > .van-tabs .van-tabs__wrap {
	height: 40px !important;
}

.pall > .van-popup .van-picker {
	width: 100vw;
}
.pall > .van-popup {
	left: auto !important;
}
</style>
<style lang="scss" scoped>
.mianlsefts {
	width: 94%;
	padding: 3%;
	display: flex;
	justify-content: space-between;
	.miantops {
		border: 1px solid #79aa0a;
		color: #79aa0a;
		width: 30%;
		height: 25px;
		font-size: 14px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 5px;
	}
}
.pall {
	width: 100%;
	height: 100vh;
	overflow: auto;

	.pallall {
		width: 100%;
		.frons {
			width: 80%;
			padding: 5% 10% 0 10%;
			.miankey {
				width: 100%;
				height: 42px;
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-size: 0.9375rem;
				.listmian {
					display: flex;
					align-items: center;
				}
				.miand {
					display: flex;
					align-items: center;
					div {
						color: #fa415f;
					}
				}
			}
		}
	}
}
</style>
