<template>
	<div class="fons">
		<div class="contns">
			<div class="topcontns">
				<div class="mianleft dja" style="margin: 0 !important;">排名</div>
				<div class="miancont"><span style="margin-left: 10px;">名字</span></div>
				<div class="const dja">
					<div class="numlit dja" v-for="(item, index) in formdata.header" :key="index">{{ item }}</div>
				</div>
				<div class="mianright dja">总成绩</div>
			</div>
			<div class="topcontnsling" v-for="(item, index) in formdata.score_list" :key="index" @click="Jump(item)">
				<div class="mianleft1 dja">{{ item.rank }}</div>
				<div class="miancont">
					<div class="mianimg dja"><van-image round width="32px" height="32px" :src="item.avatar" /></div>
					<div class="mianav">{{ item.enroll_name }}</div>
				</div>
				<div class="const dja">
					<div class="numlit dja" v-for="(sitem, index) in item.rs" :key="index">{{ sitem }}</div>
				</div>
				<div class="mianright dja">{{ item.total }}</div>
			</div>
			<van-empty v-if="!formdata.score_list" description="暂无比赛信息" />
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
export default {
	name: 'page',
	data() {
		return {
			formdata: {},
			team_member: []
		};
	},
	methods: {
		Jump(data) {
			this.$router.push({
				path: 'page/personal',
				query: {
					id: data.enroll_id
				}
			});
		}
	}
};
</script>
<style scoped></style>
<style lang="scss" scoped>
.dja {
	display: flex;
	justify-content: center;
	align-items: center;
}
.fons {
	width: 100%;
	overflow: auto;
	background: #ffffff;
	.contns {
		width: 100%;
		.topcontns {
			width: 100%;
			display: flex;
			height: 44px;
			justify-content: space-between;
			color: #ffffff;
			background: #ffffff;
			.mianleft {
				margin-left: 1px;
				width: 8%;
				height: 100%;
				background: #a4b0c6;
			}
			.miancont {
				width: 36.32%;
				height: 100%;
				background: #a4b0c6;
				line-height: 44px;
			}
			.mianright {
				width: 12%;
				height: 100%;
				background: #a4b0c6;
			}
			.const {
				width: 43.2%;
				height: 100%;
				background: #ffffff;
				display: flex;
				justify-content: space-between;
				.numlit {
					margin-left: 1px;
					height: 100%;
					flex: 1;
					background: #a4b0c6;
				}
			}
		}
		.topcontnsling {
			width: 100%;
			display: flex;
			height: 49px;
			justify-content: space-between;
			background: #ffffff;
			color: #404a4e;
			&:nth-child(even) {
				.mianright {
					background: #ebeff5 !important;
				}
				.miancont {
					background: #ebeff5 !important;
				}
				.mianleft1 {
					background: #cbd4e1;
				}
				.const {
					.numlit {
						background: #ebeff5 !important;
					}
				}
			}
			.miancont {
				width: 36.3%;
				height: 100%;
				background: #f7f7f7;
				display: flex;
				justify-content: flex-start;
				.mianimg {
					width: 30%;
					height: 100%;
				}
				.mianav {
					width: 70%;
					height: 100%;
					line-height: 44px;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}
			}
			.mianleft1 {
				width: 8%;
				height: 100%;
				background: #e9e9e9;
			}
			.mianright {
				width: 12%;
				height: 100%;
				background: #f7f7f7;
			}
			.const {
				width: 43.2%;
				height: 100%;
				background: #ffffff;
				display: flex;
				justify-content: space-between;
				.numlit {
					margin-left: 1px;
					height: 100%;
					flex: 1;
					color: #ff4b38;
					background: #f7f7f7;
				}
			}
		}
	}
}
</style>
