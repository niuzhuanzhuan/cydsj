<template>
	<div class="lismit" ref="mianall" @scroll="roll">
		<div class="limitlisnt">
			<div class="limimain">
				<div class="topimgket" v-if="fromdata.notice">
					<img src="@/assets/imgamo/ment.png" />
					<div class="likey"></div>
					<div class="mianrigth"><van-notice-bar scrollable @click="noticeindex(fromdata.notice.notice_id)" :text="fromdata.notice ? fromdata.notice.title : ''" /></div>
				</div>
				<div><van-image width="100%" :src="fromdata.cover" /></div>
				<div class="mianfonst">{{ fromdata.title }}</div>
				<div class="fonstket">时间：{{ fromdata.date }}</div>
				<div class="fonstket" @click="addressinsg">
					<div>地点：{{ fromdata.address | addresss }}</div>
					<div><img src="@/assets/imgamo/address.png" /></div>
				</div>
			</div>
		</div>
		<div class="limitlisnt">
			<div class="limimain">
				<div class="listimage">
					<div v-for="(item, index) in list" @click="miantimg(index)" :key="index" class="mianimga">
						<img :src="item.image" />
						<div class="mians">{{ item.name }}</div>
					</div>
				</div>
			</div>
		</div>

		<div class="limitlisnt">
			<van-collapse v-model="activeNames">
				<van-collapse-item name="1">
					<template #title>
						<div style="display: flex;"><img style="height: 24px; margin-right: 10px;" src="./img/hot.png" /> {{ fromdata.status_text }}</div>
					</template>
					<van-tabs
						type="card"
						v-model="fromNames"
						v-if="fromdata.types.length != 0"
						@click="vantabs"
						title-active-color="#ffffff"
						title-inactive-color="#78ac09"
						color="#78ac09"
					>
						<van-tab v-for="(item, index) in fromdata.types" :key="index" :title="item.name"></van-tab>
					</van-tabs>

					<van-empty v-else description="暂无比赛信息,待会再来查看吧" />

					<div class="mianlsefts" v-if="fromdata.types.length != 0">
						<div class="miantops" @click="showPicker = true">
							<div>{{ titlekey }}</div>
							<van-icon v-if="showPicker == false" name="arrow-down" />
							<van-icon v-else name="arrow-up" />
						</div>

						<div class="miantops" v-if="fromdata.status != 1" @click="showteamPicker = true">
							<div>{{ teamtitle }}</div>
							<van-icon v-if="showteamPicker == false" name="arrow-down" />
							<van-icon v-else name="arrow-up" />
						</div>
					</div>
					<div class="sai_top" v-if="fromdata.status != 1">
						<div class="sai_sou">
							<div class="sai_souleft"><van-field v-model="values" clearable placeholder="请输入要查询成绩" /></div>
							<div class="sai_sourith"><img src="@/assets/imgamo/suo.png" @click="search(values)" /></div>
						</div>
					</div>

					<Fourpeople ref="Fourpeople" v-show="cardNames === 4" v-if="fromdata.status === 0" />
					<personal ref="personal" v-show="cardNames === 1" v-if="fromdata.status === 0" />
					<towpeople ref="towpeople" v-show="cardNames === 3" v-if="fromdata.status === 0" />
					<team ref="teams" v-show="cardNames === 2" />
					<towpublish ref="towpublish" v-show="cardNames === 3" v-if="fromdata.status === 1" />
					<perpublish ref="perpublish" v-show="cardNames === 1" v-if="fromdata.status === 1" />
					<Fourpublish ref="Fourpublish" v-show="cardNames === 4" v-if="fromdata.status === 1" />
				</van-collapse-item>
			</van-collapse>
		</div>

		<div class="limitlisnt">
			<div class="limimain">
				<div class="miantitle">
					<div :class="[frisara == 1 ? '' : 'rigthfonst']" @click="frisara = 1">赛事介绍</div>
					<div :class="[frisara == 2 ? '' : 'rigthfonst']" style="margin-left: 15px;" @click="frisara = 2">赛事日程</div>
					<div :class="[frisara == 3 ? '' : 'rigthfonst']" style="margin-left: 15px;" @click="frisara = 3">赛事规则</div>
					<div :class="[frisara == 4 ? '' : 'rigthfonst']" style="margin-left: 15px;" @click="getData">比赛日志</div>
					<van-icon class="fronss" name="arrow-up" v-if="frisara != ''" @click="frisara = ''" />
					<van-icon class="fronss" name="arrow-down" v-else />
					<div class="fromkey" @click="Notice">公告</div>
				</div>
				<div v-if="frisara == 1"><div class="limcont" v-html="fromdata.introduce"></div></div>
				<div v-if="frisara == 2">
					<div class="mianlisto">
						<div class="huodong">赛事活动日程表</div>
						<div class="titilemian" v-for="(item, index) in fromdata.schedule" :key="index">
							<div class="mianlitop">
								<div class="fslis">{{ item.date }}</div>
								<div class="yuan1"><div class="y8uan"></div></div>
								<div class="lifpis">{{ item.group }}</div>
							</div>
							<div class="mianrigths">{{ item.type }}</div>
						</div>
					</div>
				</div>
				<div v-if="frisara == 3" class="mianfs">
					<div class="frokis" v-for="(item, index) in fromdata.rule" :key="index">
						<div class="frokis_tops">
							<div class="shuli"></div>
							<div class="fonst_title">{{ item.name }}</div>
						</div>
						<div class="chlins" v-for="(jtem, jindex) in item.list" :key="jindex">
							<div class="mian_title">
								<div class="lisng">{{ jtem.name }}</div>
								<div class="fonslui" v-for="(kety, kindex) in jtem.value" :key="kindex">{{ kety }}</div>
							</div>
						</div>
						<div class="fonst_mian" v-if="item.value" v-html="item.value"></div>
					</div>
				</div>
				<div v-if="frisara == 4" class="mianfs">
					<div class="mianfsli" v-for="(item, index) in fromlist" :key="index">
						<div class="tilis">{{ item.datetime }}</div>
						<div class="fonslis">
							<span></span>
							<div>{{ item.title }}</div>
						</div>
						<div class="frins">{{ item.content }}</div>
					</div>
					<van-empty v-if="fromlist.length === 0" description="暂无比赛日志,待会再来查看吧" />
				</div>
			</div>
		</div>

		<div class="spis">
			<van-popup v-model="showPicker" round position="bottom"><van-picker show-toolbar :columns="columnskey" @cancel="showPicker = false" @confirm="onConfirm" /></van-popup>
			<van-popup v-model="showteamPicker" round position="bottom">
				<van-picker show-toolbar :columns="columnsteam" @cancel="showteamPicker = false" @confirm="onConteamfirm" />
			</van-popup>
		</div>
		<div style="width: 100%;height: 140px;"></div>
	</div>
</template>

<script>
import api from '@/utils/api';
import towpeople from './towpeople.vue';
import Fourpeople from './Fourpeople.vue';
import personal from './personal';
import towpublish from './towpublish.vue';
import perpublish from './perpublish.vue';
import Fourpublish from './Fourpublish.vue';
import team from './team.vue';
import { mapActions } from 'vuex';
export default {
	name: 'page',
	data() {
		return {
			columnsteam: [],
			columnskey: [],
			titlekey: '',
			teamtitle: '',
			cardNames: null,
			fromNames: '',
			titlecardNames: '',
			group_id: '',
			showPicker: false,
			showteamPicker: false,
			values: '',
			active: false,
			activeNames: [],
			frisara: 1,
			keyindex: 0,
			fromdata: {
				notice: {
					title: ''
				},
				rule: [],
				groups: {},
				types: []
			},
			fromlist: [],
			bout_id: '',
			list: [
				{
					name: '比赛分组表',
					image: require('./img/img1.png')
				},
				{
					name: '个人列表',
					image: require('./img/img2.png')
				},
				{
					name: '球队列表',
					image: require('./img/img3.png')
				},
				{
					name: '球道介绍',
					image: require('./img/img4.png')
				}
			],
			formdata: {},
			storagefrom: {}
		};
	},
	computed: {},
	components: {
		Fourpeople,
		personal,
		towpeople,
		towpublish,
		perpublish,
		Fourpublish,
		team
	},
	filters: {
		addresss(data) {
			if (!data) return '';
			if (data.length > 15) {
				return data.substring(0, 15) + '...';
			} else {
				return data;
			}
		}
	},
	watch: {
		activeNames(newval, val) {
			if (newval.length > 0 && this.titlekey == '') {
				this.keyindex = 0;
				if (this.fromdata.types[0]) {
					this.titlekey = this.fromdata.types[0].groups[0].name;
					this.teamtitle = this.fromdata.types[0].bouts[0].name;
					this.columnskey = this.fromdata.types[0].groups.map(item => item.name);
					this.columnsteam = this.fromdata.types[0].bouts.map(item => item.name);
					this.group_id = this.fromdata.types[0].groups[0].value;
					this.bout_id = this.fromdata.types[0].bouts[0].value;
					this.titlecardNames = this.fromdata.types[0].value;
					if (!this.cardNames) {
						this.cardNames = this.titlecardNames;
					}
				}
			}
		},
		cardNames(newval, val) {
			if (newval != val) {
				this.Setdata();
			}
		},
		values(newval, val) {
			if (newval != val) {
				if (newval == '') {
					this.Setdata();
				}
			}
		}
	},
	activated() {
		if (localStorage['scrolls']) {
			this.$nextTick(() => {
				this.$refs.mianall.scrollTop = localStorage['scrolls'];
			});
		}
	},
	methods: {
		vantabs(data, name) {
			this.keyindex = data;
			if (this.fromdata.types) {
				this.storagefrom = this.fromdata.types[data];

				this.titlekey = this.storagefrom.groups[0].name;
				this.teamtitle = this.storagefrom.bouts[0].name;
				this.columnskey = this.storagefrom.groups.map(item => item.name).filter(item => item);
				this.columnsteam = this.storagefrom.bouts.map(item => item.name).filter(item => item);
				this.group_id = this.storagefrom.groups[0].value;
				this.bout_id = this.storagefrom.bouts[0].value;
				this.titlecardNames = this.storagefrom.value;
				this.cardNames = this.titlecardNames;
				this.values = '';
			}
		},
		roll() {
			this.$nextTick(() => {
				let scrollTop = this.$refs.mianall.scrollTop;
				let windowHeight = this.$refs.mianall.clientHeight;
				let scrollHeight = this.$refs.mianall.scrollHeight;
				localStorage['scrolls'] = scrollTop;
			});
		},
		Setdata() {
			api.match_index_score({
				match_id: this.$store.state.match_id,
				name: this.values,
				group_id: this.group_id,
				types_id: this.titlecardNames,
				bout_id: this.bout_id
			}).then(res => {
				if (res.data.xcode === 0) {
					if (this.cardNames === 1 && this.fromdata.status === 0) {
						//个人 比赛
						this.$nextTick(() => {
							if (res.data.data.score_list) {
								res.data.data.score_list.map(item => (item.stand = item.stand.split(',')));
								res.data.data.score_list.map(item => (item.score.hole_score = item.score.hole_score.split(',')));
								this.$refs.personal.formdata = res.data.data.score_list;
							}
						});
					}
					if (this.cardNames === 3 && this.fromdata.status === 0) {
						//两人 比赛
						this.$nextTick(() => {
							if (res.data.data.score_list) {
								res.data.data.score_list.map(item => (item.stand = item.stand.split(',')));
								res.data.data.score_list.map(item => (item.score.hole_score = item.score.hole_score.split(',')));
								this.$refs.towpeople.formdata = res.data.data.score_list;
							}
						});
					}
					if (this.cardNames === 4 && this.fromdata.status === 0) {
						//两人 比赛
						this.$nextTick(() => {
							if (res.data.data.score_list) {
								res.data.data.score_list.map(item => (item.stand = item.stand.split(',')));
								res.data.data.score_list.map(item => item.score.users.map(jtem => (jtem.score = jtem.score.split(','))));
								this.$refs.Fourpeople.formdata = res.data.data.score_list;
							}
						});
					}

					if (this.cardNames === 2) {
						this.$nextTick(() => {
							this.$refs.teams.formdata = res.data.data;
						});
					}

					if (this.cardNames === 1 && this.fromdata.status === 1) {
						this.$nextTick(() => {
							this.$refs.perpublish.formdata = res.data.data;
						});
					}
					if (this.cardNames === 3 && this.fromdata.status === 1) {
						this.$nextTick(() => {
							this.$refs.towpublish.formdata = res.data.data;
						});
					}
					if (this.cardNames === 4 && this.fromdata.status === 1) {
						this.$nextTick(() => {
							this.$refs.Fourpublish.formdata = res.data.data;
						});
					}
				} else {
					this.$toast(res.data.msg);
				}
			});
		},
		onConfirm(data) {
			this.titlekey = data;
			this.fromdata.types[this.keyindex].groups.map(item => {
				if (item.name == data) {
					this.group_id = item.value;
				}
			});
			this.Setdata();
			this.showPicker = false;
		},
		onConteamfirm(val) {
			this.teamtitle = val;
			this.fromdata.types[this.keyindex].bouts.map(item => {
				if (item.name == val) {
					this.bout_id = item.value;
				}
			});
			this.Setdata();
			this.showteamPicker = false;
		},
		miantimg(data) {
			if (data == 2) {
				this.$router.push('/team');
			} else if (data == 3) {
				this.$router.push('/Fairway');
			} else if (data == 1) {
				this.$router.push('/personal');
			} else {
				this.$router.push('/surface');
			}
		},
		getData() {
			this.frisara = 4;
			api.match_notice({
				match_id: this.$store.state.match_id,
				type: 4
			}).then(res => {
				this.fromlist = res.data.data.list;
			});
		},
		search(data) {
			this.name = data;
			this.Setdata();
		},
		noticeindex(data) {
			this.$router.push({
				path: 'notice_details',
				query: {
					id: data
				}
			});
		},
		Notice() {
			this.$router.push('/notice');
		},
		addressinsg() {
			if (this.fromdata.location) {
				this.$router.push({
					path: '/addrs',
					query: {
						lat: this.fromdata.location.split(',')[0],
						lng: this.fromdata.location.split(',')[1]
					}
				});
			}
		}
	}
};
</script>
<style scoped>
.van-picker__toolbar {
	width: 100vw;
}
.limcont {
	width: 94%;
	padding: 0 3%;
}
.limcont >>> table {
	width: 100%;
	overflow: auto;
}
.limcont >>> video {
	width: 100%;
}
.limcont >>> img {
	width: 100%;
}

.limcont >>> p {
	padding: 0 !important;
}

.mianrigth > .van-notice-bar {
	width: 150px;
	padding: 0;
	height: 19px;
	background-color: #ffffff;
}

.limitlisnt >>> .van-cell {
	padding: 5% 8%;
	height: 60px;
}

.limitlisnt >>> .van-collapse-item__content {
	padding: 0;
}

.limitlisnt >>> .van-tabs__nav--card {
	margin: 0;
	height: 40px !important;
}
.limitlisnt >>> .van-tabs__wrap {
	height: 40px !important;
}
.sai_souleft >>> .van-cell {
	padding: 0 !important;
	height: inherit;
	line-height: 35px !important;
	background: none;
}

.likisjfrom >>> .van-cell {
	height: 40px;
	padding: 2.5% 8%;
}

.spis >>> .van-popup--bottom {
	width: 100vw !important;
}
</style>
<style lang="scss" scoped>
$fs18: 18px;
$fs14: 14px;
$fs12: 12px;
$baf5: #f5f5f5;
$co: #9f9f9f;
$ba28: #041728;
$co1B: #78ac09;
$baEE: #eeeeee;
$ba: #041728;
$corles: #77aa09;
$hui: #838799;
.mianlsefts {
	width: 94%;
	padding: 3%;
	display: flex;
	justify-content: space-between;
	.miantops {
		border: 1px solid #79aa0a;
		color: #79aa0a;
		width: 30%;
		height: 25px;
		font-size: 14px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 5px;
	}
}
.eryuan {
	width: 21px;
	height: 21px;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
	background: #ff4b38;
}

.eryuaner {
	width: 21px;
	height: 21px;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
	background: #f1cb49;
}

.paji {
	width: 21px;
	height: 21px;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
	background: #77b2ee;
}

.pajier {
	width: 21px;
	height: 21px;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
	background: #2446d9;
}

.biao {
	width: 21px;
	height: 21px;
	display: flex;
	justify-content: center;
	align-items: center;
	color: #3f4a4e;
}

.yuan {
	width: 21px;
	height: 21px;
	border-radius: 50%;
	border: 1px solid $corles;
	display: flex;
	align-items: center;
	justify-content: center;
}

.miannav {
	width: 100%;
	// background: #0e334d;
	margin-top: 0.3125rem;

	.navtop {
		width: 94%;
		padding: 0 3%;
		height: 40px;
		// background: $ba;
		color: $corles;
		display: flex;
		align-items: center;
		font-size: 0.875rem;
	}

	.navall {
		width: 100%;
		height: 5.625rem;
		margin-top: 1px;
		display: flex;
		justify-content: space-between;

		.navleft {
			width: 74%;
			height: 100%;
			padding: 0 3%;
			// background: $ba;

			.lrftmian {
				width: 100%;
				height: 33%;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.congs {
					color: $hui;
					font-size: 14px;
					width: 21px;
					display: flex;
					justify-content: center;
					align-items: center;
				}

				.conglist {
					font-size: 15px;
					color: $corles;
					width: 21px;
					display: flex;
					justify-content: center;
					align-items: center;
				}

				.foner {
					font-size: 14px;
					color: #ffffff;
				}
			}
		}

		.navrigth {
			width: 20%;
			margin-left: 1px;
			// background: $ba;
			height: 100%;

			div {
				width: 100%;
				height: 33%;
				display: flex;
				justify-content: center;
				align-items: center;
			}

			.conglist {
				font-size: 13px;
				color: $corles;
			}

			.foner {
				font-size: 12px;
				color: #ff4b38;
			}
		}
	}

	.navbont {
		width: 100%;
		height: 80px;
		display: flex;
		margin-top: 1px;
		justify-content: space-between;

		.bontleft {
			width: 80%;
			height: 100%;
			display: flex;
			justify-content: space-between;

			.bontmian {
				// background: $ba;
				margin-left: 1px;
				width: 20%;
				height: 100%;
				font-size: 0.875rem;
				color: $corles;
				display: flex;
				flex-direction: column;
				justify-content: flex-start;

				.listkey {
					width: 90%;
					height: 30%;
					display: flex;
					justify-content: center;
					align-items: flex-end;
				}

				.listkeys {
					width: 90%;
					height: 40%;
					padding: 2% 0;
					display: flex;
					justify-content: center;
					align-items: center;
				}
			}
		}

		.bontrigth {
			// background: $ba;
			margin-left: 1px;
			width: 20%;
			height: 100%;
			display: flex;
			flex-direction: column;
			justify-content: flex-start;

			.listkey {
				width: 90%;
				height: 40%;
				display: flex;
				justify-content: center;
				align-items: flex-end;
				color: #fa415f;
				font-size: 0.875rem;
			}
		}
	}
}

.titleilist {
	width: 84%;
	height: 40px;
	padding: 0 8%;
	display: flex;
	align-items: center;
	justify-content: space-between;
	background: #ffffff;
	color: black;
	font-size: $fs14;
}

.mianactive {
	// background: $baEE;
}

.limianpost {
	width: 100%;

	.topsklig {
		width: 94%;
		padding: 2% 3%;
		background: $baEE;
	}

	.tilmian {
		width: 100%;
		height: 40px;
		font-size: $fs12;
		color: black;
		display: flex;

		.likmiand {
			width: 100%;
			display: -webkit-box;
			overflow-x: scroll;
			-webkit-overflow-scrolling: touch;

			&::-webkit-scrollbar {
				width: 0;
				height: 0;
				/**/
			}

			.linskey {
				color: $co1B;
				text-align: center;
				width: 17%;
				height: inherit;
				line-height: 40px;
				display: flex;
				justify-content: center;
				align-items: center;

				&:nth-child(1) {
					min-width: 30%;
					color: black;
					display: flex;
					justify-content: flex-start;
				}

				.lisnd {
					width: 20px;
					height: 20px;
					border-radius: 50%;
					background: #78ac09;
				}
			}

			.reds {
				color: red !important;
			}
		}

		.mialeft {
			width: 25%;
			display: flex;
			align-items: center;
			justify-content: center;
		}
	}
}

.tilslis {
	width: 100%;
	height: 40px;
	background: $ba28;
	color: $co1B;
	font-size: $fs14;
	display: flex;

	.likmiand {
		width: 100%;
		display: -webkit-box;
		overflow-x: scroll;
		-webkit-overflow-scrolling: touch;

		&::-webkit-scrollbar {
			width: 0;
			height: 0;
			/**/
		}

		.linskey {
			text-align: center;
			width: 17%;
			height: inherit;
			line-height: 40px;

			&:nth-child(1) {
				min-width: 30%;
			}
		}
	}

	.mialeft {
		width: 25%;
		display: flex;
		align-items: center;
		justify-content: center;
	}
}

.sai_top {
	background: #ffffff;
	width: 94%;
	padding: 2% 3%;

	.sai_sou {
		width: 100%;
		height: 40px;
		border-radius: 20px;
		border: 1px solid #43515e;
		display: flex;
		align-items: center;
		justify-content: center;

		.sai_souleft {
			width: 75%;
			height: 35px;
		}

		.sai_sourith {
			width: 15%;
			height: 35px;
			display: flex;
			align-items: center;
			justify-content: flex-end;

			img {
				width: $fs18;
				display: inline-block;
			}
		}
	}
}

.tab {
	height: 45px;
	line-height: 45px;
	width: 100%;
	display: flex;
	flex-direction: row;
	font-size: $fs14;
}

.tab1 {
	flex: 1;
	text-align: center;
	border: solid 1px #79aa0a;
	color: #79aa0a;
}

.tab-active {
	color: white;
	background: #79aa0a;
}

.shuli {
	width: 5px;
	height: 12px;
	background: #78ac09;
}

.mianfs {
	background: $baf5;
	width: 84%;
	padding: 1% 8%;

	.frokis {
		margin-top: 2.5%;

		.chlins {
			width: 96%;
			padding: 1% 2%;
		}

		.frokis_tops {
			display: flex;
			height: 25px;
			align-items: center;

			.fonst_title {
				font-size: $fs14;
				margin-left: 5px;
				margin-top: -2px;
			}
		}

		.chlins {
			font-size: $fs14;
			width: 96%;
			padding: 1% 2%;

			.mian_title {
				.lisng {
					height: 30px;
					line-height: 30px;
				}

				.fonslui {
					color: $co;
					height: 30px;
					line-height: 30px;
				}
			}
		}

		.fonst_mian {
			font-size: $fs14;
			color: $co;
			width: 96%;
			padding: 1% 2%;

			.mian_title {
				.fonslui {
					color: $co;
					height: 30px;
					line-height: 30px;
				}
			}
		}
	}

	.mianfsli {
		margin-top: 2.5%;
		background: #ffffff;
		width: 92%;
		padding: 0 4% 8% 4%;

		.tilis {
			font-size: $fs12;
			color: $co;
			height: 30px;
			display: flex;
			align-items: flex-end;
		}

		.fonslis {
			height: 30px;
			font-size: $fs14;
			display: flex;
			align-items: center;

			span {
				display: flex;
				align-items: center;
				display: inline-block;
				width: 10px;
				height: 10px;
				background: #fa5b46;
				border-radius: 50%;
			}

			div {
				margin-left: 5px;
			}
		}

		.frins {
			font-size: $fs14;
			color: $co;
		}
	}
}

.lismit {
	width: 100%;
	height: 100vh;
	overflow: auto;
	background: #ffffff;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #dcdcdc;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #dcdcdc;
	}
	&::-webkit-scrollbar-corner {
		background: #dcdcdc;
	}
	.limitlisnt {
		width: 100%;
		height: auto;
		background: #f8f8f8;
		padding: 0 0 10px 0;

		.limimain {
			width: 100%;
			height: auto;
			background: #ffffff;

			.miantitle {
				padding: 5% 8%;
				width: 84%;
				font-size: $fs14;
				display: flex;
				position: relative;
				align-items: center;

				.fronss {
					position: absolute;
					right: 8%;
				}

				.fromkey {
					position: fixed;
					left: 20%;
					top: 30%;
					width: 60px;
					height: 60px;
					display: flex;
					align-items: center;
					justify-content: center;
					font-size: 18px;
					color: #fff;
					border-radius: 100%;
					background: #ff5932;
					z-index: 99999;
				}

				.rigthfonst {
					color: #9f9f9f;
				}
			}

			.mianlisto {
				padding: 0 10%;
				width: 80%;

				.huodong {
					width: 92%;
					padding: 5% 4%;
					background: #78ac09;
					border-radius: 8px;
					color: #ffffff;
					font-size: $fs18;
				}

				.titilemian {
					width: 92%;
					padding: 5% 4%;

					.mianlitop {
						display: flex;

						.fslis {
							font-size: $fs14;
							color: #808080;
							height: inherit;
							display: flex;
							align-items: flex-end;
						}

						.lifpis {
							font-size: $fs14;
						}

						.yuan1 {
							width: 70px;
							height: inherit;
							display: flex;
							justify-content: center;
							align-items: center;

							.y8uan {
								width: 10px;
								height: 10px;
								border-radius: 50%;
								background: #61596e;
							}
						}
					}

					.mianrigths {
						padding: 1% 0;
						width: 220px;
						display: flex;
						justify-content: flex-end;
						margin-right: 43px;
						font-size: $fs12;
					}
				}
			}

			.topimgket {
				padding: 5% 10%;
				width: 80%;
				display: flex;

				img {
					width: 86px;
					height: 19px;
					display: block;
				}

				.likey {
					width: 3px;
					background: #80b118;
					height: inherit;
					margin-left: 10px;
				}

				.mianrigth {
					font-size: 14px;
					margin-left: 18px;
				}
			}

			.listimage {
				width: 84%;
				padding: 5% 8%;
				display: flex;
				justify-content: space-between;

				.mianimga {
					width: auto;
					font-size: $fs12;
					height: 60px;
					display: flex;
					flex-direction: column;
					align-items: center;
					justify-content: inherit;

					.mians {
						padding: 5% 0;
						display: flex;
						justify-content: center;
					}

					img {
						display: inline-block;
						width: 35px;
					}
				}
			}
		}

		.mianfonst {
			width: 80%;
			padding: 2% 10%;
			font-size: $fs18;
		}

		.fonstket {
			width: 80%;
			padding: 2% 10%;
			display: flex;
			font-size: $fs14;
			justify-content: space-between;

			img {
				display: inline-block;
				width: 14px;
			}
		}
	}
}
</style>
