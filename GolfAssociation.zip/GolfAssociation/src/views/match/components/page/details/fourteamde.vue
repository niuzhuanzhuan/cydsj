<template>
	<div class="miansall">
		<div class="answer">
			<div class="lisfromdata">
				<van-nav-bar left-text="成绩信息" left-arrow @click-left="$router.back(-1)" />
				<div class="mytitle">
					<div class="titlekey">
						<div class="mian_left dja">
							<van-image round width="32px" height="32px" fit="contain" :src="userfrom.avatar" />
							<div class="miantitle">
								<div>{{ userfrom.name }}</div>
								<div class="confonst">({{ istitle }})</div>
							</div>
						</div>
					</div>
				</div>

				<div class="tonmian">
					<div class="top_limt">
						轮次
						<div class="numlit dja" :class="{ active: index == actives }" @click="fromatindex(index, item)" v-for="(item, index) in arrlist" :key="index">
							{{ item }}
						</div>
					</div>
					<div class="contns">
						<div class="topcontns">
							<div class="mianleft dja">排名</div>
							<div class="miaconas dja">球员</div>
							<div class="mianright dja">总成绩</div>
						</div>
						<div class="topcontnsling" v-for="(item, index) in listkey" :key="index">
							<div class="limsg" @click="insetinto(index)" :class="indexkey === index ? 'mianactive' : ''">
								<div class="mianleft dja">{{ item.rank ? item.rank : '-' }}</div>
								<div class="miaconas dja">{{ item.name }}</div>
								<div class="mianright dja">{{ item.total ? item.total : 0 }}</div>
							</div>
							<div class="topsklig" v-if="indexkey === index">
								<div class="miannav">
									<div class="miatops">
										<div class="mianlimt">
											<div class="mianleft ct">Hole</div>
											<div class="mianconst ct" v-for="item in 9" :key="item">{{ item }}</div>
										</div>
										<div class="mianrigth ct">out</div>
									</div>
									<div class="conlims">
										<div class="mianlimt">
											<div class="mianleft ct">Par</div>
											<div class="mianconst ct" v-for="(jitem, jindex) in stand" :key="jindex" v-if="jindex <= 8">{{ jitem }}</div>
										</div>
										<div class="mianrigth ct">{{ stand | stand9 }}</div>
									</div>
									<div class="miands">
										<div class="miandsleft">
											<div class="mianall">
												<div class="mianleft ct">{{ item.name.split('/')[0] }}</div>
												<div class="mianconst ct" v-for="(kitem, kindex) in item.score.users[0].score" v-if="kindex <= 8" :key="kindex">
													<!-- 等于0的晴空下 -->
													<div v-if="parseInt(kitem) === 0">-</div>
													<!-- 标准杆 -->
													<div v-if="parseInt(stand[kindex]) === parseInt(kitem)">{{ kitem }}</div>
													<!-- 啪唧 -->
													<div class="paji1" v-if="parseInt(kitem) - parseInt(stand[kindex]) === 1">{{ kitem }}</div>
													<!-- 啪唧加 -->
													<div class="paji2" v-if="parseInt(kitem) - parseInt(stand[kindex]) === 2">
														<div>{{ kitem }}</div>
													</div>
													<div class="add3" v-if="parseInt(kitem) - parseInt(stand[kindex]) >= 3">{{ kitem }}</div>
													<!-- 小鸟 -->
													<div class="xiaoniao" v-if="parseInt(stand[kindex]) - parseInt(kitem) === 1">{{ kitem }}</div>
													<!-- 老鹰 -->
													<div class="laoying" v-if="parseInt(stand[kindex]) - parseInt(kitem) > 1 && kitem != 0">
														<div>{{ kitem }}</div>
													</div>
												</div>
											</div>
											<div class="mianall">
												<div class="mianleft ct">{{ item.name.split('/')[1] }}</div>
												<div class="mianconst ct" v-for="(kitem, kindex) in item.score.users[1].score" v-if="kindex <= 8" :key="kindex">
													<!-- 等于0的晴空下 -->
													<div v-if="parseInt(kitem) === 0">-</div>
													<!-- 标准杆 -->
													<div v-if="parseInt(stand[kindex]) === parseInt(kitem)">{{ kitem }}</div>
													<!-- 啪唧 -->
													<div class="paji1" v-if="parseInt(kitem) - parseInt(stand[kindex]) === 1">{{ kitem }}</div>
													<!-- 啪唧加 -->
													<div class="paji2" v-if="parseInt(kitem) - parseInt(stand[kindex]) === 2">
														<div>{{ kitem }}</div>
													</div>
													<div class="add3" v-if="parseInt(kitem) - parseInt(stand[kindex]) >= 3">{{ kitem }}</div>
													<!-- 小鸟 -->
													<div class="xiaoniao" v-if="parseInt(stand[kindex]) - parseInt(kitem) === 1">{{ kitem }}</div>
													<!-- 老鹰 -->
													<div class="laoying" v-if="parseInt(stand[kindex]) - parseInt(kitem) > 1 && kitem != 0">
														<div>{{ kitem }}</div>
													</div>
												</div>
											</div>
										</div>
										<div class="miandsrigth ct">{{ item.score.hole_score | par_score9 }}</div>
									</div>
								</div>

								<div class="miannav">
									<div class="miatops">
										<div class="mianlimt">
											<div class="mianleft ct">Hole</div>
											<div class="mianconst ct" v-for="(item, index) in 18" :key="index" v-if="item > 9">{{ item }}</div>
										</div>
										<div class="mianrigth ct">In</div>
									</div>
									<div class="conlims">
										<div class="mianlimt">
											<div class="mianleft ct">Par</div>
											<div class="mianconst ct" v-for="(jitem, eindex) in stand" :key="eindex" v-if="eindex <= 17 && eindex >= 9">{{ jitem }}</div>
										</div>
										<div class="mianrigth ct">{{ stand | stand18 }}</div>
									</div>
									<div class="miands">
										<div class="miandsleft">
											<div class="mianall">
												<div class="mianleft ct">{{ item.name.split('/')[0] }}</div>
												<div class="mianconst ct" v-if="mindex <= 17 && mindex >= 9" v-for="(kitem, mindex) in item.score.users[0].score" :key="mindex">
													<!-- 等于0的晴空下 -->
													<div v-if="parseInt(kitem) === 0">-</div>
													<!-- 标准杆 -->
													<div v-if="parseInt(stand[mindex]) === parseInt(kitem)">{{ kitem }}</div>
													<!-- 啪唧 -->
													<div class="paji1" v-if="parseInt(kitem) - parseInt(stand[mindex]) === 1">{{ kitem }}</div>
													<!-- 啪唧加 -->
													<div class="paji2" v-if="parseInt(kitem) - parseInt(stand[mindex]) === 2">
														<div>{{ kitem }}</div>
													</div>
													<div class="add3" v-if="parseInt(kitem) - parseInt(stand[mindex]) >= 3">{{ kitem }}</div>
													<!-- 小鸟 -->
													<div class="xiaoniao" v-if="parseInt(stand[mindex]) - parseInt(kitem) === 1">{{ kitem }}</div>
													<!-- 老鹰 -->
													<div class="laoying" v-if="parseInt(stand[mindex]) - parseInt(kitem) > 1 && kitem != 0">
														<div>{{ kitem }}</div>
													</div>
												</div>
											</div>
											<div class="mianall">
												<div class="mianleft ct">{{ item.name.split('/')[1] }}</div>
												<div class="mianconst ct" v-if="mindex <= 17 && mindex >= 9" v-for="(kitem, mindex) in item.score.users[1].score" :key="mindex">
													<!-- 等于0的晴空下 -->
													<div v-if="parseInt(kitem) === 0">-</div>
													<!-- 标准杆 -->
													<div v-if="parseInt(stand[mindex]) === parseInt(kitem)">{{ kitem }}</div>
													<!-- 啪唧 -->
													<div class="paji1" v-if="parseInt(kitem) - parseInt(stand[mindex]) === 1">{{ kitem }}</div>
													<!-- 啪唧加 -->
													<div class="paji2" v-if="parseInt(kitem) - parseInt(stand[mindex]) === 2">
														<div>{{ kitem }}</div>
													</div>
													<div class="add3" v-if="parseInt(kitem) - parseInt(stand[mindex]) >= 3">{{ kitem }}</div>
													<!-- 小鸟 -->
													<div class="xiaoniao" v-if="parseInt(stand[mindex]) - parseInt(kitem) === 1">{{ kitem }}</div>
													<!-- 老鹰 -->
													<div class="laoying" v-if="parseInt(stand[mindex]) - parseInt(kitem) > 1 && kitem != 0">
														<div>{{ kitem }}</div>
													</div>
												</div>
											</div>
										</div>
										<div class="miandsrigth ct">{{ item.score.hole_score | par_score18 }}</div>
									</div>
								</div>

								<div class="mianbont">
									<div class="liietm">
										<div class="laoying"><div class="mianlims"></div></div>
										<div class="mins">老鹰</div>
									</div>
									<div class="liietm">
										<div class="xiaoniao"></div>
										<div class="mins">小鸟</div>
									</div>
									<div class="liietm">
										<div class="paji1"></div>
										<div class="mins">帕忌</div>
									</div>
									<div class="liietm">
										<div class="paji2"><div></div></div>
										<div class="mins">双帕忌</div>
									</div>
									<div class="liietm">
										<div class="yishang"></div>
										<div class="mins">+3以上</div>
									</div>
								</div>
							</div>
						</div>

						<van-empty v-if="!listkey" description="暂无比赛信息" />
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import bus from '@/components/bus.js';
export default {
	data() {
		return {
			arrlist: [],
			actives: 0,
			fromlist: {},
			userfrom: {},
			listkey: [],
			arrnum: [],
			stand: [],
			istitle: '',
			type_id: null,
			indexkey: ''
		};
	},
	activated() {
		if (this.$route.query.id) {
			if (this.$route.query.states == 2) {
				this.istitle = '4人2球赛';
				this.type_id = 3;
			} else {
				this.istitle = '4人4球赛';
				this.type_id = 4;
			}
			this.getdata(this.$route.query.id, this.$route.query.group_id);
		} else {
			this.$toast('非法操作');
		}
	},
	filters: {
		par_score9(data) {
			let num = 0;

			data.split(',').map((item, index) => {
				if (index <= 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		},
		par_score18(data) {
			let num = 0;
			data.split(',').map((item, index) => {
				if (index <= 17 && index > 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		},
		stand9(data) {
			let num = 0;
			data.map((item, index) => {
				if (index <= 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		},
		stand18(data) {
			let num = 0;
			data.map((item, index) => {
				if (index <= 17 && index > 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		}
	},
	deactivated() {
		this.actives = 0;
	},
	methods: {
		insetinto(data) {
			if (data === this.indexkey) {
				this.indexkey = '';
			} else {
				this.indexkey = data;
			}
		},
		fromatindex(data, val) {
			this.actives = data;
			this.listkey = this.fromlist[val];
		},
		getdata(data, group_id) {
			api.match_index_score_detail({
				match_id: this.$store.state.match_id,
				athlete_id: data,
				type_id: this.type_id,
				group_id: group_id
			}).then(res => {
				if (res) {
					this.userfrom = res;
					this.arrlist = res.bout_names;
					this.fromlist = res.bouts;
					this.stand = res.stand.split(',');
					if (this.actives == 0) {
						let num = this.arrlist[0];
						for (let item in this.fromlist) {
							this.fromlist[item].map(jtem => {
								jtem.score.users &&
									jtem.score.users.map(jtkey => {
										jtkey.score = jtkey.score.split(',');
									});
							});
						}
						this.listkey = this.fromlist[num];
					}
				} else {
					this.$toast(res.data.msg);
				}
			});
		}
	}
};
</script>
<style scoped></style>
<style scoped lang="scss">
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;
.red {
	color: #ff4b38;
}
.ct {
	display: flex;
	justify-content: center;
	align-items: center;
}
.laoying {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 14px;
		height: 14px;
		border: 1px solid #78ac0a;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.xiaoniao {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
}
.paji1 {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	display: flex;
	justify-content: center;
	align-items: center;
}
.add3 {
	width: 100%;
	height: 100%;
	background: #ffe96c;
	display: flex;
	justify-content: center;
	align-items: center;
}
.paji2 {
	width: 18px;
	height: 18px;
	border: 1px solid #78ac0a;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 14px;
		height: 14px;
		border: 1px solid #78ac0a;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.yishang {
	width: 18px;
	height: 18px;
	background: #ffe96c;
}
.mianbont {
	width: 100%;
	display: flex;
	height: 34px;
	font-size: 10px;
	background: #e9e9e9;
	color: #404a4e;
	.liietm {
		width: 20%;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		.mins {
			margin-left: 7px;
		}
	}
}
.topsklig {
	width: 100%;
	padding: 2% 0 0 0;
	height: auto;
}
.miannav {
	width: 100%;
	.miatops {
		width: 100%;
		height: 34px;
		display: flex;
		justify-content: space-between;
		color: #ffffff;
		font-size: 10px !important;
		.mianlimt {
			width: calc(90% - 0.1px);
			display: flex;
			justify-content: space-between;
			.mianconst {
				width: calc(9.2% - 0.1px);
				height: 100%;
				background: #a4b0c6;
			}
			.mianleft {
				width: 15%;
				height: 100%;
				background: #a4b0c6;
			}
		}
		.mianrigth {
			width: 10%;
			height: 100%;
			background: #a4b0c6;
		}
	}
	.miands {
		width: 100%;
		display: flex;
		justify-content: space-between;
		background: #f0f3f7;
		color: #404a4e;
		font-size: 10px !important;
		.miandsleft {
			width: calc(90% - 0.1px);
			height: inherit;
			&:nth-child(odd) {
				.mianall {
					margin-top: 1px;
				}
			}
			.mianall {
				width: 100%;
				display: flex;
				justify-content: space-between;
				.mianconst {
					width: calc(9.2% - 0.1px);
					height: 34px;
					background: #ffffff;
				}
				.mianleft {
					width: 15%;
					height: 34px;
					background: #ffffff;
				}
			}
		}
		.miandsrigth {
			width: 10%;
			height: inherit;
			background: #ffffff;
		}
	}
	.conlims {
		width: 100%;
		height: 34px;
		display: flex;
		justify-content: space-between;
		color: #083054;
		font-size: 10px !important;
		.mianlimt {
			width: calc(90% - 0.1px);
			display: flex;
			justify-content: space-between;
			.mianconst {
				width: calc(9.2% - 0.1px);
				height: 100%;
				background: #cbd4e1;
			}
			.mianleft {
				width: 15%;
				height: 100%;
				background: #cbd4e1;
			}
		}
		.mianrigth {
			width: 10%;
			height: 100%;
			background: #cbd4e1;
		}
	}
}
.contns {
	width: 100%;
	.topcontns {
		width: 100%;
		display: flex;
		height: 44px;
		justify-content: space-between;
		color: #ffffff;
		background: #c1c1c1;
		font-size: 12px;
		.mianleft {
			width: 20%;
			height: 100%;
			background: #a4b0c6;
		}
		.miaconas {
			width: calc(40% - 1px);
			height: 100%;
			background: #a4b0c6;
		}
		.mianright {
			width: calc(40% - 1px);
			height: 100%;
			background: #a4b0c6;
		}
	}
	.topcontnsling {
		width: 100%;
		.limsg {
			width: 100%;
			display: flex;
			height: 49px;
			font-size: 14px;
			justify-content: space-between;
			background: #c1c1c1;
			color: #404a4e;
			&:nth-child(even) {
				.miaconas {
					background: #ebeff5 !important;
				}
				.mianright {
					background: #ebeff5 !important;
				}
				.mianleft {
					background: #cbd4e1 !important;
				}
			}
			.mianleft {
				width: 20%;
				height: 100%;
				background: #e9e9e9;
			}
			.miaconas {
				width: calc(40% - 1px);
				height: 100%;
				background: #f7f7f7;
			}
			.mianright {
				width: calc(40% - 1px);
				height: 100%;
				background: #f7f7f7;
			}
		}
	}
}

.active {
	background: #78ac0a;
	color: #ffffff !important;
}

.dja {
	display: flex;
	justify-content: center;
	align-items: center;
}

.lisfromdata {
	width: 100%;
	height: 100vh;
	background: #f5f5f5;

	.tonmian {
		background: #f5f5f5;
		.mianke {
			width: 100%;
			height: 34px;
			color: #ffffff;
			background: #ccd4e1;
			font-size: 14;
		}
		.top_limt {
			width: 98%;
			padding: 0 1%;
			background: #ffffff;
			height: 34px;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			color: #343434;
			.numlit {
				width: 25px;
				height: 1.5625rem;
				border-radius: 5px;
				border: 1px solid #78ac0a;
				margin-left: 20px;
				color: #78ac0a;
				&:nth-child(1) {
					margin-left: 10px;
				}
			}
		}
	}

	.mytitle {
		width: 100%;
		padding: 15px 0;
		.titlekey {
			width: 100%;
			background: #ffffff;
			height: 65px;
			display: flex;
			justify-content: center;
			align-items: center;
			color: #1e2228;
			.mian_left {
				width: 60%;
				height: 100%;
				font-size: 14px;
				.confonst {
					color: #9b9b9b;
				}
				.miantitle {
					margin-left: 10px;
				}
			}
		}
	}
}
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
