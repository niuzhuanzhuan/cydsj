<template>
	<div class="imgasall" ref="mianall" @scroll="roll">
		<div class="initmian">
			<div class="insets">
				<van-swipe class="top" v-if="fromdatalist.length != 0">
					<van-swipe-item v-for="(item, index) in fromdatalist" :key="index"><van-image :src="item" fit="cover" height="210" /></van-swipe-item>
				</van-swipe>
				<van-empty class="top" v-else description="图片直播火速赶来与您汇合,敬请期待" />
				<div class="miantitle" v-if="msg.title">
					<div class="mialis">{{ msg.title }}</div>
				</div>
				<div class="clickdata">
					<div>
						<!-- <img src="@/assets/imgamo/hemo/ingm.png" /> -->
						<van-icon name="photo-o" />
						<span>{{ msg.count ? msg.count : 0 }}</span>
					</div>
					<div>
						<!-- <img src="@/assets/imgamo/hemo/esoo.png" />
						<span>{{ msg.hits ? msg.hits : 0 }}</span> -->
					</div>
					<div>
						<!-- <img src="@/assets/imgamo/hemo/esoo.png" /> -->
						<van-icon name="eye-o" />
						<span>{{ msg.hits ? msg.hits : 0 }}</span>
					</div>
				</div>
			</div>
		</div>
		<div class="textA switchA">
			<div :class="choose == 1 ? 'activeA' : ''" @click="choose = 1">图片</div>
			<div :class="choose == 2 ? 'activeA' : ''" @click="choose = 2" style="width: 100px">时间轴</div>
			<div :class="choose == 3 ? 'activeA' : ''" @click="choose = 3">热门</div>
		</div>
		<van-pull-refresh v-model="refreshing" @refresh="onRefresh">
			<van-list
				:finished="finished"
				:immediate-check="false"
				:offset="10"
				@load="onLoadImg"
				direction="down"
				finished-text="没有更多了"
				v-model="loading"
				v-show="choose == 1"
			>
				<div class="tupic">
					<div style="margin-right: 0.5% ;width: 49.5%;">
						<van-image :key="index" width="100%" :src="item.path" class="itemImg" fit="contain" v-for="(item, index) in imgList1" @click="imgkey(item.path, item.id)" />
					</div>
					<div style="margin-left: 0.5; width: 49.5%;">
						<van-image :key="index" width="100%" :src="item.path" class="itemImg" fit="contain" v-for="(item, index) in imgList2" @click="imgkey(item.path, item.id)" />
					</div>
				</div>
			</van-list>
			<van-list
				:finished="finished"
				:immediate-check="false"
				:offset="10"
				@load="onLoadImg"
				direction="down"
				finished-text="没有更多了"
				style=" margin-bottom: 10vh;    padding-top: 10px;background: #FFFFFF;"
				v-model="loading"
				v-show="choose == 2"
			>
				<div class="tupic2">
					<div v-for="(item, index) in imgList" :key="index">
						<div style="display: flex;padding: 10px 0;">
							<div class="imgsli">
								{{ item.time.substring(0, 10) }}
								<div class="limts">{{ item.time.substring(10) }}</div>
							</div>
						</div>
						<div style="display: flex;flex-direction: row;flex-wrap: wrap;margin: 0 6%;">
							<van-image
								:key="index"
								:src="item2.filepath"
								class="itemImg2"
								fit="fill"
								lazy-load
								v-for="(item2, index) in item.list"
								@click="imgtowkey(item, item2.filepath, item2.id)"
							/>
						</div>
					</div>
				</div>
			</van-list>
			<van-list
				:finished="finished1"
				:immediate-check="false"
				:offset="10"
				@load="onLoadhot"
				direction="down"
				finished-text="没有更多了"
				style=" margin-bottom: 10vh; background: #FFFFFF;"
				v-model="loading1"
				v-show="choose == 3"
			>
				<div class="linaimg" v-for="(item, index) in hotlist" :key="index">
					<div class="litops" @click="arrlisnt(item)">
						<div class="imnlist"><van-image fit="cover" width="100%" height="186" :src="item.src" /></div>
						<div class="lisnt">
							<div class="lisnmain">
								<img :id="'img' + index" src="@/assets/imgamo/hemo/esoo.png" />
								{{ item.visit }}
							</div>
						</div>
					</div>
				</div>
			</van-list>
		</van-pull-refresh>
	</div>
</template>

<script>
import api from '@/utils/api';
import { mapActions } from 'vuex';
import wx from 'weixin-js-sdk';
import wxdonwimge from '@/components/wxdonwimge.js';
export default {
	data() {
		return {
			choose: 1,
			page: 1,
			page2: 1,
			refreshing: false,
			loading: false,
			finished: false,
			loading1: false,
			finished1: false,
			imgList: [],
			imgList1: [],
			imgList2: [],
			msg: {
				imgs: []
			},
			index: 0,
			hotlist: [],
			timemisr: null,
			fromdatalist: []
		};
	},
	deactivated() {
		localStorage.removeItem('scrollTop');
	},
	computed: {
		match_id() {
			return this.$store.state.match_id;
		}
	},
	activated() {
		if (localStorage['scrollTop']) {
			this.$nextTick(() => {
				this.$refs.mianall.scrollTop = localStorage['scrollTop'];
			});
		}
	},
	watch: {
		match_id(newval, val) {
			if (newval != val) {
				this.page = 1;
				this.page2 = 1;
				this.imgList = [];
				this.imgList1 = [];
				this.imgList2 = [];
				this.hotlist = [];
			}
		}
	},
	methods: {
		roll() {
			this.$nextTick(() => {
				let scrollTop = this.$refs.mianall.scrollTop;
				let windowHeight = this.$refs.mianall.clientHeight;
				let scrollHeight = this.$refs.mianall.scrollHeight;
				localStorage['scrollTop'] = scrollTop;
			});
		},
		...mapActions(['displayimgs', 'displayimgsindex']),
		imgkey(data, id) {
			let arrlist = [];
			this.imgList.map(item => {
				item.list.map(jtem => {
					arrlist.push(jtem.filepath);
				});
			});
			arrlist.map((item, index) => {
				if (item === data) {
					this.displayimgsindex(index);
				}
			});
			this.displayimgs(arrlist);
			this.$router.push('/match/displayimg');
			api.imghits({ id: id }).then(res => {});
		},
		onRefresh() {
			this.finished = false;
			this.page = 1;
			this.page2 = 1;
			this.imgList = [];
			this.imgList1 = [];
			this.imgList2 = [];
			this.hotlist = [];
			this.getImgDataList().getHotImgList();
		},
		onLoadImg() {
			this.settime(this.getImgDataList, 500);
		},
		onLoadhot() {
			this.settime(this.getHotImgList, 500);
		},
		settime(funfion, stops) {
			if (this.timemisr) {
				clearTimeout(this.timemisr);
			}
			this.timemisr = setTimeout(() => {
				funfion();
				this.timemisr = undefined;
			}, stops);
		},
		getImgDataList() {
			let data = {
				page: this.page,
				match_id: this.$store.state.match_id
			};
			api.getImgList(data)
				.then(res => {
					this.page++;
					let imgList = [];
					imgList = res.data;
					let imgList2 = [];
					imgList.forEach(i => {
						imgList2 = imgList2.concat(i.list);
					});
					imgList2.forEach((i, index) => {
						if (index % 2 === 0) {
							this.imgList1.push({ path: i.filepath, id: i.id });
						} else {
							this.imgList2.push({ path: i.filepath, id: i.id });
						}
					});
					this.msg = res.info;
					this.fromdatalist = this.msg.imgs;
					this.imgList = this.imgList.concat(imgList);
					this.loading = false;
					if (imgList.length >= 5) {
						this.finished = false;
					} else {
						this.finished = true;
					}
					this.refreshing = false;
				})
				.catch(err => {
					console.log(err);
				});
			return this;
		},
		getHotImgList() {
			let data = {
				page: this.page2,
				match_id: this.$store.state.match_id
			};
			api.getHotImg(data)
				.then(res => {
					if (res.data.length != 0) {
						this.page2++;
						let arr = [];
						res.data.map(item => {
							this.hotlist.push(item);
						});
						this.finished1 = false;
						this.refreshing = false;
						this.loading1 = false;
					} else {
						this.finished1 = true;
						// this.page2 -= 1;
						this.refreshing = false;
					}
				})
				.catch(err => {
					console.log(err);
				});
			return this;
		},
		arrlisnt(data) {
			let arrlist = [];
			this.hotlist.forEach(item => {
				arrlist.push(item.src);
			});
			arrlist.forEach((item, index) => {
				if (item === data.src) {
					this.displayimgsindex(index);
				}
			});
			this.displayimgs(arrlist);
			this.$router.push('/match/displayimg');
			api.imghits({ id: data.id });
			data.visit += 1;
		},
		imgtowkey(data, index, id) {
			let arr = data.list.map(item => item.filepath);
			arr.map((item, indexs) => {
				if (item === index) {
					this.displayimgsindex(indexs);
				}
			});
			this.displayimgs(arr);
			this.$router.push('/match/displayimg');
			api.imghits({ id: id });
		}
	}
};
</script>
<style>
.wrapper {
	display: flex;
	align-items: center;
	justify-content: center;
	height: 100%;
}

.block {
	width: 120px;
	height: 120px;
}
</style>
<style lang="scss" scoped>
.initmian {
	width: 94%;
	height: auto;
	padding: 3%;
	background: #f6f6f6;
	.insets {
		width: 100%;
		height: auto;
		background: #ffffff;
		border-radius: 10px;
		overflow: hidden;
		.miantitle {
			width: 92%;
			padding: 3% 4% 0 4%;
			overflow: hidden;
			.mialis {
				width: 100%;
				font-size: 15px;
				font-weight: bold;
				color: #333333;
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 3;
				overflow: hidden;
			}
		}
	}
}
.linaimg {
	margin-top: 10px;
	width: 90%;
	height: 224px;
	padding: 0 5%;
	.litops {
		width: 100%;
		height: 100%;
		border-radius: 0 0 10px 10px;
		box-shadow: 0px 4px 5px 0px rgba(233, 233, 233, 0.6);
		.imnlist {
			border-radius: 10px 10px 0 0;
			overflow: hidden;
		}
		.lisnt {
			width: 100%;
			height: 38px;
			display: flex;
			align-items: center;
			justify-content: flex-end;
			.lisnmain {
				height: 38px;
				display: flex;
				align-items: center;
				margin-right: 34px;
				color: #999999;
				font-size: 12px;
				img {
					margin-right: 5px;
				}
			}
		}
	}
}
.top {
	height: 210px;
}

.topImg {
	height: inherit;
	width: 100%;
}

.textA {
	width: 92%;
	margin-left: 4%;
	margin-right: 4%;
	display: flex;
	flex-direction: row;
}

.titleA {
	width: inherit;
	min-height: 35px;
	font-size: 16px;
	font-weight: bold;
	color: rgba(50, 50, 40, 1);
	line-height: 25px;
}

.clickdata {
	font-size: 12px;
	color: rgba(128, 128, 128, 1);
	display: flex;
	width: 94%;
	padding: 3%;
}

.clickdata div {
	width: 33%;
	display: flex;
	justify-content: center;
	align-items: center;
	i {
		font-size: 16px;
		margin-right: 5px;
	}
}

.switchA {
	width: inherit;
	height: 35px;
	font-size: 16px;
	font-family: Microsoft YaHei UI;
	font-weight: 400;
	color: rgba(128, 128, 128, 1);
	line-height: 35px;
	text-align: center;
	margin-top: 5px;
}

.activeA {
	color: #78ac06;
}

.itemImg {
	width: 100%;
	margin-right: 1%;
}

.itemImg2 {
	width: 64px;
	height: 64px;
	margin-right: 2px;
	margin-bottom: 2px;
}

.imgasall {
	width: 100%;
	height: 100%;
	overflow: hidden;
}

.tupic {
	display: flex;
	flex-direction: row;
}

.tupic2 {
	background: #ffffff;
	display: flex;
	flex-direction: column;
	width: 100%;
	.imgsli {
		display: flex;
		width: auto;
		padding: 8px 15px;
		background: rgba(248, 91, 70, 0.1);
		border-radius: 0px 30px 30px 0px;
		font-size: 14px;
		color: #f85b46;
		.limts {
			margin-left: 10px;
			font-size: 12px;
			display: flex;
			align-items: flex-end;
		}
	}
}
</style>
