<template>
	<div class="mianlins">
		<div class="bas"></div>
		<div class="mianinits">
			<div class="listitle">
				<div :class="activemian ? 'active' : ''" @click="activemian = true">视频直播</div>
				<div :class="activemian ? '' : 'active'" @click="activemian = false">精彩回放</div>
			</div>
			<div class="mianlist">
				<lives v-show="activemian == true" ref="lives" />
				<playback v-show="activemian == false" ref="playback" />
			</div>
		</div>
	</div>
</template>

<script>
import lives from './components/lives';
import playback from './components/playback';
export default {
	data() {
		return {
			activemian: true
		};
	},
	components: {
		lives,
		playback
	},
	activated() {
		if (!this.activemian) {
			this.$nextTick(() => {
				this.$refs.playback.getdata();
			});
		}
	},
	watch: {
		activemian(newval, val) {
			if (newval != val) {
				if (!newval) {
					this.$nextTick(() => {
						this.$refs.playback.getdata();
					});
				} else {
					this.$nextTick(() => {
						this.$refs.lives.getdata();
					});
				}
			}
		}
	}
};
</script>
<style></style>
<style lang="scss" scoped>
.active {
	color: #78ac06 !important;
}
.mianlins {
	width: 100%;
	.bas {
		background: #f5f5f5;
		width: 100%;
		height: 10px;
	}
	.mianinits {
		width: 94%;
		padding: 3%;
		.mianlist {
			padding: 3% 0;
			width: 100%;
		}
		.listitle {
			display: flex;
			font-size: 15px;
			div {
				margin-left: 31px;
				color: #999999;
				cursor: pointer;
				user-select: none;
				&:nth-child(2) {
					margin-left: 38px;
				}
			}
		}
	}
}
</style>
