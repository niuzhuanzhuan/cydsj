<template>
	<div class="mianli">
		<div class="initkey" v-for="(item, index) in datalist" :key="index">
			<div class="mialikey" @click="hits(item)">
				<div class="lileft">
					<div class="linst">
						<div class="inittlie">{{ item.title }}</div>
					</div>
					<div class="listbonst">
						<div>{{ item.create_time }}</div>
						<div>
							<img src="@/assets/imgamo/hemo/esoo.png" />
							{{ item.hits }}
						</div>
					</div>
				</div>
				<div class="inimgs">
					<van-image width="100" height="70" fit="contain" :src="item.img" />
					<div class="mianlit"><img src="@/assets/asso/home/play.png" /></div>
				</div>
			</div>
		</div>
		<van-empty v-if="datalist.length == 0" description="暂无回放记录信息" />
	</div>
</template>

<script>
export default {
	data() {
		return {
			datalist: [],
			ispan: 1
		};
	},
	activated() {
		sessionStorage.removeItem('pczhi');
		if (this.ispan != 1) {
			this.getdata();
		}
	},
	methods: {
		async getdata() {
			const datalist = await this.$api.video({ match_id: this.$store.state.match_id });
			datalist && (this.datalist = datalist);
		},
		async hits(data) {
			const datalist = await this.$api.video_hits({
				match_id: this.$store.state.match_id,
				id: data.id
			});
			data.hits += 1;
			this.$router.push('/match/keyvideo');
			sessionStorage['pczhi'] = JSON.stringify(data);
			this.ispan += 1;
		}
	}
};
</script>

<style scoped lang="scss">
.mianli {
	width: 100%;
	.initkey {
		width: 100%;
		height: 100px;
		border-bottom: 1px solid #f0f0f0;
		display: flex;
		align-items: center;
		cursor: pointer;
		.mialikey {
			width: 100%;
			height: 70px;
			display: flex;
			.lileft {
				width: calc(100% - 100px);
				height: 100%;
				.listbonst {
					width: 100%;
					height: 25px;
					color: #666666;
					display: flex;
					align-items: flex-end;
					font-size: 12px;
					div {
						&:nth-child(2) {
							margin-left: 60px;
							display: flex;
							align-items: center;
							img {
								margin-right: 5px;
							}
						}
					}
				}
				.linst {
					width: 95%;
					padding-right: 5;
					height: 45px;
					display: flex;
					align-items: center;
					.inittlie {
						font-size: 14px;
						color: #333333;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
						overflow: hidden;
					}
				}
			}
			.inimgs {
				width: 100px;
				height: 70px;
				border-radius: 8px;
				overflow: hidden;
				position: relative;
				.mianlit {
					position: absolute;
					width: 100%;
					top: 0;
					height: 100%;
					display: flex;
					justify-content: center;
					align-items: center;
					z-index: 99;
					img {
						width: 18px;
						height: 18px;
					}
				}
			}
		}
	}
}
</style>
