<template>
	<div class="mians">
		<div class="intlis"  v-for="(item, index) in datalist" @click="getlink(item)" :key="index">
			<van-image fit="fill" :src="item.img" />
			<div class="miantop">
				<img src="@/assets/imgamo/hemo/dong.gif" />
				正在直播
			</div>
			<div class="baonmi">
				<div class="frons">{{ item.name }}</div>
			</div>
		</div>
		<van-empty v-if="datalist.length == 0" description="暂无直播信息" />
	</div>
</template>

<script>
export default {
	data() {
		return {
			datalist: []
		};
	},
	methods: {
		async getdata() {
			const datalist = await this.$api.livelist({ match_id: this.$store.state.match_id });
			if (datalist) {
				this.datalist = datalist.list;
				// console.log(this.datalist)
			}
		},
		getlink(item) {
			sessionStorage['videos'] = JSON.stringify(item);
			this.$router.push('/match/videos');
		}
	},
	created() {}
};
</script>

<style scoped lang="scss">
.mians {
	width: 100%;
	.intlis {
		width: 100%;
		height: 210px;
		margin-bottom: 10px;
		border-radius: 6px;
		overflow: hidden;
		position: relative;
		cursor: pointer;
		.miantop {
			position: absolute;
			top: 0;
			width: 90%;
			padding: 5%;
			color: #ff5932;
			font-size: 15px;
			display: flex;
			align-items: center;
			img {
				margin-right: 10px;
			}
		}
		.baonmi {
			position: absolute;
			bottom: 0;
			width: 96%;
			padding: 0 2%;
			height: 54px;
			background: rgba(0, 0, 0, 0.3);
			color: #ffffff;
			font-size: 15px;
			display: flex;
			align-items: center;
			.frons {
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 2;
				overflow: hidden;
			}
		}
	}
}
</style>
