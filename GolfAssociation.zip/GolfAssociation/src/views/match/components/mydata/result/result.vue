<template>
	<div class="miansall">
		<div class="answer">
			<div class="lisfromdata">
				<van-nav-bar left-text="成绩查询" left-arrow @click-left="onClickLeft" />
				<div class="miand" v-if="types.length > 0">
					<van-tabs type="card" v-model="cardNames" title-active-color="#ffffff" title-inactive-color="#78ac09" color="#78ac09">
						<van-tab v-for="(item, index) in types" :key="index" :title="item.name"></van-tab>
					</van-tabs>
				</div>

				<personal v-show="choice == 1" ref="personals" />
				<teamde v-show="choice == 3" ref="teamdes" />
				<fourteamde v-show="choice == 4" ref="fourteamdes" />
				<van-empty v-if="types.length == 0" description="暂无成绩信息" />
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import bus from '@/components/bus.js';
import personal from './personal.vue';
import teamde from './teamde.vue';
import fourteamde from './fourteamde.vue';
export default {
	data() {
		return {
			datalist: [],
			cardNames: '',
			types: [],
			choice: '',
			personalnum: 1, //控制个人请求一次
			teamdesnum: 1, //控制2人请求一次
			fourteanum: 1 //控制4人请求一次
		};
	},
	activated() {
		this.getdata();
	},
	watch: {
		cardNames(newval, val) {
			if (newval != val) {
				this.choice = this.types[newval].type;
				if (this.types[newval].type === 1) {
					if (this.personalnum == 1) {
						this.$nextTick(() => {
							this.$refs.personals.getdata(this.types[newval]);
						});
						this.personalnum += 1;
					}
				}
				if (this.types[newval].type === 3) {
					if (this.teamdesnum == 1) {
						this.$nextTick(() => {
							this.$refs.teamdes.getdata(this.types[newval]);
							this.teamdesnum += 1;
						});
					}
				}
				if (this.types[newval].type === 4) {
					if (this.fourteanum == 1) {
						this.$nextTick(() => {
							this.$refs.fourteamdes.getdata(this.types[newval]);
							this.fourteanum += 1;
						});
					}
				}
			}
		}
	},
	components: {
		personal,
		teamde,
		fourteamde
	},
	methods: {
		async getdata() {
			const datalist = await this.$api.golf_mine({
				match_id: this.$store.state.match_id
			});
			if (datalist) {
				if(datalist.types){
					this.types = datalist.types;
					this.obtain(this.types[0]);
				}
			}
		},
		obtain(data) {
			this.choice = data.type;
			if (data.type === 1) {
				this.$nextTick(() => {
					this.$refs.personals.getdata(data);
				});
			}
			if (data.type === 3) {
				this.$nextTick(() => {
					this.$refs.teamdes.getdata(data);
				});
			}
			if (data.type === 4) {
				this.$nextTick(() => {
					this.$refs.fourteamdes.getdata(data);
				});
			}
		},
		onClickLeft() {
			this.$router.go(-1);
		}
	}
};
</script>
<style scoped>
.lisfromdata >>> .van-tabs .van-tabs__nav--card {
	margin: 0;
	height: 40px !important;
}
.lisfromdata >>> .van-tabs .van-tabs__wrap {
	height: 40px !important;
}
</style>
<style scoped lang="scss">
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;
.lisfromdata {
	width: 100%;
	height: 100vh;
	background: #f2f2f2;
	.miand {
		width: 100%;
		height: 40px;
		background: #ffffff;
		margin: 15px 0 10px 0;
		padding: 15px 0;
	}
}
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
