<template>
	<div class="pall" v-cloak>
		<div class="topban">
			<img src="./imgs/banner.png" />
			<div class="moantitle">
				<div class="mianall">
					<div class="miand" @click="logins">
						<div class="finas"><img :src="fromdata.avatar" /></div>
					</div>
					<div class="fonname">{{ fromdata.name ? fromdata.name : '点击头像获取登录信息' }}</div>
				</div>
			</div>
		</div>
		<div class="navall">
			<!-- <div class="navnoe" @click="selects">
				<div class="itemkeys">
					<div><img src="./imgs/gongbu.png" /></div>
					<div>成绩查询</div>
					<div><van-icon name="arrow" /></div>
				</div>
			</div> -->
			<div class="navnoe" @click="$router.push('/match/notice')">
				<div class="itemkeys">
					<div><img src="./imgs/gonggao.png" /></div>
					<div>公告</div>
					<div><van-icon name="arrow" /></div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import wx from 'weixin-js-sdk';
import { mapActions } from 'vuex';
export default {
	data() {
		return {
			fromdata: {},
			prohibit: 1,
			display: false,
			msg: ''
		};
	},
	methods: {
		...mapActions(['setnums', 'actionsSetGoPath']),
		setwach() {
			api.ga_mine({
				asso_id: this.$store.state.match_id
			}).then(res => {
				this.fromdata = res;
				this.prohibit = 2;
				this.setnums(2);
			});
		},
		getdata() {
			if (this.$store.state.token) {
				this.setwach();
				this.display = true;
			} else {
				if (sessionStorage['WeChat'] == 1) {
					this.$dialog
						.confirm({
							title: '提示',
							message: '您当前未登录，是否前去登录'
						})
						.then(() => {
							wx.miniProgram.navigateTo({ url: '/pages/login/login?path=sports' });
						})
						.catch(() => {
							// on cancel
						});
				} else {
					this.$dialog
						.confirm({
							title: '提示',
							message: '您当前未登录，是否前去登录'
						})
						.then(() => {
							this.actionsSetGoPath('/match/my');
							this.$router.push('/match/userLogin');
						})
						.catch(() => {
							// on cancel
						});
				}
			}
		},
		selects() {
			if (this.display) {
				this.$router.push('/match/result');
			} else {
				this.$toast(this.msg ? this.msg : '您当前未登录,请先登录在进行操作');
			}
		},
		logins() {
			if (this.prohibit == 1) {
				if (sessionStorage['WeChat'] == 1) {
					this.$dialog
						.confirm({
							title: '提示',
							message: '您当前未登录，是否前去登录'
						})
						.then(() => {
							wx.miniProgram.navigateTo({ url: '/pages/login/login?path=sports' });
						})
						.catch(() => {
							// on cancel
						});
				} else {
					this.$dialog
						.confirm({
							title: '提示',
							message: '您当前未登录，是否前去登录'
						})
						.then(() => {
							this.actionsSetGoPath('/match/my');
							this.$router.push('/match/userLogin');
						})
						.catch(() => {
							// on cancel
						});
				}
			}
		}
	},
	activated() {
		this.getdata();
	}
};
</script>
<style></style>
<style lang="scss" scoped>
.pall {
	width: 100%;
	height: 100vh;
	overflow: auto;
	background: #f2f2f2;
	.navall {
		margin-top: 14px;
		width: 100%;
		.navnoe {
			margin-top: 1px;
			width: 90%;
			height: 70px;
			padding: 0 5%;
			background: #ffffff;
			display: flex;
			align-items: center;
			.itemkeys {
				width: 100%;
				display: flex;
				height: 24px;
				div {
					display: flex;
					align-items: center;
					height: 100%;
					font-size: #2e2e2e;
					font-size: 14px;
					i {
						font-size: 16px;
						color: #898989;
					}
					&:nth-child(1) {
						width: 10%;
						img {
							width: 24px;
						}
					}
					&:nth-child(2) {
						width: 80%;
					}
					&:nth-child(3) {
						width: 10%;
						justify-content: flex-end;
					}
				}
			}
		}
	}
	.topban {
		width: 100%;
		position: relative;
		img {
			width: 100%;
		}
		.moantitle {
			position: absolute;
			top: 0;
			width: 100%;
			height: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			.mianall {
				.miand {
					display: flex;
					justify-content: center;
					align-items: center;
					.finas {
						width: 80px;
						height: 80px;
						background: #ffffff;
						border-radius: 50%;
						display: flex;
						justify-content: center;
						align-items: center;
						img {
							width: 76px;
							height: 76px;
							border-radius: 50%;
						}
					}
				}
				.fonname {
					margin-top: 10px;
					display: flex;
					justify-content: center;
					align-items: center;
					font-size: 16px;
					color: #ffffff;
				}
			}
		}
	}
}
</style>
