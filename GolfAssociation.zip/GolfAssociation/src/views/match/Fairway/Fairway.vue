<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar title="球道介绍" left-arrow @click-left="onClickLeft" />
			<div class="tab">
				<div :class="active ? 'tab1' : 'tab1 tab-active'" @click="active = false">前九洞</div>
				<div :class="active ? 'tab1 tab-active' : 'tab1'" @click="active = true">后九洞</div>
			</div>
			<div class="fronimgas" v-if="active == false"><img :src="datalist[0]" /></div>
			<div class="fronimgas" v-else><img :src="datalist[1]" /></div>
			<div style="height: 30px;"></div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'surface',
	data() {
		return {
			active: false,
			loading: false,
			datalist:[]
		};
	},
	activated() {
		this.getdata();
	},
	methods: {
		async getdata(){
			const datalist =await this.$api.match_yard({ match_id: this.$store.state.match_id })
			datalist&&(this.datalist=datalist.images)
		},
		onClickLeft() {
			this.$router.back(-1);
		}
	}
};
</script>
<style scoped></style>
<style scoped lang="scss">
$cocrs: #68970e;
$cofs: #9599ad;
$coba: #041728;
$cobadi: #0a2339;
$fs12: 12px;

.fronimgas {
	width: 100%;
	display: flex;
	justify-content: center;

	img {
		margin-top: 36px;
		display: inline-block;
		width: 100%;
	}
}

.tab {
	height: 40px;
	line-height: 40px;
	width: 100%;
	display: flex;
	flex-direction: row;
}

.tab1 {
	flex: 1;
	text-align: center;
	border: solid 1px #79aa0a;
	color: #79aa0a;
}

.tab-active {
	color: white;
	background: #79aa0a;
}

@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;

		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
