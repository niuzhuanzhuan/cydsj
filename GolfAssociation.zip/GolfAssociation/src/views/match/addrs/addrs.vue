<template>
	<div class="answer">
		<van-nav-bar title="����" left-text="返回" left-arrow @click-left="onClickLeft" />
		<el-amap vid="amapDemo" :zoom="14" :center="url" class="amap-demo">
			<el-amap-circle
				v-for="(circle, index) in circles"
				:key="index"
				:center="circle.center"
				:radius="circle.radius"
				:fill-opacity="circle.fillOpacity"
				:events="circle.events"
			></el-amap-circle>
		</el-amap>
	</div>
</template>

<script>
export default {
	name: 'addrs',
	data() {
		return {
			url: [],
			circles: [
				{
					center: [],
					radius: 200,
					fillOpacity: 0.5,
					events: {
						click: () => {}
					}
				}
			]
		};
	},
	mounted() {
		this.url[0] = this.$route.query.lat;
		this.url[1] = this.$route.query.lng;
		this.circles[0].center = this.url;
	},
	methods: {
		onClickLeft() {
			this.$router.go(-1);
		}
	}
};
</script>

<style scoped lang="scss">
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.answer {
		width: 37.5rem;
		height: 100vh;
		overflow: auto;
	}
}
</style>
