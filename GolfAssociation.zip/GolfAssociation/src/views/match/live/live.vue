<template>
	<div class="pages">
		<div class="mianall">
			<van-nav-bar title="图片视频直播" left-arrow @click-left="$router.back(-1)" />
			<div class="tab">
				<div :class="active ? 'tab1' : 'tab1 tab-active'" @click="active = false">图片直播</div>
				<div :class="active ? 'tab1 tab-active' : 'tab1'" @click="active = true">视频直播</div>
			</div>
			<imgmodular v-show="!active" ref="imgkeyt" />
			<broad v-show="active" ref="videos" />
		</div>
	</div>
</template>

<script>
import imgmodular from '@/views/match/components/imgmodular/imgmodular';
import broad from '@/views/match/components/broadcast/broad';
export default {
	data() {
		return {
			active: false
		};
	},
	components: {
		imgmodular,
		broad
	},
	activated() {
		if (this.active) {
			this.$nextTick(() => {
				this.$refs.videos.$refs.lives.getdata();
			});
		} else {
			this.$nextTick(() => {
				this.$refs.imgkeyt.getImgDataList().getHotImgList();
			});
		}
	},
	watch: {
		active(newval, val) {
			if (newval != val) {
				if (newval) {
					this.$nextTick(() => {
						this.$refs.videos.$refs.lives.getdata();
					});
				} else {
					console.log(0)
					this.$nextTick(() => {
						this.$refs.imgkeyt.getImgDataList().getHotImgList();
					});
				}
			}
		}
	},
	methods: {
		frommian(val) {
			if (val == 1) {
				this.active = false;
			} else {
				this.active = true;
			}
		}
	}
};
</script>

<style scoped lang="scss">
@media screen and (max-width: 768px) {
	.pages {
		width: 100vw;
		min-height: 100vh;
		background: #ffffff;
	}
}

@media screen and (min-width: 768px) {
	.pages {
		width: 100%;
		height: 100vh;
		display: flex;
		justify-content: center;
		background: #ffffff;
		.mianall {
			width: 768px;
		}
	}
}
.tab {
	height: 40px;
	line-height: 40px;
	width: 100%;
	display: flex;
	flex-direction: row;
}

.tab1 {
	flex: 1;
	text-align: center;
	border: solid 1px #79aa0a;
	color: #79aa0a;
	background: #ffffff;
}

.tab-active {
	color: white;
	background: #79aa0a;
}
</style>
