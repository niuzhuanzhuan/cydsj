<template>
	<div class="login-page">
		<div class="login-page2">
			<van-cell-group>
				<van-field
					:error-message="phoneErrorMsg"
					center
					clearable
					label="手机号："
					left-icon="contact"
					maxlength="11"
					placeholder="请输入手机号"
					type="number"
					v-model="phone"
				>
					<van-button @click="verificationCode" class="login-code" id="timing" plain size="small" slot="button" square type="default">发送验证码</van-button>
				</van-field>
				<van-field center clearable label="短信验证码：" placeholder="请输入短信验证码" type="number" v-model="msgCode" maxlength="6" left-icon="passed" />
			</van-cell-group>
			<div class="login"><van-button @click="login" class="login-btn" color="red" round type="default">登录</van-button></div>
		</div>
		<van-dialog title="易动提示" v-model="show" :message="errorMsg" @confirm="confirm" />
		<van-nav-bar class="loginTop" title="登录" left-text="返回" @click-left="onClickLeft" left-arrow />
	</div>
</template>

<script>
import qs from 'qs';
import { Toast } from 'vant';
import api from '@/utils/api';
import { mapActions, mapState } from 'vuex';
export default {
	name: 'userLogin',
	data() {
		return {
			phone: '',
			msgCode: '',
			phoneErrorMsg: '',
			timeCode: 0,
			show: false,
			errorMsg: ''
		};
	},
	created() {
		localStorage.clear();
	},
	methods: {
		...mapActions(['actionsSetToken', 'actionsSetPhone', 'actionsSetGoPath']),
		login() {
			if (!this.phone || this.phone.length < 11) {
				Toast.fail({
					duration: 3000, // 持续展示 toast
					forbidClick: true,
					message: '请检查手机号码'
				});
				return;
			}
			if (!this.msgCode || this.msgCode.length < 6) {
				Toast.fail({
					duration: 3000, // 持续展示 toast
					forbidClick: true,
					message: '请输入验证码'
				});
				return;
			}
			Toast.loading({
				message: '登录中...',
				duration: 0,
				forbidClick: true,
				loadingType: 'spinner'
			});
			let that = this;
			api.userLogin({ phone: this.phone, code: this.msgCode })
				.then(res => {
					that.actionsSetToken(res.authToken);
					sessionStorage.setItem('token', res.authToken);
					that.actionsSetPhone(this.phone);
					that.$router.replace(that.goPath);
					that.actionsSetGoPath('');
					Toast.clear();
				})
				.catch(error => {
					Toast.clear();
					that.errorMsg = error.data.msg;
					that.show = true;
				});
		},
		verificationCode() {
			if (!this.phone || this.phone.length < 11) {
				Toast.fail({
					duration: 3000, // 持续展示 toast
					forbidClick: true,
					message: '请检查手机号码'
				});
			} else if (this.timeCode === 0) {
				this.sendCode();
			}
		},
		sendCode() {
			this.timeCode = 1;
			let data = {
				type: 'enroll_login',
				phone: this.phone
			};
			let second = 60;
			let code = document.getElementById('timing');
			code.innerHTML = second + 's';
			const timer = setInterval(() => {
				second--;
				if (second) {
					code.innerHTML = second + 's';
				} else {
					clearInterval(timer);
					this.timeCode = 0;
					code.innerHTML = '发送验证码';
				}
			}, 1000);

			api.sendCode(data)
				.then(res => {
					Toast.success({
						overlay: false,
						duration: 2500, // 持续展示 toast
						forbidClick: true,
						message: '验证码发送成功'
					});
				})
				.catch(err => {
					Toast.fail({
						overlay: false,
						duration: 2500, // 持续展示 toast
						forbidClick: true,
						message: err.data.msg,
						onOpened: () => {
							clearInterval(timer);
							this.timeCode = 0;
							code.innerHTML = '发送验证码';
						}
					});
				});
		},
		confirm() {
			this.show = false;
		},
		onClickLeft() {
			this.$router.go(-1);
		}
	},
	computed: {
		...mapState(['goPath'])
	}
};
</script>

<style scoped>
.loginTop {
	position: fixed;
	top: 0;
	width: 100vw;
}
.login-page {
	width: 100%;
	padding-top: 30vh;
	height: 100vh;
	background: white;
}

@media screen and (min-width: 600px) {
	.login-page {
		display: flex;
		justify-content: center;
		flex-direction: row;
		width: 100vw;
		height: 100vh;
	}

	.login-page2 {
		width: 400px;
		height: fit-content;
		border: 1px #ededed solid;
		padding: 10px;
		border-radius: 5px;
		margin-top: 10%;
	}
}

.login {
	height: 40px;
	display: flex;
	flex-direction: row;
	justify-content: center;
	margin-top: 20px;
}

.login-code {
	color: red;
	border: none;
	border-left: #ecedee 1px solid;
}

.login-btn {
	width: 60%;
	line-height: 40px;
	height: 40px;
	box-shadow: #ff3128 0px 0px 2px 0px;
}
</style>
