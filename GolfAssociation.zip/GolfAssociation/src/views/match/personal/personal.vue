<template>
	<div class="miansall">
		<div class="answer">
			<van-nav-bar title="个人列表" left-arrow @click-left="$router.back(-1)" />

			<div class="miantops" @click="showPicker = true">
				<div>{{ titlekey }}</div>
				<van-icon v-if="showPicker == false" name="arrow-down" />
				<van-icon v-else name="arrow-up" />
			</div>
			<div class="mians" v-for="(item, index) in list" :key="index">
				<div class="miansleft">
					<div class="listp">{{ (index += 1) }}</div>
					<div class="images"><van-image round width="40px" height="40px" :src="item.avatar ? item.avatar : imgque" /></div>
					<div class="listp">{{ item.name }}</div>
				</div>
				<div class="rigths">
					{{ item.differ_name }}
					<span style="color: #FA4864;">{{ item.differ_point }}</span>
				</div>
			</div>
			<van-empty v-if="list.length == 0" description="暂无数据" />
			<van-popup v-model="showPicker" round position="bottom"><van-picker show-toolbar :columns="columns" @cancel="showPicker = false" @confirm="onConfirm" /></van-popup>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
export default {
	data() {
		return {
			imgque: require('@/assets/imgamo/lingos.png'),
			list: [],
			titlekey: '',
			group_id: 1,
			showPicker: false,
			columns: [],
			columnsfrom: [],
			listindex: 1
		};
	},
	computed: {
		match_id() {
			return this.$store.state.match_id;
		}
	},
	activated() {
		this.setdata();
	},
	watch: {
		group_id(newval, val) {
			if (newval == '') return false;
			if (newval != val) {
				this.getdata(newval);
			}
		},
		match_id(newval, val) {
			if (newval != val) {
				this.group_id = '';
				this.titlekey = '';
				this.columns = [];
				this.columnsfrom = [];
				this.listindex = 1;
			}
		}
	},
	methods: {
		onConfirm(data) {
			this.columnsfrom.map(item => {
				if (data == item.title) {
					this.titlekey = data;
					this.group_id = item.id;
				}
			});
			this.showPicker = false;
		},
		setdata() {
			if(this.columns.length>0)return false
			api.match_enroll({
				match_id: this.$store.state.match_id
			}).then(res => {
				if (res) {
					if (res.groups) {
						this.columns = res.groups.map(item => item.title);
						if (this.listindex == 1) {
							this.titlekey = this.columns[0];
							this.listindex += 1;
						}
						this.columnsfrom = res.groups;
						if (this.columnsfrom[0]) {
							this.getdata(this.columnsfrom[0].id);
						}
					} else {
						this.titlekey = '暂无数据';
					}
				}
			});
		},
		getdata(data) {
			api.match_enroll({
				group_id: data,
				match_id: this.$store.state.match_id
			}).then(res => {
				if (res) {
					res.list.map(item => {
						item.avatar = this.$store.state.domain + item.avatar;
					});
					this.list = res.list;
				}
			});
		}
	}
};
</script>
<style scoped></style>
<style scoped lang="scss">
.mians {
	width: 84%;
	padding: 5% 8% 0 8%;
	font-size: 14px;
	display: flex;
	justify-content: space-between;
	.miansleft {
		display: flex;
		.images {
			width: 70px;
			display: flex;
			justify-content: center;
		}
		.listp {
			display: flex;
			align-items: center;
			height: inherit;
			min-width: 20px;
			justify-content: center;
		}
	}
	.rigths {
		height: inherit;
		display: flex;
		align-items: center;
	}
}
.miantops {
	width: 86%;
	padding: 3% 4% 3% 10%;
	background: #78ac09;
	color: #ffffff;
	font-size: 14px;
	display: flex;
	justify-content: space-between;
}
@media screen and (max-width: 600px) {
	.answer {
		width: 100%;
		height: 100vh;
		overflow: auto;
	}
}

@media screen and (min-width: 600px) {
	.miansall {
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center;
		margin: 0 auto;
		.answer {
			width: 37.5rem;
			height: 100vh;
			overflow: auto;
		}
	}
}
</style>
