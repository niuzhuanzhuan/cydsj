<template>
  <div class="news">
    <div class="index">

        <van-nav-bar
            class="assoNavBar"
            title="公告列表"
            
            left-arrow
            @click-left="() => { this.$router.back() }"
        />
    
        <van-list
            v-model="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
            offset='1'>

            <div class="listDIV">
                <div class="list" v-for="(item,index) in noticeList" :key="index" @click="goNewsDetails(item.notice_id)">
                    <div style="padding-top: 5px">
                        <div class="tips">
                            <van-tag type="danger" size="large" 
                            :color="
                            item.type == 1 ? '#FDB37F' 
                            : item.type == 2 ? '#7FBAFD' 
                            : item.type == 3 ? '#FD8F7F' 
                            : item.type == 4 ? '##56910C' 
                            : '' "
                            >{{ item.type_text }}</van-tag>
                        </div>

                        <div class="content">
                            {{ item.title }}
                        </div>

                        <div class="time">{{ item.datetime }}</div>
                    </div>
                </div>
            </div>

        </van-list>

      <!-- 加载loading -->
      <van-overlay :show="loadingshow" >
          <div class="wrapper" >
              <van-loading type="spinner" color="#1989fa" ></van-loading>
              <p>拼命加载中...</p>
          </div>
      </van-overlay>

    </div>
  </div>
</template>

<script>

import { mapState,mapActions } from 'vuex';
import Store from '@/vuex/store';
import api from '@/components/http.js'
import global from '@/global'

export default {
    data(){
        return {
            loadingshow : false,

            noticeList : [],

            // 分页
            page : 0,

            // 下拉刷新
            list:[],
            loading: false,
            finished: false,
        }
    },
    activated(){
        
    },
    computed: {
        ...mapState(['token'])
    },
    methods : {

        ...mapActions(['actionsSetGoPath']),

        getData(){

            const data = {
                asso_id : sessionStorage.getItem('asso_id'),
                limit : 15,
                page : this.page
            }

            // 加载状态结束
            this.loading = false;   
            this.loadingshow = true;

            api.ga_notice(data).then(res => {

                this.loadingshow = false;
                
                if(res.data.xcode == 0){

                    for (let i = 0; i < res.data.data.list.length; i++) {
                        this.noticeList.push(res.data.data.list[i])
                    }

                    // 没有数据后，不在下拉刷新
                    if(res.data.data.list.length < 10){
                        this.finished = true;
                    }

                    // 加载状态结束
                    // this.loading = false;

                    // console.log('第几页：' + this.page)

                }else{
                    this.loading = false;
                    this.$toast(res.data.msg);
                    this.$router.back()
                }
            })

        },

        // 下拉刷新
        onLoad() {

            this.page++

            this.getData();

        },
        
        // 去详情
        goNewsDetails(id){
            this.$router.push({path : '/asso/newsDetails', query : {id : id}})
        },

    }
}
</script>

<style lang="scss" scoped>
    .news {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        // overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

  @media screen and (max-width: 600px) {
    .index {
        width: 100vw;
        min-height: 100vh;
        height: auto;
        background-color: #FFFFFF;
    }

    .listDIV{
        height: auto;
    }

    .list{
        padding-top: 10px;
        padding-bottom: 10px;
        height: 40px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.03);

        .tips{
          float: left;
          padding-left: 20px;
        }

        .content{
          float: left;
          padding-left: 10px;
          padding-top: 2px;
          width: 200px;
          overflow: hidden;/*超出部分隐藏*/
          white-space: nowrap;/*不换行*/
          text-overflow:ellipsis;/*超出部分文字以...显示*/
        }

        .time{
          float: right;
          font-size: 12px;
          padding-top: 10px;
          padding-right: 20px;
          color: rgba(16, 16, 16, 0.29);
        }

    }
  }

  @media screen and (min-width: 600px) {
    .index {
        width: 600px;
        min-height: 100vh;
        height: auto;
        background-color: #FFFFFF;
    }

    .listDIV{
        height: auto;
    }

    .list{
        padding-top: 10px;
        padding-bottom: 10px;
        height: 40px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.03);

        .tips{
          float: left;
          padding-left: 20px;
        }

        .content{
          float: left;
          padding-left: 10px;
          padding-top: 2px;
          width: 200px;
          overflow: hidden;/*超出部分隐藏*/
          white-space: nowrap;/*不换行*/
          text-overflow:ellipsis;/*超出部分文字以...显示*/
        }

        .time{
          float: right;
          font-size: 12px;
          padding-top: 10px;
          padding-right: 20px;
          color: rgba(16, 16, 16, 0.29);
        }

    }
  }
</style>
