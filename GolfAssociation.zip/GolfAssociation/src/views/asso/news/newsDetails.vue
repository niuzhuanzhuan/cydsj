<template>
  <div class="newsDetails">
    <div class="index">

        <van-nav-bar
            class="assoNavBar"
            title="详情"
            
            left-arrow
            @click-left="() => { this.$router.back() }"
        />

        <div style="padding: 15px">
            <div class="htmltitle">{{ data.title }}</div>
            <div class="htmltime">{{ data.update_time }}</div>

            <div class="vhtml" v-html="data.content" ></div>
        </div>

        <!-- 加载loading -->
        <van-overlay :show="loadingshow" >
            <div class="wrapper" >
                <van-loading type="spinner" color="#1989fa" ></van-loading>
                <p>拼命加载中...</p>
            </div>
        </van-overlay>

    </div>
  </div>
</template>

<script>

import { mapState,mapActions } from 'vuex';
import Store from '@/vuex/store';
import api from '@/components/http.js'
import global from '@/global'

export default {
    data(){
        return {
            loadingshow : false,

            data : "",
        }
    },
    activated(){
        this.getData()
    },
    computed: {
        ...mapState(['token'])
    },
    methods : {

        ...mapActions(['actionsSetGoPath']),

        getData(){

            const data = {
                asso_id : sessionStorage.getItem('asso_id'),
                notice_id : this.$route.query.id,
                limit : '',
                page : ''
            }

            // 加载状态结束
            this.loadingshow = true;

            api.ga_notice(data).then(res => {

                this.loadingshow = false;
                
                if(res.data.xcode == 0){

                    this.data = res.data.data.info
                    console.log(res.data.data.info)

                }else{
                    this.$toast(res.data.msg);
                    this.$router.back()
                }
            })

        },

    }
}
</script>

<style lang="scss" scoped>
    .newsDetails {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    .htmltitle{
        text-align: center;
        font-size: 22px;
        padding-top: 20px;
        padding-bottom: 10px;
    }

    .htmltime{
        font-size: 14px;
        color: #888585;
        padding-bottom: 10px;
    }

  @media screen and (max-width: 600px) {
    .index {
        width: 100vw;
        min-height: 100vh;
        height: auto;
        background-color: #FFFFFF;
    }
  }

  @media screen and (min-width: 600px) {
    .index {
        width: 600px;
        min-height: 100vh;
        height: auto;
        background-color: #FFFFFF;
    }
  }
</style>
