<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="运动员详情"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 我的信息 -->
            <div class="user">

                <!-- 个人信息 -->
                <div class="info">

                    <div class="name">
                        {{ userinfo.name }}
                        <!-- <van-tag round type="success" color='#56910C'>未实名</van-tag> -->
                    </div>

                    <div class="phone">{{ userinfo.phone }}</div>

                    <!-- <div class="almost">
                        <span class="tips">平均差点:</span>
                        <span class="number">
                            {{ userinfo.differ_point }}
                        </span>
                    </div> -->

                </div>

                <!-- 头像 -->
                <div class="avatar">
                    <van-image
                        round
                        width="5.5rem"
                        height="5.5rem"
                        fit="cover"
                        :src="userinfo.avatar"
                    />
                </div>

            </div>

            <!-- 个人荣誉 -->
            <div class="glory">

                <div class="title">个人荣耀</div>

                <div class="list" v-for="item in userinfo.honors" :key="item">

                    <div class="tag"></div>

                    <div class="text">{{ item }}</div>

                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

    import api from '@/components/http'

    export default {
        data() {
            return {
                loadingshow : false,

                userinfo : {},
            }
        },
        activated () {
            this.getData()
        },
        methods: {
            getData() {
                
                this.loadingshow = true;

                api.getTeamUserDetail({yid : this.$route.query.yid}).then(res => {

                    this.loadingshow = false;

                    if(res.data.xcode == 0){
                        
                        this.userinfo = res.data.data
                        // this.userinfo.avatar = sessionStorage.getItem('asso_url') + this.userinfo.avatar
                        this.userinfo.phone = this.noPassByMobile(this.userinfo.phone);

                        this.userinfo.honors = this.userinfo.honors.split(',')

                        console.log(this.userinfo)

                    }else{
                        this.$toast(res.data.msg)
                    }


                })
            },

            // 星号处理手机号
            noPassByMobile(str){
                if(null != str && str != undefined){
                    var pat=/(\d{3})\d*(\d{4})/;
                    return str.replace(pat,'$1****$2');
                } else {
                    return "";
                }
            },
        },
    }
</script>

<style lang="scss" scoped>
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        background: #EDEDED;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }
        
        // 个人信息
        .user{
            line-height: 35px;
            font-size: 18px;
            margin-top: 20px;
            height: 125px;
            // border-bottom: 1px solid #92909055;

            .info{
                float: left;
                margin-left: 20px;

                .name{
                    font-size: 28px;
                    font-weight: 600;
                    span{
                        font-size: 16px;
                        font-weight: 500;
                    }
                }

                .almost{

                    .tips{
                        font-size: 15px;
                    }

                    .number{
                        font-size: 30px;
                        color: #56910C;

                        span{
                            margin-left: 5px;
                            font-size: 15px;
                        }
                    }
                }
            }

            .avatar{
                float: right;
                margin-right: 14px;
            }
        }

        .glory{
            padding: 20px;

            .title{
                font-size: 18px;
            }

            .list{
                padding-top: 15px;
                .tag{
                    width: 15px;
                    height: 15px;
                    border-radius: 50px;
                    background: #C5DD9C;
                    float: left;
                    margin-right: 8px;
                    margin-top: 2px;
                }
            }


        }

    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        // 个人信息
        .user{
            line-height: 35px;
            font-size: 18px;
            margin-top: 20px;
            height: 125px;
            // border-bottom: 1px solid #92909055;

            .info{
                float: left;
                margin-left: 20px;

                .name{
                    font-size: 28px;
                    font-weight: 600;
                    span{
                        font-size: 16px;
                        font-weight: 500;
                    }
                }

                .almost{

                    .tips{
                        font-size: 15px;
                    }

                    .number{
                        font-size: 30px;
                        color: #56910C;

                        span{
                            margin-left: 5px;
                            font-size: 15px;
                        }
                    }
                }
            }

            .avatar{
                float: right;
                margin-right: 14px;
            }
        }

        .glory{
            padding: 20px;

            .title{
                font-size: 18px;
            }

            .list{
                padding-top: 15px;
                .tag{
                    width: 15px;
                    height: 15px;
                    border-radius: 50px;
                    background: #C5DD9C;
                    float: left;
                    margin-right: 8px;
                    margin-top: 2px;
                }
            }


        }

    }
</style>