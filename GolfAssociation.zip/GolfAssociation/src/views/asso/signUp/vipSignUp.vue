<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="会员注册"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 个人信息 -->
            <div class="user">

                <!-- 头像 -->
                <div class="avatar">
                    <van-image
                        round
                        width="5.5rem"
                        height="5.5rem"
                        fit="cover"
                        :src="user.avatar"
                    />
                </div>

                <div class="text">

                    <div class="name">
                        {{ user.name != null ? user.name : '高尔夫用户' }}
                    </div>

                    <div class="title">
                        {{ welcome }}
                    </div>

                </div>

            </div>

            <!-- 福利 -->
            <div class="welfare">

                <div class="title">
                    <span>会员福利</span>
                </div>

                <van-grid :border="false" :column-num="3">
                    <van-grid-item v-for="(item,index) in welfare" :key="index" >
                        <van-image :src="item.image" width="2.5rem" height="2.5rem" round />
                        <div class="text">{{ item.name }}</div>
                    </van-grid-item>
                </van-grid>

            </div>

            <!-- 价格 -->
            <div class="money">

                <div style="white-space: nowrap;overflow-y: auto;">

                    <div class="list" 
                        v-for="(item,index) in price" 
                        :key="index" 
                        @click="onMoney(item.value)"
                        :style="item.click == 2 ? 'border: 2px solid #60971B;' : ''"
                    >

                        <div class="title">VIP</div>
                        <div class="name">{{ item.name }}</div>
                        <div class="number">￥{{ item.price }}<span>元</span> </div>
                    </div>

                </div>

            </div>

            <div class="signUpBtn" style="margin: 16px;" >
                <van-button block type="info" color="#56910C" @click="onSignUp">
                    立即注册会员
                </van-button>
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

    import api from '@/components/http'

    export default {
        name : 'vipSignUp',
        data() {
            return {
                loadingshow: false,

                // 提示语句
                welcome : '',

                // 价格
                price : [],

                // 个人信息
                user : {},
                
                // 福利
                welfare : [],

                // 已经选择的价格
                clickWelfare : {},

                url : '',

            }
        },
        activated () {
            
        },
        mounted () {
            this.getData();
        },
        methods: {
            getData() {
                this.loadingshow = true;

                api.getMemberData().then(res => {

                    this.loadingshow = false;

                    if(res.data.xcode == 0){
                        
                        var data = res.data.data

                        if(data.flag){
                            this.$router.replace({ path: "/asso/vipPay", query: { 
                                    id : 1, 
                                    name : '会员', 
                                    desc : this.clickWelfare.desc, 
                                    price : this.clickWelfare.price, 
                                    title : this.clickWelfare.name,
                                    num : this.clickWelfare.value
                                }
                            });
                        }


                        this.price = data.price
                        this.user = data.user
                        this.welcome = data.welcome
                        this.welfare = data.welfare

                        this.welfare.forEach(element => {
                            element.image = this.url + element.image
                        });

                        this.price.forEach(element => {
                            element.click = false
                        });

                    }else{
                        this.$toast(res.data.msg)
                    }

                })
            },

            onMoney(value){
                
                var list = []

                this.price.forEach(res => {
                    if(value == res.value){
                        res.click = 2
                        this.clickWelfare = res                        
                    }else{
                        res.click = 1
                    }

                    list.push(res)
                })

                this.price = list;
            },

            onSignUp(){

                if(this.clickWelfare.name){
                    this.$router.push({ path: "/asso/vipPay", query: { 
                            id : 1, 
                            name : '会员', 
                            desc : this.clickWelfare.desc, 
                            price : this.clickWelfare.price, 
                            title : this.clickWelfare.name,
                            num : this.clickWelfare.value
                        } 
                    });
                }else{
                    this.$toast('请选择要办理多久的会员')
                }

            }

        },
    }
</script>

<style lang="scss" scoped>
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        background: #EDEDED;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .user{
            padding: 20px;

            .avatar{
                float: left;
                padding-right: 20px;
            }

            .text{
                .name{
                    font-size: 25px;
                    font-weight: 600;
                }
                .title{
                    font-size: 14px;
                    line-height: 25px;
                    color: #C9C9C9;
                }
            }

        }

        .welfare{
            
            width: 90%;
            border-radius: 10px;
            margin: 0 auto;
            border: 1px solid #56910C;
            padding-bottom: 10px;

            .title{
                background: #56910C;
                color: #ffffff;
                border-radius: 8px 8px 0 0;
                line-height: 40px;
                span{
                    margin-left: 10px;
                }
            }

            .text{
                padding-top: 10px;
            }

        }
        
        .money{
            overflow: hidden;
            width: 92%;
            margin: 35px auto;

            .list{
                // float: left;
                background: #F5F5F5;
                line-height: 30px;
                padding: 10px 0;
                width: 120px;
                text-align: center;
                margin-left: 10px;
                display: inline-block;
                border-radius: 10px;
                font-size: 14px;

                .title{
                    background: #EAF1DF;
                    border-radius: 20px;
                    color: #56910C;
                    font-weight: 600;
                    width: 80%;
                    margin: 0 auto;
                }

                .number{
                    color: #FF3E3E;
                    font-size: 20px;
                }

            }

        }

        ::-webkit-scrollbar {
            display: none; /* Chrome Safari */
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }
    }
</style>