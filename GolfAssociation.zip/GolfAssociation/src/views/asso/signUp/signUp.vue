<template>
    <div class="signUp">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                :title="HTMLname + '注册'"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 注册信息提交 -->
            <div class="fill_in_signUp" v-if="signUp">
                <!-- <div class="name"><div>{{ HTMLname }}注册</div></div> -->

                <div style="font-size: 16px; padding-left: 15px; padding-top: 10px; padding-bottom: 10px;">实名认证</div>

                <div class="form">

                    <van-form @submit="onSubmit">

                        <div class="input">
                            <div class="content">
                                <van-field
                                    v-model="data.nickname"
                                    name="nickname"
                                    label="昵称"
                                    placeholder="昵称"
                                    left-icon="friends"
                                    input-align="right"
                                    error-message-align="right"
                                    :rules="[{ required: true, message: '请填写昵称' }]"
                                />

                                <van-field
                                    v-model="data.name"
                                    name="name"
                                    label="姓名"
                                    placeholder="姓名"
                                    left-icon="friends"
                                    input-align="right"
                                    error-message-align="right"
                                    :rules="[{ required: true, message: '请填写姓名' }]"
                                />

                                <van-field
                                    v-model="data.id_card"
                                    name="id_card"
                                    label="身份证"
                                    placeholder="身份证"
                                    left-icon="graphic"
                                    input-align="right"
                                    error-message-align="right"
                                    :rules="[{ required: true, message: '请填写身份证' }]"
                                />

                                <van-field
                                    v-model="data.phone"
                                    name="phone"
                                    label="手机号"
                                    placeholder="手机号"
                                    left-icon="phone"
                                    input-align="right"
                                    error-message-align="right"
                                    readonly
                                />
                            </div>
                        </div>

                        <!-- 资质上传 -->
                        <div class="qualifications">

                            <div class="tips">
                                <div class="icon">
                                    <van-icon name="todo-list" />
                                </div>
                                <div class="text">资质上传</div>
                            </div>

                            <!-- <el-upload
                                class="upload"
                                :action="UPurl + '/portal/file/uploadImage/'"
                                :on-preview="handlePreview"
                                :on-remove="handleRemove"
                                :on-success="qualificationsSuccess"
                                :on-error="error"
                                :file-list="fileList"
                                list-type="picture-card">
                                <i class="el-icon-plus"></i>
                            </el-upload> -->

                            <el-upload
                                class="upload"
                                :action="UPurl + '/portal/file/uploadImage/'"
                                :on-preview="handlePreview"
                                :on-success="qualificationsSuccess"
                                :on-remove="handleRemove"
                                :on-error="error"
                                :file-list="fileList"
                                :limit="5"
                                :on-exceed="videohandleExceed"
                                list-type="picture-card">
                                <i class="el-icon-plus"></i>
                            </el-upload>

                        </div>

                        <div class="signUpBtn" style="margin: 16px;">
                            <van-button block type="info" native-type="submit" color="#56910C">
                            立即注册
                            </van-button>
                        </div>

                    </van-form>

                </div>
            </div>

            <!-- 审核结果 -->
            <div class="AuditResults" v-else>
                
                <!-- 审核信息 -->
                <div class="info">
                    <div class="text">
                        <div class="tips">协会名称</div>
                        <div class="content">{{ asso_name }}</div>
                    </div>
                    <div class="text">
                        <div class="tips">注册项目</div>
                        <div class="content">{{ HTMLname }}注册</div>
                    </div>
                    <!-- <div class="text">
                        <div class="tips">缴费金额</div>
                        <div class="content">￥0.00</div>
                    </div> -->
                </div>

                <!-- 步骤条 -->
                <div class="status">
                    <!-- <van-steps class="step" direction="vertical" :active="AuditData.state == -1 ? 2 : 1" >
                        <van-step>
                            <div class="tips" >{{ AuditData.apprs[0].text }}</div>
                            <div class="time">{{ AuditData.apprs[0].reason }}</div>
                            <div class="time">{{ AuditData.apprs[0].time }}</div>
                        </van-step>
                        <van-step>
                            <div class="tips">信息审核中</div>
                        </van-step>
                        <van-step v-if="AuditData.apprs.length == 1">
                            <div class="tips">审核结果</div>
                        </van-step>
                        <van-step v-else>
                            <div class="tips" :style="AuditData.state == -1 ? 'color:#ec0202' : 'color:#07c160'">{{ AuditData.apprs[1].text }}</div>
                            <div class="time" :style="AuditData.state == -1 ? 'color:#ec0202' : 'color:#07c160'">{{ AuditData.apprs[1].reason }}</div>
                            <div class="time" :style="AuditData.state == -1 ? 'color:#ec0202' : 'color:#07c160'">{{ AuditData.apprs[1].time }}</div>
                        </van-step>
                    </van-steps> -->
                    <!-- <van-steps class="step" direction="vertical" :active="AuditData.state == 0 ? AuditData.apprs.length + 1 : AuditData.apprs.length" > -->
                    <van-steps class="step" direction="vertical" :active="Number(AuditData.apprs.length)" >
                        <van-step v-for='(item,index) in AuditData.apprs' :key="index">
                            <div class="tips" :style="item.result == 'no' ? 'color:#ec0202' : 'color:#000'">{{ item.text }}</div>
                            <div class="time" :style="item.result == 'no' ? 'color:#ec0202' : 'color:#000'">{{ item.reason }}</div>
                            <div class="time" :style="item.result == 'no' ? 'color:#ec0202' : 'color:#000'">{{ item.time }}</div>
                        </van-step>
                        <van-step v-if='AuditData.state == 0'>
                            <div class="tips">信息审核中</div>
                        </van-step>
                    </van-steps>
                </div>

                <van-button style="width: 90%; margin: 0 auto;margin-bottom: 20px;" color="#ec0202" block v-if='AuditData.state == -1' @click="ReApply">重新申请</van-button>
                <van-button style="width: 90%; margin: 0 auto;margin-bottom: 20px;" color="#56910C" block @click="() => { this.$router.back() }">返回</van-button>
                
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>
            
            <!-- 图片放大查看 -->
            <el-dialog :visible.sync="dialogVisible">
                <img width="100%" :src="dialogImageUrl" alt="">
            </el-dialog>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import http from '@/global'

export default {
    data(){
        return {
            loadingshow : false,

            // 审核结果
            signUp : true,

            asso_name : '',

            HTMLname : '',

            id : '',

            asso_id : sessionStorage.getItem('asso_id'),

            UPurl : http.REST_URL,

            url : '',

            // 注册信息
            data : {
                source : this.$route.query.id,
                Remarks : this.$route.query.name,
                asso_id : '',
                name : '',
                nickname : '',
                id_card : '',
                phone : '',
                avatar : '',
                qualifications : '',
            },

            // 审核信息
            AuditData : [],

            // 资质 img
            fileList : [],
            // 查看图片
            dialogImageUrl: '',
            dialogVisible: false,

            // 步骤条
            step_active : 1,
        }
    },
    activated(){
        this.getData()
    },
    methods :{

        getData(){
            this.loadingshow = true;

            this.id = this.$route.query.id
            this.HTMLname = this.$route.query.name
            this.data.source = this.$route.query.id
            this.data.Remarks = this.$route.query.name

            const data = {
                source : this.id,
                asso_id : this.asso_id,
            }
            api.ga_enroll_info(data).then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0 ){

                    this.asso_name = res.data.data.asso_name

                    this.data.nickname = res.data.data.user_info.nickname
                    this.data.name = res.data.data.user_info.name
                    this.data.id_card = res.data.data.user_info.id_card
                    this.data.phone = res.data.data.user_info.phone
                    this.data.avatar = res.data.data.user_info.avatar

                    if(res.data.data.info.apprs.length > 0){
                        this.signUp = false
                        this.AuditData = res.data.data.info
                    }else{
                        this.signUp = true
                    }

                }else{
                    this.$notify(res.data.msg)
                }

            })
        },

        // 注册按钮
        onSubmit(values){

            this.data.asso_id = this.asso_id;
            this.data.nickname = values.nickname;
            this.data.name = values.name;
            this.data.id_card = values.id_card;
            this.data.phone = values.phone;

            const img = [];
            this.fileList.forEach(res => {
                img.push(res.url.split(this.url)[1])
            })
            this.data.qualifications = String(img)

            api.ga_enroll(this.data).then(res => {
                if(res.data.xcode == 0){
                    this.$notify({ type: 'success', message: res.data.msg })
                    this.signUp = false
                    this.getData()
                }else{
                    this.$notify(res.data.msg)
                }
            })
        },

        // 重新申请
        ReApply(){
            this.signUp = true;
            // this.AuditData = []
        },

        // 资质上传成功回调
        qualificationsSuccess(res){
            this.fileList.push({url : res[0].domain + '/' + res[0].filepath})
        },
        // 删除资质图片
        handleRemove(file, fileList) {
            this.fileList = fileList
        },
        // 查看图片
        handlePreview(file) {
            this.dialogImageUrl = file.url;
            this.dialogVisible = true;
        },
        // 文件上传失败
        error(err){
            this.$notify('文件上传失败！！！');
        },
        // 限制提示
        videohandleExceed() {
            this.$notify('只能上传5张图片');
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .signUp {
        width: 100vw;
        height: auto;
        display: flex;
        flex-direction: row;
        justify-content: center;
        overflow-x: hidden;
        background: #F8F8F8;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
        }
        
        // 注册信息
        .fill_in_signUp{
            .name{
                height: 50px;
                font-size: 20px;
                font-weight: 600;
                background: #FFFFFF;
                text-align: center;
                div{
                    padding-top: 10px;
                }
            }
            
            .form{
                .input{
                    // height: 250px;
                    background: white;
                    .content{
                        padding-top: 5px;
                    }
                }
            }

            .qualifications{
                
                margin-top: 30px;
                background: white;
                // height: 200px;

                .tips{
                    font-size: 16px;
                    height: 30px;
                    padding-top: 20px;
                    padding-bottom: 20px;
                    padding-left: 10px;
                    .icon{
                        float: left;
                    }
                    .text{
                        padding-top: 4px;
                    }
                }

                .upload{
                    padding-left: 20px;
                }

            }
        }

        // 审核结果
        .AuditResults{
            width: 100%;
            height: 100vh;
            background: #FFFFFF;

            .info{
                padding-top: 40px;
                padding-left: 20px;
                scroll-padding-bottom: 40px;
                .text{

                    font-size: 18px;
                    height: 55px;

                    div{
                        float: left;
                    }

                    .tips{
                        font-weight: 600;
                        margin-right: 25px;
                    }

                    .content{
                        width: 220px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
            }
            
            .status{
                padding-left: 10px;
                .step{
                    // font-weight: 600;
                    .tips{
                        font-size: 18px;
                        line-height: 25px;
                    }
                    .time{
                        font-size: 14px;
                        width: 300px;
                    }
                }
            }
        }

    }

    @media screen and (min-width: 600px) {
		.index {
            width: 600px;
            min-height: 100vh;
            height: auto;
        }

        // 注册信息
        .fill_in_signUp{
            .name{
                height: 50px;
                font-size: 20px;
                font-weight: 600;
                background: #FFFFFF;
                text-align: center;
                div{
                    padding-top: 10px;
                }
            }
            
            .form{
                .input{
                    // height: 250px;
                    background: white;
                    .content{
                        padding-top: 5px;
                    }
                }
            }

            .qualifications{
                
                margin-top: 30px;
                background: white;
                // height: 200px;

                .tips{
                    font-size: 16px;
                    height: 30px;
                    padding-top: 20px;
                    padding-bottom: 20px;
                    padding-left: 10px;
                    .icon{
                        float: left;
                    }
                    .text{
                        padding-top: 4px;
                    }
                }

                .upload{
                    padding-left: 20px;
                }

            }
        }

        // 审核结果
        .AuditResults{
            width: 100%;
            height: 100vh;
            background: #FFFFFF;

            .info{
                padding-top: 40px;
                padding-left: 20px;
                scroll-padding-bottom: 40px;
                .text{

                    font-size: 18px;
                    height: 55px;

                    div{
                        float: left;
                    }

                    .tips{
                        font-weight: 600;
                        margin-right: 25px;
                    }

                    .content{
                        width: 220px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
            }
            
            .status{
                padding-left: 10px;
                .step{
                    // font-weight: 600;
                    .tips{
                        font-size: 18px;
                        line-height: 25px;
                    }
                    .time{
                        font-size: 14px;
                        width: 300px;
                    }
                }
            }
        }
    }

</style>