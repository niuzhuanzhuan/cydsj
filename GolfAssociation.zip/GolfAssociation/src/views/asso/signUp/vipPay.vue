<template>
    <div class="signUp">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="支付"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 注册信息提交 -->
            <div class="fill_in_signUp" v-if="signUp">
                <div class="name"><div>{{ HTMLname }}注册</div></div>

                 <div class="moneyTitle">

                    <div class="asso_name">{{ asso_name }}</div>

                    <div class="desc">{{ this.$route.query.desc }}</div>

                    <div class="price">￥{{ this.$route.query.price }} <span>/</span> <span>元</span></div>

                </div>

                <div style="font-size: 16px; padding-left: 15px; padding-top: 10px; padding-bottom: 10px;">实名认证</div>

                <div class="form">

                    <van-form @submit="onSubmit">

                        <div class="input">
                            <div class="content">
                                <van-field
                                    v-model="data.nickname"
                                    name="nickname"
                                    label="昵称"
                                    placeholder="昵称"
                                    left-icon="friends"
                                    input-align="right"
                                    error-message-align="right"
                                    :rules="[{ required: true, message: '请填写昵称' }]"
                                />

                                <van-field
                                    v-model="data.name"
                                    name="name"
                                    label="姓名"
                                    placeholder="姓名"
                                    left-icon="friends"
                                    input-align="right"
                                    error-message-align="right"
                                    :rules="[{ required: true, message: '请填写姓名' }]"
                                />

                                <van-field
                                    v-model="data.id_card"
                                    name="id_card"
                                    label="身份证"
                                    placeholder="身份证"
                                    left-icon="graphic"
                                    input-align="right"
                                    error-message-align="right"
                                    :rules="[{ required: true, message: '请填写身份证' }]"
                                />

                                <van-field
                                    v-model="data.phone"
                                    name="phone"
                                    label="手机号"
                                    placeholder="手机号"
                                    left-icon="phone"
                                    input-align="right"
                                    error-message-align="right"
                                    readonly
                                />
                            </div>
                        </div>

                        <div class="signUpBtn" style="margin: 16px;">
                            <van-button block type="info" native-type="submit" color="#56910C">
                            开通会员
                            </van-button>
                        </div>

                    </van-form>

                </div>
            </div>

            <!-- 审核结果 -->
            <div class="AuditResults" v-else>
                
                <!-- 审核信息 -->
                <div class="info">
                    <div class="text">
                        <div class="tips">协会名称</div>
                        <div class="content">{{ asso_name }}</div>
                    </div>
                    <div class="text">
                        <div class="tips">注册项目</div>
                        <div class="content">{{ HTMLname }}注册</div>
                    </div>
                    <div class="text">
                        <div class="tips">缴费金额</div>
                        <div class="content">￥0.00</div>
                    </div>
                </div>

                <!-- 步骤条 -->
                <div class="status">
                    <van-steps class="step" direction="vertical" :active="Number(AuditData.apprs.length)" >
                        <van-step v-for='(item,index) in AuditData.apprs' :key="index">
                            <div class="tips" :style="item.result == 'no' ? 'color:#ec0202' : 'color:#000'">{{ item.text }}</div>
                            <div class="time" :style="item.result == 'no' ? 'color:#ec0202' : 'color:#000'">{{ item.reason }}</div>
                            <div class="time" :style="item.result == 'no' ? 'color:#ec0202' : 'color:#000'">{{ item.time }}</div>
                        </van-step>
                        <van-step v-if='AuditData.state == 0'>
                            <div class="tips">信息审核中</div>
                        </van-step>
                    </van-steps>
                </div>

                <van-button style="width: 90%; margin: 0 auto;margin-bottom: 20px;" color="#ec0202" block v-if='AuditData.state == -1' @click="ReApply">重新申请</van-button>
                <van-button style="width: 90%; margin: 0 auto;margin-bottom: 20px;" color="#56910C" block @click="() => { this.$router.back() }">返回首页</van-button>

            </div>

            <!-- 支付弹窗 -->
            <van-share-sheet
                v-model="showShare"
                title="支付方式"
                :options="options"
                @select="onSelect"
            />

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import {wxPay} from '@/components/wxPay'

import http from '@/global'

export default {
    data(){
        return {
            loadingshow : false,

            showShare : false,

            options: [
                { name: '微信', icon: 'wechat' },
                // { name: '支付宝', icon: 'weibo' },
            ],

            // 审核结果
            signUp : true,

            asso_name : '',

            HTMLname : this.$route.query.name,

            id : this.$route.query.id,

            asso_id : sessionStorage.getItem('asso_id'),

            UPurl : http.REST_URL,

            // url : sessionStorage.getItem('asso_url'),

            // 注册信息
            data : {
                source : this.$route.query.id,
                Remarks : this.$route.query.name,
                asso_id : '',
                name : '',
                nickname : '',
                id_card : '',
                phone : '',
                avatar : '',
                qualifications : '',
                out_trade_no : '',
                num : '',
            },

            // 审核信息
            AuditData : [],


            // 步骤条
            step_active : 1,
        }
    },
    // activated(){

    //     if(this.data.out_trade_no != ''){
    //         this.loadingshow = true;
    //         api.checkOrder({ out_trade_no : this.data.out_trade_no }).then(res => {
    //             this.loadingshow = false;
    //             if(res.data.xcode == 0){
    //                 this.getData()
    //             }else{
    //                 this.$notify(res.data.msg)
    //             }
    
    //         })
    //     }

    // },
    activated(){
        this.getData()
    },
    methods :{

        getData(){
            this.loadingshow = true;

            const data = {
                source : this.id,
                asso_id : this.asso_id,
            }
            api.ga_enroll_info(data).then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0 ){

                    this.data.nickname = res.data.data.user_info.nickname
                    this.data.name = res.data.data.user_info.name
                    this.data.id_card = res.data.data.user_info.id_card
                    this.data.phone = res.data.data.user_info.phone
                    this.data.avatar = res.data.data.user_info.avatar

                    if(res.data.data.info.apprs.length > 0){
                        this.signUp = false
                        this.AuditData = res.data.data.info
                    }else{
                        this.signUp = true
                    }

                }else{
                    this.$notify(res.data.msg)
                }

            })
        },

        // 注册按钮
        onSubmit(values){

            this.data.asso_id = this.asso_id;
            this.data.nickname = values.nickname;
            this.data.name = values.name;
            this.data.id_card = values.id_card;
            this.data.phone = values.phone;

            // 生成订单号
            this.data.out_trade_no = this.data.phone + new Date().getTime() + Math.ceil(Math.random()*100)

            // this.showShare = true

            this.$dialog.alert({
                title: '温馨提示',
                theme: 'round-button',
                confirmButtonText : '查看支付结果',
                confirmButtonColor : '#56910c'
            }).then(() => {
                this.loadingshow = true;
                api.checkOrder({ out_trade_no : this.data.out_trade_no }).then(res => {
                    this.loadingshow = false;
                    if(res.data.xcode == 0){
                        this.getData()
                    }else{
                        this.$notify(res.data.msg)
                    }
        
                })
            });

            this.onPay()

            // api.ga_enroll(this.data).then(res => {
            //     if(res.data.xcode == 0){
            //         this.$notify({ type: 'success', message: res.data.msg })
            //         this.signUp = false
            //         this.getData()
            //     }else{
            //         this.$notify(res.data.msg)
            //     }
            // })
        },

        // 重新申请
        ReApply(){
            this.signUp = true;
            // this.AuditData = []
        },

        onPay(){
            this.data.num = this.$route.query.num
            wxPay("/rest/golf_asso/openMember",this.data)
        },

        // 支付弹窗
        onSelect(option){
            this.$toast(option.name);
            this.showShare = false;
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .signUp {
        width: 100vw;
        height: auto;
        display: flex;
        flex-direction: row;
        justify-content: center;
        overflow-x: hidden;
        background: #F8F8F8;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
        }
        
        // 注册信息
        .fill_in_signUp{

            .name{
                height: 50px;
                font-size: 20px;
                font-weight: 600;
                background: #FFFFFF;
                text-align: center;
                div{
                    padding-top: 10px;
                }
            }
            
            .moneyTitle{

                padding : 0 20px;
                background: #FFFFFF;
                line-height: 50px;
                padding-bottom: 10px;

                .asso_name{
                    font-size: 18px;
                }

                .desc{
                    font-size: 16px;
                }

                .price{
                    color: #FF3E3E;
                    font-size: 30px;

                    span{
                        font-size: 15px;
                    }
                }

            }
            
            .form{
                .input{
                    // height: 250px;
                    background: white;
                    .content{
                        padding-top: 5px;
                    }
                }
            }

            .qualifications{
                
                margin-top: 30px;
                background: white;
                // height: 200px;

                .tips{
                    font-size: 16px;
                    height: 30px;
                    padding-top: 20px;
                    padding-bottom: 20px;
                    padding-left: 10px;
                    .icon{
                        float: left;
                    }
                    .text{
                        padding-top: 4px;
                    }
                }

                .upload{
                    padding-left: 20px;
                }

            }
        }

        // 审核结果
        .AuditResults{
            width: 100%;
            height: 100vh;
            background: #FFFFFF;

            .info{
                padding-top: 40px;
                padding-left: 20px;
                scroll-padding-bottom: 40px;
                .text{

                    font-size: 18px;
                    height: 55px;

                    div{
                        float: left;
                    }

                    .tips{
                        font-weight: 600;
                        margin-right: 25px;
                    }

                    .content{
                        width: 220px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
            }
            
            .status{
                padding-left: 10px;
                .step{
                    // font-weight: 600;
                    .tips{
                        font-size: 18px;
                        line-height: 25px;
                    }
                    .time{
                        font-size: 14px;
                        width: 300px;
                    }
                }
            }
        }

    }

    @media screen and (min-width: 600px) {
		.index {
            width: 600px;
            min-height: 100vh;
            height: auto;
        }

        // 注册信息
        .fill_in_signUp{
            .name{
                height: 50px;
                font-size: 20px;
                font-weight: 600;
                background: #FFFFFF;
                text-align: center;
                div{
                    padding-top: 10px;
                }
            }
            
            .form{
                .input{
                    // height: 250px;
                    background: white;
                    .content{
                        padding-top: 5px;
                    }
                }
            }

            .qualifications{
                
                margin-top: 30px;
                background: white;
                // height: 200px;

                .tips{
                    font-size: 16px;
                    height: 30px;
                    padding-top: 20px;
                    padding-bottom: 20px;
                    padding-left: 10px;
                    .icon{
                        float: left;
                    }
                    .text{
                        padding-top: 4px;
                    }
                }

                .upload{
                    padding-left: 20px;
                }

            }
        }

        // 审核结果
        .AuditResults{
            width: 100%;
            height: 100vh;
            background: #FFFFFF;

            .info{
                padding-top: 40px;
                padding-left: 20px;
                scroll-padding-bottom: 40px;
                .text{

                    font-size: 18px;
                    height: 55px;

                    div{
                        float: left;
                    }

                    .tips{
                        font-weight: 600;
                        margin-right: 25px;
                    }

                    .content{
                        width: 220px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
            }
            
            .status{
                padding-left: 10px;
                .step{
                    // font-weight: 600;
                    .tips{
                        font-size: 18px;
                        line-height: 25px;
                    }
                    .time{
                        font-size: 14px;
                        width: 300px;
                    }
                }
            }
        }
    }

</style>