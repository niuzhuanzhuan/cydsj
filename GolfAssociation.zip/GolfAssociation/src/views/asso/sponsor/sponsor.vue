<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="赞助"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 顶部 Banner 和 赞助总金额 -->
            <div class="top">

                <div class="banner">
                    <van-swipe :autoplay="3000">
                        <van-swipe-item v-for="(image, index) in images" :key="index">
                            <img v-lazy="image" width="100%" height="150"/>
                        </van-swipe-item>
                    </van-swipe>
                </div>


                <div class="sponsor">

                    <!-- <div class="money">
                        <div class="title">赞助总额</div>
                        <div class="number">¥ {{ total_amount }}</div>
                    </div> -->

                    <div class="money">
                        <div class="title">赞助专区</div>
                        <img src="../../../assets/asso/sponsor/sponsor.png" alt="">
                    </div>

                    <div class="button">
                        <van-button color="#56910C" @click="goSponsor_refer">我要赞助</van-button>
                    </div>

                </div>

            </div>

            <!-- 分割线 -->
            <div class="line"></div>

            <!-- 赞助列表 -->
            <div class="list" >

                <div class="title">赞助榜单</div>

                <div class="box" v-for="(item,index) in list" :key="index">

                    <div class="rank">
                        <div style="font-size: 12px">TOP</div>
                        <div style="font-size: 18px">{{ item.rank }}</div>
                    </div>

                    <!-- <div class="money">
                        <div>赞助金额</div>
                        <div class="moneyNumber">
                            {{ item.amount }}
                            <span>{{ item.unit }}</span>
                        </div>
                        <div>{{ item.name }}</div>
                    </div> -->

                    <div class="money">
                        <div>赞助身份</div>
                        <div class="moneyNumber">
                            {{ item.name }}
                        </div>
                    </div>

                    <div class="logo">
                        <van-image width="120" height="70" :src="item.logo" fit="contain"/>
                    </div>

                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import navigation from '../tabbar/tabbar'
import api from "@/components/http.js";
import Store from "@/vuex/store";

export default {
    data(){
        return {

            loadingshow : false,

            images: [],

            total_amount : 0,

            list : [],
        }
    },
    components : {
        navigation
    },
    activated(){
        this.getData();
    },
    methods :{
        getData(){
            
            // if(Store.state.token){
                this.loadingshow = true;

                api.ga_sponsor_index({ asso_id : sessionStorage.getItem('asso_id') }).then(res => {
                    
                    this.loadingshow = false;

                    if(res.data.xcode == 0){

                        this.images = res.data.data.rotation

                        this.total_amount = res.data.data.total_amount

                        res.data.data.list.forEach(element => {
                            // element.logo = sessionStorage.getItem('asso_url') + element.logo;

                            const number = Number(element.amount)

                            if(number < 10000){
                                element.unit = '元'
                            }else if(number < 10000000){
                                element.unit = '万'
                                element.amount = Number(element.amount) / 10000
                            }else if(number < 100000000){
                                element.unit = '千万'
                                element.amount = Number(element.amount) / 10000000
                            }else{
                                element.unit = '亿'
                                element.amount = Number(element.amount) / 100000000
                            }

                            element.amount = Number(element.amount).toFixed(0)

                        });

                        this.list = res.data.data.list

                    }else{
                        this.$toast(res.data.msg)
                    }
                })
            // }else{
            //     this.$dialog
            //     .confirm({
            //         message: "请先登录",
            //     })
            //     .then(() => {
            //         this.$router.push( "/asso/mine" );
            //     })
            //     .catch(() => {
            //         this.$router.replace("/");
            //     });
            // }
            
        },

        goSponsor_refer(){
            this.$router.push({ path: "/asso/SponsorRefer"});
        }
        
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }

        .top{

            margin-bottom: 10px;

            .banner{
                width: 90%;
                margin: 20px auto;

                img{
                    border-radius: 10px;
                }
            }

            .sponsor{
                width: 90%;
                margin: 0 auto;
                line-height: 30px;
                height: 60px;

                .money{
                    width: 50%;
                    float: left;

                    .title{
                        font-size: 14px;
                        color: rgba(16, 16, 16, 0.29);
                    }

                    .number{
                        font-size: 19px;
                    }

                    img{
                        width: 30px;
                        padding-left: 10px;
                    }
                }

                .button{
                    float: right;
                    margin-top: 15px;
                    button{
                        height: 35px;
                        border-radius: 10px;
                    }
                }
            }
        }

        .line{
            height: 10px;
            background: rgba(0, 0, 0, 0.03);
        }

        .list{
            width: 94%;
            margin: 0 auto;

            .title{
                margin-top: 25px;
                margin-bottom: 10px;
                font-size: 15px;
            }

            .box{
                
                width: 100%;
                height: 100px;
                background: rgba(0, 0, 0, 0.03);
                margin-bottom: 20px;
                border-radius: 8px;

                .rank{
                    float: left;
                    color: #FD8F7F;
                    text-align: center;
                    margin-right: 20px;
                    margin-left: 20px;
                    margin-top: 35px;
                }

                .money{
                    float: left;
                    line-height: 30px;
                    color: rgba(16, 16, 16, 0.29);
                    font-size: 13px;
                    margin-top: 17px;
                    width: 28%;

                    
                    .moneyNumber{
                        font-size: 25px;
                        color: #7A7A7A;
                        width: 132px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;

                        span{
                            font-size: 14px;
                        }
                    }
                }

                .logo{
                    float: right;
                    margin-right: 20px;
                    margin-top: 15px;
                }

            }
        }

    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }

        .top{

            margin-bottom: 10px;

            .banner{
                width: 90%;
                margin: 20px auto;

                img{
                    border-radius: 10px;
                }
            }

            .sponsor{
                width: 90%;
                margin: 0 auto;
                line-height: 30px;
                height: 60px;

                .money{
                    width: 50%;
                    float: left;

                    .title{
                        font-size: 14px;
                        color: rgba(16, 16, 16, 0.29);
                    }

                    .number{
                        font-size: 19px;
                    }
                }

                .button{
                    float: right;
                    margin-top: 10px;
                    button{
                        height: 35px;
                        border-radius: 10px;
                    }
                }
            }
        }

        .line{
            height: 10px;
            background: rgba(0, 0, 0, 0.03);
        }

        .list{
            width: 90%;
            margin: 0 auto;

            .title{
                margin-top: 25px;
                margin-bottom: 10px;
                font-size: 15px;
            }

            .box{
                
                width: 100%;
                height: 100px;
                background: rgba(0, 0, 0, 0.03);
                margin-bottom: 20px;
                border-radius: 8px;

                .rank{
                    float: left;
                    color: #FD8F7F;
                    text-align: center;
                    margin-right: 20px;
                    margin-left: 20px;
                    margin-top: 35px;
                }

                .money{
                    float: left;
                    line-height: 30px;
                    color: rgba(16, 16, 16, 0.29);
                    font-size: 13px;
                    margin-top: 17px;
                    
                    .moneyNumber{
                        font-size: 25px;
                        color: #7A7A7A;

                        span{
                            font-size: 14px;
                        }
                    }
                }

                .logo{
                    float: right;
                    margin-right: 20px;
                    margin-top: 15px;
                }

            }
        }
    }

</style>