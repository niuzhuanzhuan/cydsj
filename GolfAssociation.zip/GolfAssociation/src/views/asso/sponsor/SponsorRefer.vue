<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="赞助"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- <div class="title">
                <div>赞助贵州省高尔夫球协会</div>
            </div> -->

            <div class="fromData">
                
                <div class="fromTitle">金额</div>

                <!-- <van-field class="field" v-model="from.amount" type="digit" label="¥" placeholder="输入金额" @input="onMoney"/> -->
                <van-field class="field" v-model="from.amount" type="number" label="¥" placeholder="输入金额" @input="onMoney"/>

                <div class="fromTitle">赞助身份</div>

                <van-field class="field" v-model="from.name" placeholder="输入您的名字或者企业名称" />

                <div class="fromTitle">头像/LOGO</div>

                <el-upload
                    class="upload"
                    :action="UPurl + '/portal/file/uploadImage/'"
                    :on-preview="handlePreview"
                    :on-success="qualificationsSuccess"
                    :on-error="error"
                    :file-list="fileList"
                    :on-remove="handleRemove"
                    :limit="1"
                    :on-exceed="videohandleExceed"
                    list-type="picture-card">
                    <i class="el-icon-plus"></i>
                </el-upload>

                <div class="button" @click="onSubmit">
                    <van-button color="#56910C">确认赞助</van-button>
                </div>

            </div>

            <div class="moneyTitle">
                ¥{{ money }}
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

            <!-- 图片放大查看 -->
            <el-dialog :visible.sync="dialogVisible">
                <img width="100%" :src="dialogImageUrl" alt="" >
            </el-dialog>

            <!-- 支付弹窗 -->
            <van-share-sheet
                v-model="showShare"
                title="支付方式"
                :options="options"
                @select="onSelect"
            />

        </div>
    </div>
</template>

<script>

import api from "@/components/http.js";

import http from '@/global'

import {wxPay} from '@/components/wxPay'

import Store from "@/vuex/store";

export default {
    data(){
        return {

            loadingshow : false,

            from : {
                name : '',
                amount : 0,
                phone : '',
                logo : '',
            },

            UPurl : http.REST_URL,

            fileList : [],

            // 查看图片
            dialogImageUrl: '',
            dialogVisible: false,

            // url : sessionStorage.getItem('asso_url'),

            money : 0,

            showShare : false,

            options: [
                { name: '微信', icon: 'wechat' },
                // { name: '支付宝', icon: 'weibo' },
            ],

            // 订单号
            out_trade_no : '',
        }
    },
    activated(){
        // console.log('activated 函数 执行');
        
        // if(this.out_trade_no != ''){
        //     this.loadingshow = true;
        //     api.checkOrder({ out_trade_no : this.out_trade_no }).then(res => {
        //         this.loadingshow = false;
        //         if(res.data.xcode == 0){
        //             this.$notify(res.data.msg)
        //         }else{
        //             this.$notify(res.data.msg)
        //         }

        //     })
        // }
        
        this.fileList = []
    },
    methods :{
        onSubmit(){
            
            if(this.from.name != '' && this.from.amount != ''){

                if(this.fileList.length > 0){

                    this.from.logo = this.fileList[0].url

                    const data = {
                        asso_id : sessionStorage.getItem('asso_id'),
                        name : this.from.name,
                        amount : this.from.amount,
                        phone : this.from.phone,
                        logo : this.from.logo,
                        remark : '',
                        out_trade_no : new Date().getTime() + Math.ceil(Math.random()*100),
                    }

                    this.out_trade_no = data.out_trade_no

                    if (Store.state.token) {
                        
                        // 去微信支付
                        this.onPay(data)
                        
                        // 延时 2 秒 弹出 查看支付按钮
                        window.setTimeout(function(){

                            this.$dialog.alert({
                                title: '温馨提示',
                                theme: 'round-button',
                                confirmButtonText : '查看支付结果',
                                confirmButtonColor : '#56910c'
                            }).then(() => {
                                this.loadingshow = true;
                                api.checkOrder({ out_trade_no : this.out_trade_no }).then(res => {
                                    this.loadingshow = false;
                                    if(res.data.xcode == 0){
                                        this.$notify(res.data.msg)
                                        this.$router.replace('/asso/sponsor');
                                    }else{
                                        this.$notify(res.data.msg)
                                    }

                                })
                            });

                        },2000)

                    }else{
                        this.$dialog
                        .confirm({
                            message: "请先登录",
                        })
                        .then(() => {
                            this.$router.push( "/asso/mine" );
                        })
                        .catch(() => {
                            // this.$router.replace("/");
                        });
                    }

                    // this.loadingshow = true;

                    // api.ga_sponsor_refer(data).then(res => {

                    //     this.loadingshow = false;

                    //     if(res.data.xcode == 0){
                    //         this.$toast(res.data.msg)
                    //     }else{
                    //         this.$toast(res.data.msg)
                    //     }

                    // }).catch(err => {
                    //     this.loadingshow = false;
                    // })

                }else{
                    this.$notify('请上传一张logo或者头像')
                }

            }else{
                this.$notify('名字和金额不能为空！！！')
            }
            
        },

        onMoney(value){
            if(value != 0){
                this.money = value
            }else{
                this.money = 0
            }
        },

        // 资质上传成功回调
        qualificationsSuccess(res){
            this.fileList.push({url : res[0].domain + '/' + res[0].filepath})
        },
        // 删除资质图片
        handleRemove(file, fileList) {
            this.fileList = fileList
        },
        // 查看图片
        handlePreview(file) {
            this.dialogImageUrl = file.url;
            this.dialogVisible = true;
        },
        // 文件上传失败
        error(err){
            this.$notify('文件上传失败！！！');
        },
        // 限制提示
        videohandleExceed() {
            this.$notify('只能上传1张图片');
        },
        
        onSelect(option){
            this.$toast(option.name);
            this.showShare = false;
        },

        onPay(payData){
            wxPay("/rest/golf_asso/sponsorPay",payData)
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        // margin-bottom: 70px;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }

        .title{
            height: 50px;
            background: #EFEFEF;
            font-size: 15px;
            line-height: 50px;
            div{
                padding-left: 50px;
            }
        }

        .fromData{
            width: 90%;
            margin: 0 auto;

            .fromTitle{
                color: #7A7A7A;
                font-size: 14px;
                // padding: 20px 20px;
                padding-top: 30px;
                padding-bottom: 10px;
                padding-left: 20px;
            }
            
            .upload{
                padding-left: 18px;
            }
        }

        .moneyTitle{
            text-align: center;
            font-size: 30px;
            color: rgba(122, 122, 122, 1);
            padding-top: 10px;
        }

        .button{
            position: absolute;
            width: 90%;
            bottom: 20px;

            button{
                width: 100%;
            }
        }

    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }
    }

</style>