<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="我的"
                
                left-arrow
                @click-left="onBack"
            />

            <!-- 我的信息 -->
            <div class="user">

                <!-- 个人信息 -->
                <div class="info" v-if="token">

                    <div class="name">
                        {{ userinfo.name }}
                        <!-- <van-tag round type="success" color='#56910C'>未实名</van-tag> -->
                    </div>

                    <div class="phone">{{ userinfo.phone }}</div>

                    <!-- <div class="almost">
                        <span class="tips">平均差点:</span>
                        <span class="number">
                            {{ userinfo.almost }}
                            <van-tag round type="success" color='#56910C'>新增数据</van-tag>
                        </span>
                    </div> -->

                </div>

                <div class="loginButton" v-else>
                    <van-button type="primary" color="#78AC09" size="normal" @click="onLogin">用户登录</van-button>
                </div>

                <!-- 头像 -->
                <div class="avatar">
                    <van-image
                        round
                        width="5.5rem"
                        height="5.5rem"
                        fit="cover"
                        :src="userinfo.avatar"
                        @click="onLogin"
                    />
                </div>

            </div>

            <!-- 我的菜单导航 -->
            <div class="myMenu">

                <div class="nav" v-for="(item,index) in navigation" :key="index" @click="goPath(item.path)" >
                    <div class="tips">{{ item.tips }}</div>
                    <van-icon name="arrow" class="icon"/>
                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import navigation from '../tabbar/tabbar'

import api from '@/components/http.js'

import Store from "@/vuex/store";

import wx from 'weixin-js-sdk'

export default {
    data(){
        return {

            loadingshow : false,

            token : Store.state.token,

            userinfo : {
                // name : '小南瓜',
                // phone : '18888888888',
                // almost : 36,
            },

            navigation : [
                {tips:'我的账单',path:'/asso/mybill'},
                {tips:'我的协会',path:'/asso/myAsso'},
                {tips:'我的赛事',path:'/asso/myMatch'},
                {tips:'我的审核',path:'/asso/myReview'},
                {tips:'我的培训',path:'/asso/myTraining'},
            ],
        }
    },
    components : {
        navigation
    },
    activated(){
        this.getdata();
    },
    methods :{

        getdata(){

            this.loadingshow = true;

            const data = {
                asso_id : sessionStorage.getItem('asso_id'),
            }

            api.ga_mine(data).then(res => {
                
                this.loadingshow = false

                if(res.data.xcode == 0){
                    
                    this.userinfo = {
                        name : res.data.data.name,
                        phone : res.data.data.phone,
                        almost : res.data.data.avg_differ,
                        avatar : res.data.data.avatar
                    }

                    this.userinfo.phone = this.noPassByMobile(this.userinfo.phone);

                }else{
                    this.$toast(res.data.msg)
                }
            })

        },

        goPath(path){
            if(this.token){
                this.$router.push(path);
            }
        },

        onLogin(){
            console.log('登录')
            wx.miniProgram.navigateTo({url: '/pages/login/login?path=mine'})
        },

        // 星号处理手机号
        noPassByMobile(str){
            if(null != str && str != undefined){
                var pat=/(\d{3})\d*(\d{4})/;
                return str.replace(pat,'$1****$2');
            } else {
                return "";
            }
        },

        onBack(){
            this.$router.replace('/?asso_id=' + sessionStorage.getItem('asso_id'))
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        margin-bottom: 70px;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 93vh;
            height: auto;
            background-color: #FFFFFF;
        }

        // 个人信息
        .user{
            line-height: 35px;
            font-size: 18px;
            margin-top: 20px;
            height: 125px;
            border-bottom: 1px solid #92909055;

            .info{
                float: left;
                margin-left: 20px;
                width: 50%;

                .name{
                    font-size: 28px;
                    font-weight: 600;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;

                    span{
                        font-size: 16px;
                        font-weight: 500;
                    }
                }

                .almost{

                    .tips{
                        font-size: 15px;
                    }

                    .number{
                        font-size: 30px;
                        color: #56910C;

                        span{
                            margin-left: 5px;
                            font-size: 15px;
                        }
                    }
                }
            }
            
            .loginButton{
                position: absolute;
                width: 200px;
                text-align: center;
                button{
                    width: 150px;
                    border-radius: 5px;
                    height: 40px;
                    margin-left: 30px;
                    margin-top: 30px;
                }
            }

            .avatar{
                float: right;
                margin-right: 40px;
            }
        }

        // 个人菜单
        .myMenu{
            margin-top: 20px;

            .nav{
                height: 40px;
                width: 85%;
                font-size: 16px;
                // background: red;
                font-weight: 600;
                margin: 10px 22px;

                .tips{
                    float: left;
                    margin-top: 9px;
                }

                .icon{
                    float: right;
                    margin-top: 12px;
                }

                
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }

        // 个人信息
        .user{
            line-height: 35px;
            font-size: 18px;
            margin-top: 20px;
            height: 125px;
            border-bottom: 1px solid #92909055;

            .info{
                float: left;
                margin-left: 20px;
                width: 50%;

                .name{
                    font-size: 28px;
                    font-weight: 600;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;

                    span{
                        font-size: 16px;
                        font-weight: 500;
                    }
                }

                .almost{

                    .tips{
                        font-size: 15px;
                    }

                    .number{
                        font-size: 30px;
                        color: #56910C;

                        span{
                            margin-left: 5px;
                            font-size: 15px;
                        }
                    }
                }
            }
            
            .loginButton{
                position: absolute;
                width: 200px;
                text-align: center;
                button{
                    width: 150px;
                    border-radius: 5px;
                    height: 40px;
                    margin-left: 30px;
                    margin-top: 30px;
                }
            }

            .avatar{
                float: right;
                margin-right: 40px;
            }
        }

        // 个人菜单
        .myMenu{
            margin-top: 20px;

            .nav{
                height: 40px;
                width: 85%;
                font-size: 16px;
                // background: red;
                font-weight: 600;
                margin: 10px 22px;

                .tips{
                    float: left;
                    margin-top: 9px;
                }

                .icon{
                    float: right;
                    margin-top: 12px;
                }

                
            }
        }
    }

</style>