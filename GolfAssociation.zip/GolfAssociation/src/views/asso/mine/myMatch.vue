<template>
    <div class="mian">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="我的赛事"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="box1" v-for="(item,index) in data" :key="index">
                
                <div class="box2">
                    
                    <van-image
                        class="img"
                        width="5rem"
                        height="5rem"
                        fit="cover"
                        :src="item.avatar"
                    />

                    <div class="text">
                        <div class="name">{{ item.title }}</div>

                        <div class="tips" >{{ item.introduce }}</div>
                    </div>

                    <div class="button">
                        <van-button color="#56910C" size="mini" v-if="item.end" @click="goInfo(item.match_id)">查看详情</van-button>
                        <van-image class="img" width="70" height="70" :src="imgend" v-else/>
                    </div>

                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import end from "@/assets/asso/mine/end.png"

import api from '@/components/http.js'

export default {
    data(){
        return{

            loadingshow : false,
            
            imgend : end,

            data : []
        }
    },
    activated (){
        this.getdata()
    },
    methods : {
        getdata(){
            this.loadingshow = true;
            api.ga_mine_match({ asso_id : sessionStorage.getItem('asso_id') }).then(res => {
                
                this.loadingshow = false;

                if(res.data.xcode == 0){
                    // res.data.data.list.forEach(element => {
                    //     element.avatar = sessionStorage.getItem('asso_url') + element.avatar
                    // });

                    this.data = res.data.data.list
                }else{
                    this.$toast(res.data.msg)
                }

            })

        },

        // 去赛事详情
        goInfo(id){
            this.$router.push({ path: "/match", query: { match_id: id , from : 'wxApp' } });
            sessionStorage.setItem('asso_router', '/asso/myMatch');
        }
    }
}
</script>

<style lang="scss" scoped>

    .mian {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper {
        margin-top: 19rem;
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p {
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;
            height: 140px;
                
            .box2{
                padding: 30px 20px;
                height: 80px;
            }

            .img{
                float: left;
                margin-right: 10px;
            }

            .text{
                float: left;
                width: 46%;
                line-height: 45px;

                .name{
                    font-size: 20px;
                    font-weight: 600;
                    width: 100%;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .tips{
                    font-size: 15px;
                    width: 210px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .button{
                float: right;
                margin-top: 10px;

                button{
                    border-radius: 5px;
                    font-weight: 600;
                }

                .img{
                    position: absolute;
                    right: 10px;
                }
            }

        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;
            height: 140px;
                
            .box2{
                padding: 30px 20px;
                height: 80px;
            }

            .img{
                float: left;
                margin-right: 10px;
            }

            .text{
                float: left;
                width: 46%;
                line-height: 45px;

                .name{
                    font-size: 20px;
                    font-weight: 600;
                    width: 100%;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .tips{
                    font-size: 15px;
                    width: 210px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .button{
                float: right;
                margin-top: 10px;

                button{
                    border-radius: 5px;
                    font-weight: 600;
                }

                .img{
                    position: absolute;
                    right: 10px;
                }
            }

        }

    }

</style>