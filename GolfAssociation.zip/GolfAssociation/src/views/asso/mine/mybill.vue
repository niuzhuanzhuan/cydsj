<template>
    <div class="mian">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="我的账单"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="box1" v-for="(item,index) in data" :key="index">
                
                <div class="box2">
                    <div class="type">类型：{{ item.type }}</div>
                
                    <div class="nameTpis">
                        <div class="name">名称：<span>{{ item.name }}</span></div>
                        <div class="tips">{{ item.name_str }}</div>
                    </div>

                    <div class="timeAndmoney">
                        <div class="time">时间：{{ item.time }}</div>
                        <div class="money">￥{{ item.price }}</div>
                    </div>
                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from "@/components/http.js";

export default {
    data(){
        return{

            loadingshow : false,

            data : []
        }
    },
    activated (){
        this.getData()
    },
    methods : {
        getData(){

            this.loadingshow = true;

            api.getMyPrice().then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0){
                    
                    this.data = res.data.data

                }else{
                    this.$toast(res.data.msg)
                }

            })
        }
    }
}
</script>

<style lang="scss" scoped>

    .mian {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }


    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;

            .box2{
                padding: 20px 20px
            }

            .type{
                height: 40px;
            }

            .nameTpis{
                height: 40px;
                .name{
                    float: left;
                    width: 190px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    span{
                        font-size: 18px;
                    }
                }
                .tips{
                    float: right;
                }
            }

            .timeAndmoney{
                height: 40px;
                .time{
                    float: left;
                    color: rgba(16, 16, 16, 0.29);
                    font-size: 18px;
                }
                .money{
                    float: right;
                    color: rgb(255, 0, 0);
                    font-size: 22px;

                }
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;

            .box2{
                padding: 20px 20px
            }

            .type{
                height: 40px;
            }

            .nameTpis{
                height: 40px;
                .name{
                    float: left;
                    width: 190px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    span{
                        font-size: 18px;
                    }
                }
                .tips{
                    float: right;
                }
            }

            .timeAndmoney{
                height: 40px;
                .time{
                    float: left;
                    color: rgba(16, 16, 16, 0.29);
                    font-size: 18px;
                }
                .money{
                    float: right;
                    color: rgb(255, 0, 0);
                    font-size: 22px;

                }
            }
        }
    }

</style>