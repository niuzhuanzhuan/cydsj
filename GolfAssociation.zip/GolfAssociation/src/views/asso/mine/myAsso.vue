<template>
    <div class="mian">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="我的协会"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="box1" v-for="(item,index) in data" :key="index">
                
                <div class="box2">
                    
                    <van-image
                        class="img"
                        width="5rem"
                        height="5rem"
                        fit="cover"
                        :src="item.avatar"
                    />

                    <div class="text">
                        <div class="name">{{ item.name }}</div>

                        <!-- <div class="tips">{{ item.introduce }}</div> -->
                    </div>

                    <!-- <div class="grade">
                        <div>V1</div>
                    </div> -->

                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from "@/components/http.js";

export default {
    data(){
        return{

            loadingshow : false,

            data : []
        }
    },
    activated (){
        this.getData();
    },
    methods : {
        getData(){
            this.loadingshow = true;

            api.getMyAsso().then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0){
                    
                    this.data = res.data.data

                    this.data.forEach(element => {
                        // element.avatar = sessionStorage.getItem('asso_url') + element.avatar
                    });

                }else{
                    this.$toast(res.data.msg)
                }

            })
        }
    }
}
</script>

<style lang="scss" scoped>

    .mian {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper {
        margin-top: 19rem;
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p {
            font-size: 18px;
        }
    }


    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;
            height: 140px;
                
            .box2{
                padding: 30px 20px
            }

            .img{
                float: left;
                margin-right: 10px;
            }

            .text{
                float: left;
                width: 55%;
                line-height: 76px;

                .name{
                    font-size: 25px;
                    font-weight: 600;
                    width: 100%;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .tips{
                    font-size: 16px;
                    width: 100%;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .grade{
                float: left;
                width: 30px;
                height: 30px;
                background: #56910C;
                color: #ffffff;
                margin-top: 5px;
                margin-left: 10px;

                div{
                    margin: 7px 5px;
                }
            }

        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;
            height: 140px;
                
            .box2{
                padding: 30px 20px
            }

            .img{
                float: left;
                margin-right: 10px;
            }

            .text{
                float: left;
                width: 55%;
                line-height: 40px;

                .name{
                    font-size: 25px;
                    font-weight: 600;
                    width: 100%;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .tips{
                    font-size: 16px;
                    width: 100%;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .grade{
                float: left;
                width: 30px;
                height: 30px;
                background: #56910C;
                color: #ffffff;
                margin-top: 5px;
                margin-left: 10px;

                div{
                    margin: 7px 5px;
                }
            }

        }

    }

</style>