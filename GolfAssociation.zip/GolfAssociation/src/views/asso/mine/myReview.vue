<template>
    <div class="mian">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="我的审核"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="box1" v-for="(item,index) in data" :key="index">
                
                <div class="box2">
                    <div class="type">{{ item.typeName }}</div>
                
                    <div class="nameTpis">
                        <div class="name"><span>{{ item.role }}</span></div>
                        <div class="tips" :style=" item.state == 1 ? 'color: #56910C' : item.state == 0 ? 'color: #2535FB' : item.state == -1 ? 'color: #FF0B0B' : '' ">{{ item.state_txt }}</div>
                    </div>

                    <div class="timeAndmoney">
                        <div class="time">加入时间：{{ item.datetime }}</div>
                    </div>
                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http.js'

export default {
    data(){
        return{

            loadingshow : false,

            data : [
                // {
                //     typeName : '高尔夫球协会',
                //     role : '教练员',
                //     state_txt : '审核通过',
                //     create_time : '2020.05.20',
                //     state : 1,
                // },
            ]
        }
    },
    activated (){
        this.getdata()
    },
    methods : {

        getdata(){
            this.loadingshow = true;
            api.ga_mine_appr().then(res => {
                
                this.loadingshow = false;

                if(res.data.xcode == 0){
                    this.data = res.data.data.list
                }else{
                    this.$toast(res.data.msg)
                }

            })

        },

    }
}
</script>

<style lang="scss" scoped>

    .mian {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }


    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;

            .box2{
                padding: 20px 20px
            }

            .type{
                height: 40px;
                font-size: 20px;
            }

            .nameTpis{
                height: 40px;
                .name{
                    float: left;
                    width: 190px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    span{
                        font-size: 17px;
                    }
                }
                .tips{
                    float: right;
                }
            }

            .timeAndmoney{
                height: 40px;
                .time{
                    float: left;
                    color: rgba(16, 16, 16, 0.29);
                    font-size: 18px;
                }
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #d8d8d865;
        }

        .box1{
            background: #ffffff;
            margin-bottom: 10px;

            .box2{
                padding: 20px 20px
            }

            .type{
                height: 40px;
            }

            .nameTpis{
                height: 40px;
                .name{
                    float: left;
                    width: 190px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    span{
                        font-size: 18px;
                    }
                }
                .tips{
                    float: right;
                }
            }

            .timeAndmoney{
                height: 40px;
                .time{
                    float: left;
                    color: rgba(16, 16, 16, 0.29);
                    font-size: 18px;
                }
            }
        }
    }

</style>