<template>
    <div class="home">
        <div class="index">
            <!-- 协会文字介绍 -->
            <div class="AssociationName">
                <div class="letf">
                    <div class="name">{{ ga_info_Data.name }}</div>
                    <div class="Introduction">
                        <div>{{ ga_info_Data.title }}简介</div>
                        <div>{{ ga_info_Data.introduce }}</div>
                    </div>
                </div>

                <div class="right">
                    <van-button class="btn" type="primary" color="#56910C" @click="goAsso">组织架构</van-button>
                </div>
            </div>

            <!-- 协会视屏图片介绍 -->
            <div class="video_img">
                <div class="video">
                    <div id="mse"></div>
                </div>
                <div class="img">
                    <van-image
                        fit="cover"
                        v-for="(item,index) in img"
                        :key="index"
                        lazy-load
                        :src="item"
                        width="150"
                        height="100"
                        @click="showIMG(item)"
                    />
                </div>
            </div>

            <!-- 注册 -->
            <div class="registered">
                <van-row gutter="20">
                    <van-col
                        class="col"
                        span="6"
                        v-for="(item,index) in registered"
                        :key="index"
                        @click="clickRegistered(item.id,item.name)"
                    >
                        <!-- <img src="../../../assets/home/registered.svg" alt /> -->
                        <div>{{ item.name }}</div>
                    </van-col>
                </van-row>
            </div>
            
            <!-- 各地协会 -->
            <div class="union" @click="onGolfList(1)" v-if="asso_flag">
                <span>{{ asso_name }}</span>
                <van-icon class="icon" name="arrow" />
            </div>

            <!-- 合作企业 -->
            <div class="union" @click="() => { this.$router.push('/asso/jointVenture') }">
                <span>合作企业</span>
                <van-icon class="icon" name="arrow" />
            </div>

            <!-- 球场/基地 -->
            <div class="Tab">
                <van-tabs type="card" color="#56910C">

                    <van-tab title="高尔夫球场" title-style="font-size: 16px;">
                        <div class="content">
                            <div style="width: 90%;margin: 0 auto;padding-top:15px">
                                <div style="float: left;font-size:21px;">高尔夫球场</div>
                                <div style="float: right;margin-top: 5px;" @click="onGolfList(2)">
                                    更多
                                    <van-icon name="arrow" />
                                </div>
                            </div>

                            <div class="yard" @click="onGolfInfo(yard.id)">
                                <div style=" font-size: 20px">{{ yard.name }}</div>
                                <div style=" color: #b4b4b4">{{ yard.introduce }}</div>
                            </div>

                        </div>
                    </van-tab>

                    <van-tab title="高尔夫球基地" title-style="font-size: 16px;">
                        <div class="content">
                            <div style="width: 90%;margin: 0 auto;padding-top:15px">
                                <div style="float: left;font-size:21px;">高尔夫基地</div>
                                <div style="float: right;margin-top: 5px;" @click="onGolfList(3)">
                                    更多
                                    <van-icon name="arrow" />
                                </div>
                            </div>

                            <div class="yard" @click="onGolfInfo(yard_base.id)">
                                <div style=" font-size: 20px">{{ yard_base.name }}</div>
                                <div style=" color: #b4b4b4">{{ yard_base.introduce }}</div>
                            </div>
                        </div>
                    </van-tab>

                </van-tabs>
            </div>

            <!-- 公告 -->
            <div class="announcement">
                <!-- 提示 -->
                <div style="height: 55px; border-bottom: 1px solid rgba(0, 0, 0, 0.03)">
                    <div
                        style="height: 27px; padding-top: 15px"
                        @click="()=>{this.$router.push('/asso/news')}"
                    >
                        <div style="float: left; font-size: 20px; padding-left: 20px">最新公告</div>
                        <div style="float: right; padding-top: 5px; padding-right: 20px">
                            <van-icon name="arrow" />
                        </div>
                    </div>
                </div>

                <!-- 公告List -->
                <div>
                    <div
                        class="list"
                        v-for="(item,index) in noticeList"
                        :key="index"
                        @click="goNewsDetails(item.notice_id)"
                    >
                        <div style="padding-top: 5px">
                            <div class="tips">
                                <van-tag
                                    type="danger"
                                    size="large"
                                    :color="
                  item.type == 1 ? '#FDB37F' 
                  : item.type == 2 ? '#7FBAFD' 
                  : item.type == 3 ? '#FD8F7F' 
                  : item.type == 4 ? '##56910C' 
                  : '' "
                                >{{ item.type_text }}</van-tag>
                            </div>

                            <div class="content">
                                <!-- <van-notice-bar scrollable :text="item.title"/> -->
                                {{ item.title }}
                            </div>

                            <div class="time">{{ item.datetime }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 最新赛事推荐 -->
            <div class="newMatch">
                <!-- 提示 -->
                <div style="height: 55px; border-bottom: 1px solid rgba(0, 0, 0, 0.03)">
                    <div style="height: 27px; padding-top: 15px">
                        <div
                            style="float: left; font-size: 20px; padding-left: 20px; color: #56910C"
                        >最新赛事推荐</div>
                        <div style="float: right; padding-top: 5px; padding-right: 20px">
                            <van-icon name="arrow" />
                        </div>
                    </div>
                </div>

                <div
                    class="content"
                    style="width: 92%;margin: 0 auto; padding-bottom: 40px;"
                    v-for="(item,index) in match"
                    :key="index"
                    @click="goInfo(item.id)"
                >
                    <van-image class="img" :src="item.cover">
                        <template v-slot:loading>
                            <van-loading type="spinner" size="20" />
                        </template>
                    </van-image>
                    <div class="text" style="float: left;">{{ item.title }}</div>
                    <div style="color: #56910C; float: right; padding-top: 5px;">查看详情</div>
                </div>
            </div>

            <van-overlay :show="IMGshow" @click="IMGshow = false" z-index="999">
                <div class="IMGwrapper" @click.stop>
                    <van-image lazy-load :src="ga_info_IMG" />
                </div>
            </van-overlay>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow">
                <div class="wrapper">
                    <van-loading type="spinner" color="#1989fa"></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

            <!-- 导航 -->
            <navigation></navigation>
        </div>
    </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import Store from "@/vuex/store";
import api from "@/components/http.js";
import global from "@/global";
import Player from "xgplayer";

import navigation from "../tabbar/tabbar";

import {wxShare} from "cydsj-app-tool"

export default {
    name: "Home",
    data() {
        return {
            loadingshow: false,

            url: "",

            IMGshow: false,

            // 高尔夫协会信息
            ga_info_Data: [],

            // 协会介绍图片
            img: [],
            ga_info_IMG: "",

            // 注册
            registered: [
                { id: 1, name: "会员" },
                { id: 2, name: "教练" },
                { id: 3, name: "裁判" },
                { id: 4, name: "运动员" },
            ],

            // 分会列表
            branchList: [],

            // 球场
            yard: [],

            // 基地
            yard_base : [],

            // 公告列表
            noticeList: [],

            // 最新赛事推荐
            match: [],

            // 视频插件
            PlayerVidep: null,

            asso_name : '',
            asso_flag : true,
        };
    },
    components: {
        navigation,
    },
    mounted () {
        
        if(this.GetRequest("path")){
            this.$router.push({ path: "/asso/" + this.GetRequest("path") });
        }

        // this.IFToken();
        this.getData();

        this.PlayerVidep = new Player({
            id: "mse",
            url: '',
            width: 150,
            height: 100,
            // fluid: true,  //跟随父元素的宽度大小变化
            ignores: [
                "progress",
                "error",
                "play",
                "time",
                "volume",
            ], //关闭组件
            // controls: false,
            lang: "zh-cn",
        });

    },
    computed: {
        ...mapState(["token"]),
    },
    methods: {
        ...mapActions(["actionsSetGoPath"]),

        // 判断登录
        IFToken() {
            if (Store.state.token) {
                
            } else {
                this.$dialog
                .confirm({
                    message: "请先登录",
                })
                .then(() => {
                    this.$router.push( "/asso/mine" );
                })
                .catch(() => {
                    // this.$router.replace("/");
                });
            }
        },

        getData() {
            this.loadingshow = true;

            const data = {
                asso_id: sessionStorage.getItem('asso_id'),
                limit: 6,
            };

            api.ga_home(data)
                .then((res) => {
                    this.loadingshow = false;

                    if (res.data.xcode == 0) {
                        sessionStorage.setItem("asso_id", res.data.data.info.id);

                        sessionStorage.setItem("asso_url", res.data.data.domain);

                        sessionStorage.setItem("asso_name", res.data.data.info.name);

                        this.ga_info_Data = res.data.data.info;

                        this.img = []

                        // 图片介绍
                        // if (this.ga_info_Data.images) {
                        //     this.ga_info_Data.images
                        //         .split(",")
                        //         .forEach((element) => {
                        //             this.img.push(this.url + element);
                        //         });
                        // }
                        
                        this.PlayerVidep.start(this.ga_info_Data.videos)

                        // 播放器开始播放进入全屏
                        this.PlayerVidep.on("play", function (player) {
                            player.getFullscreen(player.root);
                            // 播放器退出全屏暂停播放
                            player.on("exitFullscreen", function () {
                                player.pause();
                            });
                        });

                        // 分会列表
                        // res.data.data.part.forEach((element) => {
                        //     element.avatar = this.url + element.avatar;
                        // });
                        this.branchList = res.data.data.part;

                        // 球场
                        if(res.data.data.yard != null){
                            this.yard = res.data.data.yard;
                        }

                        // 基地
                        if(res.data.data.yard_base != null){
                            this.yard_base = res.data.data.yard_base;
                        }

                        // 公告
                        this.noticeList = res.data.data.notice;

                        // 最新赛事推荐封面图
                        // res.data.data.match.forEach((element) => {
                        //     element.cover = this.url + element.cover;
                        // });

                        // 最新赛事推荐
                        this.match = res.data.data.match;

                        // 各地市协会名称
                        this.asso_name = res.data.data.asso_name;

                        // 是否显示各地市协会列表
                        this.asso_flag = res.data.data.asso_flag;

                        
                    } else {
                        this.$toast(res.data.msg);
                    }
                })
                .catch((err) => {
                    this.loadingshow = false;
                    if (err.response.status == 401) {
                        this.$toast(err.response.data.msg);
                        // this.actionsSetToken("");
                        sessionStorage.setItem("token", "");
                        // this.actionsSetGoPath({
                        //     type: "actionsSetGoPath",
                        //     payload: "/",
                        // });
                        this.$router.replace("/");
                    }
                });
        },

        // 去组织架构
        goAsso() {
            this.$router.push("/asso/asso");
        },

        // 获取公告
        getNotice() {
            api.ga_notice().then((res) => {
                if (res.data.xcode == 0) {
                    this.noticeList = res.data.data.list;
                } else {
                    this.$toast(res.data.msg);
                }
            });
        },

        // 注册
        clickRegistered(id, name) {
            // this.$toast('ID---' + id + '---技术开发中');

            if (Store.state.token) {
                if(id == 1){
                    this.$router.push({
                        path: "/asso/vipSignUp",
                        query: { id: id, name: name },
                    });
                }else{
                    this.$router.push({
                        path: "/asso/signUp",
                        query: { id: id, name: name },
                    });
                }
            } else {
                this.$dialog
                .confirm({
                    message: "请先登录",
                })
                .then(() => {
                    this.$router.push( "/asso/mine" );
                })
                .catch(() => {
                    // this.$router.replace("/");
                });
            }
        },

        // IMG弹窗
        showIMG(img) {
            this.IMGshow = true;
            this.ga_info_IMG = img;
        },

        // 去公告详情
        goNewsDetails(id) {
            this.$router.push({ path: "/asso/newsDetails", query: { id: id } });
        },

        // 去高尔夫 协会、球场、基地 列表
        onGolfList(type){
            this.$router.push({ path: "/asso/golfListTable", query: { type: type , id : this.ga_info_Data.id} });
        },

        // 去高尔夫某个 球场 或 基地 详细介绍
        onGolfInfo(id){
            this.$router.push({ path: "/asso/vHtml", query: { id : id} });
        },

        // 获取url的token
        GetRequest(param) {
            let url = location.href; //获取url中"?"符后的字串
            let params = url.match(/\?.*/);
            if (!params) return;
            url = params[0];
            const theRequest = {};
            if (url.indexOf("?") !== -1) {
                const str = url.substr(1);
                const strs = str.split("&");
                for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                }
            }
            return theRequest[param];
        },

        // 去赛事详情
        goInfo(id){
            this.$router.push({ path: "/asso/matchinfo", query: { match_id: id } });
        }
    },
};
</script>

<style lang="scss" scoped>
.home {
    display: flex;
    flex-direction: row;
    justify-content: center;
    width: 100vw;
    height: auto;
    overflow-x: hidden;
    margin-bottom: 70px;
}

// loading 加载
.wrapper {
    text-align: center;
    color: rgb(168, 169, 170);
    font-size: 20px;
    p {
        font-size: 18px;
    }
}

// 图片弹窗
.IMGwrapper {
    width: 100%;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%); /*向左向上分别平移自身的一半*/
    -webkit-transform: translate(-50%, -50%);
    -moz-transform: translate(-50%, -50%);
    text-align: center;
}

@media screen and (max-width: 600px) {
    .index {
        width: 100vw;
        min-height: 100vh;
        height: auto;
        background-color: #ffffff;
    }

    // 协会文字介绍
    .AssociationName {
        height: 66px;
        padding-top: 40px;
        padding-bottom: 20px;

        .letf {
            float: left;
            margin-left: 20px;
            line-height: 22px;
            width: 50%;

            .name {
                // width: 225px;
                width: 100%;
                font-size: 20px;
                color: #222222;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .Introduction {
                margin-top: 5px;
                // width: 230px;
                width: 100%;
                font-size: 15px;
                color: #bbbbbb;
                div {
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }
        }

        .right {
            float: right;
            margin-right: 20px;

            .btn {
                margin-top: 8px;
                font-size: 15px;
                font-weight: 600;
                border-radius: 5px;
                height: 40px;
            }
        }
    }

    // 协会视频图片介绍
    .video_img {
        // width: auto;
        width: 90%;
        height: 100px;
        margin: 0 auto;
        margin-bottom: 25px;
        white-space: nowrap; /*文本不会换行，文本会在在同一行上继续*/
        overflow-x: auto;
        overflow-y: hidden;

        .video {
            float: left;
            width: 150px;
            margin-right: 15px;
        }

        .img {
            div {
                margin-right: 15px;
                // width: 150px;
                // height: 100px;
                display: inline-block; /*行内块元素*/
            }
        }
    }
    // 隐藏滑动条
    .video_img::-webkit-scrollbar {
        display: none; /* Chrome Safari */
    }

    // 注册
    .registered {
        width: 95%;
        margin: 0 auto;
        margin-bottom: 20px;
        text-align: center;
        font-size: 17px;
        img {
            width: 30px;
            padding-bottom: 5px;
        }
    }

    // 各地协会
    .union{
        line-height: 50px;
        padding: 0px 18px;
        background: #F7F7F7;
        font-size: 18px;

        .icon{
            margin-top: 15px;
            float: right;
        }
    }

    // 分会/基地
    .Tab {
        .content {
            margin-top: 15px;
            background-color: rgba(0, 0, 0, 0.03);
            height: 165px;

            .row {
                padding-top: 40px;
                text-align: center;
            }

            .yard {
                padding-top: 60px;
                line-height: 25px;

                div {
                    margin: 0 auto;
                    width: 300px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    word-break: keep-all;
                }
            }
        }
    }

    // 公告
    .announcement {
        .list {
            padding-top: 10px;
            padding-bottom: 10px;
            // height: 25px;
            height: 45px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.03);

            .tips {
                float: left;
                padding-left: 20px;
            }

            .content {
                float: left;
                padding-left: 10px;
                padding-top: 2px;
                width: 200px;
                overflow: hidden; /*超出部分隐藏*/
                white-space: nowrap; /*不换行*/
                text-overflow: ellipsis; /*超出部分文字以...显示*/
            }

            .time {
                float: right;
                font-size: 12px;
                padding-top: 10px;
                padding-right: 20px;
                color: rgba(16, 16, 16, 0.29);
            }
        }
    }

    // 赛事推荐
    .newMatch {
        margin-bottom: 20px;
        font-size: 18px;

        .img {
            width: 100%;
            height: 180px;
        }

        .text {
            padding-top: 5px;
            width: 50%;
            overflow: hidden; /*超出部分隐藏*/
            white-space: nowrap; /*不换行*/
            text-overflow: ellipsis; /*超出部分文字以...显示*/
        }
    }
}

@media screen and (min-width: 600px) {
    .index {
        width: 600px;
        min-height: 100vh;
        height: auto;
        background-color: #ffffff;
    }

    // 协会文字介绍
    .AssociationName {
        height: 66px;
        padding-top: 40px;
        padding-bottom: 20px;

        .letf {
            float: left;
            margin-left: 20px;
            line-height: 22px;

            .name {
                width: 225px;
                font-size: 20px;
                color: #222222;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .Introduction {
                margin-top: 5px;
                width: 230px;
                font-size: 15px;
                color: #bbbbbb;
                div {
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }
        }

        .right {
            float: right;
            margin-right: 20px;

            .btn {
                margin-top: 8px;
                font-size: 15px;
                font-weight: 600;
                border-radius: 5px;
                height: 40px;
            }
        }
    }

    // 协会视频图片介绍
    .video_img {
        // width: auto;
        width: 90%;
        height: 100px;
        margin: 0 auto;
        margin-bottom: 25px;
        white-space: nowrap; /*文本不会换行，文本会在在同一行上继续*/
        overflow-x: auto;
        overflow-y: hidden;

        .video {
            float: left;
            width: 150px;
            margin-right: 15px;
        }

        .img {
            div {
                margin-right: 15px;
                width: 150px;
                height: 100px;
                display: inline-block; /*行内块元素*/
            }
        }
    }
    // 隐藏滑动条
    .video_img::-webkit-scrollbar {
        display: none; /* Chrome Safari */
    }

    // 注册
    .registered {
        width: 95%;
        margin: 0 auto;
        margin-bottom: 20px;
        text-align: center;
        font-size: 17px;
        img {
            width: 30px;
            padding-bottom: 5px;
        }
    }

    // 各地协会
    .union{
        line-height: 50px;
        padding: 0px 18px;
        background: #F7F7F7;
        font-size: 18px;

        .icon{
            margin-top: 15px;
            float: right;
        }
    }

    // 分会/基地
    .Tab {
        .content {
            margin-top: 15px;
            background-color: rgba(0, 0, 0, 0.03);
            height: 165px;

            .row {
                padding-top: 40px;
                text-align: center;
            }

            .yard {
                padding-top: 60px;
                line-height: 25px;

                div {
                    margin: 0 auto;
                    width: 300px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    word-break: keep-all;
                }
            }
        }
    }

    // 公告
    .announcement {
        .list {
            padding-top: 10px;
            padding-bottom: 10px;
            // height: 25px;
            height: 45px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.03);

            .tips {
                float: left;
                padding-left: 20px;
            }

            .content {
                float: left;
                padding-left: 10px;
                padding-top: 2px;
                width: 200px;
                overflow: hidden; /*超出部分隐藏*/
                white-space: nowrap; /*不换行*/
                text-overflow: ellipsis; /*超出部分文字以...显示*/
            }

            .time {
                float: right;
                font-size: 12px;
                padding-top: 10px;
                padding-right: 20px;
                color: rgba(16, 16, 16, 0.29);
            }
        }
    }

    // 赛事推荐
    .newMatch {
        margin-bottom: 20px;
        font-size: 18px;

        .img {
            width: 100%;
            height: 180px;
        }

        .text {
            padding-top: 5px;
            width: 50%;
            overflow: hidden; /*超出部分隐藏*/
            white-space: nowrap; /*不换行*/
            text-overflow: ellipsis; /*超出部分文字以...显示*/
        }
    }
}
</style>
