<template>
    <div class="mine">
        <div class="index">

            <van-nav-bar
                class="assoNavBar"
                title="合作企业"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />
            
            <div class="content">

                <van-grid :border="false" :column-num="2" :gutter="12">
                    <van-grid-item v-for="(item,index) in Data.enterprises" :key="index" style="border-radius: 10px;">
                        <div class="enterprises">
                            <van-image class="image" width="150" height="50" :src="item.images" fit="contain" lazy-load/>
                            <div class="text">
                                {{ item.name }}
                            </div>
                        </div>
                    </van-grid-item>
                </van-grid>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" z-index='999'>
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import Player from "xgplayer";
import api from '@/components/http'

export default {
    data(){
        return {

            loadingshow : false,

            Data : {},
        }
    },
    components : {

    },
    activated(){
        this.getData()
    },
    methods :{
        getData(){
            this.loadingshow = true;

            api.ga_enterprise({ asso_id : sessionStorage.getItem('asso_id') }).then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0){
                    this.Data = res.data.data.info
                }else{
                    this.$toast(res.data.msg)
                }

            })

            
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        // background-color: #F6F6F6;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #F6F6F6;
        }

        .content{
            .enterprises{
                text-align: center;
                border-radius: 5px;

                .text{
                    font-size: 16px;
                }
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #F6F6F6;
        }
    }

</style>