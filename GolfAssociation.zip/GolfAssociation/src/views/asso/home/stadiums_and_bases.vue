<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="列表"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            

            <div class="TrainingTabs">
                <van-tabs v-model="active" type="card" color="#56910C" @click="onTabes">

                    <van-tab title="协会球场" >
                        
                        <div class="box" v-for="(item,index) in list" :key="index" @click="onAsso(item.id)">

                            <div class="text">
                                <div class="title">{{ item.name }}</div>
                                <div class="content">{{ item.introduce }}</div>
                            </div>

                            <van-icon class="icon" name="arrow" size="20"/>

                        </div>

                        <van-empty style="background: #FFFFFF;" description="暂无数据" v-if="list.length <= 0"/>

                    </van-tab>

                    <van-tab title="协会基地" >
                        
                        <div class="box" v-for="(item,index) in list" :key="index" @click="onAsso(item.id)">

                            <div class="text">
                                <div class="title">{{ item.name }}</div>
                                <div class="content">{{ item.introduce }}</div>
                            </div>

                            <van-icon class="icon" name="arrow" size="20"/>

                        </div>

                        <van-empty style="background: #FFFFFF;" description="暂无数据" v-if="list.length <= 0"/>

                    </van-tab>

                </van-tabs>
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import img from '@/assets/asso/sponsor/sponsor.png'

export default {
    data(){
        return {

            loadingshow : false,

            list : [],

            active : 0,
        }
    },
    components : {

    },
    activated(){
        if(this.active == 0){
            this.getData(1)
        }else{
            this.getData(2)
        }
    },
    methods :{
        getData(type){
            
            this.loadingshow = true;

            switch (type) {

                // 球场
                case 1:
                    api.getYardBase({ type : 'yard' }).then(res => {
                        this.loadingshow = false
                        if(res.data.xcode == 0){
                            this.list = res.data.data.yard;
                        }else{
                            this.$toast(res.data.msg)
                        }
                    })
                    break;

                // 基地
                case 2:
                    api.getYardBase({ type : 'yard_base' }).then(res => {
                        this.loadingshow = false
                        if(res.data.xcode == 0){
                            this.list = res.data.data.yard_base;
                        }else{
                            this.$toast(res.data.msg)
                        }
                    })
                    break;
            
                default:
                    break;
            }
            
        },

        // 去详情
        onAsso(id){

            this.$router.push({ path: "/asso/vHtml", query: { id : id } });

        },

        // 导航切换
        onTabes(item){
            if(item == 0){
                this.getData(1)
            }else{
                this.getData(2)
            }
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }
    

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .TrainingTabs{
            background: #ffffff;
            height: 100%;
        }

        .box{
            
            background: #ffffff;
            padding: 0px 20px;
            height: 90px;
            border-bottom: 1px solid #efefef;

            .text{
                padding-top: 22px;
                float: left;
                width: 85%;

                .title{
                    font-size: 18px;
                    font-weight: 600;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .content{
                    width: 200px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .icon{
                float: right;
                padding-top: 35px;
            }

        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .box{
            
            margin: 10px 0px;
            background: #F7F7F7;
            padding: 0px 20px;
            height: 90px;

            .TX{
                padding: 20px 0px;
                padding-right: 20px;
                float: left;
            }

            .text{
                padding-top: 22px;
                float: left;
                width: 85%;

                .title{
                    font-size: 18px;
                    font-weight: 600;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .content{
                    width: 200px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .icon{
                float: right;
                padding-top: 35px;
            }

        }
    }

</style>