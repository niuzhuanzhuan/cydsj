<template>
    <div class="asso">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="组织架构"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 协会数据 -->
            <div class="myData">
                
                <!-- 头像名/名字 -->
                <div class="name_avatar">
                    <img class="avatar" :src="myData.avatar" alt="">
                    <div class="name">{{ myData.name }}</div>

                    <!-- <van-button
                        style="margin: 28px 0px;float: right;"
                        color="#56910C" 
                        type="primary"
                        size="mini"
                        @click="open(myData.id)"
                        v-if="myData.id != asso_id"
                    >查看协会</van-button> -->

                </div>

                <!-- 介绍 -->
                <div class="introduce">
                    <div class="introduceText">{{ myData.introduce }}</div>
                </div>

            </div>

            <!-- 协会人员列表 -->
            <div class="assoUserList">
                <van-grid :column-num="5" :border="false">
                    <van-grid-item v-for="(item,index) in assoUserList" :key="index" @click="onTabbar(item.name,index)">
                        <van-image lazy-load :src="item.img" width="30" height="30"/>
                        <div class="name">{{ item.name }}</div>
                    </van-grid-item>
                </van-grid>
            </div>

            <!-- 协会荣誉 -->
            <div class="assoHonor">
                <div class="boxTitle">
                    协会荣誉
                </div>
                <div class="content" v-for="(item,index) in myData.honors" :key="index">{{ item }}</div>
            </div>

            <!-- 协会联系信息 -->
            <div class="contact">
                <div class="boxTitle">
                    联系我们
                </div>
                <div class="content">
                    <div class="box">
                        <van-image class="icon" width="20" height="20" :src="require('../../../assets/asso/framework/map.png')" />
                        <div class="text">{{ myData.address_info }}</div>
                    </div>
                    <div class="box">
                        <van-image class="icon" width="20" height="20" :src="require('../../../assets/asso/framework/phone1.png')" />
                        <div class="text">{{ myData.contacts_name }}  {{ myData.contacts_phone }}</div>
                    </div>
                    <div class="box">
                        <van-image class="icon" width="20" height="20" :src="require('../../../assets/asso/framework/phone2.png')" />
                        <div class="text">{{ myData.contacts_tel }}</div>
                    </div>
                </div>
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import img1 from '@/assets/asso/framework/1.png'
import img2 from '@/assets/asso/framework/2.png'
import img3 from '@/assets/asso/framework/3.png'
import img4 from '@/assets/asso/framework/4.png'
import img5 from '@/assets/asso/framework/5.png'

export default {
    data(){
        return {
            loadingshow : false,

            // url : sessionStorage.getItem('asso_url'),

            asso_id : sessionStorage.getItem('asso_id'),
            
            // 协会数据
            myData : [],

            // 是不是分协会
            branch : 0,

            // 协会人员列表九宫格数据
            assoUserList : [
                { 
                    img: img1, 
                    name: "管理人员" 
                },
                { 
                    img: img2, 
                    name: "会员" 
                },
                { 
                    img: img3, 
                    name: "裁判" 
                },
                { 
                    img: img4, 
                    name: "教练" 
                },
                { 
                    img: img5, 
                    name: "运动员" 
                },
            ],
        }
    },
    activated(){
        this.getData();

        if(this.$route.query.branch){
            this.branch = this.$route.query.branch
        }else{
            this.branch = 0
        }

    },
    // mounted(){
    //     this.getData();
    // },
    methods :{
        getData(){
            this.loadingshow = true;
            
            // const data ={
            //     asso_id : ''
            // }

            const data ={
                id : ''
            }

            if(this.$route.query.asso_id){
                data.id = this.$route.query.asso_id

            }else{
                data.id = sessionStorage.getItem('asso_id')
            }

            api.getAssoDetail(data).then(res => {
                
                this.loadingshow = false;
                
                if(res.data.xcode == 0){
                    
                    // 荣耀
                    res.data.data.res_asso.honors = res.data.data.res_asso.honors.split(',')

                    this.myData = res.data.data.res_asso

                }else{
                    this.$toast(res.data.msg);
                }

            })
            
        },

        // 跳转协会团队列表
        onTeamInfo(id){
            this.$router.push({ path: "/asso/team", query: { id: id } });
        },

        // 跳转协会人员列表
        onTabbar(item,index){

            if(this.$route.query.asso_id){
                this.asso_id = this.$route.query.asso_id
            }else{
                this.asso_id = sessionStorage.getItem('asso_id')
            }

            switch (index) {

                case 0:
                    this.$router.push({ path: "/asso/adminList", query: { type: 5, title: item , branch : this.branch , asso_id : this.asso_id } });
                    break;

                case 1:
                    this.$router.push({ path: "/asso/userList", query: { type: 3, title: item , branch : this.branch , asso_id : this.asso_id } });
                    break;

                case 2:
                    this.$router.push({ path: "/asso/userList", query: { type: 1, title: item , branch : this.branch , asso_id : this.asso_id } });
                    break;

                case 3:
                    this.$router.push({ path: "/asso/userList", query: { type: 2, title: item , branch : this.branch , asso_id : this.asso_id } });
                    break;

                case 4:
                    this.$router.push({ path: "/asso/userList", query: { type: 4, title: item , branch : this.branch , asso_id : this.asso_id } });
                    break;
            
                default:
                    break;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
    
    .asso {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    .boxTitle{
        padding: 20px 15px;
        font-size: 18px;
        font-family: Source Han Sans CN;
        font-weight: 500;
    }
    
    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }
        
        // 协会介绍
        .myData{
            padding: 10px;
            margin: 0 auto;
            background-color: #ffffff;

            // 名字——头像
            .name_avatar{
                height: 80px;
                width: 340px;

                .avatar{
                    width: 80px;
                    height: 80px;
                    border-radius: 50px;
                    float: left;
                }
                .name{
                    font-size: 20px;
                    font-weight: 600;
                    float: left;
                    margin: 25px 20px;
                }
            }

            // 协会介绍
            .introduce{

                .introduceText{
                    padding: 10px;
                    color: #666666;
                    font-size: 14px;
                    line-height: 22px;
                }

            }
        }

        // 协会人员列表
        .assoUserList{
            margin: 15px 0px;
            .name{
                padding-top: 10px;
                font-size: 13px;
            }
        }

        // 协会荣誉
        .assoHonor{
            background: #ffffff;
            .content{
                padding: 0px 15px;
                padding-bottom: 20px;
                color: #666666;
                font-size: 14px;
                line-height: 22px;
            }
        }
        
        // 协会联系信息
        .contact{
            margin: 15px 0px;
            background: #ffffff;

            .content{
                padding: 0px 12px;

                .box{
                    padding-bottom: 15px;
                    .icon{
                        float: left;
                    }
                    .text{
                        color: #666666;
                        padding-left: 30px;
                        font-size: 14px;
                        height: 20px;
                    }
                }
            }
        }

    }

    @media screen and (min-width: 600px) {
		.index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        // 协会介绍
        .myData{
            padding: 10px;
            margin: 0 auto;
            background-color: #ffffff;

            // 名字——头像
            .name_avatar{
                height: 80px;
                width: 340px;

                .avatar{
                    width: 80px;
                    height: 80px;
                    border-radius: 50px;
                    float: left;
                }
                .name{
                    font-size: 20px;
                    font-weight: 600;
                    float: left;
                    margin: 25px 20px;
                }
            }

            // 协会介绍
            .introduce{

                .introduceText{
                    padding: 10px;
                    color: #666666;
                    font-size: 14px;
                    line-height: 22px;
                }

            }
        }

        // 协会人员列表
        .assoUserList{
            margin: 15px 0px;
            .name{
                padding-top: 10px;
                font-size: 13px;
            }
        }

        // 协会荣誉
        .assoHonor{
            background: #ffffff;
            .content{
                padding: 0px 15px;
                padding-bottom: 20px;
                color: #666666;
                font-size: 14px;
                line-height: 22px;
            }
        }
        
        // 协会联系信息
        .contact{
            margin: 15px 0px;
            background: #ffffff;

            .content{
                padding: 0px 12px;

                .box{
                    padding-bottom: 15px;
                    .icon{
                        float: left;
                    }
                    .text{
                        color: #666666;
                        padding-left: 30px;
                        font-size: 14px;
                        height: 20px;
                    }
                }
            }
        }
    }

</style>