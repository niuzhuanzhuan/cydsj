<template>
    <div class="asso">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="组织架构"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 我的协会数据 -->
            <div class="myData">
                
                <!-- 头像名/名字 -->
                <div class="name_avatar">
                    <img class="avatar" :src="myData.avatar" alt="">
                    <div class="name">{{ myData.name }}</div>

                    <van-button
                        style="margin: 28px 0px;float: right;"
                        color="#56910C" 
                        type="primary"
                        size="mini"
                        @click="open(myData.id)"
                        v-if="myData.id != asso_id"
                    >查看协会</van-button>

                </div>

                <!-- 介绍 -->
                <div class="introduce box">

                    <div class="tips">
                        <div class="greenBox"></div>
                        <div class="text">协会介绍</div>
                    </div>

                    <div class="introduceText">{{ myData.introduce }}</div>

                </div>

                <!-- 球队列表 -->
                <div class="introduce box">

                    <div class="tips">
                        <div class="greenBox"></div>
                        <div class="text">球队列表</div>
                    </div>

                    <div class="teamList" v-for="(item,index) in team" :key="index" @click="onTeamInfo(item.id)">
                        
                        <div class="TX" >
                            <van-image
                                width="55px"
                                height="55px"
                                fit="contain"
                                :src="item.avatar"
                                round
                            />
                        </div>

                        <div class="text">
                            <div class="title">{{ item.number }}人</div>
                            <div class="content">{{ item.name }}</div>
                        </div>

                        <van-icon class="icon" name="arrow" size="20"/>

                    </div>

                </div>

                <!-- 荣耀 -->
                <div class="glory box">

                    <div class="tips">
                        <div class="greenBox"></div>
                        <div class="text">协会荣耀</div>
                    </div>

                    <div class="honors" v-for="(item,index) in myData.honors" :key="index">{{ item }}</div>

                </div>

                <!-- 主席 -->
                <div class="Chairman box">

                    <div class="tips">
                        <div class="greenBox"></div>
                        <div class="text">主席</div>
                    </div>

                    <!-- 头像名/名字 -->
                    <div class="nameAndavatar" v-for="(item,index) in myData.chairman" :key="index">
                        <!-- <img class="avatar" :src="item.avatar" alt=""> -->
                        <van-image class="avatar" :src="item.avatar" round>
                            <template v-slot:loading>
                                <van-loading type="spinner" size="20" />
                            </template>
                        </van-image>
                        <div class="name">{{ item.name }}</div>
                    </div>

                </div>

                <!-- 副主席 -->
                <div class="Chairman box">

                    <div class="tips">
                        <div class="greenBox"></div>
                        <div class="text">副主席</div>
                    </div>

                    <!-- 头像名/名字 -->
                    <div class="nameAndavatar" v-for="(item,index) in myData.chairman2" :key="index">
                        <!-- <img class="avatar" :src="item.avatar" alt=""> -->
                        <van-image class="avatar" :src="item.avatar" round>
                            <template v-slot:loading>
                                <van-loading type="spinner" size="20" />
                            </template>
                        </van-image>
                        <div class="name">{{ item.name }}</div>
                    </div>

                </div>

                <!-- 通用人员显示 -->
                <div class="Chairman box" v-for="(item,index) in myData.others" :key="index">

                    <div class="tips">
                        <div class="greenBox"></div>
                        <div class="text">{{ item.name }}</div>
                    </div>

                    <!-- 头像名/名字 -->
                    <div class="nameAndavatar" v-for="(item,index) in item.list" :key="index" v-if="index <= 8">
                        <van-image class="avatar" :src="item.avatar" round>
                            <template v-slot:loading>
                                <van-loading type="spinner" size="20" />
                            </template>
                        </van-image>
                        <div class="name">{{ item.name }}</div>
                    </div>

                    <van-button 
                        color="#56910C" 
                        type="primary" 
                        block v-if="item.name == '运动员' && item.list != 0" 
                        style="font-size : 16px"
                        @click="onUserList"
                    >查看更多</van-button>

                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import global from '@/global'

export default {
    data(){
        return {
            loadingshow : false,
            // url : sessionStorage.getItem('asso_url'),
            myData : [],
            team : [],
            asso_id : sessionStorage.getItem('asso_id')
        }
    },
    activated(){
        this.getData();
    },
    // mounted(){
    //     this.getData();
    // },
    methods :{
        getData(){
            this.loadingshow = true;
            
            const data ={
                asso_id : ''
            }

            if(this.$route.query.asso_id){
                data.asso_id = this.$route.query.asso_id

            }else{
                data.asso_id = sessionStorage.getItem('asso_id')
            }

            api.ga_asso(data).then(res => {
                
                this.loadingshow = false;
                
                if(res.data.xcode == 0){
                    
                    console.log(res.data.data.inf)

                    // 协会头像
                    // res.data.data.info.avatar = this.url + res.data.data.info.avatar

                    // 荣耀
                    res.data.data.info.honors = res.data.data.info.honors.split(',')

                    // // 主席
                    // res.data.data.info.chairman.forEach((element,index) => {
                    //     res.data.data.info.chairman[index].avatar = this.url + res.data.data.info.chairman[index].avatar
                    // });
                    // // 副主席
                    // res.data.data.info.chairman2.forEach((element,index) => {
                    //     res.data.data.info.chairman2[index].avatar = this.url + res.data.data.info.chairman2[index].avatar
                    // });

                    // // 通用人员
                    // res.data.data.info.others.forEach((element,index) => {
                    //     res.data.data.info.others[index].list.forEach((element,index2) => {
                    //         res.data.data.info.others[index].list[index2].avatar = this.url + res.data.data.info.others[index].list[index2].avatar
                    //     })
                    // });

                    this.myData = res.data.data.info

                    this.team = res.data.data.team

                }else{

                }

            })
            
        },

        onTeamInfo(id){
            this.$router.push({ path: "/asso/team", query: { id: id } });
        },

        open(id){
            sessionStorage.setItem("asso_id", id);
            window.location.href = global.REST_URL + '/golfAsso/#/?match_id=' + id
            // window.location.href = 'http://192.168.43.223:8080/golfAsso/#/?match_id=' + id
        },

        onUserList(id){
            this.$router.push({ path: "/asso/userList", query: { id: this.myData.id } });
        }
    }
}
</script>

<style lang="scss" scoped>
    
    .asso {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        margin-bottom: 70px;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    .box{
        margin-top: 40px;
    }

    .tips{
        margin-bottom: 20px;
        .greenBox{
            width: 10px;
            height: 20px;
            background: #56910C;
            float: left;
            margin-top: 4px;
            margin-right: 10px;
        }

        .text{
            font-size: 20px;
            font-weight: 600;
        }
    }
    
    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 93vh;
            height: auto;
            background-color: #FFFFFF;
        }

        .myData{
            width: 90%;
            margin: 0 auto;

            // 名字——头像
            .name_avatar{
                height: 80px;
                width: 340px;
                margin-top: 20px;

                .avatar{
                    width: 80px;
                    height: 80px;
                    border-radius: 50px;
                    float: left;
                }
                .name{
                    font-size: 20px;
                    font-weight: 600;
                    float: left;
                    margin: 25px 20px;
                }
            }

            // 协会介绍
            .introduce{

                .introduceText{
                    width: 95%;
                    margin-left: 10px;
                    line-height: 25px;
                }

            }

            // 球队列表
            .teamList{
            
                margin: 10px 0px;
                background: #F7F7F7;
                height: 90px;
                padding: 0px 20px;
                border-radius: 5px;

                .TX{
                    padding: 20px 0px;
                    padding-right: 20px;
                    float: left;
                }

                .text{
                    padding-top: 22px;
                    float: left;
                    width: 50%;

                    .title{
                        font-size: 13px;
                        color: #555555;
                    }
                    .content{
                        font-size: 20px;
                        font-weight: 600;
                        // width: 200px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }

                .icon{
                    float: right;
                    padding-top: 35px;
                }

            }

            /* 荣耀 */
            .glory{

                .honors{
                    font-size: 18px;
                    margin-left: 10px;
                    margin-bottom: 10px;
                }

            }

            // 人员显示
            .Chairman{

                height: auto;

                .nameAndavatar{
                    margin-left: 10px;
                    display: inline-block;
                    margin-right: 20px;
                    text-align: center;
                    padding-bottom: 10px;

                    .avatar{
                        width: 60px;
                        height: 60px;
                        border-radius: 50px;
                        margin-bottom: 5px;
                    }

                    .name{
                        font-size: 16px;
                    }
                }
            }
        }

    }

    @media screen and (min-width: 600px) {
		.index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }

        .myData{
            width: 90%;
            margin: 0 auto;

            // 名字——头像
            .name_avatar{
                height: 80px;
                width: 340px;
                margin-top: 20px;

                .avatar{
                    width: 80px;
                    height: 80px;
                    border-radius: 50px;
                    float: left;
                }
                .name{
                    font-size: 20px;
                    font-weight: 600;
                    float: left;
                    margin: 25px 20px;
                }
            }

            // 协会介绍
            .introduce{

                .introduceText{
                    width: 95%;
                    margin-left: 10px;
                    line-height: 25px;
                }

            }

             // 球队列表
            .teamList{
            
                margin: 10px 0px;
                background: #F7F7F7;
                height: 90px;
                padding: 0px 20px;
                border-radius: 5px;

                .TX{
                    padding: 20px 0px;
                    padding-right: 20px;
                    float: left;
                }

                .text{
                    padding-top: 22px;
                    float: left;

                    .title{
                        font-size: 13px;
                        color: #555555;
                    }
                    .content{
                        font-size: 20px;
                        font-weight: 600;
                        width: 200px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }

                .icon{
                    float: right;
                    padding-top: 35px;
                }

            }

            /* 荣耀 */
            .glory{

                .honors{
                    font-size: 18px;
                    margin-left: 10px;
                    margin-bottom: 10px;
                }

            }

            // 人员显示
            .Chairman{

                height: auto;

                .nameAndavatar{
                    margin-left: 10px;
                    display: inline-block;
                    margin-right: 20px;
                    text-align: center;
                    padding-bottom: 10px;

                    .avatar{
                        width: 60px;
                        height: 60px;
                        border-radius: 50px;
                        margin-bottom: 5px;
                    }

                    .name{
                        font-size: 16px;
                    }
                }
            }
        }
    }

</style>