<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="列表"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="box" v-for="(item,index) in list" :key="index" @click="onAsso(item.id)">

                <div class="TX" v-if="type == 1">
                    <van-image
                        width="55px"
                        height="55px"
                        fit="contain"
                        :src="item.avatar"
                        round
                    />
                </div>

                <div class="text">
                    <div class="title">{{ item.name }}</div>
                    <div class="content">{{ item.introduce }}</div>
                </div>

                <van-icon class="icon" name="arrow" size="20"/>

            </div>

            <van-empty description="暂无数据" v-if="list.length <= 0"/>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import img from '@/assets/asso/sponsor/sponsor.png'

export default {
    data(){
        return {

            loadingshow : false,

            list : [],

            type : '',

        }
    },
    components : {

    },
    activated(){
        this.getData()
    },
    methods :{
        getData(){
            
            this.loadingshow = true;

            this.type = this.$route.query.type

            switch (Number(this.type)) {
                
                // 各地区协会
                case 1:
                    api.getAssoList({ id : sessionStorage.getItem('asso_id') }).then(res => {
                        this.loadingshow = false
                        if(res.data.xcode == 0){
                            this.list = res.data.data.golf_asso;
                            this.list.forEach(ele => {
                                ele.avatar = res.data.data.domain +  ele.avatar
                            })
                        }else{
                            this.$toast(res.data.msg)
                        }
                    })
                    break;

                // 球场
                case 2:
                    api.getYardBase({ type : 'yard' }).then(res => {
                        this.loadingshow = false
                        if(res.data.xcode == 0){
                            this.list = res.data.data.yard;
                        }else{
                            this.$toast(res.data.msg)
                        }
                    })
                    break;

                    // 球场
                case 3:
                    api.getYardBase({ type : 'yard_base' }).then(res => {
                        this.loadingshow = false
                        if(res.data.xcode == 0){
                            this.list = res.data.data.yard_base;
                        }else{
                            this.$toast(res.data.msg)
                        }
                    })
                    break;
            
                default:
                    break;
            }
            

            
        },

        onAsso(id){

            switch (Number(this.type)) {
                // 各地区协会
                case 1:
                    this.$router.push({ path: "/asso/asso", query: { asso_id: id , branch : 1 } });
                    break;

                // // 球场
                // case 2:
                //     this.$router.push({ path: "/asso/vHtml", query: { id : id} });
                //     break;

                //     // 球场
                // case 3:
                //     this.$router.push({ path: "/asso/vHtml", query: { id : id} });
                //     break;
            
                default:
                    break;
            }

        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }
    

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .box{
            
            margin: 10px 0px;
            background: #F7F7F7;
            padding: 0px 20px;
            height: 90px;

            .TX{
                padding: 20px 0px;
                padding-right: 20px;
                float: left;
            }

            .text{
                padding-top: 22px;
                float: left;
                width: 60%;

                .title{
                    font-size: 18px;
                    font-weight: 600;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .content{
                    width: 200px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .icon{
                float: right;
                padding-top: 35px;
            }

        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .box{
            
            margin: 10px 0px;
            background: #F7F7F7;
            padding: 0px 20px;
            height: 90px;

            .TX{
                padding: 20px 0px;
                padding-right: 20px;
                float: left;
            }

            .text{
                padding-top: 22px;
                float: left;
                width: 60%;

                .title{
                    font-size: 18px;
                    font-weight: 600;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .content{
                    width: 200px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }

            .icon{
                float: right;
                padding-top: 35px;
            }

        }
    }

</style>