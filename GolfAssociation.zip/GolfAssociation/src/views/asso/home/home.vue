<template>
    <div class="home">
        <div class="index">

            <!-- 协会名称 -->
            <div class="AssociationName">

                <div class="content">
                    <div class="name">{{ ga_info_Data.name }}</div>
                    <div class="btn" @click="goAsso">
                        <div class="text">点击进入</div>
                        <van-icon name="arrow" size="15" style="margin-top: 8px;"/>
                    </div>
                </div>

            </div>
            
            <!-- 轮播 -->
            <div class="swipe">
                <van-swipe :autoplay="3000" style="border-radius: 20px;">
                    <van-swipe-item v-for="(item,index) in img" :key="index" @click="onSwipe(item,index)">
                        <van-image lazy-load :src="item" fit="cover" width="100%" height="180px" style="border-radius: 20px;"/>
                        
                        <!-- 视频播放标志 -->
                        <div class="play" v-if="index == 0">
                            <van-image :src="videoPlayIMG" width="40px" height="40px" />
                        </div>
                    </van-swipe-item>
                </van-swipe>
            </div>

            <!-- 导航 -->
            <div class="tabbar">
                <navigation></navigation>
            </div>

            <!-- 公告 -->
            <div class="announcement">
                <div style="height: 48px;">
                    <div style="height: 27px; padding-top: 15px" >
                        <div style="float: left; font-size: 18px; padding-left: 20px">最新公告</div>
                        <van-button
                            class="moreButton"
                            plain
                            hairline
                            round
                            size="small"
                            color="#999999"
                            @click="()=>{this.$router.push('/asso/news')}"
                        >查看更多</van-button>
                    </div>
                </div>

                <div>
                    <div
                        class="list"
                        v-for="(item,index) in noticeList"
                        :key="index"
                        @click="goNewsDetails(item.notice_id)"
                    >
                        <div style="padding-top: 5px">
                            <div class="tips">
                                <van-tag
                                    type="danger"
                                    size="large"
                                    :color="
                                    item.type == 1 ? '#FDB37F' 
                                    : item.type == 2 ? '#7FBAFD' 
                                    : item.type == 3 ? '#FD8F7F' 
                                    : item.type == 4 ? '##56910C' 
                                    : '' "
                                >{{ item.type_text }}</van-tag>
                            </div>

                            <div class="content">
                                {{ item.title }}
                            </div>

                            <div class="time">{{ item.datetime }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 最新赛事推荐 -->
            <div class="newMatch">
                <div style="height: 48px;">
                    <div style="height: 27px; padding-top: 15px" >
                        <div style="float: left; font-size: 18px; padding-left: 20px">最新赛事推荐</div>
                        <van-button
                            class="moreButton"
                            plain
                            hairline
                            round
                            size="small"
                            color="#999999"
                            @click="()=>{this.$router.push('/asso/match')}"
                        >查看更多</van-button>
                    </div>
                </div>

                <div
                    class="content"
                    v-for="(item,index) in match"
                    :key="index"
                    @click="goInfo(item.id)"
                >
                    <van-image class="image" fit="cover" :src="item.cover">
                        <template v-slot:loading>
                            <van-loading type="spinner" size="20" />
                        </template>
                    </van-image>
                    <div class="contentText">
                        <div class="text" style="float: left;">{{ item.title }}</div>
                        <!-- <div style="color: #56910C; float: right; padding-top: 5px;">查看详情</div> -->
                        <van-button 
                            color="#56910C" 
                            style="color: #56910C; float: right; height: 28px; font-size: 12px; margin-top: 5px;" 
                            round
                            >查看详情</van-button>
                    </div>
                </div>
            </div>

            <!-- 播放器 -->
            <van-overlay :show="showVideo" @click="showVideo = false,PlayerVidep.pause()">
                <div class="wrapper">
                    <div class="video">
                        <div id="mse"></div>
                    </div>
                </div>
            </van-overlay>

            <van-overlay :show="IMGshow" @click="IMGshow = false" z-index="999">
                <div class="IMGwrapper" @click.stop>
                    <van-image lazy-load :src="ga_info_IMG" />
                </div>
            </van-overlay>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow">
                <div class="wrapper">
                    <van-loading type="spinner" color="#1989fa"></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import Store from "@/vuex/store";
import api from "@/components/http.js";
import global from "@/global";
import Player from "xgplayer";

import navigation from "../tabbar/tabbar";

import {wxShare} from "cydsj-app-tool"

import playIMG from "@/assets/asso/home/play.png"

import wx from 'weixin-js-sdk'

export default {
    name: "Home",
    data() {
        return {

            loadingshow: false,

            url: "",

            IMGshow: false,

            // 高尔夫协会信息
            ga_info_Data: [],

            // 协会介绍图片
            img: [],
            ga_info_IMG: "",

            // 分会列表
            branchList: [],

            // 球场
            yard: [],

            // 基地
            yard_base : [],

            // 公告列表
            noticeList: [],

            // 最新赛事推荐
            match: [],

            // 视频插件
            PlayerVidep: null,
            // 显示视频
            showVideo : false,
            // 播放按钮图片
            videoPlayIMG : playIMG,

            asso_name : '',
            asso_flag : true,
        };
    },
    components: {
        navigation,
    },
    mounted () {
        
        this.PlayerVidep = new Player({
            id: "mse",
            url: '',
            fluid: true,  //跟随父元素的宽度大小变化
            ignores: [
                "error",
                "play",
            ], //关闭组件
            // controls: false,
            lang: "zh-cn",
        });
        
        if(this.GetRequest("path")){
            this.$router.push({ path: "/asso/" + this.GetRequest("path") });
        }

        // this.IFToken();
        this.getData();

    },
    computed: {
        ...mapState(["token"]),
    },
    methods: {
        ...mapActions(["actionsSetGoPath"]),

        // 判断登录
        IFToken() {
            if (Store.state.token) {
                
            } else {
                this.$dialog
                .confirm({
                    message: "请先登录",
                })
                .then(() => {
                    this.$router.push( "/asso/mine" );
                })
                .catch(() => {
                    // this.$router.replace("/");
                });
            }
        },

        getData() {
            this.loadingshow = true;

            const data = {
                asso_id: sessionStorage.getItem('asso_id'),
                limit: 3,
            };

            api.ga_home(data)
                .then((res) => {
                    this.loadingshow = false;

                    if (res.data.xcode == 0) {

                        sessionStorage.setItem("asso_id", res.data.data.info.id);
                        // sessionStorage.setItem("asso_url", res.data.data.domain);
                        // sessionStorage.setItem("asso_name", res.data.data.info.name);

                        this.ga_info_Data = res.data.data.info;

                        this.img = []

                        // 视频封面图
                        this.img.push(this.ga_info_Data.videos_image);

                        // 图片介绍
                        if (this.ga_info_Data.images) {
                            this.ga_info_Data.images.split(",").forEach((element) => {
                                this.img.push(element);
                            });
                        }
                        
                        this.PlayerVidep.start(this.ga_info_Data.videos)

                        // 播放器开始播放进入全屏
                        // this.PlayerVidep.on("play", function (player) {
                        //     player.getFullscreen(player.root);
                        //     // 播放器退出全屏暂停播放
                        //     player.on("exitFullscreen", function () {
                        //         player.pause();
                        //     });
                        // });

                        // 分会列表
                        // res.data.data.part.forEach((element) => {
                        //     element.avatar = this.url + element.avatar;
                        // });
                        this.branchList = res.data.data.part;

                        // 球场
                        if(res.data.data.yard != null){
                            this.yard = res.data.data.yard;
                        }

                        // 基地
                        if(res.data.data.yard_base != null){
                            this.yard_base = res.data.data.yard_base;
                        }

                        // 公告
                        this.noticeList = res.data.data.notice;

                        // // 最新赛事推荐封面图
                        // res.data.data.match.forEach((element) => {
                        //     element.cover = this.url + element.cover;
                        // });

                        // 最新赛事推荐
                        this.match = res.data.data.match;

                        // 各地市协会名称
                        this.asso_name = res.data.data.asso_name;

                        // 是否显示各地市协会列表
                        this.asso_flag = res.data.data.asso_flag;

                        
                    } else {
                        this.$toast(res.data.msg);
                    }
                })
                // .catch((err) => {
                //     this.loadingshow = false;
                //     if (err.response.status == 401) {
                //         this.$toast(err.response.data.msg);
                //         // this.actionsSetToken("");
                //         sessionStorage.setItem("token", "");
                //         // this.actionsSetGoPath({
                //         //     type: "actionsSetGoPath",
                //         //     payload: "/",
                //         // });
                //         this.$router.replace("/");
                //     }
                // });
        },

        // 去组织架构
        goAsso() {
            this.$router.push("/asso/asso");
        },

        // 获取公告
        getNotice() {
            api.ga_notice().then((res) => {
                if (res.data.xcode == 0) {
                    this.noticeList = res.data.data.list;
                } else {
                    this.$toast(res.data.msg);
                }
            });
        },

        // IMG弹窗
        onSwipe(img,index) {

            if(index == 0){
                console.log('视频')
                this.showVideo = true
            }else{
                this.IMGshow = true;
                this.ga_info_IMG = img;
            }
        },

        // 去公告详情
        goNewsDetails(id) {
            this.$router.push({ path: "/asso/newsDetails", query: { id: id } });
        },

        // 获取url的token
        GetRequest(param) {
            let url = location.href; //获取url中"?"符后的字串
            let params = url.match(/\?.*/);
            if (!params) return;
            url = params[0];
            const theRequest = {};
            if (url.indexOf("?") !== -1) {
                const str = url.substr(1);
                const strs = str.split("&");
                for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                }
            }
            return theRequest[param];
        },

        // 去赛事详情
        goInfo(id){

            // const ua = window.navigator.userAgent.toLowerCase();

            // if (ua.indexOf('micromessenger') == -1) {
            //     // 不在小程序
            //     this.$router.push({ path: "/match", query: { match_id: id } });
            //    this.$toast('不在小程序');
            // } else {
            //     wx.miniProgram.getEnv(function(res) {
            //         if (res.miniprogram) {
            //             // 走在小程序的逻辑
            //             this.$router.push({ path: "/match", query: { match_id: id , from : 'wxApp' } });
            //             this.$toast('在小程序');
            //         } else {
            //             // 走不在小程序的逻辑
            //             this.$router.push({ path: "/match", query: { match_id: id } });
            //             this.$toast('不在小程序');
            //         }
            //     })
            // }

            this.$router.push({ path: "/match", query: { match_id: id , from : 'wxApp' } });
        }
    },
};
</script>

<style lang="scss" scoped>
.home {
    display: flex;
    flex-direction: row;
    justify-content: center;
    width: 100vw;
    height: auto;
    overflow-x: hidden;
    // margin-bottom: 70px;
}

// loading 加载
.wrapper {
    text-align: center;
    color: rgb(168, 169, 170);
    font-size: 20px;
    p {
        font-size: 18px;
    }
}

// 图片弹窗
.IMGwrapper {
    width: 100%;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%); /*向左向上分别平移自身的一半*/
    -webkit-transform: translate(-50%, -50%);
    -moz-transform: translate(-50%, -50%);
    text-align: center;
}

// 更多按钮
.moreButton{
    float: right; 
    margin-right: 20px;
    width: 75px; 
    height: 26px;
    font-size: 13px;
}

// 介绍视频
.video{
    width: 100%;
    height: 200px;
}

@media screen and (max-width: 600px) {
    .index {
        width: 100vw;
        min-height: 100vh;
        height: auto;
        background-color: #EFEFEF;
    }

    // 协会名称
    .AssociationName {
        background-image: url('../../../assets/asso/home/bj.png');
        background-size: 100%;
        width: 100%;
        height: 199px;

        .content{
            padding: 30px 20px;
            .name {
                float: left;
                color: #FFFFFF;
                font-size: 18px;
                font-weight: 600;
            }

            .btn{
                float: right;
                width: 100px;
                height: 30px;
                background: #FFFFFF;
                border-radius: 20px;
                color: #78AC06;
                font-size: 15px;
                line-height: 30px;
                text-align: center;

                .text{
                    float: left;
                    margin-left: 10px;
                }
                
            }
        }
    }

    // 轮播
    .swipe{
        width: 90%;
        height: 180px;
        margin: 0 auto;
        border-radius: 20px;
        margin-top: -120px;

        .play{
            position: absolute;
            top : 67px;
            text-align: center;
            width: 100%;
        }
    }

    // 导航
    .tabbar{
        margin: 15px 0;
    }

    // 公告
    .announcement {
        background-color: #FFFFFF;

        .list {
            padding-top: 10px;
            padding-bottom: 10px;
            height: 38px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.03);

            .tips {
                float: left;
                padding-left: 20px;
            }

            .content {
                float: left;
                padding-left: 10px;
                padding-top: 2px;
                width: 200px;
                overflow: hidden; /*超出部分隐藏*/
                white-space: nowrap; /*不换行*/
                text-overflow: ellipsis; /*超出部分文字以...显示*/
            }

            .time {
                float: right;
                font-size: 12px;
                padding-top: 7px;
                padding-right: 20px;
                color: rgba(16, 16, 16, 0.29);
            }
        }
    }
    
    // 赛事推荐
    .newMatch {
        margin-top: 20px;
        font-size: 18px;
        background-color: #FFFFFF;
        padding-bottom: 20px;

        .content{
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0px 10px 10px -10px #EEEEEE;
            width: 90%;
            margin: 20px auto;

            .image {
                width: 100%;
                height: 180px;
            }

            .contentText{
                height: 35px;
                .text {
                    padding-top: 5px;
                    width: 50%;
                    overflow: hidden; /*超出部分隐藏*/
                    white-space: nowrap; /*不换行*/
                    text-overflow: ellipsis; /*超出部分文字以...显示*/
                }
            }
            
        }
    }
}

@media screen and (min-width: 600px) {
    .index {
        width: 600px;
        min-height: 100vh;
        height: auto;
        background-color: #EFEFEF;
    }

    // 协会名称
    .AssociationName {
        background-image: url('../../../assets/asso/home/bj.png');
        background-size: 100%;
        width: 100%;
        height: 199px;

        .content{
            padding: 30px 20px;
            .name {
                float: left;
                color: #FFFFFF;
                font-size: 18px;
                font-weight: bold;
            }

            .btn{
                float: right;
                width: 100px;
                height: 30px;
                background: #FFFFFF;
                border-radius: 20px;
                color: #78AC06;
                font-size: 15px;
                line-height: 30px;
                text-align: center;

                .text{
                    float: left;
                    margin-left: 10px;
                }
                
            }
        }
    }

    // 轮播
    .swipe{
        width: 90%;
        height: 180px;
        margin: 0 auto;
        border-radius: 20px;
        margin-top: -120px;
    }

    // 导航
    .tabbar{
        margin: 15px 0;
    }

    // 公告
    .announcement {
        background-color: #FFFFFF;

        .list {
            padding-top: 10px;
            padding-bottom: 10px;
            height: 38px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.03);

            .tips {
                float: left;
                padding-left: 20px;
            }

            .content {
                float: left;
                padding-left: 10px;
                padding-top: 2px;
                width: 200px;
                overflow: hidden; /*超出部分隐藏*/
                white-space: nowrap; /*不换行*/
                text-overflow: ellipsis; /*超出部分文字以...显示*/
            }

            .time {
                float: right;
                font-size: 12px;
                padding-top: 7px;
                padding-right: 20px;
                color: rgba(16, 16, 16, 0.29);
            }
        }
    }
    
    // 赛事推荐
    .newMatch {
        margin-top: 20px;
        font-size: 18px;
        background-color: #FFFFFF;
        padding-bottom: 20px;

        .content{
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0px 10px 10px -10px #EEEEEE;
            width: 90%;
            margin: 0 auto;

            .image {
                width: 100%;
                height: 180px;
            }

            .contentText{
                height: 35px;
                .text {
                    padding-top: 5px;
                    width: 50%;
                    overflow: hidden; /*超出部分隐藏*/
                    white-space: nowrap; /*不换行*/
                    text-overflow: ellipsis; /*超出部分文字以...显示*/
                }
            }
            
        }
    }
}
</style>
