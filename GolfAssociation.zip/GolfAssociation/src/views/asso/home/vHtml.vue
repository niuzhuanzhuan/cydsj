<template>
    <div class="mian">
        <div class="index">

            <van-nav-bar
                class="assoNavBar"
                title="详情"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />
            
            <div class="html">
                <div class="htmltitle">{{ data.name }}</div>
                <div class="htmltime">{{ data.create_time }}</div>
            </div>

            <div class="html" v-html="data.desc"></div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

    import api from '@/components/http'

    export default {
        name : 'vHtml',
        data() {
            return {
                loadingshow : false,

                data: '',
            }
        },
        mounted () {
            this.getData();
        },
        methods: {
            getData() {
                
                this.loadingshow = true;

                api.getYardBaseDetail({id : this.$route.query.id}).then(res => {

                    this.loadingshow = false;

                    if(res.data.xcode == 0){
                        
                        this.data = res.data.data.yard

                    }else{
                        this.$toast(res.data.msg)
                    }

                })

            }
        },
    }
</script>

<style lang="scss">
    .mian {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    .htmltitle{
        text-align: center;
        font-size: 22px;
        padding-top: 20px;
        padding-bottom: 10px;
    }

    .htmltime{
        font-size: 14px;
        color: #888585;
        padding-bottom: 10px;
    }

    .html{
        padding: 0 15px;
        
        video {
            width: 100%;
        }

        img{
            width: 100%;
        }

    }


    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }
    }
</style>