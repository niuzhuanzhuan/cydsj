<template>
  <div id="app">

    <van-grid :column-num="4" :border="false">
        <van-grid-item v-for="(item,index) in tabbarList" :key="index" @click="onTabbar(item,index)">
            <van-image lazy-load :src="item.img" width="50" height="50"/>
            <div class="name">{{ item.name }}</div>
        </van-grid-item>
    </van-grid>

  </div>
</template>

<script>

import img1 from '@/assets/asso/home/1.png'
import img2 from '@/assets/asso/home/2.png'
import img3 from '@/assets/asso/home/3.png'
import img4 from '@/assets/asso/home/4.png'
import img5 from '@/assets/asso/home/5.png'
import img6 from '@/assets/asso/home/6.png'
import img7 from '@/assets/asso/home/7.png'
import img8 from '@/assets/asso/home/8.png'

export default {
    name : 'tabbar',
    data(){
        return {

            // 导航
            tabbarList: [
                { 
                    img: img1, 
                    name: "赛事" 
                },
                { 
                    img: img2, 
                    name: "地方协会" 
                },
                { 
                    img: img3, 
                    name: "球队" 
                },
                { 
                    img: img4, 
                    name: "球场/基地" 
                },
                { 
                    img: img5, 
                    name: "培训" 
                },
                { 
                    img: img6, 
                    name: "赞助" 
                },
                { 
                    img: img7, 
                    name: "合作企业" 
                },
                { 
                    img: img8,
                    name: "我的" 
                },
            ],

        }
    },
    mounted () {
        
    },
    methods:{
        onTabbar(item,index){
            switch (index) {

                case 0:
                    this.$router.push("/asso/match");
                    break;

                case 1:
                    this.$router.push({ path: "/asso/golfListTable", query: { type: 1 } });
                    break;

                case 2:
                    this.$router.push("/asso/teamList");
                    break;

                case 3:
                    this.$router.push("/asso/stadiums_and_bases");
                    break;

                case 4:
                    this.$router.push("/asso/training");
                    break;

                case 5:
                    this.$router.push("/asso/sponsor");
                    break;

                case 6:
                    this.$router.push('/asso/jointVenture');
                    break;

                case 7:
                    this.$router.push("/asso/mine");
                    break;
            
                default:
                    break;
            }
        }
    }
}
</script>

<style lang="scss" scoped>
    .name{
        color: #333333;
        font-size: 14px;
        padding-top: 8px;
    }
</style>
