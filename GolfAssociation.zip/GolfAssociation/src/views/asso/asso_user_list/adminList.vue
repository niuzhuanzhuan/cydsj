<template>
    <div class="mine">
        <div class="index">

            <van-nav-bar
                class="assoNavBar"
                :title="'协会' + navBarTitile"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 主席 -->
            <div class="box">
                <div class="title">
                    协会主席
                </div>
                <div class="user" v-for="(item,index) in myData.chairman" :key="index">
                    <van-image fit="fill" class="img" round lazy-load width="55" height="55" :src="item.avatar" />
                    <div class="name">{{ item.name }}</div>
                    <van-icon class="icon" :name="item.sex == 0 ?  female : male" />
                </div>
            </div>

            <!-- 副主席 -->
            <div class="box">
                <div class="title">
                    协会副主席
                </div>
                <div class="user" v-for="(item,index) in myData.chairman2" :key="index">
                    <van-image fit="fill" class="img" round lazy-load width="55" height="55" :src="item.avatar" />
                    <div class="name">{{ item.name }}</div>
                    <van-icon class="icon" :name="item.sex == 0 ?  female : male" />
                </div>
            </div>

            <!-- 理事 -->
            <div class="box" v-for="(item,index) in myData.others" :key="index">
                <div class="title">
                    {{ item.name }}
                </div>
                <div class="user" v-for="(item2,index) in item.list" :key="index">
                    <van-image fit="fill" class="img" round lazy-load width="55" height="55" :src="item2.avatar" />
                    <div class="name">{{ item2.name }}</div>
                    <van-icon class="icon" :name="item2.sex == 0 ?  female : male" />
                </div>
            </div>

             <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

    import api from '@/components/http'

    import sex1 from "@/assets/asso/userList/male.png"
    import sex2 from "@/assets/asso/userList/female.png"

    export default {
        name: 'userList',
        data() {
            return {
                loadingshow: false,

                navBarTitile : '列表',

                myData : [],

                male : sex1,
                female : sex2,

                // 是不是分协会
                branch : 0,
            }
        },
        mounted () {
            this.navBarTitile = this.$route.query.title
            this.getData()
        },
        methods: {
            getData(){

                this.loadingshow = true;

                const data ={
                    asso_id : sessionStorage.getItem('asso_id'),
                    type : this.$route.query.type,
                }

                api.getAssoUserList(data).then(res => {
                    
                    this.loadingshow = false;
                    
                    if(res.data.xcode == 0){
                        
                       this.myData = res.data.data

                    }else{

                    }

                })
                
            },
        },
    }
</script>

<style lang="scss" scoped>
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .box{
            background-color: #FFFFFF;
            margin-top: 10px;
            
            .title{
                padding-top: 15px;
                padding-left: 15px;
                font-size: 18px;
            }

            .user{
                // margin: 15px;
                margin-top: 15px;
                margin-left: 20px;
                height: 65px;
                border-bottom: 1px solid #E6E6E6;

                .img{
                    float: left;
                }

                .name{
                    float: left;
                    margin-left: 20px;
                    margin-top: 20px;
                }

                .icon{
                    float: left;
                    margin-left: 8px;
                    margin-top: 22px;
                }
            }
        }

        
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }
    }
</style>