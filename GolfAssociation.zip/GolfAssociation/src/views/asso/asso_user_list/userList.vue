<template>
    <div class="mine">
        <div class="index">

            <van-nav-bar
                class="assoNavBar"
                :title="navBarTitile + '列表'"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="list">
                
                <!-- 申请按钮 -->
                <div class="button" v-if="branch == 0">
                    <van-button color="#78AC06" size="large" round @click="onClick">申请{{navBarTitile}}身份</van-button>
                </div>

                <!-- 人员列表 -->
                <van-list
                        v-model="loading"
                        :finished="finished"
                        finished-text="没有更多了"
                        offset="5"
                        @load="onLoad"
                    >
                    <div class="user" v-for="(item,index) in list" :key="index">
                        <van-image fit="fill" class="img" round lazy-load width="55" height="55" :src="item.avatar" />
                        <div class="name">{{ item.name }}</div>
                        <van-icon class="icon" :name="item.gender == 0 ? female : male" />
                    </div>
                </van-list>

            </div>


            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

    import api from '@/components/http'

    import Store from "@/vuex/store";

    import sex1 from "@/assets/asso/userList/male.png"
    import sex2 from "@/assets/asso/userList/female.png"

    export default {
        name: 'userList',
        data() {
            return {
                loadingshow: false,

                navBarTitile : '列表',

                list: [],
                
                // 控制上拉加载
                loading: false,
                finished: false,

                male : sex1,
                female : sex2,

                page : 1,
                
                // 总人数
                total : 0,

                // 是不是分协会
                branch : 0,
            }
        },
        mounted () {
            this.getData(this.page)
            this.navBarTitile = this.$route.query.title;

            if(this.$route.query.branch){
                this.branch = this.$route.query.branch
            }else{
                this.branch = 0
            }
        },
        methods: {
            getData(page){

                this.loadingshow = true;
                const data ={
                    asso_id : sessionStorage.getItem('asso_id'),
                    type : this.$route.query.type,
                    page : page,
                }

                api.getAssoUserList(data).then(res => {
                    
                    this.loadingshow = false;
                    
                    if(res.data.xcode == 0){
                        
                        // this.list = res.data.data.data
                        res.data.data.data.forEach(element => {
                            this.list.push(element)
                        });

                        this.total = res.data.data.total
                    }

                })
                
            },

            // 上拉加载
            onLoad() {
                
                this.page++

                this.getData(this.page)

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                // if (this.list.length >= this.total) {
                //     this.finished = true;
                // }
            },

            // 注册
            onClick(){
                
                if (Store.state.token) {
                    
                    // if(this.$route.query.type == 2){
                    //     this.$router.push({
                    //         path: "/asso/vipPay",
                    //         query: { id: this.$route.query.type, name: this.navBarTitile },
                    //     });
                    // }else{
                    //     this.$router.push({
                    //         path: "/asso/signUp",
                    //         query: { id: this.$route.query.type, name: this.navBarTitile },
                    //     });
                    // }

                    this.$router.push({
                        path: "/asso/signUp",
                        query: { id: this.$route.query.type, name: this.navBarTitile },
                    });

                } else {
                    this.$dialog
                    .confirm({
                        message: "请先登录",
                    })
                    .then(() => {
                        this.$router.push( "/asso/mine" );
                    })
                    .catch(() => {
                        // this.$router.replace("/");
                    });
                }

            },
        },
    }
</script>

<style lang="scss" scoped>
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        height: auto;
        width: 100vw;
        // overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .list{
            background-color: #FFFFFF;
            .button{
                width: 90%;
                margin: 0 auto;
                padding: 20px 0px;
            }

            .user{
                margin: 15px;
                height: 65px;
                border-bottom: 1px solid #E6E6E6;

                .img{
                    float: left;
                }

                .name{
                    float: left;
                    margin-left: 20px;
                    margin-top: 20px;
                }

                .icon{
                    float: left;
                    margin-left: 8px;
                    margin-top: 22px;
                }
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .list{
            background-color: #FFFFFF;
            .button{
                width: 90%;
                margin: 0 auto;
                padding: 20px 0px;
            }

            .user{
                margin: 15px;
                height: 65px;
                border-bottom: 1px solid #E6E6E6;

                .img{
                    float: left;
                }

                .name{
                    float: left;
                    margin-left: 20px;
                    margin-top: 20px;
                }

                .icon{
                    float: left;
                    margin-left: 8px;
                    margin-top: 22px;
                }
            }
        }
    }
</style>