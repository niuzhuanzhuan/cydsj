<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="团队介绍"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            
            <!-- 头像、名称 -->
            <div class="top">
                
                <!-- 团队头像 -->
                <van-image
                    class="img"
                    round
                    width="70"
                    height="70"
                    :src="info.avatar"
                    fit="fill"
                />

                <div class="content">
                    <!-- 团队名字 -->
                    <div class="name">{{ info.name }}</div>
                    <!-- 团队口号 -->
                    <div class="slogan">{{ info.slogan }}</div>
                </div>

            </div>

            <!-- 视频介绍 -->
            <div class="video">
                <div id="mse"></div>
            </div>

            <!-- 简介 -->
            <div class="introduce">

                <div class="title">
                    <div class="spot" />
                    球队简介
                </div>

                <div class="content">{{ info.introduce }}</div>

            </div>
                
            <!-- 荣誉 -->
            <div class="glory">

                <div class="title">
                    <div class="spot" />
                    球队荣耀
                </div>

                <div class="content">
                    <div class="text" v-for="(item,index) in info.honour" :key="index">
                        <div class="spot" />
                        <div class="texts">{{ item }}</div>
                    </div>
                </div>

            </div>

            <!-- 队员 -->
            <div class="user">

                <div class="title">
                    <div class="spot" />
                    球队队员
                </div>

                <div class="content" >
                    <van-grid :column-num="3" :border="false">
                        <van-grid-item v-for="(item,index) in user" :key="index" @click="onTeamUser(item.id)">
                            <van-image class="img" lazy-load :src="item.avatar" width="70" height="70" fit="cover"/>
                            <div class="name">{{ item.name }}</div>
                        </van-grid-item>
                    </van-grid>

                    <van-empty description="暂无成员" v-if="user.length == 0" />

                </div>

                <div class="button" @click="onUserList" v-if="open">
                    <div class="text">更多</div>
                    <van-icon class="icon" name="arrow-down" color="#666666" />
                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import Player from "xgplayer";

export default {
    name : 'team',
    data(){
        return {

            loadingshow : false,

            info : {},

            user : [
                {   
                    id : 1,
                    img : 'https://img.yzcdn.cn/vant/cat.jpeg',
                    name : '哇哈哈'
                },
            ],

            playerVidep : null,

            // 更多按钮的展开
            open : true,

            page : 1,
        }
    },
    components : {

    },
    mounted () {

        // 创建视频
        this.playerVidep = new Player({
            id: "mse",
            url: '',
            fluid: true,  //跟随父元素的宽度大小变化
            ignores: [
                "progress",
                "error",
                "play",
                "time",
                "volume",
            ], //关闭组件
            // controls: false,
            lang: "zh-cn",
        });

        this.getData();
    },
    methods :{
        getData(){
            
            this.loadingshow = true;

            api.getTeamDetail({ id : this.$route.query.id }).then(res => {
                this.loadingshow = false
                if(res.data.xcode == 0){
                    this.info = res.data.data.team
                    this.user = res.data.data.user.data

                    this.playerVidep.start(this.info.videos)

                    if(this.user < 10){
                        this.open = false
                    }

                }else{
                    this.$toast(res.data.msg)
                }
            })
            
        },

        // 更多成员
        onUserList(){

            this.page++

            api.getTeamDetail({ id : this.$route.query.id , page : this.page }).then(res => {
                this.loadingshow = false
                if(res.data.xcode == 0){

                    res.data.data.user.data.forEach(element => {
                        this.user.push(element)
                    });

                    if(res.data.data.user.data.length < 10){
                        this.open = false
                    }

                }else{
                    this.$toast(res.data.msg)
                }
            })

        },

        onTeamUser(yid){
            this.$router.push({ path: "/asso/userinfo", query: { yid: yid } });
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        background: #EDEDED;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    .title{
        padding-left: 10px;
        padding-top: 20px;
        font-size: 18px;
        color: #333333;

        .spot{
            float: left;
            width: 12px;
            height: 12px;
            background-color: #78AC06;
            border-radius: 50px;
            margin: 6px;
        }
    }
    
    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .top{
            background-color: #FFFFFF;
            width: 100%;
            // height: 100px;

            .img{
                float: left;
                padding: 15px 10px;
            }

            .content{
                padding: 24px 10px;
                line-height: 30px;
                width: 284px;
                margin-left: 75px;

                .name{
                    font-size: 19px;
                    font-weight: 600;
                    color: #333333;
                }
                .slogan{
                    overflow: hidden;
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    width: 80%;
                    font-size: 13px;
                    color: #666666;
                    height: 28px;
                }
            }

        }

        .video{
            width: 100%;
            margin: 10px 0px;
        }

        .introduce{
            margin-bottom: 10px;
            background-color: #FFFFFF;

            .content{
                padding: 10px 32px;
                padding-bottom: 20px;
                font-size: 15px;
                line-height: 22px;
                color: #666666;
            }
        }

        .glory{
            margin-bottom: 10px;
            background: #FFFFFF;

            .content{
                padding: 10px 32px;
                padding-bottom: 20px;
                font-size: 15px;
                line-height: 22px;
                color: #666666;

                .text{
                    margin: 15px 0px;
                    height: 22px;
                   
                    .spot{
                        float: left;
                        width: 12px;
                        height: 12px;
                        background-color: #78AC06;
                        border-radius: 50px;
                        margin: 5px;
                        margin-right: 10px;
                        box-shadow: #E4EECD 0px 0px 1px 4px;
                    }

                    .texts{
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                        width: 85%;
                    }
                }
            }
        }
        
        .user{
            margin-bottom: 10px;
            background: #FFFFFF;

            .content{
                padding-top: 10px;
                padding-bottom: 20px;
                // height: 248px;
                // overflow:hidden;

                .name{
                    color: #333333;
                    margin-top: 5px;
                    font-size: 15px;
                }
            }

            .button{
                width: 60px;
                height: 30px;
                margin: 0 auto;
                font-size: 15px;
                color: #666666;

                .text{
                    float: left;
                }

                .icon{
                    float: right;
                    margin-top: 2px;
                }
            }
        }

    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .top{
            background-color: #FFFFFF;
            width: 100%;
            // height: 100px;

            .img{
                float: left;
                padding: 15px 10px;
            }

            .content{
                padding: 24px 10px;
                line-height: 30px;
                width: 284px;
                margin-left: 75px;

                .name{
                    font-size: 19px;
                    font-weight: 600;
                    color: #333333;
                }
                .slogan{
                    font-size: 13px;
                    color: #666666;
                    height: 28px;
                }
            }

        }

        .video{
            width: 100%;
            margin: 10px 0px;
        }

        .introduce{
            margin-bottom: 10px;
            background-color: #FFFFFF;

            .content{
                padding: 10px 32px;
                padding-bottom: 20px;
                font-size: 15px;
                line-height: 22px;
                color: #666666;
            }
        }

        .glory{
            margin-bottom: 10px;
            background: #FFFFFF;

            .content{
                padding: 10px 32px;
                padding-bottom: 20px;
                font-size: 15px;
                line-height: 22px;
                color: #666666;

                .text{
                    margin: 15px 0px;
                    height: 22px;

                    .spot{
                        float: left;
                        width: 12px;
                        height: 12px;
                        background-color: #78AC06;
                        border-radius: 50px;
                        margin: 5px;
                        margin-right: 10px;
                        box-shadow: #E4EECD 0px 0px 1px 4px;
                    }
                }
            }
        }
        
        .user{
            margin-bottom: 10px;
            background: #FFFFFF;

            .content{
                padding-top: 10px;
                padding-bottom: 20px;
                height: 248px;
                overflow:hidden;
	            transition:height .5s;

                .name{
                    color: #333333;
                    margin-top: 5px;
                    font-size: 15px;
                }
            }

            .button{
                width: 60px;
                height: 30px;
                margin: 0 auto;
                font-size: 15px;
                color: #666666;

                .text{
                    float: left;
                }

                .icon{
                    float: right;
                    margin-top: 2px;
                }
            }
        }

    }

</style>