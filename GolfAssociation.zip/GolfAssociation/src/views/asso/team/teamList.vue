<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="球队列表"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="box" v-for="(item,index) in list" :key="index" @click="onTeamInfo(item.id)">
                
                <!-- 头像 -->
                <div class="img">
                    <van-image
                        round
                        width="50px"
                        height="50px"
                        :src="item.avatar"
                        fit="fill"
                    />
                </div>

                <!-- 名字 和 团队人数 -->
                <div class="content">
                    <div class="name">{{ item.name }}</div>
                    <div class="number">{{ item.number }}人</div>
                </div>

                <van-icon class="icon" name="arrow" size="18" color="#999999" />

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

export default {
    name : 'team',
    data(){
        return {

            loadingshow : false,

            list : [
                {
                    img : 'https://img.yzcdn.cn/vant/cat.jpeg',
                    name : '我就是一个团队',
                    number : 10
                },
            ],
        }
    },
    components : {

    },
    mounted () {
        this.getData();
    },
    methods :{
        getData(){
            this.loadingshow = true;
            
            const data ={
                id : ''
            }

            if(this.$route.query.asso_id){
                data.id = this.$route.query.asso_id

            }else{
                data.id = sessionStorage.getItem('asso_id')
            }

            api.getAssoDetail(data).then(res => {
                
                this.loadingshow = false;
                
                if(res.data.xcode == 0){

                    this.list = res.data.data.team

                }else{
                    this.$toast(res.data.msg);
                }

            })
            
        },

        onTeamInfo(id){
            this.$router.push({ path: "/asso/teamInfo", query: { id: id } });
        }
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        background: #EDEDED;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }
    

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }
        
        .box{
            background-color: #FFFFFF;
            border-radius: 10px;
            width: 90%;
            height: 70px;
            margin: 15px auto;
            box-shadow: #F1F1F1 1px 1px 10px 10px;

            .img{
                float: left;
                margin: 10px;
            }

            .content{
                float: left;
                line-height: 25px;
                margin-top: 12px;
                .name{
                    color: #333333;
                    font-size: 17px;
                }
                .number{
                    color: #78AC06;
                    font-size: 14px;
                }
            }

            .icon{
                // margin-top: 20px;
                margin: 25px 10px;
                float: right;
            }
        }

    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .box{
            background-color: #FFFFFF;
            border-radius: 10px;
            width: 90%;
            height: 70px;
            margin: 15px auto;
            box-shadow: #F1F1F1 1px 1px 10px 10px;

            .img{
                float: left;
                margin: 10px;
            }

            .content{
                float: left;
                line-height: 25px;
                margin-top: 12px;
                .name{
                    color: #333333;
                    font-size: 17px;
                }
                .number{
                    color: #78AC06;
                    font-size: 14px;
                }
            }

            .icon{
                // margin-top: 20px;
                margin: 25px 10px;
                float: right;
            }
        }
    }

</style>