<template>
    <div class="match">
        <div class="index">

            <van-nav-bar
                class="assoNavBar"
                title="详情"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="html" v-html="html"></div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http.js'

export default {
    name : 'matchHtml',
    data(){
        return {
            loadingshow : false,
            html : ''
        }
    },
    components : {
    },
    mounted () {
        this.getData();
    },
    methods :{
        getData(){

            this.loadingshow = true;
            
            const data = {
                match_id : this.$route.query.match_id
            }

            api.ga_match_info(data).then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0){

                    // res.data.data.info.cover = sessionStorage.getItem('asso_url') + res.data.data.info.cover

                    this.html = res.data.data.info.introduce

                }else{
                    this.$toast(res.data.msg)
                }

            })
            
        },
    }
}
</script>

<style lang="scss">
    
    .match {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        margin-bottom: 70px;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    .html{
        padding: 15px;

        video {
            width: 100%;
        }

        img{
            width: 100%;
        }
    }


    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 93vh;
            height: auto;
            background-color: #FFFFFF;
        }
        
    }

    @media screen and (min-width: 600px) {
		.index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }

    }

</style>