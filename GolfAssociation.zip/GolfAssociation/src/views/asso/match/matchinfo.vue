<template>
    <div class="match">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="赛事介绍"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 图片 -->
            <div class="cover">
                <van-image :src="info.cover" height="200">
                    <template v-slot:loading>
                    <van-loading type="spinner" size="20" />
                    </template>
                </van-image>
            </div>

            <div class="info">

                <!-- 名称 -->
                <div class="title">{{ info.title }}</div>

                <!-- 介绍 -->
                <div class="intro" @click="gointro(info.id)">
                    <div class="text">
                        赛事详情：{{ info.intro }}
                    </div>
                    <div class="data">
                        <van-icon name="arrow-down" />
                    </div>
                </div>
                
                <!-- 报名时间 -->
                <div class="start_time">
                    开始时间
                    <div class="data">{{ info.start_time }}</div>
                </div>

                <!-- 报名时间 -->
                <div class="end_time">
                    结束时间
                    <div class="data">{{ info.end_time }}</div>
                </div>

                <!-- 地点 -->
                <div class="address">
                    赛事地点
                    <div class="data">{{ info.address }}</div>
                </div>

                <div class="button">
                    <van-button color="#56910C" @click="goMatch(info.url)">查看详情</van-button>
                </div>
            
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http.js'

import wx from 'weixin-js-sdk'

export default {
    data(){
        return {
            loadingshow : false,

            info : [],

            activeNames : ['1'],
        }
    },
    components : {
        
    },
    activated(){
        this.getData()
    },
    methods :{
        getData(){

            this.loadingshow = true;
            
            const data = {
                match_id : this.$route.query.match_id
            }

            api.ga_match_info(data).then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0){

                    // res.data.data.info.cover = sessionStorage.getItem('asso_url') + res.data.data.info.cover

                    this.info = res.data.data.info

                }else{
                    this.$toast(res.data.msg)
                }

            })
            
        },

        gointro(match_id){
            this.$router.push({ path: "/asso/matchHtml", query: { match_id: match_id } });
        },

        goMatch(url){
            // window.location.href = url
            // alert('match_id---' + this.$route.query.match_id)
            wx.miniProgram.navigateTo({url: '/pages/sports/sports?match_id=' + this.$route.query.match_id + '&title=' + this.info.title})
        }
    }
}
</script>

<style lang="scss" scoped>
    
    .match {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
        margin-bottom: 70px;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 90vh;
            height: auto;
            background-color: #FFFFFF;
        }

        .info{
            margin: 10px 20px;
            font-size: 18px;
            line-height: 50px;
            color: #7A7A7A;

            .title{
                color: #000;
                font-weight: 600;
            }

            .intro{
                width: 100%;
                height: 50px;

                .text{
                    height: 45px;
                    width: 85%;
                    overflow: hidden;/*超出部分隐藏*/
                    white-space: nowrap;/*不换行*/
                    text-overflow:ellipsis;/*超出部分文字以...显示*/
                    float: left;
                }
            }

            .data{
                float: right;
            }
        }

        .button{
            // position: absolute;
            // width: 90%;
            // bottom: 20px;
            margin-top: 50%;

            button{
                font-size: 18px;
                width: 100%;
            }
        }
    }

    @media screen and (min-width: 600px) {
		.index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #FFFFFF;
        }

        .info{
            margin: 10px 20px;
            font-size: 18px;
            line-height: 50px;
            color: #7A7A7A;

            .title{
                color: #000;
                font-weight: 600;
            }

            .intro{
                width: 100%;
                height: 50px;

                .text{
                    height: 45px;
                    width: 85%;
                    overflow: hidden;/*超出部分隐藏*/
                    white-space: nowrap;/*不换行*/
                    text-overflow:ellipsis;/*超出部分文字以...显示*/
                    float: left;
                }
            }

            .data{
                float: right;
            }
        }

        .button{
            position: absolute;
            width: 90%;
            bottom: 20px;

            button{
                font-size: 18px;
                width: 100%;
            }
        }

    }

</style>