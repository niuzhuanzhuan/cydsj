<template>
    <div class="match">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="赛事"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 最新赛事推荐 -->
            <div class="newMatch">
                <div
                    class="content"
                    v-for="(item,index) in match"
                    :key="index"
                    @click="goInfo(item.id)"
                >
                    <van-image class="image" fit="cover" :src="item.cover">
                        <template v-slot:loading>
                            <van-loading type="spinner" size="20" />
                        </template>
                    </van-image>
                    <div class="contentText">
                        <div class="text" style="float: left;">{{ item.title }}</div>
                        <van-button 
                            color="#56910C" 
                            style="color: #56910C; float: right; height: 28px; font-size: 12px; margin-top: 5px;" 
                            round
                            >查看详情</van-button>
                    </div>
                </div>
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import Store from "@/vuex/store";

import navigation from '../tabbar/tabbar'

import api from '@/components/http.js'

import wx from 'weixin-js-sdk'

export default {
    data(){
        return {
            loadingshow : false,
            match : [],
        }
    },
    components : {
        navigation
    },
    // activated(){
    //     this.getData()
    // },
    mounted(){
        this.getData()
    },
    methods :{

        getData(){
            
            // if(Store.state.token){
                this.loadingshow = true;

                const data = {
                    asso_id : sessionStorage.getItem('asso_id'),
                    type : '',
                }

                api.ga_match(data).then(res => {
                    
                    this.loadingshow = false;

                    if(res.data.xcode == 0){
                        // res.data.data.list.forEach(element => {
                        //     element.cover = sessionStorage.getItem('asso_url') + element.cover
                        // });

                        this.match = res.data.data.list
                    }else{
                        this.$toast(res.data.msg)
                    }

                })
            // }else{
            //     this.$dialog
            //     .confirm({
            //         message: "请先登录",
            //     })
            //     .then(() => {
            //         this.$router.push( "/asso/mine" );
            //     })
            //     .catch(() => {
            //         this.$router.replace("/");
            //     });
            // }
            
        },

        // 去赛事详情
        goInfo(id){

            // const ua = window.navigator.userAgent.toLowerCase();

            // if (ua.indexOf('micromessenger') == -1) {
            //     // 不在小程序
            //     this.$router.push({ path: "/match", query: { match_id: id } });
            // } else {
            //     wx.miniProgram.getEnv(function(res) {
            //         if (res.miniprogram) {
            //             // 走在小程序的逻辑
            //             this.$router.push({ path: "/match", query: { match_id: id , from : 'wxApp' } });
            //         } else {
            //             // 走不在小程序的逻辑
            //             this.$router.push({ path: "/match", query: { match_id: id } });
            //         }
            //     })
            // }

            this.$router.push({ path: "/match", query: { match_id: id , from : 'wxApp' } });
        }
    }
}
</script>

<style lang="scss" scoped>
    
    .match {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        .newMatch {
            margin-top: 20px;
            font-size: 18px;
            padding-bottom: 20px;

            .content{
                border-radius: 10px;
                box-shadow: 0px 10px 10px -10px #EEEEEE;
                width: 90%;
                margin: 20px auto;
                background-color: #ffffff;

                .image {
                    width: 100%;
                    height: 180px;
                }

                .contentText{
                    height: 35px;
                    padding: 10px;

                    .text {
                        padding-top: 5px;
                        width: 50%;
                        overflow: hidden; /*超出部分隐藏*/
                        white-space: nowrap; /*不换行*/
                        text-overflow: ellipsis; /*超出部分文字以...显示*/
                    }
                }
                
            }
        }
    }

    @media screen and (min-width: 600px) {
		.index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #EFEFEF;
        }

        // 赛事推荐
        .matchList{
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0px 10px 10px -10px #EEEEEE;
            width: 90%;
            margin: 10px auto;

            .image {
                width: 100%;
                height: 180px;
            }

            .contentText{
                height: 35px;
                .text {
                    padding-top: 5px;
                    width: 50%;
                    overflow: hidden; /*超出部分隐藏*/
                    white-space: nowrap; /*不换行*/
                    text-overflow: ellipsis; /*超出部分文字以...显示*/
                }
            }
            
        }
    }

</style>