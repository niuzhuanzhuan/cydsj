<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="培训课程"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 课程详情 -->
            <div class="video">
                
                <!-- 播放器 -->
                <div id="mse"></div>

                <div class="title">
                    <div class="name">{{ CourseData.name }}</div>
                    <div class="difficulty">
                        难度
                        <van-rate class="rate" v-model="CourseData.difficulty" :size="16" readonly />
                    </div>
                </div>

            </div>

            <!-- 分割线 -->
            <!-- <div class="line"></div> -->

            <!-- 线上培训课程列表 -->
            <div class="CourseDetails" v-if="CourseData.mode == 1">

                <div class="title">课程列表</div>

                <div class="content">
                    
                    <div class="box" v-for="(item,index) in CourseData.videos" :key="index" @click="onPlayVides(item.url)">
                        <van-icon class="icon" name="play-circle-o" />
                        <span>{{ item.name }}</span>
                    </div>

                </div>

            </div>

            <!-- 线下培训课程列表 -->
            <div class="CourseDetails" v-if="CourseData.mode == 2">

                <div class="title">课程详情</div>

                <div class="v-html" v-html="CourseData.remark" >

                </div>

            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" z-index='999'>
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import Player from "xgplayer";
import api from '@/components/http'

export default {
    name: 'playClass',
    data(){
        return {

            loadingshow : false,

            CourseData : {},

            PlayerVides : null,
        }
    },
    components : {

    },
    mounted () {
        this.getData()
    },
    methods :{
        getData(){
            this.loadingshow = true;

            api.ga_cultivate_videos({ cultivate_id : this.$route.query.id }).then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0){
                    
                    this.CourseData = res.data.data.info

                    this.PlayerVides = new Player({
                        id: "mse",
                        url: this.CourseData.video.url,
                        poster: this.CourseData.cover,
                        fluid: true,  //跟随父元素的宽度大小变化
                        ignores: [
                            "error",
                        ], //关闭组件
                        lang: "zh-cn",
                    });

                }else{
                    this.$toast(res.data.msg)
                }

            })

            
        },

        onPlayVides(url){
            this.PlayerVides.start(url)
            this.PlayerVides.play()
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    .v-html{
        padding: 15px;

        img{
            width: 100%;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .line{
            width: 100%;
            height: 10px;
            background: rgba(0, 0, 0, 0.03);
        }

        .video{
            padding: 10px 10px;

            .title{
                line-height: 35px;
                padding: 10px 15px;
                .name{
                    font-size: 18px;
                    color: #101010;
                }
                .difficulty{
                    font-size: 15px;
                    color: #7A7A7A;
                    .rate{
                        padding-left: 5px;
                    }
                }
                .money{
                    font-size: 15px;
                    color: #7A7A7A;
                    span{
                        color: #FF0000;
                    }
                    .span1{
                        font-size: 12px;
                        padding-left: 5px;
                    }
                    .span2{
                        font-size: 20px;
                    }
                }
            }
        }
        
        .CourseDetails{
            padding: 10px 20px;
            // height: 100%;
            background: rgba(0, 0, 0, 0.03);

            .box{
                line-height: 40px;
                background: #ffffff;
                text-align: center;
                margin-top: 10px;

                .icon{
                    padding-right: 10px;
                }
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .line{
            width: 100%;
            height: 10px;
            background: rgba(0, 0, 0, 0.03);
        }

        .video{
            padding: 10px 10px;

            .title{
                line-height: 35px;
                padding: 10px 15px;
                .name{
                    font-size: 18px;
                    color: #101010;
                }
                .difficulty{
                    font-size: 15px;
                    color: #7A7A7A;
                    .rate{
                        padding-left: 5px;
                    }
                }
                .money{
                    font-size: 15px;
                    color: #7A7A7A;
                    span{
                        color: #FF0000;
                    }
                    .span1{
                        font-size: 12px;
                        padding-left: 5px;
                    }
                    .span2{
                        font-size: 20px;
                    }
                }
            }
        }
    }

</style>