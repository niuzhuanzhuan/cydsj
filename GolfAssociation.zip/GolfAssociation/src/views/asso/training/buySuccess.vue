<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="支付"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="SuccessTitle">

                <img src="../../../assets/asso/Buy/buy.svg" alt="">

                <div class="title">您已经购买成功！</div>

            </div>

            <div class="info">

                <div class="box">
                    <span class="title">支付金额</span>
                    <span class="number">¥{{ data.money }}</span>
                </div>

                <div class="box">
                    <span class="title">订单编码</span>
                    <span class="number">{{ data.number }}</span>
                </div>
                
            </div>
            

            <div class="button" >
                <van-button color="#56910C" @click="onBuy">立即去培训</van-button>
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

export default {
    data(){
        return {

            loadingshow : false,

            data : {
                money : this.$route.query.money,
                number : this.$route.query.number,
            }
            
        }
    },
    components : {

    },
    activated(){
        this.getData()
    },
    methods :{
        getData(){
            // this.loadingshow = true;
            
        },

        onBuy(){
            this.$router.push('/asso/training');
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }
    

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .SuccessTitle{
            padding: 20px 10px;
            text-align: center;
            line-height: 30px;
            color: #7A7A7A;
            font-size: 14px;
        }

        .info{
            line-height: 30px;
            background: rgba(0, 0, 0, 0.03);
            padding: 20px 60px;
            font-size: 14px;
            
            span{
                padding-right: 20px;
            }

            .title{
                color: #7A7A7A;
            }
        }

        .button{
            width: 90%;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translate(-50%, -50%); /*向左向上分别平移自身的一半*/
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);

            button{
                width: 100%;
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .SuccessTitle{
            padding: 20px 10px;
            text-align: center;
            line-height: 30px;
            color: #7A7A7A;
            font-size: 14px;
        }

        .info{
            line-height: 30px;
            background: rgba(0, 0, 0, 0.03);
            padding: 20px 60px;
            font-size: 14px;
            
            span{
                padding-right: 20px;
            }

            .title{
                color: #7A7A7A;
            }
        }

        .button{
            width: 90%;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translate(-50%, -50%); /*向左向上分别平移自身的一半*/
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);

            button{
                width: 100%;
            }
        }
    }

</style>