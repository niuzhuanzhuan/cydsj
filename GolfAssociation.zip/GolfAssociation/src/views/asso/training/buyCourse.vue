<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="课程详情"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <!-- 课程详情 -->
            <div class="video">
                
                <!-- 播放器 -->
                <div id="mse"></div>

                <div class="title">
                    <div class="name">{{ CourseData.name }}</div>
                    <div class="difficulty">
                        难度
                        <van-rate class="rate" v-model="CourseData.difficulty" :size="16" readonly />
                    </div>
                    <div class="money">
                        价格
                        <span class="span1">¥</span>
                        <span class="span2">{{ CourseData.amount }}</span>
                    </div>
                </div>

            </div>

            <!-- 分割线 -->
            <div class="line"></div>

            <!-- 培训教师 -->
            <div class="user">

                <div class="title">培训教师</div>

                <div class="personnel">

                    <div class="box" v-for="(item,index) in CourseData.teachers" :key="index">

                        <div class="avatar">
                            <van-image 
                                width="70" 
                                height="70" 
                                :src="item.avatar" 
                                fit="cover"
                                lazy-load
                                round
                            />
                        </div>

                        <div class="text">
                            <div class="title">{{ item.role }}</div>
                            <div>{{ item.name }}</div>
                        </div>

                    </div>

                </div>

            </div>

            <!-- 分割线 -->
            <div class="line"></div>

            <!-- 课程详情 -->
            <div class="CourseDetails">
                <div class="title">课程详情</div>
                <div class="content" v-html="CourseData.details"></div>
            </div>

            <div class="button">
                <van-button color="#56910C" @click="onbuy">立即购买</van-button>
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" z-index='999'>
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import Player from "xgplayer";
import api from '@/components/http'

export default {
    name : 'buyCourse',
    data(){
        return {

            loadingshow : false,

            CourseData : {},
        }
    },
    components : {

    },
    // activated(){
    //     this.getData()
    // },
    mounted () {
        
        this.getData()

        this.PlayerVidep = new Player({
            id: "mse",
            url: '',
            poster: '',
            fluid: true,  //跟随父元素的宽度大小变化
            ignores: [
                "error",
            ], //关闭组件
            lang: "zh-cn",
        });
    },
    methods :{
        getData(){
            this.loadingshow = true;

            api.ga_cultivate_info({ id : this.$route.query.id }).then(res => {

                this.loadingshow = false;

                if(res.data.xcode == 0){

                    this.CourseData = res.data.data.info

                    // this.CourseData.teachers.forEach(element => {
                    //     element.avatar = sessionStorage.getItem('asso_url') + element.avatar
                    // });

                    this.PlayerVidep.start(this.CourseData.video[0].url)

                    this.PlayerVidep.poster = this.CourseData.cover

                }else{
                    this.$toast(res.data.msg)
                }

            })
        },

        onbuy(){
            this.$router.push({ path : '/asso/buy' , query: { id: this.$route.query.id } })
        }
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .line{
            width: 100%;
            height: 10px;
            background: rgba(0, 0, 0, 0.03);
        }

        .video{
            padding: 10px 10px;

            .title{
                line-height: 35px;
                padding: 10px 15px;
                .name{
                    font-size: 18px;
                    color: #101010;
                }
                .difficulty{
                    font-size: 15px;
                    color: #7A7A7A;
                    .rate{
                        padding-left: 5px;
                    }
                }
                .money{
                    font-size: 15px;
                    color: #7A7A7A;
                    span{
                        color: #FF0000;
                    }
                    .span1{
                        font-size: 12px;
                        padding-left: 5px;
                    }
                    .span2{
                        font-size: 20px;
                    }
                }
            }
        }

        .user{
            padding: 10px 25px;

            .title{
                font-size: 18px;
                font-weight: 600;
            }

            .personnel{

                .box{
                    // width: 150px;
                    height: 70px;
                    line-height: 25px;
                    padding: 20px 10px;
                    display: inline-block;

                    .avatar{
                        float: left;
                    }

                    .text{
                        padding-top: 10px;
                        margin-left: 15px;
                        float: right;
                        height: 60px;

                        .title{
                            color: rgba(16, 16, 16, 0.29);
                        }
                    }
                }
            }
        }

        .CourseDetails{
            padding: 10px 25px;

            .title{
                font-size: 18px;
                font-weight: 600;
                padding-bottom: 15px;
            }

            .content{
                padding: 10px 0;
                line-height: 25px;

                img{
                    width: 100%;
                }
            }
        }

        .button{
            width: 90%;
            margin: 50px auto;
            button{
                width: 100%;
                font-size: 18px;
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .line{
            width: 100%;
            height: 10px;
            background: rgba(0, 0, 0, 0.03);
        }

        .video{
            padding: 10px 10px;

            .title{
                line-height: 35px;
                padding: 10px 15px;
                .name{
                    font-size: 18px;
                    color: #101010;
                }
                .difficulty{
                    font-size: 15px;
                    color: #7A7A7A;
                    .rate{
                        padding-left: 5px;
                    }
                }
                .money{
                    font-size: 15px;
                    color: #7A7A7A;
                    span{
                        color: #FF0000;
                    }
                    .span1{
                        font-size: 12px;
                        padding-left: 5px;
                    }
                    .span2{
                        font-size: 20px;
                    }
                }
            }
        }

        .user{
            padding: 10px 25px;

            .title{
                font-size: 18px;
                font-weight: 600;
            }

            .personnel{

                .box{
                    // width: 150px;
                    height: 70px;
                    line-height: 25px;
                    padding: 20px 10px;
                    display: inline-block;

                    .avatar{
                        float: left;
                    }

                    .text{
                        padding-top: 10px;
                        margin-left: 15px;
                        float: right;
                        height: 60px;

                        .title{
                            color: rgba(16, 16, 16, 0.29);
                        }
                    }
                }
            }
        }

        .CourseDetails{
            padding: 10px 25px;

            .title{
                font-size: 18px;
                font-weight: 600;
                padding-bottom: 15px;
            }

            .content{
                padding: 10px 0;
                line-height: 25px;
                img{
                    width: 100%;
                }
            }
        }

        .button{
            width: 90%;
            margin: 50px auto;
            button{
                width: 100%;
                font-size: 18px;
            }
        }
    }

</style>