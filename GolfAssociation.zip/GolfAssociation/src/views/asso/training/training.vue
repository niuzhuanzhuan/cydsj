<template>
    <div class="mine">
        <div class="index">

            <van-nav-bar
                class="assoNavBar"
                title="培训"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="TrainingTabs">
                <van-tabs v-model="active" type="card" color="#56910C" @click="onTabes">

                    <van-tab title="线上培训" >
                        
                        <div class="box" v-for="(item,index) in list" :key="index">

                            <div class="box2">
                                <van-image class="image" width="120" height="80" :src="item.cover" lazy-load/>

                                <div class="text">
                                    <div class="name">{{ item.name }}</div>

                                    <div class="courses">
                                        <span>{{ item.courses }}节课程</span>
                                        <span>名师录像</span>
                                    </div>

                                    <div class="money">
                                        <span>¥</span>
                                        {{ item.amount }}
                                        <div class="button">
                                            <van-button class="buy" color="rgba(255, 216, 216, 0.61)" round @click="onBuyCourse(item.id)" v-if="item.isbuy != 1">购买课程</van-button>
                                            <van-button color="#56910C" round @click="onPlayClass(item.id)" v-else>查看课程</van-button>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                        </div>

                        <van-empty v-if="empty" description="暂无培训课程" />

                    </van-tab>

                    <van-tab title="线下培训" >
                        
                        <div class="box" v-for="(item,index) in list" :key="index">

                            <div class="box2">
                                <van-image class="image" width="120" height="80" :src="item.cover" lazy-load/>

                                <div class="text">
                                    <div class="name">{{ item.name }}</div>

                                    <div class="courses">
                                        <span>{{ item.courses }}节课程</span>
                                        <!-- <span>名师录像</span> -->
                                    </div>

                                    <div class="money">
                                        <span>¥</span>
                                        {{ item.amount }}
                                        <div class="button">
                                            <van-button class="buy" color="rgba(255, 216, 216, 0.61)" round @click="onBuyCourse(item.id)" v-if="item.isbuy != 1">购买课程</van-button>
                                            <van-button color="#56910C" round @click="onPlayClass(item.id)" v-else>查看课程</van-button>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                        </div>

                        <van-empty v-if="empty" description="暂无培训课程" />

                    </van-tab>

                </van-tabs>
            </div>

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import navigation from '../tabbar/tabbar'
import api from '@/components/http'
import Store from "@/vuex/store";

export default {
    data(){
        return {

            loadingshow : false,

            empty : false,

            active : 0,

            list : [],
        }
    },
    components : {
        navigation
    },
    activated(){
        this.getData(1)
        this.active = 0
    },
    methods :{
        getData(mode){

            // if(Store.state.token){
                this.loadingshow = true;

                const data = {
                    mode : mode,
                    asso_id : sessionStorage.getItem('asso_id')
                }

                api.ga_cultivate_index(data).then(res => {

                    this.loadingshow = false;

                    if(res.data.xcode == 0){
                        this.list = res.data.data.list;

                        // this.list.forEach(element => {
                        //     element.cover = sessionStorage.getItem('asso_url') + element.cover
                        // });

                        if(this.list.length == 0){
                            this.empty = true
                        }

                    }else{
                        this.$toast(res.data.msg)
                    }

                })
            // }else{
            //     this.$dialog
            //     .confirm({
            //         message: "请先登录",
            //     })
            //     .then(() => {
            //         this.$router.push( "/asso/mine" );
            //     })
            //     .catch(() => {
            //         this.$router.replace("/");
            //     });
            // }
            
        },

        // 标签切换回调
        onTabes(name,title){
            if(name == 0){
                this.getData(1)
            }else{
                this.getData(2)
            }
        },
        
        // 购买
        onBuyCourse(id){
            this.$router.push({ path: "/asso/buyCourse", query: { id: id } });
        },

        // 去培训
        onPlayClass(id){
            this.$router.push({ path: "/asso/playClass", query: { id: id } });
        }
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: rgba(0, 0, 0, 0.03);
        }

        .TrainingTabs{
            background: #FFFFFF;
            
            .box{
                margin: 15px 0px;
                height: 120px;
                background: #FFFFFF;
                line-height: 30px;

                .box2{
                    height: 82px;
                    padding-top: 20px;
                }

                .image{
                    float: left;
                    margin-left: 15px;

                    img{
                        border-radius: 5px;
                    }
                }

                .text{

                    width: 50%;
                    float: right;
                    margin-right: 15px;

                    .name{
                        width: 160px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        font-size: 16px;
                        font-weight: 600;
                    }

                    .courses{
                        font-size: 13px;
                        color: rgba(16, 16, 16, 0.29);
                        span{
                            padding-right: 10px;
                        }
                    }

                    .money{
                        width: 100%;
                        font-size: 18px;
                        color: #FF0000;
                        span{
                            font-size: 13px;
                        }
                        .button{
                            float: right;
                            button{
                                height: 25px;
                            }
                        }
                    }

                }

            }
        }

    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: rgba(0, 0, 0, 0.03);
        }

        .TrainingTabs{
            background: #FFFFFF;
            
            .box{
                margin: 15px 0px;
                height: 120px;
                background: #FFFFFF;
                line-height: 30px;

                .box2{
                    height: 82px;
                    padding-top: 20px;
                }

                .image{
                    float: left;
                    margin-left: 15px;

                    img{
                        border-radius: 5px;
                    }
                }

                .text{

                    width: 50%;
                    float: right;
                    margin-right: 15px;

                    .name{
                        width: 160px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        font-size: 16px;
                        font-weight: 600;
                    }

                    .courses{
                        font-size: 13px;
                        color: rgba(16, 16, 16, 0.29);
                        span{
                            padding-right: 10px;
                        }
                    }

                    .money{
                        width: 100%;
                        font-size: 18px;
                        color: #FF0000;
                        span{
                            font-size: 13px;
                        }
                        .button{
                            float: right;
                            button{
                                height: 25px;
                            }
                        }
                    }

                }

            }
        }
    }

</style>