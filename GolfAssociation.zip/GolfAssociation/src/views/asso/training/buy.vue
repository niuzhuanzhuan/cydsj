<template>
    <div class="mine">
        <div class="index">
            
            <van-nav-bar
                class="assoNavBar"
                title="支付"
                
                left-arrow
                @click-left="() => { this.$router.back() }"
            />

            <div class="box1">

                <div class="name_money">
                    <div class="name">{{ data.name }}</div>
                    <div class="money">¥{{ data.amount }}</div>
                </div>

                <div class="title">
                    <span>{{ data.courses }}节课程</span>
                    <span>名师录播</span>
                </div>

                <!-- <div class="title">
                    <span>主讲：杨利兴</span>
                    <span>班主任：杨利兴</span>
                </div> -->

            </div>

            <div class="box2" v-if="data.favourable_available">
                <div class="money">
                    <div class="title">使用优惠券</div>
                    <div class="number">¥{{ data.favourable }}</div>
                </div>
            </div>

            <div class="box3">

                <div class="title">
                    <div class="text">商品金额</div>
                    <div class="number">¥{{ data.amount }}</div>
                </div>

                <div class="title" v-if="data.favourable_available">
                    <div class="text">优惠券金额</div>
                    <div class="number">-¥{{ data.favourable }}</div>
                </div>

                <div class="TotalPrice">
                    <div class="money">
                        <span class="title">合计：</span>
                        <span class="number">¥{{ data.pay }}</span>
                    </div>
                </div>

            </div>

            <div class="button" >
                <van-button color="#56910C" @click="onBuy">立即购买</van-button>
            </div>

            <!-- 支付弹窗 -->
            <van-share-sheet
                v-model="showShare"
                title="支付方式"
                :options="options"
                @select="onSelect"
            />

            <!-- 加载loading -->
            <van-overlay :show="loadingshow" >
                <div class="wrapper" >
                    <van-loading type="spinner" color="#1989fa" ></van-loading>
                    <p>拼命加载中...</p>
                </div>
            </van-overlay>

        </div>
    </div>
</template>

<script>

import api from '@/components/http'

import {wxPay} from '@/components/wxPay'

import Store from "@/vuex/store";

export default {
    data(){
        return {

            loadingshow : false,

            showShare : false,

            data : {},

            options: [
                { name: '微信', icon: 'wechat' },
                // { name: '支付宝', icon: 'weibo' },
            ],

            payData : {
                out_trade_no : '',
            },

        }
    },
    components : {

    },
    activated(){
        // console.log('activated 函数 执行');

        // if(this.payData.out_trade_no != ''){
        //     this.loadingshow = true;
        //     api.checkOrder({ out_trade_no : this.payData.out_trade_no }).then(res => {
        //         this.loadingshow = false;
        //         if(res.data.xcode == 0){
        //             this.$router.replace({ path: '/asso/buySuccess', query: { money : this.data.amount , number : this.payData.out_trade_no} });
        //         }else{
        //             this.$notify(res.data.msg)
        //         }
    
        //     })
        // }
        this.getData()
    },
    methods :{
        getData(){
            this.loadingshow = true;
            api.ga_cultivate_prebuy({ cultivate_id : this.$route.query.id }).then(res => {
                this.loadingshow = false
                if(res.data.xcode == 0){
                    this.data = res.data.data.cultivate;
                }else{
                    this.$toast(res.data.msg)
                }
            })
        },

        onBuy(){
            // this.$router.replace('/asso/buySuccess');
            // this.showShare = true

            if (Store.state.token) {
                this.$dialog.alert({
                    title: '温馨提示',
                    theme: 'round-button',
                    confirmButtonText : '查看支付结果',
                    confirmButtonColor : '#56910c'
                }).then(() => {
                    this.loadingshow = true;
                    api.checkOrder({ out_trade_no : this.payData.out_trade_no }).then(res => {
                        this.loadingshow = false;
                        if(res.data.xcode == 0){
                            this.$router.replace({ path: '/asso/buySuccess', query: { money : this.data.amount , number : this.payData.out_trade_no} });
                        }else{
                            this.$notify(res.data.msg)
                        }
            
                    })
                });

                this.onPay()
            } else {
                this.$dialog
                .confirm({
                    message: "请先登录",
                })
                .then(() => {
                    this.$router.push( "/asso/mine" );
                })
                .catch(() => {
                    // this.$router.replace("/");
                });
            }
            
        },

        onPay(){

            this.payData = {
                out_trade_no : new Date().getTime() + Math.ceil(Math.random()*100),
                id : this.$route.query.id,
                asso_id : sessionStorage.getItem('asso_id')
            }

            wxPay("/rest/golf_asso/cultivatePay",this.payData)
        },

        // 支付弹窗
        onSelect(option){
            this.$toast(option.name);
            this.showShare = false;
        },
    }
}
</script>

<style lang="scss" scoped>
    
    .mine {
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100vw;
        height: auto;
        overflow-x: hidden;
    }

    // loading 加载
    .wrapper{
        text-align: center;
        color: rgb(168, 169, 170);
        font-size: 20px;
        p{
            font-size: 18px;
        }
    }
    

    @media screen and (max-width: 600px) {
        .index {
            width: 100vw;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .box1{
            margin: 10px 10px;
            padding: 10px 20px;
            background: rgba(0, 0, 0, 0.03);
            line-height: 35px;
            color: rgba(16, 16, 16, 0.29);
            border-radius: 10px;

            .name_money{
                height: 35px;
                .name{
                    float: left;
                    font-weight: 600;
                    color: #000;
                }
                .money{
                    float: right;
                    color: #7A7A7A;
                }
            }

            span{
                font-size: 14px;
                padding-right: 15px;
            }
        }

        .box2{
            margin: 10px 10px;
            background: rgba(0, 0, 0, 0.03);
            line-height: 30px;
            border-radius: 10px;

            .money{
                padding: 10px 20px;
                height: 30px;

                .title{
                    float: left;
                }

                .number{
                    float: right;
                    color: #FF0000;
                }

            }
        }

        .box3{
            margin: 10px 10px;
            padding: 10px 20px;
            background: rgba(0, 0, 0, 0.03);
            line-height: 35px;
            border-radius: 10px;

            .title{
                height: 35px;
                .text{
                    float: left;
                }
                .number{
                    float: right;
                    color: #7A7A7A;
                }
            }

            .TotalPrice{

                height: 35px;

                .money{
                    float: right;

                    span{
                        padding-left: 10px;
                    }

                    .number{
                        color: #FF0000;
                    }
    
                }
            }

        }

        .button{
            width: 90%;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translate(-50%, -50%); /*向左向上分别平移自身的一半*/
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);

            button{
                width: 100%;
            }
        }
    }

    @media screen and (min-width: 600px) {
        .index {
            width: 600px;
            min-height: 100vh;
            height: auto;
            background-color: #ffffff;
        }

        .box1{
            margin: 10px 10px;
            padding: 10px 20px;
            background: rgba(0, 0, 0, 0.03);
            line-height: 35px;
            color: rgba(16, 16, 16, 0.29);
            border-radius: 10px;

            .name_money{
                height: 35px;
                .name{
                    float: left;
                    font-weight: 600;
                    color: #000;
                }
                .money{
                    float: right;
                    color: #7A7A7A;
                }
            }

            span{
                font-size: 14px;
                padding-right: 15px;
            }
        }

        .box2{
            margin: 10px 10px;
            background: rgba(0, 0, 0, 0.03);
            line-height: 30px;
            border-radius: 10px;

            .money{
                padding: 10px 20px;
                height: 30px;

                .title{
                    float: left;
                }

                .number{
                    float: right;
                    color: #FF0000;
                }

            }
        }

        .box3{
            margin: 10px 10px;
            padding: 10px 20px;
            background: rgba(0, 0, 0, 0.03);
            line-height: 35px;
            border-radius: 10px;

            .title{
                height: 35px;
                .text{
                    float: left;
                }
                .number{
                    float: right;
                    color: #7A7A7A;
                }
            }

            .TotalPrice{

                height: 35px;

                .money{
                    float: right;

                    span{
                        padding-left: 10px;
                    }

                    .number{
                        color: #FF0000;
                    }
    
                }
            }

        }

        .button{
            width: 90%;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translate(-50%, -50%); /*向左向上分别平移自身的一半*/
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);

            button{
                width: 100%;
            }
        }
    }

</style>