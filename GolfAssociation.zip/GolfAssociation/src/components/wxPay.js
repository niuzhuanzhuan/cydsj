
import wx from 'weixin-js-sdk'

export const wxPay = function(url,data){
    let a={url:url,data:data}
    let payData=encodeURI(JSON.stringify(a))
    wx.miniProgram.navigateTo({url: '/pages/h5pay/h5pay?payData=' + payData})
}


