import wx from 'weixin-js-sdk';
const downImage = (url) => {

	wx.miniProgram.postMessage({
		data: {
			imgData: url // 刚才拿到的base64 数据
		}
	})
	wx.miniProgram.navigateBack({
		delta: 1
	})
}
export default {
	downImage
}
