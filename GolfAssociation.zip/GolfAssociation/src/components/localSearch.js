export const useLocalSearch = (list, keywords) => {
	const searchedList = list.length > 0 ? list.filter(item =>item.includes(keywords)) : list;
	return searchedList;
};

// 获取url的token
export const GetRequest = (param) => {
	let url = location.href; //获取url中"?"符后的字串
	let params = url.match(/\?.*/);
	if (!params) return;
	url = params[0];
	const theRequest = {};
	if (url.indexOf("?") !== -1) {
		const str = url.substr(1);
		const strs = str.split("&");
		for (var i = 0; i < strs.length; i++) {
		theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
		}
	}
	return theRequest[param];
}

//调用 原生 GPS 运动
const uploadLocation = () => {
	var u = navigator.userAgent;
	if (u.indexOf('EasyDo') > -1) {
	  if (u.indexOf('Android') > -1 || u.indexOf('Adr') > -1) {
		/*alert("安卓")*/
		return android.uploadLocation();
	  } else if (!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
	  /*  alert("苹果")*/
		// native.startSports(JSON.stringify(obj));
		return WebViewJavascriptBridge.callHandler('uploadLocation',JSON.stringify(),function(response) {
		  document.getElementById("returnValue").value = response;
		});
	  }
	}
  };

export default useLocalSearch;GetRequest;uploadLocation;
