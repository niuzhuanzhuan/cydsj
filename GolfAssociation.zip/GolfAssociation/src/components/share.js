import wx from 'weixin-js-sdk';
import api from '@/utils/api.js';
const sharekey = () => {
	api.shareButton().then(res => {
		wx.config(res.data.data)

	}).catch(error => {

	})
}

export default {
	sharekey
}
