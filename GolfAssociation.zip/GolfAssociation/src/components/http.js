import qs from 'qs'
import Vue from 'vue'
import Store from '@/vuex/store'

// 登录
const userLogin = function (data) {
  let url = '/rest/user/enrollLogin';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 发送验证码
const sendCode = function (data) {
  let url = '/rest/smsCode/sendCode';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 高尔夫协会信息表
const ga_home = function (data) {
  let url = '/rest/golf_asso/ga_home';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 组织架构
const ga_asso = function (data) {
  let url = '/rest/golf_asso/ga_asso';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 分协会详情
const getAssoDetail = function (data) {
  let url = '/rest/golf_asso/getAssoDetail';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 协会人员列表
const getAssoUserList = function (data) {
  let url = '/rest/golf_asso/getAssoUserList';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 合作企业
const ga_enterprise = function (data) {
    let url = '/rest/golf_asso/ga_enterprise';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 高尔夫协会-分会列表
const ga_part = function (data) {
  let url = '/rest/golf_asso/ga_part';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 高尔夫协会-球场和基地
const getYardBase = function (data) {
  let url = '/rest/golf_asso/getYardBase';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 高尔夫协会-球场和基地 某一个详情
const getYardBaseDetail = function (data) {
  let url = '/rest/golf_asso/getYardBaseDetail';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 高尔夫协会-分协会列表
const getAssoList = function (data) {
  let url = '/rest/golf_asso/getAssoList';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 高尔夫协会-团队信息
const getTeamDetail = function (data) {
  let url = '/rest/golf_asso/getTeamDetail';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 团队球员个人信息
const getTeamUserDetail = function (data) {
  let url = '/rest/golf_asso/getTeamUserDetail';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 公告
const ga_notice = function (data) {
  let url = '/rest/golf_asso/ga_notice';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 报名
const ga_enroll = function (data) {
  let url = '/rest/golf_asso/ga_enroll';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 报名结果
const ga_enroll_info = function (data) {
  let url = '/rest/golf_asso/ga_enroll_info';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 我的页面 个人信息
const ga_mine = function (data) {
    let url = '/rest/golf_asso/ga_mine';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 我的页面 审核
const ga_mine_appr = function (data) {
    let url = '/rest/golf_asso/ga_mine_appr';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 我的页面 赛事
const ga_match = function (data) {
    let url = '/rest/golf_asso/ga_match';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 总赛事列表
const ga_mine_match = function (data) {
    let url = '/rest/golf_asso/ga_mine_match';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 赛事详情
const ga_match_info = function (data) {
    let url = '/rest/golf_asso/ga_match_info';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 赞助首页
const ga_sponsor_index = function (data) {
    let url = '/rest/golf_asso/ga_sponsor_index';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 赞助提交
const ga_sponsor_refer = function (data) {
    let url = '/rest/golf_asso/ga_sponsor_refer';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 培训课程列表
const ga_cultivate_index = function (data) {
    let url = '/rest/golf_asso/ga_cultivate_index';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 培训课程购买详情
const ga_cultivate_info = function (data) {
    let url = '/rest/golf_asso/ga_cultivate_info';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 培训课程购买详情
const ga_cultivate_prebuy = function (data) {
    let url = '/rest/golf_asso/ga_cultivate_prebuy';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 去上课
const ga_cultivate_videos = function (data) {
    let url = '/rest/golf_asso/ga_cultivate_videos';
  
    return Vue.$axios.post(url, data, {
      headers: {
        'XX-Device-Type': 'web',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'XX-token': Store.state.token
      },
      transformRequest: (data) => {
        data = qs.stringify(data);
        return data
      }
    }).then(res => {
          return  Promise.resolve(res);
    })
  
};

// 会员注册福利 和 价格选择
const getMemberData = function (data) {
  let url = '/rest/golf_asso/getMemberData';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 我的账单
const getMyPrice = function (data) {
  let url = '/rest/golf_asso/getMyPrice';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 我的协会
const getMyAsso = function (data) {
  let url = '/rest/golf_asso/getMyAsso';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 我的培训
const getMyCultivate = function (data) {
  let url = '/rest/golf_asso/getMyCultivate';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

// 订单查询
const checkOrder = function (data) {
  let url = '/rest/golf_asso/checkOrder';

  return Vue.$axios.post(url, data, {
    headers: {
      'XX-Device-Type': 'web',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'XX-token': Store.state.token
    },
    transformRequest: (data) => {
      data = qs.stringify(data);
      return data
    }
  }).then(res => {
        return  Promise.resolve(res);
  })

};

const Api={
  userLogin,
  sendCode,
  ga_home,
  ga_asso,
  getAssoDetail,
  getAssoUserList,
  ga_enterprise,
  ga_part,
  getYardBase,
  getYardBaseDetail,
  getAssoList,
  getTeamDetail,
  getTeamUserDetail,
  ga_notice,
  ga_enroll,
  ga_enroll_info,
  ga_mine,
  ga_mine_appr,
  ga_mine_match,
  ga_match,
  ga_match_info,
  ga_sponsor_index,
  ga_sponsor_refer,
  ga_cultivate_index,
  ga_cultivate_info,
  ga_cultivate_prebuy,
  ga_cultivate_videos,
  getMemberData,
  getMyPrice,
  getMyAsso,
  getMyCultivate,
  checkOrder
}
export default Api
