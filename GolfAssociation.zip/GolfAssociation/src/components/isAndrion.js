/**
 * Created by worktime on 2017/12/14.
 */
import Vue from 'vue'
//import qs from 'qs'



const appShare = (obj, val) => {
  var u = navigator.userAgent
  if (u.indexOf('EasyDo') > -1) {
    if (val === 'runShare') {
      obj = {
          shareType: 'image',
          title: '',
          description: '',
          logo: '',
          link:'',
          isShareYD:'false',
          dynData:{
            dynamicType:'',
            imgUrl:'',
            title:'',
            view_link: '',
            goodsType: '',
            userID: '',
            product_id:''
          }
        }
    }
    if (u.indexOf('Android') > -1 || u.indexOf('Adr') > -1) {
      android.getShareInfo(JSON.stringify(obj))
    } else if (!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
      //native.getShareInfo(JSON.stringify(obj))
      WebViewJavascriptBridge.callHandler('getShareInfo',JSON.stringify(obj),function(response) {
        document.getElementById("returnValue").value = response;
      });
    }
  }
}
const voiceBroadcast=(content)=>{
  if (content !== ''){
    let obj = {
      htmls:content
    }
    let u = navigator.userAgent
    console.log(obj)
    if (u.indexOf('EasyDo') > -1) {
      if (u.indexOf('Android') > -1 || u.indexOf('Adr') > -1) {
        android.getHtmlInfos(JSON.stringify(obj))
      } else if (!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
        //native.getHtmlInfos(JSON.stringify(obj))
        WebViewJavascriptBridge.callHandler('getHtmlInfos',JSON.stringify(obj),function(response) {
          document.getElementById("returnValue").value = response;
        });
      }
    }
  }

}
export {
    appShare,
    voiceBroadcast
}
