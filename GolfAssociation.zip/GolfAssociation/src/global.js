const global = {
  DEFAULT_AJAX_HEADERS: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
  REST_URL: 'https://api.live.yongdongli.net',
  BASE_URL: 'https://api.live.yongdongli.net',
  FILE_URL: 'https://res.yongdongli.net/'

  // REST_URL: 'https://api.live.sportbd.cn',
  // BASE_URL: 'https://api.live.sportbd.cn',
  // FILE_URL: 'https://res.sportbd.cn/'

  // REST_URL: 'http://192.168.0.166',
  // BASE_URL: 'http://192.168.0.166',
  // FILE_URL: 'https://res.sportbd.cn/'
}

export default global