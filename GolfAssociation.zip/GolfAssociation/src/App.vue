<template>
	<div id="app">
		<keep-alive exclude="Home,match,userList,playClass,vipSignUp,buyCourse,tabbar,team,matchHtml,vHtml"><router-view /></keep-alive>
		<div
			v-show="loading"
			v-if="loadinit"
			id="mianskeys"
			style="width: 100vw;position: absolute;top: 0; height: 100%;  display: flex;justify-content: center;align-items: center;z-index: 99999;background: rgba(0,0,0,.2);"
		>
			<van-loading type="spinner" vertical color="#78AC09">正在拼命加载中...</van-loading>
		</div>
		<van-overlay :show="showmian">
			<div class="wrapper">
				<div class="block">{{ titles }}</div>
			</div>
		</van-overlay>
	</div>
</template>

<script>
import bus from '@/components/bus.js';
import { mapActions, mapGetters } from 'vuex';
export default {
	data() {
		return {
			loading: false,
			loadinit: true,
			showmian: false,
			titles: '链接有误，请检查！'
		};
	},
	created() {
		bus.$on('loading', msg => {
			this.loading = msg.msg;
		});
	},
	activated() {
		this.geturls();
	},
	watch: {
		$route(newValue, oldValue) {
			if (newValue.path != oldValue.path) {
				this.geturls();
			}
		},
		displays(newval) {
			if (newval == 1) {
				this.loadinit = true;
			} else {
				this.loadinit = false;
			}
		}
	},
	computed: {
		...mapGetters(['displays'])
	},
	methods: {
		...mapActions(['setmatid']),
		geturls() {
			this.showmian = false;
			if (sessionStorage['match_id'] || sessionStorage['asso_id']) {
				const initurl = this.$route.query;
				if (Object.keys(initurl).length > 0) {
					if (initurl.match_id) {
						this.inits('match_id', initurl.match_id);
					} else if (initurl.asso_id) {
						this.inits('asso_id', initurl.asso_id);
					}
				} else {
					if (sessionStorage['match_id']) {
						this.inits('match_id', sessionStorage['match_id']);
					} else if (sessionStorage['asso_id']) {
						this.inits('asso_id', sessionStorage['asso_id']);
					} else {
						this.showmian = true;
					}
				}
			} else {
				const initurl = this.$route.query;
				if (initurl) {
					if (initurl.match_id) {
						this.inits('match_id', initurl.match_id);
					} else if (initurl.asso_id) {
						this.inits('asso_id', initurl.asso_id);
					} else {
						this.showmian = true;
					}
				} else {
					this.showmian = true;
				}
			}
		},
		inits(sess, data) {
			if (data != '') {
				sessionStorage[sess] = data;
				this.setmatid(data);
			} else {
				this.showmian = true;
			}
		}
	}
};
</script>

<style lang="scss">
@import url('./assets/css/css.css');
.wrapper {
	display: flex;
	align-items: center;
	justify-content: center;
	height: 100vh;
	width: 100vw;
	background: #4c4c4c;
	opacity: 0.8;
}
.block {
	color: #ffffff;
}
* {
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #f5f5f5;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #f5f5f5;
	}
	&::-webkit-scrollbar-corner {
		background: #f5f5f5;
	}
}
</style>
