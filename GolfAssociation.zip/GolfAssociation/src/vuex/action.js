const actions = {
	// action 是异步的通过使用dispath来触发
	//  这里我在两个方法中使用了两个不同的参数，
	// 一个是context，它是一个和store对象具有相同对象属性的参数。
	// 在第二个函数中，我是直接使用了这个对象的commit的方法。
	actionsAddCount(context, n = 0) {

		console.log(context)
		return context.commit('mutationsAddCount', n)
	},
	actionsReduceCount({
		commit
	}, n = 0) {
		return commit('mutationsReduceCount', n)
	},
	actionsSetToken({
		commit
	}, token = '') {

		console.log("setToken:", token);
		return commit('setToken', token)
	},
	actionSetTrainItem({
		commit
	}, trainItem = '') {

		console.log("SetTrainItem:", trainItem);
		return commit('setTrainItem', trainItem)
	},
	actionsSetPhone({
		commit
	}, phone = '') {

		console.log("setPhone:", phone);
		return commit('setPhone', phone)
	},
	actionsSetGoPath({
		commit
	}, goPath = '') {
		return commit('setGoPath', goPath)
	},
	actionsSetTeamId({
		commit
	}, teamId = '') {

		console.log("setTeamId:", teamId);
		return commit('setTeamId', teamId)
	},
	//运动会id
	actionsSetYDHId({
		commit
	}, ydhId = '') {
		console.log("setYDHId:", ydhId);
		return commit('setYDHId', ydhId)
	},
	//选择运动赛事
	actionsSetYDHEvent({
		commit
	}, event = '') {
		console.log("setYDHEvent:", event);
		return commit('setYDHEvent', event)
	},
	//选择的赛事的子项
	actionsSetJoinItem({
		commit
	}, joinItem = '') {
		console.log("setJoinItem:", joinItem);
		return commit('setJoinItem', joinItem)
	},
	displayimgs({
		commit
	}, data) {
		return commit('displayimg', data)
	},
	displayimgsindex({
		commit
	}, data) {
		return commit('imgsindex', data)
	},
	setwebsocket({
		commit
	}, data) {
		return commit('set_websocket', data)
	},
	setdomain({
		commit
	}, data) {
		return commit('set_domain', data)
	},
	setmatid({
		commit
	}, data) {
		return commit('mat_id', data)
	},
	setnums(state, data) {
		state.state.nums = data
	},
	displays(state, data){
		state.state.displays=data;
	}

}
export default actions;
