import Vuex from 'vuex'
import Vue from 'vue'
import mutations from "./mutation";
import stateAll from "./state";
import actions from "./action";
import getters from "./get";
Vue.use(Vuex)
export default new Vuex.Store({
	state: stateAll,
	mutations: mutations,
	actions: actions,
	getters: getters
});
