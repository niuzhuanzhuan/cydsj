// vuex 中的getters 想当于vue中的computed  ，
// getters是vuex 中的计算属性 ，计算属性写起来是方法，
// 但它是个属性
const getters = {
	count: (state) => state.count,
	phone: (state) => state.phone,
	token: (state) => state.token,
	displays: (state) => state.displays,
}
export default getters;
