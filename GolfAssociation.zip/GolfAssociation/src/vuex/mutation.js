const mutations = {
	mutationsAddCount(state, n = 0) {
		return (state.count += n)
	},
	mutationsReduceCount(state, n = 0) {
		return (state.count -= n)
	},
	setToken(state, token) {
		return state.token = token
	},
	setvideo_train_id(state, video_train_id) {
		return state.video_train_id = video_train_id
	},
	setTrainItem(state, trainItem) {
		return state.trainItem = trainItem
	},
	setPhone(state, phone) {
		return state.phone = phone
	},
	setGoPath(state, goPath) {
		console.log(goPath)
		return state.goPath = goPath
	},
	setTeamId(state, teamId) {
		return state.teamId = teamId
	},
	//运动会
	setYDHId(state, ydhId) {
		return state.ydhId = ydhId
	}, //运动会
	setYDHEvent(state, event) {
		return state.event = event
	}, //运动会某个赛事
	setJoinItem(state, joinItem) {
		return state.joinItem = joinItem
	}, //运动会某个赛事
	displayimg(state, data) { //直播预览图片
		state.imageslist = data
	},
	imgsindex(state, data) { //预览图片第几张开始
		return state.imgindex = data
	},
	mat_id(state, data) { //恒丰杯赛事ID
		return state.match_id = data
	},
	set_websocket(state, data){
		state.websocket = data
	},
	set_domain(state, data){
		state.domain = data
	},
}
export default mutations;
