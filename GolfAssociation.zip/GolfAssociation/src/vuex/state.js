const stateAll = {
	count: 0,
	token: '',
	trainItem: '',
	phone: '',
	teamId: '', //38妇女节团队id
	//运动会
	ydhId: '', //运动会id
	event: '', //运动会某个赛事
	joinItem: '', //选择的报名项目
	goPath: '', //当前路径
	video_train_id: '',
	imageslist: [], //预览图片
	imgindex: 0, //预览图片从第几开始
	match_id:'',
	websocket:'',
	domain:'',
	nums:1,//控制点击我的菜单请求次数
	displays:1
}
export default stateAll
