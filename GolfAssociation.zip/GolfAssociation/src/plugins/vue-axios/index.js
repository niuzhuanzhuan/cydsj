import Axios from 'axios'

const install = function (Vue, options = {}) {
  if (install.installed) return

  if (!Axios) {
    console.error('You have to install axios.')
    return
  }

  var axios = Axios.create(options)
  Vue.$axios = axios

  Object.defineProperties(Vue.prototype, {
    $axios: {
      get () {
        return axios
      }
    }
  })
}

export default install
