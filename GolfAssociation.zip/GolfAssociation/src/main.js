import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './vuex/store'

import './css/css.scss'

// 引用 Vant
import Vant, {
	Lazyload
} from 'vant';
import 'vant/lib/index.css';
Vue.use(Vant).use(Lazyload);

// 引用 Element
import {
	Upload,
	Dialog
} from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(Upload).use(Dialog)

import 'element-ui/lib/theme-chalk/base.css';
import CollapseTransition from 'element-ui/lib/transitions/collapse-transition';
Vue.component(CollapseTransition.name, CollapseTransition)

import Axios from './plugins/vue-axios'
import global from './global'
Vue.use(Axios, {
	baseURL: global.BASE_URL,
	headers: global.DEFAULT_AJAX_HEADERS
})



// 获取url的token
function GetRequest(param) {
	let url = location.href; //获取url中"?"符后的字串
	let params = url.match(/\?.*/);
	if (!params) return;
	url = params[0];
	const theRequest = {};
	if (url.indexOf("?") !== -1) {
		const str = url.substr(1);
		const strs = str.split("&");
		for (var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
		}
	}
	return theRequest[param];
}
let token = GetRequest("token")
let token1 = sessionStorage.getItem('token')
if (token || token1) {
	if (token) {
		sessionStorage.setItem('token', token);
		store.commit("setToken", token);
	} else {
		store.commit("setToken", token1);
	}
}

if (GetRequest("asso_id")) {
	sessionStorage.setItem("asso_id", GetRequest("asso_id"));
}else{
	sessionStorage.setItem("asso_id", '1');
}

Vue.config.productionTip = false
import api from "./utils/newapi.js"
Vue.prototype.$api = api
// import share from './components/share'
// share.sharekey()

new Vue({
	router,
	store,
	render: h => h(App)
}).$mount('#app')
