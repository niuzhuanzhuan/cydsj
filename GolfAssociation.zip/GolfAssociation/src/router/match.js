export const routes = [{
		path: '/match',
		component: resolve => require(['@/views/match/Home/home'], resolve),
		meta: {
			keepAlive: true
		}
	}, {
		path: '/match/displayimg',
		component: resolve => require(['@/views/match/displayimg/displayimg'], resolve),
		meta: {
			keepAlive: true
		}
	}, {
		path: '/match/address',
		component: resolve => require(['@/views/match/address/address'], resolve),
	}, {
		path: '/match/personal',
		component: resolve => require(['@/views/match/personal/personal'], resolve),
		meta: {
			keepAlive: true
		}
	}, {
		path: '/match/surface',
		component: resolve => require(['@/views/match/surface/surface'], resolve),
	},
	{
		path: '/match/userLogin',
		name: '/match/userLogin',
		component: resolve => require(['@/views/match/user/userLogin'], resolve),
	},
	{
		path: '/match/notice', //公告页面
		component: resolve => require(['@/views/match/Notice/index'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/match/pcvideo', 
		component: resolve => require(['@/views/match/pcvideo/pcvideo'], resolve),
		
	},
	{
		path: '/match/keyvideo', 
		component: resolve => require(['@/views/match/pcvideo/keyvideo'], resolve),
		
	},
	{
		path: '/match/pcvideo', 
		component: resolve => require(['@/views/match/pcvideo/pcvideo'], resolve),
		
	},
	{
		path: '/match/team',
		component: resolve => require(['@/views/match/team/team'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/match/teamdetails',
		component: resolve => require(['@/views/match/team/teamdetails'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/match/playback',
		component: resolve => require(['@/views/match/playback/playback'], resolve),
		
	},
	{
		path: '/match/Fairway',
		component: resolve => require(['@/views/match/Fairway/Fairway'], resolve),
		
	},
	{
		path: '/match/notice_details', //公告详情页面
		component: resolve => require(['@/views/match/notice_details/index'], resolve),
		
	},
	{
		path: '/match/page/personal',
		component: resolve => require(['@/views/match/components/page/details/personal'], resolve),
		
	},
	{
		path: '/match/page/teamde',
		component: resolve => require(['@/views/match/components/page/details/teamde'], resolve),
	},
	{
		path: '/match/page/perteam',
		component: resolve => require(['@/views/match/components/page/details/perteam'], resolve),
	},
	{
		path: '/match/page/fourteamde',
		component: resolve => require(['@/views/match/components/page/details/fourteamde'], resolve),
	},
	{
		path: '/match/result',
		component: resolve => require(['@/views/match/components/mydata/result/result'], resolve),
	},
	{
		path: '/match/details',
		component: resolve => require(['@/views/match/details/details'], resolve),
	},
	{
		path: '/match/Ranking',
		component: resolve => require(['@/views/match/Ranking/Ranking'], resolve),
	},
	{
		path: '/match/live',
		component: resolve => require(['@/views/match/live/live'], resolve),
	},
	{
		path: '/match/my',
		component: resolve => require(['@/views/match/my/my'], resolve),
	},
	{
		path: '/match/achievement',
		component: resolve => require(['@/views/match/achievement/achievement'], resolve),
	},
	{
		path: '/match/videos',
		component: resolve => require(['@/views/match/videos/videos'], resolve),
	},
]