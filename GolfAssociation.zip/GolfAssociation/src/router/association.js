const childarrs = [
    // -------------------登录---------------------
    {
        path: '/asso/userLogin',
        name: 'userLogin',
        component: resolve => require(['@/views/asso/user/userLogin'], resolve),
    },

    // --------------------首页---------------------
    {
        path: '/',
        name: 'home',
        component: resolve => require(['@/views/asso/home/home'], resolve),
    },
    // 组织架构
    {
        path: '/asso/asso',
        name: 'asso',
        component: resolve => require(['@/views/asso/home/asso'], resolve),
    },
    // 协会管理员列表
    {
        path: '/asso/adminList',
        name: 'adminList',
        component: resolve => require(['@/views/asso/asso_user_list/adminList'], resolve),
    },
    // 协会人员列表
    {
        path: '/asso/userList',
        name: 'userList',
        component: resolve => require(['@/views/asso/asso_user_list/userList'], resolve),
    },
    // 团队列表
    {
        path: '/asso/teamList',
        name: 'teamList',
        component: resolve => require(['@/views/asso/team/teamList'], resolve),
    },
    // 团队详情
    {
        path: '/asso/teamInfo',
        name: 'teamInfo',
        component: resolve => require(['@/views/asso/team/teamInfo'], resolve),
    },
    // 团队个人信息
    {
        path: '/asso/userinfo',
        name: 'userinfo',
        component: resolve => require(['@/views/asso/userinfo/userinfo'], resolve),
    },
    // 合作企业
    {
        path: '/asso/jointVenture',
        name: 'jointVenture',
        component: resolve => require(['@/views/asso/home/jointVenture'], resolve),
    },
    // 高尔夫 协会\球场\基地 列表 (旧版本)
    {
        path: '/asso/golfListTable',
        name: 'golfListTable',
        component: resolve => require(['@/views/asso/home/golfListTable'], resolve),
    },
    // 高尔夫 球场\基地 列表 (新版本)
    {
        path: '/asso/stadiums_and_bases',
        name: 'stadiums_and_bases',
        component: resolve => require(['@/views/asso/home/stadiums_and_bases'], resolve),
    },
    // 高尔夫 球场\基地 详情
    {
        path: '/asso/vHtml',
        name: 'vHtml',
        component: resolve => require(['@/views/asso/home/vHtml'], resolve),
    },
    // 公告
    {
        path: '/asso/news',
        name: 'news',
        component: resolve => require(['@/views/asso/news/news'], resolve),
    },
    // 公告详情
    {
        path: '/asso/newsDetails',
        name: 'newsDetails',
        component: resolve => require(['@/views/asso/news/newsDetails'], resolve),
    },

    
    // --------------------赛事---------------------
    {
        path: '/asso/match',
        name: 'match',
        component: resolve => require(['@/views/asso/match/match'], resolve),
    },
    // 赛事详情
    {
        path: '/asso/matchinfo',
        name: 'matchinfo',
        component: resolve => require(['@/views/asso/match/matchinfo'], resolve),
    },
    // 赛事介绍详情
    {
        path: '/asso/matchHtml',
        name: 'matchHtml',
        component: resolve => require(['@/views/asso/match/matchHtml'], resolve),
    },

    // --------------------培训---------------------
    {
        path: '/asso/training',
        name: 'training',
        component: resolve => require(['@/views/asso/training/training'], resolve),
    },
    // 课程详情
    {
        path: '/asso/buyCourse',
        name: 'buyCourse',
        component: resolve => require(['@/views/asso/training/buyCourse'], resolve),
    },
    // 购买
    {
        path: '/asso/buy',
        name: 'buy',
        component: resolve => require(['@/views/asso/training/buy'], resolve),
    },
    // 购买成功
    {
        path: '/asso/buySuccess',
        name: 'buySuccess',
        component: resolve => require(['@/views/asso/training/buySuccess'], resolve),
    },
    // 开始上课
    {
        path: '/asso/playClass',
        name: 'playClass',
        component: resolve => require(['@/views/asso/training/playClass'], resolve),
    },

    // --------------------赞助---------------------
    {
        path: '/asso/sponsor',
        name: 'sponsor',
        component: resolve => require(['@/views/asso/sponsor/sponsor'], resolve),
    },
    // 去赞助
    {
        path: '/asso/SponsorRefer',
        name: 'SponsorRefer',
        component: resolve => require(['@/views/asso/sponsor/SponsorRefer'], resolve),
    },

    // --------------------我的---------------------
    {
        path: '/asso/mine',
        name: 'mine',
        component: resolve => require(['@/views/asso/mine/mine'], resolve),
    },
    // 我的账单
    {
        path: '/asso/mybill',
        name: 'mybill',
        component: resolve => require(['@/views/asso/mine/mybill'], resolve),
    },
    // 我的协会
    {
        path: '/asso/myAsso',
        name: 'myAsso',
        component: resolve => require(['@/views/asso/mine/myAsso'], resolve),
    },
    // 我的赛事
    {
        path: '/asso/myMatch',
        name: 'myMatch',
        component: resolve => require(['@/views/asso/mine/myMatch'], resolve),
    },
    // 我的培训
    {
        path: '/asso/myTraining',
        name: 'myTraining',
        component: resolve => require(['@/views/asso/mine/myTraining'], resolve),
    },
    // 我的审核
    {
        path: '/asso/myReview',
        name: 'myReview',
        component: resolve => require(['@/views/asso/mine/myReview'], resolve),
    },


    // --------------------注册---------------------
    // 教练、裁判、运动员
    {
        path: '/asso/signUp',
        name: 'signUp',
        component: resolve => require(['@/views/asso/signUp/signUp'], resolve),
    },
    // 会员
    {
        path: '/asso/vipSignUp',
        name: 'vipSignUp',
        component: resolve => require(['@/views/asso/signUp/vipSignUp'], resolve),
    },
    // 会员
    {
        path: '/asso/vipPay',
        name: 'vipPay',
        component: resolve => require(['@/views/asso/signUp/vipPay'], resolve),
    },
]

export default {
    childarrs
}
