import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}


import asso from './association.js'
import *as match from './match.js'

const routes = [
	...asso.childarrs,
	...match.routes
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})



router.beforeEach((to, from, next) => {
	// 协会
	if(to.path.includes('asso')){
		if(to.query.asso_id){
			next()
		}else{
			next({
				path:to.path,
				name:to.name,
				query:{
					...to.query,
					asso_id:sessionStorage.getItem("asso_id")
				}
			})
		}


	}
	// 赛事
	else if(to.path.includes('match')){
		if(to.query.match_id){
			if(to.query.asso_id){
				next()
			}
			else{
				next({
					path:to.path,
					name:to.name,
					query:{
						...to.query,
						asso_id:sessionStorage.getItem("asso_id"),
					}
				})
			}
		}else{
			next({
				path:to.path,
				name:to.name,
				query:{
					...to.query,
					asso_id:sessionStorage.getItem("asso_id"),
					match_id:sessionStorage.getItem("match_id"),
					from:'wxApp'
				}
			})
		}
	}
	// 首页
	else{
		next()
	}


/*	if(to.query.asso_id){
		next()
	}else{
		next({
			path:to.path,
			name:to.name,
			query:{
				...to.query,
				asso_id:sessionStorage.getItem("asso_id")
			}
		})
	}*/

});

export default router
