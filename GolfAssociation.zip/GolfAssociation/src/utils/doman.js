// 网站全局变量

module.exports = {
	// URL : "https://api.live.sportbd.cn/", //测试服服务器地址
	URL: "https://api.live.yongdongli.net", //正式服务器地址
};
