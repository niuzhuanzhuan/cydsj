import request from "./http";
import qs from "qs";
import store from "@/vuex/store";

let match_index = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_index',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_yard = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_yard',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_details = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_details',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_team = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_team',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_lattice_header = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_lattice_header',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_score_header = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_score_header',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_score = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_score',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_score_detail = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_score_detail',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let golf_mine = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/golf_mine',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let livelist = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf1/livelist',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let video = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf1/video',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let video_hits = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf1/video_hits',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let imgtobase64 = (data, suc) => {
	return request({
		method: 'post',
		url: 'rest/golf1/imgtobase64',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let chat_list = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf1/chat_list',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let chat_add = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf1/chat_add',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_rank_header = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_rank_header',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_rank = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_rank',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};
export default {
	match_rank,
	match_rank_header,
	match_lattice_header,
	match_team,
	match_details,
	match_index,
	match_yard,
	match_score_header,
	match_score,
	match_score_detail,
	golf_mine,
	livelist,
	video,
	video_hits,
	imgtobase64,
	chat_list,
	chat_add,
}
