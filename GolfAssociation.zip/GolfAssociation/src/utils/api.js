import request from "./http";
import qs from "qs";
import store from "@/vuex/store";
import {
	Dialog
} from 'vant';
//分享按钮
let shareButton = (data, suc) => {
	return request({
		method: 'post',
		url: 'rest/shareInfo/getWXJSSDKConfig',
		data: qs.stringify(data),
		headers: {
			'XX-Device-Type': 'web',
			'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
		},
	})
};
let userLogin = (data, suc) => { //登录
	return request({
		method: 'post',
		url: '/rest/user/enrollLogin',
		data: qs.stringify(data),
	})
};
let sendCode = (data, suc) => { //登录
	return request({
		method: 'post',
		url: '/rest/smsCode/sendCode',
		data: qs.stringify(data)
	})
};
const getImgList = (data) => {
	return request({
		method: 'GET',
		url: '/rest/golf1/imglist',
		params: data
	})
}

const getHotImg = (data) => {
	return request({
		method: 'GET',
		url: '/rest/golf1/imgtop',
		params: data
	})
}

const livelist = (data) => {
	return request({
		method: 'post',
		url: '/rest/golf1/livelist',
		data: qs.stringify(data),
	})
}

const eav_list = (data) => { //评论列表
	return request({
		method: 'post',
		url: '/rest/golf1/eav_list',
		data: qs.stringify(data),
		headers: {
			'XX-token': store.state.token
		},
	})
}

const live_like = (data) => { //点赞
	return request({
		method: 'post',
		url: '/rest/golf1/live_like',
		data: qs.stringify(data),
		headers: {
			'XX-token': store.state.token
		},
	})
}

const live_hits = (data) => { //加点击量
	return request({
		method: 'post',
		url: '/rest/golf1/live_hits',
		data: qs.stringify(data),
		headers: {
			'XX-token': store.state.token
		},
	})
}

const live_eav = (data) => { //评论比赛
	return request({
		method: 'post',
		url: '/rest/golf1/live_eav',
		data: qs.stringify(data),
		headers: {
			'XX-token': store.state.token
		},
	})
}

let userinfo = (data, suc) => { //用户信息
	return request({
		method: 'post',
		url: '/rest/userInfo/index',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let golf_score_rank = (data, suc) => { //成绩排名
	return request({
		method: 'post',
		url: '/rest/golf20/golf_score_rank',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let golf_match_bouts = (data, suc) => { //赛事的场次
	return request({
		method: 'post',
		url: '/rest/golf20/golf_match_bouts',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let golf_match_by_user = (data, suc) => { //我的
	return request({
		method: 'post',
		url: '/rest/golf20/golf_match_by_user',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let golf_score_view = (data, suc) => { //球员的成绩
	return request({
		method: 'post',
		url: '/rest/golf20/golf_score_view',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let golf_score_check = (data, suc) => { //成绩确认
	return request({
		method: 'post',
		url: '/rest/golf20/golf_score_check',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let imghits = (data, suc) => { //给图片加点击量
	return request({
		method: 'post',
		url: '/rest/golf1/imghits',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let img_hits = (data, suc) => { //给图片页面加点击量
	return request({
		method: 'post',
		url: '/rest/golf1/img_hits',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let check_yid = (data, suc) => { //登录
	return request({
		method: 'post',
		url: '/rest/golf1/check_yid',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_index = (data, suc) => { //恒丰杯赛事ID
	return request({
		method: 'post',
		url: '/rest/golf20/match_index',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	}).then(suc)
};

let match_enroll = (data, suc) => { //恒丰杯赛事报名人员
	return request({
		method: 'post',
		url: '/rest/golf20/match_enroll',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_queue = (data, suc) => { //恒丰杯赛事报名阵列
	return request({
		method: 'post',
		url: '/rest/golf20/match_lattice',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_bouts = (data, suc) => { //赛事的场次
	return request({
		method: 'post',
		url: '/rest/golf20/match_bouts',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_rank = (data, suc) => { //成绩排名
	return request({
		method: 'post',
		url: '/rest/golf20/match_rank',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_notice = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/golf_notice',
		data: qs.stringify(data)
	})
};

let match_notice_info = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/golf_notice_info',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_index_score = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_index_score',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let restvideo = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf1/video',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let video_hits = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf1/video_hits',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_group_bout = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_group_bout',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let golf_team = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_team',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_lattice_group = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_lattice_group',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_team_info = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_team_info',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let match_index_score_detail = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_score_detail',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let ga_mine = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf_asso/ga_mine',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};

let restmatch_index = (data, suc) => {
	return request({
		method: 'post',
		url: '/rest/golf20/match_index',
		headers: {
			'XX-token': store.state.token
		},
		data: qs.stringify(data)
	})
};
export default {
	restmatch_index,
	ga_mine,
	match_index_score_detail,
	match_team_info,
	match_lattice_group,
	golf_team,
	match_group_bout,
	video_hits,
	restvideo,
	match_index_score,
	match_notice_info,
	match_notice,
	match_rank,
	match_bouts,
	match_queue,
	match_enroll,
	match_index,
	check_yid,
	img_hits,
	imghits,
	golf_score_check,
	golf_score_view,
	golf_match_by_user,
	golf_match_bouts,
	golf_score_rank,
	userinfo,
	live_eav,
	live_hits,
	live_like,
	eav_list,
	livelist,
	sendCode,
	userLogin,
	shareButton,
	getImgList,
	getHotImg
}
