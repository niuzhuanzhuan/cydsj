'use strict'
import Vue from 'vue'
import axios from 'axios'
import doman from './doman'
import {
	Toast,
	Dialog
} from "vant";
import bus from '@/components/bus.js'

const service = axios.create({
	baseURL: doman.URL,
	timeout: 10000, // 请求超时时间
	headers: {
		'XX-Device-Type': 'web',
		'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
	},
});

if (navigator && navigator.onLine === false) { //检查设备是否能够上网
	Toast({
		message: '当前设备网络没有连接，请检查',
		duration: 0,
		type: 'error'
	})
}


//request请求拦截器
service.interceptors.request.use(
	config => {
		bus.$emit('loading', {
			msg: true
		});
		return config
	},
	error => {
		return Promise.error(error);
	});
//响应拦截器
service.interceptors.response.use(res => {
	bus.$emit('loading', {
		msg: false
	});
	if (res.status === 200) {
		if(res.data.xcode==0){
			return Promise.resolve(res.data.data);
		}else{
			Toast(res.data.msg)
		}
	} else {
		return Promise.reject(res);
	}
}, error => {
	bus.$emit('loading', {
		msg: false
	});
	
	if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) { //超时提示
		Toast({
			message: '当前网络不是太好哦！请重新刷新页面试试！！',
		})
	}
	if(error.response){
		switch (error.response.status) {
			case 500:
				Toast('数据错误')
				break;
		}
	}
	return Promise.reject(error.response);
})


export default service
