// const path = require('path');
module.exports = {
    publicPath: '/golf/asso/',
    // publicPath: '/golf',
}