// const path = require('path');

module.exports = {
	// baseUrl: '',
	// productionSourceMap: false,
	// devServer: {
	//  host: 'localhost',
	//  port: 8080, // 端口
	// },
	// assetsPublicPath : ''
	publicPath: './',
	// configureWebpack: {
	// 	externals: {
	// 		'AMap': 'AMap' // 高德地图配置
	// 	}
	// }
}
