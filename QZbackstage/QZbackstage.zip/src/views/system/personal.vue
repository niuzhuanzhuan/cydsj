<template>
	<div class="miancont">
		<div class="fromslist">
			<div class="titles">基本信息</div>
			<el-form ref="form" label-position="top" :rules="rules" :model="form" label-width="80px">
				<el-form-item label="昵称" prop="user_nickname"><el-input v-model="form.user_nickname" style="width: 30rem;" show-word-limit maxlength="10"></el-input></el-form-item>
				<el-form-item label="手机号码" prop="mobile"><el-input v-model.number="form.mobile" style="width: 30rem;"></el-input></el-form-item>
				<el-form-item label="描述">
					<el-input type="textarea" style="width: 30rem;" v-model="form.signature" maxlength="128" :rows="4" show-word-limit></el-input>
				</el-form-item>

				<el-form-item>
					<div class="bontms"><el-button type="primary" style="width: 78px;" @click="Submit('form')">提 交</el-button></div>
				</el-form-item>
			</el-form>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import { mapActions, mapGetters } from 'vuex';
export default {
	data() {
		var validatephone = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入电话号码'));
			} else {
				if (!define.phone.test(value)) {
					callback(new Error('手机号码格式不正确请检查'));
				} else {
					callback();
				}
			}
		};
		return {
			form: {
				user_nickname:''
			},
			rules: {
				mobile: [{ required: true, validator: validatephone, trigger: 'blur' }],
				user_nickname: [{ required: true, message: '昵称不能为空', trigger: 'blur' }]
			}
		};
	},
	computed: {},
	watch: {},
	activated() {
		if (!!this.$store.state.information.user) {
			this.$set(this.form,'user_nickname',this.$store.state.information.user.user_nickname)
			this.$set(this.form,'mobile',this.$store.state.information.user.mobile)
			this.$set(this.form,'signature',this.$store.state.information.user.signature)
		}else{
			setTimeout(() => {
				if (this.$router.currentRoute.name != 'Login') {
					this.$router.push('/Login')
				}
			}, 500)
		}
	},
	methods: {
		...mapActions(['settoken']),
		Submit(form) {
			this.$refs[form].validate(async valid => {
				if (valid) {
					let datalist = await api.userinfoEdit(this.form);
					if (datalist) {
						this.settoken(datalist.data);
						this.$message.success(datalist.msg);
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>
<style scoped>
.fromslist >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.fromslist >>> .el-form-item__label::before {
	margin-left: 5px;
}
/* .miancont>>>iframe .h-page-header{
		display: none;
	} */
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs18: 18px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.bontms {
	width: 30rem;
	display: flex;
	justify-content: flex-start;
	height: 60px;
	align-items: center;
}
.miancont {
	height: inherit;
	display: flex;
	overflow-y: auto;
	width: 100%;
	display: flex;
	justify-content: center;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #2772ff;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #2772ff;
	}
	&::-webkit-scrollbar-corner {
		background: #2772ff;
	}
	.fromslist {
		.titles {
			padding-top: 30px;
			padding-bottom: 30px;
			color: @co5;
			font-size: @fs18;
			font-weight: 500;
		}
		.titlis {
			width: 30rem;
			color: #999;
			font-size: @fs14;
			line-height: 20px;
		}
	}
}
</style>
