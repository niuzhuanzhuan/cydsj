<template>
	<div class="miancont"><el-button type="success" style="width: 150px;height: 80px;font-size: 24px;" @click="getdata">查看监控</el-button></div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	data() {
		return {
			url: ''
		};
	},
	activated() {},
	methods: {
		async getdata() {
			let datalist = await api.Haikangspreview();
			if (datalist) {
				let height = document.body.clientHeight || document.documentElement.clientHeight;
				let width = document.body.clientWidth || document.documentElement.clientWidth;
				// this.url=datalist.data
				// open(datalist.data);	
				window.open(datalist.data,'', `height=${height},   width=${width} toolbar=no,   menubar=no,   scrollbars=no,   resizable=yes,   location=no,   status=yes`);
			}
		}
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
.miancont {
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
	background: url(imgae/logo.jpg) no-repeat;
	background-size: 100% 100%;
}
</style>
