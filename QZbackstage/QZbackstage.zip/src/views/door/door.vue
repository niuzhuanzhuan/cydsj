<template>
	<div class="miancont"><el-button type="success" style="width: 150px;height: 80px;font-size: 24px;" @click="getdata">查看门禁</el-button></div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	data() {
		return {
			src: ''
		};
	},
	computed: {},
	watch: {},
	activated() {},
	methods: {
		async getdata() {
			let datalist = await api.Haikangs();
			if (datalist) {
				let height = document.body.clientHeight || document.documentElement.clientHeight;
				let width = document.body.clientWidth || document.documentElement.clientWidth;
				window.open(
					datalist.data,
					'newwindow',
					`height=${height},   width=${width} toolbar=no,   menubar=no,   scrollbars=no,   resizable=yes,   location=no,   status=yes`
				);
			}
		}
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
	background: url(imgae/logo.jpg) no-repeat;
	background-size: 100% 100%;
}
</style>
