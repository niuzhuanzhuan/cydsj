<template>
	<div class="miancont">
		<div class="toplist">
			<el-row :gutter="20" style="height: 100%;">
				<el-col :span="12" style="height: 100%;">
					<el-card class="mgb20" shadow="hover"><joleft ref="joleft"/></el-card>
				</el-col>
				<el-col :span="12" style="height: 100%;"><el-card class="mgb20" shadow="hover">
				<jorigth />
				</el-card></el-col>
			</el-row>
		</div>
		<div class="tablekets">
			<tables @Refresh="Refresh"/>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
import joleft from './joleft.vue';
import jorigth from './jorigth.vue';
import tables from './tables.vue'
export default {
	data() {
		return {};
	},
	computed: {},
	mounted() {},
	components: {
		joleft,
		tables,
		jorigth
	},
	watch: {},
	created() {},
	methods: {
		Refresh(){
			this.$nextTick(()=>{
				this.$refs.joleft.getdata();
			})
		},
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.toplist >>> .el-card__body {
	padding: 0;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	width: 100%;
	height: 100%;
	overflow: hidden;
	.toplist {
		width: 96%;
		padding: 1% 2% 0 2%;
		height: 48%;
		.mgb20 {
			padding: 0;
			height: inherit;
		}
	}
	.tablekets{
		margin-top: 1%;
		width: 100%;
		height: 48%;
	}
}
</style>
