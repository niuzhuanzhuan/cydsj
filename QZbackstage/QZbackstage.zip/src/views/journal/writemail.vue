<template>
	<div class="miancont">
		<div class="miantop">
			<el-form :model="ruleForm" :rules="rules" label-position="top" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<el-form-item label="收件人" prop="username">
					<el-autocomplete v-model="ruleForm.username" clearable :fetch-suggestions="querySearch" style="width: 96%;"></el-autocomplete>
				</el-form-item>

				<el-form-item label="主题" prop="title"><el-input v-model="ruleForm.title" style="width: 96%;"></el-input></el-form-item>

				<el-form-item label="正文" prop="content"><el-input type="textarea" style="width: 96%;" rows="10" v-model="ruleForm.content"></el-input></el-form-item>
				<el-form-item>
					<template>
						<div class="bons">
							<el-button style="width: 96px;" @click="getupdate('ruleForm')">发送</el-button>
							<el-button style="width: 96px;margin-right: 4%;" @click="gobot">关闭</el-button>
						</div>
					</template>
				</el-form-item>
			</el-form>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	data() {
		let validate = (rule, value, callback) => {
			if (value == '') {
				callback(new Error('请输入访问对象'));
			} else {
				let indexof = this.list.find(item => item.user_nickname == value);
				if (!indexof) {
					callback(new Error('发送人不存在，请检查您是否输入错误'));
				} else {
					this.$set(this.ruleForm, 'id', [indexof.id]);
					callback();
				}
			}
		};
		return {
			ruleForm: {
				username: ''
			},
			rules: {
				content: [{ required: true, message: '邮件内容不能为空', trigger: 'blur' }],
				username: [{ required: true, validator: validate, trigger: 'change' }],
				title: [{ required: true, message: '请填写邮件主题', trigger: 'blur' }]
			},
			Selectdata: []
		};
	},
	computed: {},
	components: {},
	watch: {},
	deactivated() {},
	activated() {
		this.getdata();
	},
	methods: {
		async getdata() {
			let datalist = await api.message_add();
			if (datalist) {
				datalist.data.map(item => {
					this.$set(item, 'value', item.user_nickname);
				});
				this.list = datalist.data;
			}
		},
		querySearch(queryString, cb) {
			var restaurants = this.list;
			var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
			// 调用 callback 返回建议列表的数据
			cb(results);
		},
		createFilter(queryString) {
			return restaurant => {
				return restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0;
			};
		},
		getupdate(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					let listdata = await api.message_add_post(this.ruleForm);
					if (listdata) {
						for (let item in this.ruleForm) {
							this.ruleForm[item] = '';
						}
						this.$message.success(listdata.msg);
						this.$router.go(-1);
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		gobot() {
			this.$router.go(-1);
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.demo-ruleForm >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.demo-ruleForm >>> .el-form-item__label::before {
	margin-left: 5px;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.bons {
	width: 100%;
	display: flex;
	justify-content: flex-end;
	align-items: center;
	height: 100px;
}
.miancont {
	width: calc(100% - 40px);
	padding: 20px;
	height: calc(100% - 40px);
	.miantop {
		width: 100%;
		padding: 20px 25px;
		.titles {
			padding-bottom: 30px;
			color: @co5;
			font-size: @fs16;
		}
	}
}
</style>
