<template>
	<div class="litop">
		<div slot="header" class="clearfix">
			<div class="frons">
				<span>最新动态</span>
				<el-button icon="el-icon-refresh" style="float: right; padding: 3px;font-size: 16px;" type="text" @click="getdata">刷新</el-button>
			</div>
			<div class="froall">
				<div class="letopall">
					<div class="letop_letf">创建时间</div>
					<div class="letop_regith">日志内容</div>
				</div>
				<div class="alllist" v-if="datalist.length!=0">
					<div class="itemlist" v-for="(item, index) in datalist" :key="index">
						<div class="item_left">{{ item.create_time|create_time }}</div>
						<div class="cotxs">
							<div class="yuan" :style="{ background: index == 0 ? '#1E7FFF' : '#DADADA' }">
								<div class="poline"><div class="lisgf"></div></div>
							</div>
						</div>
						<div class="item_rigth">{{ item.name }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
export default {
	data() {
		return {
			datalist: []
		};
	},
	created() {
		this.getdata();
	},
	filters:{
		create_time(data){
			if(!data)return '-'
			return define.month(data)
		}
	},
	methods: {
		async getdata() {
			let datalist = await api.log_list();
			if (datalist) {
				this.datalist = datalist.data.data;
			}
		}
	}
};
</script>

<style lang="less" scoped>
.litop {
	width: 100%;
	.frons {
		padding: 10px;
		border-bottom: 1px solid #efefef;
	}
	.froall {
		width: 100%;
		height: 390px;
		.letopall {
			width: 100%;
			height: 60px;
			display: flex;
			color: #272727;
			.letop_letf {
				width: 25%;
				padding: 0 0 0 5%;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}
			.letop_regith {
				width: 60%;
				padding-left: 10%;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}
		}
		.alllist {
			width: 100%;
			font-size: 16px;
			overflow: auto;
			height: 280px;
			&::-webkit-scrollbar {
				width: 2px;
				height: 5px;
				/**/
			}
			&::-webkit-scrollbar-track {
				background: #FFFFFF;
				border-radius: 2px;
			}
			&::-webkit-scrollbar-thumb {
				background: #1e7fff;
				border-radius: 10px;
			}
			&::-webkit-scrollbar-thumb:hover {
				background: #1e7fff;
			}
			&::-webkit-scrollbar-corner {
				background: #1e7fff;
			}
			.itemlist {
				width: 100%;
				height: 40px;
				display: flex;
				&:last-child {
					.cotxs {
						.poline {
							display: none;
						}
					}
				}
				.item_left {
					padding-left: 5%;
					width: 25%;
					height: 100%;
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}
				.item_rigth {
					width: 60%;
					height: 100%;
					display: flex;
					padding-left: 5%;
					justify-content: flex-start;
					align-items: center;
				}
				.cotxs {
					width: 5%;
					height: 100%;
					display: flex;
					justify-content: center;
					align-items: center;
					position: relative;
					z-index: 1;
					.yuan {
						width: 14px;
						height: 14px;
						border-radius: 50%;
						background: #dadada;
					}
					.poline {
						position: absolute;
						top: 26px;
						width: 14px;
						height: 100%;
						display: flex;
						justify-content: center;
						.lisgf {
							width: 2px;
							height: 100%;
							background: #dadada;
						}
					}
				}
			}
		}
	}
}
</style>
