<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<div class="handle-left">
				<div class="listname"><el-input v-model="name" placeholder="请输入名称"></el-input></div>
				<div class="listname">
					<el-date-picker
						v-model="date"
						value-format="yyyy-MM-dd HH:mm:ss"
						type="datetimerange"
						range-separator="至"
						start-placeholder="开始日期"
						end-placeholder="结束日期"
					></el-date-picker>
				</div>
			</div>
			<div class="handle-regith">
				<div class="listname"><el-button style="width: 96px; background-color: #1E7FFF;" type="primary" @click="querys">查询</el-button></div>
				<div class="listname"><el-button style="width: 96px;" @click="Reset">重置</el-button></div>
				<div class="listname"><el-button style="width: 96px;" @click="exporttable">导出</el-button></div>
			</div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
					<el-table-column type='index' fixed="left" width="60" label="排序"></el-table-column>
					<el-table-column prop="nickname" label="操作人" min-width="180"></el-table-column>
					<el-table-column prop="name" label="名称" min-width="180"></el-table-column>
					<el-table-column prop="create_time" min-width="180" label="时间"></el-table-column>
					<el-table-column prop="msg" min-width="180" label="内容"></el-table-column>
					<el-table-column label="操作" min-width="180" fixed="right">
						<template slot-scope="scope" v-if="types!=2">
							<el-popover placement="top" popper-class="popper" trigger="hover" content="修改日志">
								<el-button slot="reference" icon="el-icon-edit" type="text" v-show="scope.row.id != 1" size="small" @click="updatas(scope.row)"></el-button>
							</el-popover>
							<el-popover placement="top" popper-class="popper" trigger="hover" content="删除日志">
								<el-button slot="reference" type="text" icon="el-icon-delete" v-show="scope.row.id != 1" @click="delects(scope.row)" size="small"></el-button>
							</el-popover>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" style="padding-top: 0px;" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		<dialogs :title="'修改日志'" ref="dialogs" :width="500" @Submit="Submit" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
import dialogs from './dialog.vue';
export default {
	data() {
		return {
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			name: '',
			date: [],
			types:2
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		dialogs
	},
	filters: {},
	watch: {},
	created() {
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 120;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		exporttable() {
			this.$confirm('您确定要把当前表格导出吗？', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.log_list({ name: this.name, page: this.page, start_time: this.date[0], end_time: this.date[1], pagesize: this.pagesize, excel: 1 });
					if (listdata) {
						window.location.href=listdata.data.url
					}
				})
				.catch(() => {});
		},
		Submit() {
			this.getdata();
			this.$emit('Refresh');
		},
		...mapActions(['Navtitle', 'menutitle']),
		querys() {
			this.page = 1;
			this.getdata();
		},
		Reset() {
			this.name = '';
			this.date = [];
			this.page = 1;
			this.getdata();
		},
		async getdata() {
			let listdata = await api.log_list({
				name: this.name,
				page: this.page,
				start_time: this.date[0],
				end_time: this.date[1],
				pagesize: this.pagesize
			});
			if (listdata) {
				listdata.data.data.map(item => {
					item.create_time = define.year(item.create_time);
				});
				this.tableData = listdata.data.data;
				this.types=listdata.data.type
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		updatas(data) {
			this.$nextTick(() => {
				this.$refs.dialogs.ruleForm = data;
				this.$refs.dialogs.dialogVisible = true;
			});
		},
		delects(data) {
			this.$confirm('您确定要把当前日志名为 :' + data.name + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.log_del({ id: data.id });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
						this.$emit('Refresh');
					}
				})
				.catch(() => {});
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	height: inherit;
	.mianlist {
		margin: 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		height: 70px;
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	justify-content: space-between;
	margin-top: 5px;
	.handle-left {
		display: flex;
		overflow: hidden;
		justify-content: flex-start;
		flex-wrap: wrap;
	}
	.handle-regith {
		display: flex;
		overflow: hidden;
		justify-content: flex-start;
		flex-wrap: wrap;
		padding-right: 40px;
	}
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
