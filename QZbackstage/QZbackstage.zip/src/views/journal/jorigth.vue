<template>
	<div class="litop">
		<div slot="header" class="clearfix">
			<div class="frons">
				<span>消息动态</span>
				<el-button icon="el-icon-refresh" style="float: right; padding: 3px;font-size: 16px;" type="text" @click="getdata">刷新</el-button>
			</div>
			<div class="froall">
				<div class="froleft">
					<div class="listleft" @click="choice(0)" :class="{ active: froindex == 0 }"><div class="ziji">写邮件</div></div>
					<div class="listleft" @click="choice(1)" :class="{ active: froindex == 1 }">
						<div class="ziji">
							<span>收件箱</span>
							<span>
								(
								<span style="color: #CE891A;">{{ renum }}</span>
								)
							</span>
						</div>
					</div>
					<div class="listleft" @click="choice(2)" :class="{ active: froindex == 2 }">
						<div class="ziji">
							<span>已发送</span>
							<span>
								(
								<span style="color: #69A9FF;">{{ sendkey }}</span>
								)
							</span>
						</div>
					</div>
				</div>
				<div class="froregth">
					<receipt ref="receipts" v-show="froindex == 1" @recount="recount" />
					<send ref="sends" v-show="froindex == 2" @sendss="sendss" />
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import Receipt from './Receipt.vue';
import send from './send.vue';
import { mapActions } from 'vuex';
export default {
	data() {
		return {
			datalist: [],
			froindex: 1,
			renum: 0,
			sendkey: 0
		};
	},
	created() {
		
	},
	activated() {
		sessionStorage.removeItem('titlekey');
		if(this.froindex==0){
			this.$nextTick(() => {
				this.$refs.sends.getdata();
				this.$refs.receipts.getdata();
			});
		}
	},
	components: {
		Receipt,
		send
	},
	watch: {
		froindex(newval, val) {
			if (newval != val) {
				if (newval == 1) {
					this.$nextTick(() => {
						this.$refs.receipts.getdata();
					});
				} else if (newval == 2) {
					this.$nextTick(() => {
						this.$refs.sends.getdata();
					});
				}
			}
		}
	},
	methods: {
		...mapActions(['Navtitle', 'menutitle']),
		getdata() {
			if (this.froindex == 1) {
				this.$nextTick(() => {
					this.$refs.receipts.getdata();
				});
			} else if (this.froindex == 2) {
				this.$nextTick(() => {
					this.$refs.sends.getdata();
				});
			}
		},
		recount(data) {
			this.renum = data;
		},
		sendss(data) {
			this.sendkey = data;
		},
		choice(data) {
			this.froindex = data;
			if(data==0){
				this.Navtitle('系统管理/日志管理/写邮件');
				this.$router.push('/writemail')
			}
		}
	}
};
</script>

<style lang="less" scoped>
.active {
	background: #e8f2ff;
}
.litop {
	width: 100%;
	.frons {
		padding: 10px;
		border-bottom: 1px solid #efefef;
	}
	.froall {
		width: 100%;
		height: 390px;
		display: flex;
		.froleft {
			width: 18%;
			border-right: 1px solid #efefef;
			height: 94%;
			padding: 1%;
			.listleft {
				width: 100%;
				min-height: 30px;
				display: flex;
				justify-content: center;
				align-items: center;
				cursor: pointer;
				color: #272727;
				&:hover {
					background: #e8f2ff;
				}
				.ziji {
					width: 120px;
					height: 100%;
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}
			}
		}
		.froregth {
			width: 80%;
			height: 98%;
		}
	}
}
</style>
