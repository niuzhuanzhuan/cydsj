<template>
	<div class="mianalls">
		<div class="miantop">
			<div class="todays" :key='num'>
				<div class="limts">
					<span style="margin-left: 10px;">今天</span>
					<span style="color: #ADADAD;">
						(共
						<span style="color: #EEBC84;">{{ total }}</span>
						封)
					</span>
				</div>
				<div class="festlist" v-for="(item, index) in fromdata.news" :key="index">
					<div class="lefts"><el-checkbox v-model="item.selected" @change="handleCheckedCitiesChange(item)"></el-checkbox></div>
					<div class="rights" @click="details(item)">
						<div class="minaall">
							<div class="linmhert">
								<div>{{ item.title }}</div>
								<div style="margin-right: 10px;">{{ item.create_time }}</div>
							</div>
							<div class="linmhert">
								<div class="fronst">{{ item.content }}</div>
							</div>
						</div>
					</div>
				</div>
				<div class="festlist" v-if="fromdata.news.length == 0"><div class="frmos">暂无更多数据</div></div>
			</div>
			<div class="todays">
				<div class="limts"><span style="margin-left: 10px;">更早</span></div>
				<div class="festlist" v-for="(item, index) in fromdata.ol" :key="index">
					<div class="lefts"><el-checkbox v-model="item.selected" @change="handleCheckedCitiesChange(item)"></el-checkbox></div>
					<div class="rights" @click="details(item)">
						<div class="minaall">
							<div class="linmhert">
								<div>{{ item.title }}</div>
								<div style="margin-right: 10px;">{{ item.create_time }}</div>
							</div>
							<div class="linmhert">
								<div class="fronst">{{ item.content }}</div>
							</div>
						</div>
					</div>
				</div>
				<div class="festlist" v-if="fromdata.ol.length == 0"><div class="frmos">暂无更多数据</div></div>
			</div>
		</div>
		<div class="mianbont">
			<div class="bonts"><el-button :disabled="disabled" @click="delects">删除</el-button></div>
		</div>
		<maildialog ref="maildialogs" :title="titles" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import maildialog from './maildialog.vue';
export default {
	data() {
		return {
			total: 0,
			disabled: true,
			fromdata: {
				news: [],
				ol: []
			},
			listnum: [],
			titles: '',
			num:1
		};
	},
	components: {
		maildialog
	},
	methods: {
		details(data) {
			this.$nextTick(() => {
				this.$refs.maildialogs.dialogVisible = true;
				this.$refs.maildialogs.ruleForm = data;
				this.titles = '邮件标题：' + data.title;
			});
		},
		handleCheckedCitiesChange(data) {
			if (this.listnum.findIndex(item => item === data.id) == -1) {
				this.listnum.push(data.id);
			} else {
				this.listnum.splice(this.listnum.findIndex(item => item === data.id), 1);
			}
			if (this.listnum.length > 0) {
				this.disabled = false;
			} else {
				this.disabled = true;
			}
		},
		delects() {
			this.$confirm('您确定要把当前选中的这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.message_send_del({ id: this.listnum });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.listnum=[]
						this.num+=1
						this.getdata();
					}
				})
				.catch(() => {});
		},
		async getdata() {
			let datalist = await api.message_send_list({});
			if (datalist) {
				this.$emit('sendss', datalist.data.count);
				this.fromdata = datalist.data.data;
				this.total = this.fromdata.news.length;
			}
		}
	},
	created() {
		this.getdata();
	}
};
</script>
<style scoped>
.lefts >>> .el-checkbox__inner {
	width: 16px;
	height: 16px;
}
</style>
<style lang="less" scoped>
.mianalls {
	width: 100%;
	height: 100%;
	.miantop {
		width: 100%;
		height: 80%;
		overflow: auto;
		.todays {
			width: 100%;
			.limts {
				width: 100%;
				height: 40px;
				display: flex;
				align-items: center;
			}
			.festlist {
				width: calc(100% - 10px);
				height: 60px;
				padding-left: 10px;
				display: flex;
				justify-content: flex-start;
				border-bottom: 1px solid #ededed;
				.frmos {
					width: 100%;
					height: 100%;
					display: flex;
					justify-content: center;
					align-items: center;
					color: #aaaaaa;
					font-size: 12px;
				}
				.lefts {
					width: 30px;
					height: 100%;
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}
				.rights {
					cursor: pointer;
					width: calc(100% - 40px);
					height: 100%;
					display: flex;
					justify-content: flex-start;
					.minaall {
						width: 100%;
						height: 100%;
						.linmhert {
							width: 100%;
							height: 50%;
							font-size: 12px;
							align-items: center;
							display: flex;
							justify-content: space-between;
							.fronst {
								width: 100%;
								height: 100%;
								line-height: 25px;
								color: #aaaaaa;
								overflow: hidden;
								text-overflow: ellipsis;
								white-space: nowrap;
								font-size: 12px;
							}
						}
					}
				}
			}
		}
		&::-webkit-scrollbar {
			width: 2px;
			height: 5px;
			/**/
		}
		&::-webkit-scrollbar-track {
			background: #ffffff;
			border-radius: 2px;
		}
		&::-webkit-scrollbar-thumb {
			background: #1e7fff;
			border-radius: 10px;
		}
		&::-webkit-scrollbar-thumb:hover {
			background: #1e7fff;
		}
		&::-webkit-scrollbar-corner {
			background: #1e7fff;
		}
	}
	.mianbont {
		width: 100%;
		height: 20%;
		overflow: hidden;
		background: #ffffff;
		display: flex;
		justify-content: flex-end;
		align-items: center;
		.bonts {
			margin-right: 10px;
		}
	}
}
</style>
