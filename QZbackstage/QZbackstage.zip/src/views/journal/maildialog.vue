<template>
	<div class="lindliog" v-if="dialogVisible">
		<el-dialog :title="title" :visible.sync="dialogVisible" :close-on-click-modal="false" :width="width + 'px'" :before-close="handleClose">
			<div class="miatitle">
				<div class="mianname">
					<div>{{ruleForm.no==1?'发件人':'收件人'}}：</div>
					<div>{{ruleForm.user_name}}</div>
				</div>
				<div class="mianname">
					<div>发件时间：</div>
					<div>{{ruleForm.create_time}}</div>
				</div>
				<div class="mianname">
					<div style="">内容：</div>
					<div>{{ruleForm.content}}</div>
				</div>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button @click="handleClose">关 闭</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
import define from '@/components/define/define';
import api from '@/utils/api.js';
export default {
	props: ['title', 'width'],
	data() {
		return {
			ruleForm: {},
			dialogVisible: false,
		};
	},
	methods: {
		handleClose() {
			this.dialogVisible = false;
		},
	}
};
</script>
<style scoped lang="less">
	.miatitle{
		width: 100%;
		height: auto;
		.mianname{
			width: 100%;
			min-height: 40px;
			display: flex;
			align-items: center;
		}
	}
</style>
<style scoped>
.lindliog >>> .el-form-item {
	margin-bottom: 10px;
}
.lindliog >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.lindliog >>> .el-dialog {
	margin: 0 auto 250px;
}
.lindliog >>> .el-dialog__body {
	padding: 20px;
}
.lindliog >>> .el-dialog__header {
	border-bottom: 1px solid #e3e3e3;
}
.lindliog >>> .el-dialog__title {
	font-size: 16px;
}
.lindliog >>> .el-dialog__footer {
	background: #f5f5f5;
	padding: 18px 20px 12px;
}
.lindliog >>> .el-dialog__footer .el-button {
	width: 96px;
	font-size: 16px;
}
.lindliog >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}
</style>
