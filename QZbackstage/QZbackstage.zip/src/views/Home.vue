<template>
	<div>
		<div class="home">{{ name }}</div>
		<button @click="numlins()">你好</button>
	</div>
</template>

<script>
import { reactive, toRefs } from '@vue/composition-api';
export default {
	setup() {
		const state = reactive({
			name: 1
		});
		const numlins = () => {
			return (state.name += 1);
		};
		return {
			...toRefs(state),
			numlins
		};
	}
};
</script>
