<template>
	<div class="miancont">
		<div class="miantop">
			<el-form :model="ruleForm" :rules="rules" label-position="top" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<div class="titles">基本信息</div>
				<el-form-item label="角色名称" prop="name"><el-input v-model="ruleForm.name" style="width: 38.375rem;"></el-input></el-form-item>
				<el-form-item label="角色介绍"><el-input type="textarea" style="width: 38.375rem;" rows="6" v-model="ruleForm.remark"></el-input></el-form-item>
				<el-form-item label="状态"><el-switch v-model="ruleForm.status" active-text="启用" inactive-text="禁用"></el-switch></el-form-item>
				<div class="titlestop">系统权限配置</div>
				<!-- <div class="titlekey">
					请配置当前角色<span v-if="ruleForm.name">({{ruleForm.name}})</span>在系统管理中的菜单访问权限。 <span class="fonco">
					如果需要进行二次授权时，需要勾选“角色管理”或“用户管理”的菜单权限，可选择的权限范围为此处配置的系统管理菜单权限。</span>
				</div> -->
				<div class="quantop">
					<div class="titlekey">
						请配置当前角色
						<span v-if="ruleForm.name">({{ ruleForm.name }})</span>
						在系统管理中的菜单访问权限。
						<span class="fonco">如果需要进行二次授权时，需要勾选“角色管理”或“用户管理”的菜单权限，可选择的权限范围为此处配置的系统管理菜单权限。</span>
					</div>
					<div class="treekey">
						<el-tree
							:data="constdata"
							ref="tree"
							show-checkbox
							node-key="id"
							icon-class="el-icon-arrow-right"
							:default-expanded-keys="[0]"
							:default-checked-keys="Selectdata"
							:props="defaultProps"
							@check-change="checkchange"
						></el-tree>
					</div>
				</div>
				<div style="height: 100px;"></div>
			</el-form>
		</div>
		<div class="bonslit">
			<div class="lisng">
				<el-button type="primary" style="width: 96px;" @click="getupdate('ruleForm')">确定</el-button>
				<el-button style="width: 96px;" @click="gobot">取消</el-button>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import { mapActions } from 'vuex';
export default {
	data() {
		return {
			ruleForm: {},
			rules: {
				name: [{ required: true, message: '请输入角色名称', trigger: 'blur' }]
			},
			constdata: [
				{
					id: 0,
					name: '全选',
					list: []
				}
			],
			Selectdata: [],
			defaultProps: {
				children: 'list',
				label: 'name'
			}
		};
	},
	computed: {},
	components: {},
	watch: {},
	deactivated() {
		this.ruleForm = {};
		this.$refs.tree.setCheckedKeys([]);
	},
	activated() {
		if (this.$route.query.selectid) {
			this.setdata(this.$route.query.selectid);
		}
	},
	created() {
		this.getdata();
	},
	methods: {
		async getdata() {
			let datalist = await api.authorize();
			if (datalist) {
				this.constdata[0].list = datalist.data;
			}
		},
		checkchange() {
			this.Selectdata = this.$refs.tree.getCheckedNodes().map(item => item.id);
			this.$set(this.ruleForm, 'menuId', this.Selectdata);
		},
		...mapActions(['Navtitle']),
		getupdate(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					if (this.ruleForm.status) {
						this.$set(this.ruleForm, 'status', 1);
					} else {
						this.$set(this.ruleForm, 'status', 0);
					}
					let listdata = await api.updaterole(this.ruleForm);
					if (listdata) {
						this.$message.success(listdata.msg);
						this.$router.go(-1);
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		async setdata(data) {
			let datalist = await api.selectrole({ id: data });
			if (datalist) {
				this.ruleForm = datalist.data;
				this.Selectdata=datalist.data.menuId.map(item=>parseInt(item))
				this.$set(this.ruleForm,"menuId",datalist.data.menuId)
				if (this.ruleForm.status == 1) {
					this.$set(this.ruleForm, 'status', true);
				} else {
					this.$set(this.ruleForm, 'status', false);
				}
			}
		},
		gobot() {
			this.$router.go(-1);
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.demo-ruleForm >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.demo-ruleForm >>> .el-form-item__label::before {
	margin-left: 5px;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.fonco {
	color: #2196f3;
}
.bonslit {
	width: 99%;
	height: 60px;
	position: absolute;
	bottom: 0;
	z-index: 999;
	display: flex;
	justify-content: flex-start;
	align-items: center;
	border-top: 1px solid #e0e0e0;
	background: #ffffff;
	.lisng {
		width: 614px;
		height: 100%;
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}
}
.miancont {
	width: inherit;
	padding: 20px;
	height: inherit;
	.miantop {
		width: 100%;
		padding: 20px 25px;
		.titles {
			padding-bottom: 30px;
			color: @co5;
			font-size: @fs16;
		}
		.titlestop {
			padding-top: 30px;
			padding-bottom: 10px;
			color: @co5;
			font-size: @fs16;
		}
		.titlekey {
			font-size: @fs14;
			height: 48px;
			background: #eef7fe;
			padding: 5px;
			line-height: 24px;
			display: table-cell;
		}
		.quantop {
			width: 58.875rem;
			height: 600px;
			border: 1px solid #e0e0e0;
			.treekey {
				width: 96%;
				height: 542px;
				padding: 0 2%;
			}
		}
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-bottom: 20px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
