<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<div class="listname"><el-button type="text" icon="el-icon-plus" @click="adddata">添加</el-button></div>
			<div class="listname"><el-button type="text" icon="el-icon-delete" :disabled="displays" @click="deletedata">删除</el-button></div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable" @selection-change="handleSelectionChange">
					<el-table-column type="selection" min-width="80" :selectable="checkSelectable"></el-table-column>
					<el-table-column prop="name" label="角色名称" min-width="180"></el-table-column>
					<el-table-column prop="create_time" min-width="180" label="创建时间"></el-table-column>
					<el-table-column prop="update_time" min-width="180" label="更新时间"></el-table-column>
					<el-table-column prop="remark" min-width="180" label="描述"></el-table-column>
					<el-table-column label="操作" min-width="180" fixed="right">
						<template slot-scope="scope">
							<el-popover placement="top" popper-class="popper" trigger="hover" content="修改角色">
								<el-button slot="reference" icon="el-icon-edit" type="text" v-show="scope.row.id != 1" size="small" @click="updatas(scope.row.id)"></el-button>
							</el-popover>
							<el-popover placement="top" popper-class="popper" trigger="hover" content="删除角色">
								<el-button slot="reference" type="text" icon="el-icon-delete" v-show="scope.row.id != 1" @click="delects(scope.row)" size="small"></el-button>
							</el-popover>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
export default {
	data() {
		return {
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			sum: [],
			displays: true
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination
	},
	watch: {
		sum(newval) {
			this.displays = true;
			if (newval.length > 0) {
				this.displays = false;
			}
		}
	},
	activated() {
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 150;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		...mapActions(['Navtitle', 'menutitle']),
		handleSelectionChange(data) {
			this.sum = data.map(item => item.id);
		},
		deletedata() {
			this.$confirm('您确定要把当前选中的数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.roleDelete({ id: this.sum });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		checkSelectable(row) {
			return row.id != 1;
		},
		async getdata() {
			let listdata = await api.rbacindex({
				page: this.page,
				pagesize: this.pagesize
			});
			if(listdata){
				listdata.data.data.map((item, index) => {
					item.create_time = define.timestampToTime(item.create_time);
					item.update_time = define.timestampToTime(item.update_time);
				});
				this.tableData = listdata.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		updatas(data) {
			this.Navtitle('系统管理/角色管理/修改角色');
			this.$router.push({
				path: '/role_up',
				query: {
					selectid: data
				}
			});
		},
		adddata() {
			this.Navtitle('系统管理/角色管理/添加角色');
			this.$router.push('/role_up');
		},
		delects(data) {
			this.$confirm('您确定要把当前角色名为 :' + data.name + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.roleDelete({ id: [data.id] });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	overflow: hidden;
	height: inherit;
	.mianlist {
		margin: 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-top: 5px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
