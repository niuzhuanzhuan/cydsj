<template>
	<div class="frolist">
		<div class="frolist_top">
			<el-popover ref="popover" placement="bottom-start" width="200" trigger="click">
				<div class="mianling">
					<div class="lingku">上级用户组：{{ fromdata.name }}</div>
				</div>
				<el-form :model="ruleForm" :rules="rules" ref="ruleForm" class="demo-ruleForm">
					<el-form-item prop="name"><el-input style="margin-top: 10px;" placeholder="用户组名称" v-model="ruleForm.name"></el-input></el-form-item>
					<el-form-item>
						<div style="width: 100%;display: flex;justify-content: flex-end;">
							<el-button style="width: 96px;" type="primary" @click="submitForm('ruleForm')">确定</el-button>
						</div>
					</el-form-item>
				</el-form>
			</el-popover>
			<el-popover placement="top-start" popper-class="popper" trigger="hover" content="添加用户组">
				<el-button style="font-size: 16px;" slot="reference" type="text" v-popover:popover icon="el-icon-plus"></el-button>
			</el-popover>

			<el-popover ref="updapopover" placement="bottom-start" width="200" trigger="click">
				<div class="mianling">
					<div class="lingku">上级用户组：{{ fromdata.name }}</div>
				</div>
				<el-form :model="ruleForm1" :rules="rules" ref="ruleForm1" class="demo-ruleForm">
					<el-form-item prop="name"><el-input style="margin-top: 10px;" placeholder="用户组名称" v-model="ruleForm1.name"></el-input></el-form-item>
					<el-form-item>
						<div style="width: 100%;display: flex;justify-content: flex-end;">
							<el-button style="width: 96px;" type="primary" @click="submitForm1('ruleForm1')">确定</el-button>
						</div>
					</el-form-item>
				</el-form>
			</el-popover>
			<el-popover placement="top-start" popper-class="popper" trigger="hover" content="修改用户组">
				<el-button style="font-size: 16px;" v-popover:updapopover slot="reference" type="text" icon="el-icon-edit"></el-button>
			</el-popover>

			<el-popover placement="top-start" popper-class="popper" trigger="hover" content="删除用户组">
				<el-button style="font-size: 16px;" :disabled="ruleForm1.p_id == 0" @click="organization_dels" slot="reference" type="text" icon="el-icon-delete"></el-button>
			</el-popover>

			<!-- <el-popover placement="top-start" popper-class="popper" trigger="hover" content="向上移动">
				<el-button style="font-size: 16px;" slot="reference" type="text" icon="el-icon-top"></el-button>
			</el-popover>
	
			<el-popover placement="top-start" popper-class="popper" trigger="hover" content="向下移动">
				<el-button style="font-size: 16px;" slot="reference" type="text" icon="el-icon-bottom"></el-button>
			</el-popover> -->
		</div>
		<el-input placeholder="输入关键字进行过滤" v-model="filterText" clearable></el-input>
		<el-tree
			class="filter-tree"
			:expand-on-click-node="false"
			:data="datalimt"
			:props="defaultProps"
			node-key="id"
			default-expand-all
			icon-class="el-icon-arrow-right"
			:filter-node-method="filterNode"
			ref="tree"
			:key="imlts"
			:highlight-current="true"
			@node-click="nodeclick"
			:current-node-key="indextree"
		>
			<span class="custom-tree-node" slot-scope="{ node, data }">
				<i style="font-size: 18px;" v-if="node.id == 1" class="el-icon-addeddiqiu"></i>
				<i style="font-size: 18px;" v-else class="el-icon-addedshouye"></i>
				<span style="height: inherit;margin-left: 5px;display: flex;align-items: center;">{{ node.label }}</span>
			</span>
		</el-tree>
	</div>
</template>

<script>
import define from '@/components/define/define';
import api from '@/utils/api.js';
export default {
	props: ['title', 'width'],
	data() {
		let validate = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('此项为必填项'));
			} else {
				var patrn = /[`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘'，。、]/im;
				if (patrn.test(value)) {
					callback(new Error('不允许输入特殊字符，请检查'));
				} else {
					callback();
				}
			}
		};
		return {
			filterText: '',
			imlts: 0,
			fromdata: {},
			ruleForm: {},
			ruleForm1: {},
			datalimt: [],
			indextree: 1,
			rules: {
				name: [{ validator: validate, trigger: 'blur' }]
			},
			defaultProps: {
				children: 'list',
				label: 'name'
			}
		};
	},
	activated() {
		this.getferre();
	},
	watch: {
		filterText(val) {
			this.$refs.tree.filter(val);
		}
	},
	methods: {
		filterNode(value, data) {
			if (!value) return true;
			return data.name.indexOf(value) !== -1;
		},
		nodeclick(data, val, limt) {
			this.indextree = val.key;
			this.fromdata = val.parent.data;
			this.ruleForm1 = data;
			this.$emit('setfromdata',data);
			this.$emit('setorgan_id', data.id);
		},
		async getferre() {
			let datalist = await api.Personorganization();
			if (datalist) {
				this.datalimt = datalist.data;
				if (!this.fromdata.id) {
					this.fromdata = this.datalimt[0];
					this.ruleForm1 = this.datalimt[0];
					this.$emit('setfromdata', this.datalimt[0]);
					this.$emit('setorgan_id', this.datalimt[0].id);
				} else {
					this.$emit('setfromdata', this.datalimt[0]);
					this.$emit('setorgan_id', this.datalimt[0].id);
					this.imlts += 1;
				}
			}
		},
		submitForm1(formName) {
			this.$refs[formName].validate(async valid => {
				if (valid) {
					var datalist = await api.Personorganization_submit({
						name: this.ruleForm1.name,
						p_id: this.ruleForm1.p_id,
						id: this.ruleForm1.id
					});
					if (datalist) {
						this.$message.success(datalist.msg);
						this.getferre();
						this.$refs.updapopover.showPopper = false;
					}
				} else {
					return false;
				}
			});
		},
		submitForm(formName) {
			this.$refs[formName].validate(async valid => {
				if (valid) {
					var datalist = await api.Personorganization_submit({
						name: this.ruleForm.name,
						p_id: this.ruleForm1.id
					});
					if (datalist) {
						this.ruleForm.name = '';
						this.$message.success(datalist.msg);
						this.getferre();
						this.$refs.popover.showPopper = false;
					}
				} else {
					return false;
				}
			});
		},
		organization_dels() {
			this.$confirm(`此操作将同时删除用户组下的所有用户及用户组。确定删除用户组 ${this.ruleForm1.name} ?`, '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.Personorganization_del({ id: this.ruleForm1.id });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getferre();
						this.indextree = 1;
						this.fromdata = this.datalimt[0];
						this.ruleForm1 = this.datalimt[0];
						this.$emit('setfromdata', this.datalimt[0]);
						this.$emit('setorgan_id', this.datalimt[0].id);
					}
				})
				.catch(() => {});
		}
	}
};
</script>

<style scoped lang="less">
.custom-tree-node {
	display: flex;
}
.filter-tree {
	margin-top: 10px;
}
.frolist {
	width: 100%;
	height: 100%;
	.frolist_top {
		width: 100%;
		height: 35px;
		display: flex;
	}
}
</style>
