<template>
	<div class="mins">
		<el-form ref="form" label-position="top" :inline="true" :model="form" label-width="80px">
			<div class="itlim">
				<el-form-item label="姓名"><el-input style="width: 100%;" clearable v-model="form.personName"></el-input></el-form-item>
			</div>
			<div class="itlim">
				<el-form-item label="性别">
					<el-select v-model="form.gender" style="width: 100%;" clearable placeholder="请选择性别">
						<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
					</el-select>
				</el-form-item>
			</div>
			<div class="itlim">
				<el-form-item label="手机号"><el-input style="width: 100%;" clearable v-model.number="form.phoneNo" placeholder="请输入手机号码"></el-input></el-form-item>
			</div>
			<div class="itlim" v-if="rotate != 90">
				<el-form-item label="工作单位">
					<el-select v-model="form.company" style="width: 100%;" filterable  clearable placeholder="请选择工作单位">
						<el-option v-for="(item, index) in company" :key="item.index" :label="item.name" :value="item.name"></el-option>
					</el-select>
				</el-form-item>
			</div>
			<div class="itlim" v-if="rotate != 90">
				<el-form-item label="人员身份">
					<el-select v-model="form.identityType" style="width: 100%;" filterable  clearable placeholder="请选择人员身份">
						<el-option v-for="(item, index) in personnel" :key="item.index" :label="item.name" :value="item.name"></el-option>
					</el-select>
				</el-form-item>
			</div>
			<div class="itlim" v-if="rotate != 90">
				<el-form-item label="所在运动队">
					<el-select v-model="form.jobPost" style="width: 100%;" filterable  clearable placeholder="请选择所在运动队">
						<el-option v-for="(item, index) in motion" :key="item.index" :label="item.name" :value="item.name"></el-option>
					</el-select>
				</el-form-item>
			</div>
			<div class="itlim" v-if="rotate != 90">
				<el-form-item label="审核状态">
					<el-select v-model="form.status" style="width: 100%;" filterable  clearable placeholder="请选择审核状态">
						<el-option   label="未通过" value="0"></el-option>
						<el-option label="未审核" value="1"></el-option>
						<el-option  label="通过" value="2"></el-option>
					</el-select>
				</el-form-item>
			</div>
			<div class="itlim" :style="{ width: rotate == 90 ? '25%' : '25%' }">
				<el-form-item>
					<div class="bonnoe">
						<el-button type="primary" style="width: 78px;background-color: #1E7FFF;" @click="queryfrom">查询</el-button>
						<el-button style="width: 78px;" @click="Reset">重置</el-button>
						<el-button style="width: 78px;" @click="exporttable">导出</el-button>
						<div class="lifroms" @click="setup"><i class="el-icon-d-arrow-left" v-if="displays" :style="{ transform: 'rotate(' + rotate + 'deg)' }"></i></div>
					</div>
				</el-form-item>
			</div>
		</el-form>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	data() {
		return {
			form: {
				personName: '',
				gender: '',
				phoneNo: '',
				company: '',
				identityType: '',
				jobPost: ''
			},
			company: [],
			personnel: [],
			motion: [],
			options: [
				{
					value: '1',
					label: '男'
				},
				{
					value: '2',
					label: '女'
				},
				{
					value: '0',
					label: '保密'
				}
			],
			rotate: 90
		};
	},
	computed: {
		displays() {
			if (Object.keys(this.form).length <= 3) {
				return false;
			}
			return true;
		}
	},
	created() {
		this.getdata();
	},
	methods: {
		exporttable(){
			this.$emit("exporttable",this.form)
		},
		async getdata() {
			let datalist = await api.dictindex();
			if (datalist) {
				datalist.data.data.map(item => {
					if (item.type === 1) {
						this.company.push(item);
					} else if (item.type === 2) {
						this.personnel.push(item);
					} else {
						this.motion.push(item);
					}
				});
			}
		},
		setup() {
			if (this.rotate === 90) {
				this.rotate = 270;
			} else {
				this.rotate = 90;
			}
		},
		Reset() {
			for (let item in this.form) {
				this.form[item] = '';
			}
			this.$emit('queryfrom', this.form);
		},
		queryfrom() {
			this.$emit('queryfrom', this.form);
		}
	}
};
</script>
<style>
.mins > .el-form {
	width: 100%;
	display: flex;
	flex-wrap: wrap;
}
.mins > .el-form .el-form-item {
	width: 100%;
	margin-bottom: 5px;
	padding: 0 0 0 12px;
}
.mins > .el-form .el-form-item .el-form-item__label {
	padding: 0;
	line-height: 24px;
}
</style>

<style lang="less" scoped>
.lifroms {
	width: 30px;
	height: 32px;
	display: flex;
	justify-content: center;
	align-items: center;
	cursor: pointer;
	&:active {
		color: #1e7fff;
	}
}
.mins {
	width: 100%;
	display: flex;
	.itlim {
		width: 25%;
		display: flex;
		justify-content: flex-end;
	}
}
.bonnoe {
	width: 100%;
	height: 57px;
	display: flex;
	justify-content: flex-end;
	align-items: flex-end;
}
</style>
