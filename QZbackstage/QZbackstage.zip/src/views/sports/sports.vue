<template>
	<div class="contex">
		<div class="miancont" ref="miancont">
			<div class="handle-box">
				<div class="listname"><el-button type="text" icon="el-icon-plus" @click="adddata">添加运动队</el-button></div>
			</div>
			<div class="mianlist">
				<template>
					<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
						<el-table-column type='index' fixed="left" width="60" label="排序"></el-table-column>
						<el-table-column prop="name" min-width="100" label="运动队名称"></el-table-column>
						<el-table-column label="操作" width="150" fixed="right">
							<template slot-scope="scope">
								<el-popover placement="top" popper-class="popper" trigger="hover" content="修改运动队">
									<el-button slot="reference" icon="el-icon-edit" type="text" v-show="scope.row.id != 1" size="small" @click="updatas(scope.row)"></el-button>
								</el-popover>
								<el-popover placement="top" popper-class="popper" trigger="hover" content="删除运动队">
									<el-button slot="reference" type="text" icon="el-icon-delete" v-show="scope.row.id != 1" @click="delects(scope.row)" size="small"></el-button>
								</el-popover>
							</template>
						</el-table-column>
					</el-table>
				</template>
			</div>
			<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		</div>
		<dialogs ref="dialogs" :title="title" :width="390" @Submit="Submit" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
import dialogs from './dialog.vue';
export default {
	data() {
		return {
			title: '',
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: []
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		dialogs
	},
	watch: {},
	activated() {
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 120;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		Submit() {
			this.getdata();
		},
		...mapActions(['Navtitle', 'menutitle', 'gettitles']),
		async getdata() {
			let listdata = await api.dictindex({
				type: 3,
				page: this.page,
				pagesize: this.pagesize
			});
			if (listdata) {
				this.tableData = listdata.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		updatas(data) {
			this.$nextTick(() => {
				this.title = '修改运动队';
				this.$refs.dialogs.ruleForm = data;
				this.$refs.dialogs.dialogVisible = true;
			});
		},
		adddata() {
			this.$nextTick(() => {
				this.title = '添加运动队';
				this.$refs.dialogs.ruleForm.type = 3;
				this.$refs.dialogs.dialogVisible = true;
			});
		},
		delects(data) {
			this.$confirm('您确定要把当前运动队名称为 :' + data.name + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.dictdel({ id: data.id });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.filter-tree {
	margin-top: 10px;
}
.miansli {
	width: 100%;
	height: 100%;
}
.demo-ruleForm >>> {
}
.h-page-header {
	display: none !important;
}
.custom-tree-node {
	display: flex;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.mianling {
	width: 100%;
	height: auto;
	.lingku {
		color: #999999;
	}
}
.contex {
	width: 100%;
	height: inherit;
	position: relative;
}

.miancont {
	width: 100%;
	height: inherit;
	position: relative;
	.mianlist {
		margin: 2px 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		background: #ffffff;
		border-top: 1px solid #e3e3e3;
		position: absolute;
		z-index: 999;
		bottom: 0;
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname1 {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
}
.lisfenge {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
}
</style>
