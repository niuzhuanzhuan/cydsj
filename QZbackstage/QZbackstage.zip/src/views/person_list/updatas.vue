<template>
	<div class="miancont">
		<div class="miantop">
			<div class="fomnsli">
				<div class="titles">人员基本信息</div>
				<el-form :model="ruleForm" :rules="rules" label-position="top" ref="ruleForm" label-width="100px" class="demo-ruleForm">
					<el-form-item label="姓名" prop="personName"><el-input v-model="ruleForm.personName" placeholder="请输入姓名" style="width: 30rem;"></el-input></el-form-item>
					<el-form-item label="性别" prop="gender">
						<el-select v-model="ruleForm.gender" style="width: 30rem;" clearable placeholder="请选择性别">
							<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
						</el-select>
					</el-form-item>
					<el-form-item label="手机号码" prop="phoneNo"><el-input v-model.number="ruleForm.phoneNo" style="width: 30rem;"></el-input></el-form-item>
					<el-form-item label="工作单位">
						<el-select v-model="ruleForm.company" style="width: 30rem;" filterable clearable placeholder="请选择工作单位">
							<el-option v-for="(item, index) in company" :key="item.index" :label="item.name" :value="item.name"></el-option>
						</el-select>
					</el-form-item>
					<el-form-item label="人员身份">
						<el-select v-model="ruleForm.identityType" style="width: 30rem;" filterable clearable placeholder="请选择人员身份">
							<el-option v-for="(item, index) in personnel" :key="item.index" :label="item.name" :value="item.name"></el-option>
						</el-select>
					</el-form-item>
					<el-form-item label="所在运动队">
						<el-select v-model="ruleForm.jobPost" style="width: 30rem;" filterable clearable placeholder="请选择所在运动队">
							<el-option v-for="(item, index) in motion" :key="item.index" :label="item.name" :value="item.name"></el-option>
						</el-select>
					</el-form-item>
					<div class="titles">正面免冠照</div>
					<el-form-item>
						<el-upload class="avatar-uploader" action="" accept="image/jpeg" :show-file-list="false" :on-change="changeFile">
							<img v-if="ruleForm.imageUrl" :src="ruleForm.imageUrl" class="avatar" />
							<i v-else class="el-icon-plus avatar-uploader-icon"></i>
							<div slot="tip" class="el-upload__tip">请上传或采集正面免冠照，露出眼睛和眉毛；</div>
							<div slot="tip" class="el-upload__tip">图片文件支持.jpg 格式；</div>
							<div slot="tip" class="el-upload__tip">图片文件大小10 KB~200 KB。</div>
						</el-upload>
					</el-form-item>
				</el-form>
				<div style="height: 100px;"></div>
			</div>
		</div>
		<div class="bonslit">
			<div class="lisng">
				<el-button type="primary" style="width: 96px;background: #1E7FFF;" @click="getupdate('ruleForm')">确定</el-button>
				<el-button style="width: 96px;" @click="gobot">取消</el-button>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import { mapActions } from 'vuex';
import { URL } from '@/utils/doman';
export default {
	data() {
		var validatephone = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入电话号码'));
			} else {
				if (!define.phone.test(value)) {
					callback(new Error('手机号码格式不正确请检查'));
				} else {
					callback();
				}
			}
		};
		return {
			company: [],
			personnel: [],
			motion: [],
			imlit: 0,
			options: [
				{
					value: '1',
					label: '男'
				},
				{
					value: '2',
					label: '女'
				},
				{
					value: '0',
					label: '保密'
				}
			],
			ruleForm: {
				imageUrl: '',
				face: ''
			},
			rules: {
				phoneNo: [{ required: true, validator: validatephone, trigger: 'blur' }],
				gender: [{ required: true, message: '请选择性别', trigger: 'blur' }],
				personName: [{ required: true, message: '请输入姓名', trigger: 'blur' }]
			}
		};
	},
	computed: {},
	components: {},
	watch: {},
	deactivated() {
		for (let item in this.ruleForm) {
			this.ruleForm[item] = '';
		}
	},
	activated() {
		this.$set(this.ruleForm, 'organization_id', this.$store.state.titlekeys.id);
		if (this.$route.query.selectid) {
			this.setdata(this.$route.query.selectid);
		}
	},
	created() {
		this.limtdata();
	},
	methods: {
		async limtdata() {
			let datalist = await api.dictindex();
			if (datalist) {
				datalist.data.data.map(item => {
					if (item.type === 1) {
						this.company.push(item);
					} else if (item.type === 2) {
						this.personnel.push(item);
					} else {
						this.motion.push(item);
					}
				});
			}
		},
		changeFile(f) {
			if (f.raw.type != 'image/jpeg') {
				this.$message.error('图片文件仅支持.jpg 格式');
				return false;
			}
			let that = this;
			let reader = new FileReader();
			reader.readAsDataURL(f.raw);
			reader.onload = function() {
				if (that.showSize(this.result) > 200) {
					that.$message.error('图片文件大小10 KB~200 KB,当前图片太大了');
				} else {
					that.ruleForm.imageUrl = this.result;
					that.ruleForm.face = this.result.replace('data:image/jpeg;base64,', '');
				}
			};
		},
		showSize(base64url) {
			//获取base64图片大小，返回KB数字
			var str = base64url.replace('data:image/jpeg;base64,', '');
			var equalIndex = str.indexOf('=');
			if (str.indexOf('=') > 0) {
				str = str.substring(0, equalIndex);
			}
			var strLength = str.length;
			var fileLength = parseInt(strLength - (strLength / 8) * 2);
			// 由字节转换为KB
			var size = '';
			size = (fileLength / 1024).toFixed(2);
			var sizeStr = size + ''; //转成字符串
			var index = sizeStr.indexOf('.'); //获取小数点处的索引
			var dou = sizeStr.substr(index + 1, 2); //获取小数点后两位的值
			if (dou == '00') {
				//判断后两位是否为00，如果是则删除00
				return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
			}
			return parseInt(size);
		},
		...mapActions(['Navtitle']),
		getupdate(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					this.ruleForm.imageUrl = '';
					let datalist = await api.Personsubmit(this.ruleForm);
					if (datalist) {
						this.$message.success(datalist.msg);
						this.$router.go(-1);
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		async setdata(data) {
			let listdata = await api.Personoperation({ id: data });
			if (listdata) {
				this.ruleForm = listdata.data;
				this.$set(this.ruleForm, 'imageUrl', listdata.data.faceUrl);
				this.$set(this.ruleForm, 'role_id', listdata.data.role_ids);
			}
		},
		gobot() {
			this.$router.go(-1);
		}
	}
};
</script>
<style>
.avatar-uploader .el-upload {
	width: 195px;
	height: 260px;
	border: 1px dashed #d9d9d9;
	border-radius: 6px;
	cursor: pointer;
	position: relative;
	overflow: hidden;
}
.avatar-uploader .el-upload:hover {
	border-color: #409eff;
}
.avatar-uploader-icon {
	font-size: 28px;
	color: #8c939d;
	width: 195px;
	height: 260px;
	line-height: 260px;
	text-align: center;
}
.avatar {
	width: 195px;
	height: 260px;
	display: block;
}
</style>
<style scoped>
@import url('../../assets/css/tables.css');
.demo-ruleForm >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.demo-ruleForm >>> .el-form-item__label::before {
	margin-left: 5px;
}
.el-upload__tip {
	margin: 0;
	height: 20px !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	width: 98%;
	padding: 20px 1%;
	height: inherit;
	.miantop {
		width: 98%;
		padding: 20px 1%;
		display: flex;
		justify-content: flex-start;
		.fomnsli {
			width: 960px;
			overflow: auto;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: flex-start;
			.titles {
				width: 614px;
				padding-bottom: 30px;
				color: @co5;
				font-size: @fs16;
			}
		}
	}
	.bonslit {
		width: 99%;
		height: 60px;
		position: absolute;
		bottom: 0;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		border-top: 1px solid #e0e0e0;
		background: #ffffff;
		.lisng {
			width: 614px;
			height: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
		}
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-bottom: 20px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
