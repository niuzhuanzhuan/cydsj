<template>
	<div class="contex">
		<div class="contex_left"><trees @setorgan_id="setorgan_id" @setfromdata="setfromdata" /></div>
		<div class="miancont" ref="miancont">
			<div class="top_mian"><search ref='search' @queryfrom="queryfrom" @exporttable="exporttable" /></div>
			<div class="handle-box">
				<div class="listname"><el-button type="text" icon="el-icon-upload" @click="Importtable">导入</el-button></div>
				<div class="lisfenge"><el-divider direction="vertical"></el-divider></div>
				<div class="listname"><el-button type="text" icon="el-icon-plus" @click="adddata">添加</el-button></div>
				<div class="listname"><el-button type="text" icon="el-icon-delete" :disabled="displays" @click="deletedata">删除</el-button></div>
				<div class="lisfenge"><el-divider direction="vertical"></el-divider></div>
			</div>
			<div class="mianlist">
				<template>
					<el-table :data="tableData" stripe :height="heights" ref="multipleTable" @selection-change="handleSelectionChange">
						<el-table-column type="selection" min-width="80" :selectable="checkSelectable"></el-table-column>
						<el-table-column prop="personName" min-width="100" label="姓名"></el-table-column>
						<el-table-column prop="gender" min-width="100" label="性别">
							<template slot-scope="scope">
								{{ scope.row.gender == 1 ? '男' : scope.row.gender == 2 ? '女' : '保密' }}
							</template>
						</el-table-column>
						<el-table-column prop="organization_name" min-width="100" label="所属组织"></el-table-column>
						<!-- <el-table-column prop="jobNo" min-width="100" label="工号"></el-table-column> -->
						<el-table-column prop="phoneNo" min-width="100" label="手机号码"></el-table-column>
						<el-table-column prop="company" min-width="100" label="工作单位"></el-table-column>
						<el-table-column prop="identityType" min-width="100" label="身份类型"></el-table-column>
						<el-table-column prop="status" min-width="100" label="审核状态">
							<template slot-scope="scope">
								<el-tag type="success" v-if="scope.row.status == 2">通过</el-tag>
								<el-tag v-if="scope.row.status == 1">未审核</el-tag>
								<el-tag type="info" v-if="scope.row.status == 0">未通过</el-tag>
							</template>
						</el-table-column>
						<el-table-column prop="memo" min-width="100" label="未通过原因"></el-table-column>
						<el-table-column label="操作" min-width="100" fixed="right">
							<template slot-scope="scope">
								<el-popover placement="top" popper-class="popper" trigger="hover" content="修改人员信息">
									<el-button slot="reference" icon="el-icon-edit" type="text" size="small" @click="updatas(scope.row.id)"></el-button>
								</el-popover>
								<el-popover placement="top" popper-class="popper" trigger="hover" content="删除人员信息">
									<el-button slot="reference" type="text" icon="el-icon-delete" @click="delects(scope.row)" size="small"></el-button>
								</el-popover>
							</template>
						</el-table-column>
					</el-table>
				</template>
			</div>
			<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		</div>
		<dialogs ref="dialogs" :title="title" :width="600" @Submits="Submits" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import search from './search.vue';
import trees from './trees.vue';
import dialogs from './dialog.vue';
export default {
	data() {
		return {
			displayslimt: false,
			display: false,
			keylimg: 0,
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			sum: [],
			displays: true,
			organ_id: null,
			fromdata: {},
			limi: 0,
			title: '',
			froms:{}
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		search,
		trees,
		dialogs
	},
	watch: {
		sum(newval) {
			this.displays = true;
			if (newval.length > 0) {
				this.displays = false;
			}
		},
		organ_id(newval, val) {
			if (newval != val) {
				this.getdata();
			}
		}
	},
	deactivated() {
		this.limi = 1;
	},
	activated() {
		if (this.limi == 1) {
			this.getdata();
		}
		sessionStorage.removeItem('titlekey');
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 200;
			this.heights = scrollHeight;
		});
	},
	methods: {
		Importtable() {
			this.title = '导入表格';
			this.$refs.dialogs.dialogVisible = true;
		},
		Submits() {
			this.getdata();
		},
		exporttable(data) {
			let { company, gender, identityType, jobPost, personName, phoneNo, status } = data;
			this.$confirm('您确定要把当前表格导出吗？', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.Personindex({
						organization_id: this.organ_id,
						page: this.page,
						pagesize: this.pagesize,
						personName: personName,
						phoneNo: phoneNo,
						gender: gender,
						company: company,
						identityType: identityType,
						jobPost: jobPost,
						excel: 1,
						status: status
					});
					if (listdata) {
						window.location.href = listdata.data.url;
					}
				})
				.catch(() => {});
		},
		setorgan_id(data) {
			this.organ_id = data;
		},
		setfromdata(data) {
			this.fromdata = data;
		},
		Submit() {
			this.getferre();
		},
		queryfrom(data) {
			let { company, gender, identityType, jobPost, personName, phoneNo, status } = data;
			this.froms=data
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata(company, gender, identityType, jobPost, personName, phoneNo, status);
		},
		...mapActions(['Navtitle', 'menutitle', 'gettitles']),
		handleSelectionChange(data) {
			this.sum = data.map(item => item.id);
		},
		deletedata() {
			this.$confirm('您确定要把当前选中的数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.Personperson_del({ id: this.sum });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		checkSelectable(row) {
			return row.id != 1;
		},
		async getdata(company = '', gender = '', identityType = '', jobPost = '', personName = '', phoneNo = '', status = '') {
			let listdata = await api.Personindex({
				organization_id: this.organ_id,
				page: this.page,
				pagesize: this.pagesize,
				personName: personName,
				phoneNo: phoneNo,
				gender: gender,
				company: company,
				identityType: identityType,
				jobPost: jobPost,
				status: status
			});
			if (listdata) {
				this.limi = 0;
				this.tableData = listdata.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.$nextTick(()=>{
				this.pagesize = data;
				let { company, gender, identityType, jobPost, personName, phoneNo, status } = this.$refs.search.form
				this.getdata(company, gender, identityType, jobPost, personName, phoneNo, status);
			})
		},
		handleCurrentChange(data) {
			this.$nextTick(()=>{
				this.page = data;
				let { company, gender, identityType, jobPost, personName, phoneNo, status } = this.$refs.search.form
				this.getdata(company, gender, identityType, jobPost, personName, phoneNo, status);
			})
		},
		updatas(data) {
			this.limi = 1;
			this.$set(this.fromdata, 'titlein', '目标用户组');
			this.gettitles(this.fromdata);
			this.Navtitle('人员管理/基本信息/修改人员信息');
			this.$router.push({
				path: '/person_up',
				query: {
					selectid: data
				}
			});
		},
		adddata() {
			this.limi = 1;
			this.$set(this.fromdata, 'titlein', '目标用户组');
			this.gettitles(this.fromdata);
			this.Navtitle('人员管理/基本信息/添加人员信息');
			this.$router.push('/person_up');
		},
		delects(data) {
			this.$confirm('您确定要把当前名称为 :' + data.personName + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.Personperson_del({ id: [data.id] });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.mianling {
	width: 100%;
	height: auto;
	.lingku {
		color: #999999;
	}
}
.contex {
	width: 100%;
	height: inherit;
	position: relative;
	overflow: hidden;
	.contex_left {
		position: absolute;
		left: 0;
		top: -6px;
		width: 224px;
		height: 100%;
		border-right: 1px solid #e0e0e0;
		padding: 0 12px;
	}
}

.miancont {
	width: calc(100%-250px);
	margin-left: 250px;
	height: inherit;
	position: relative;
	.top_mian {
		width: 100%;
		margin-top: 5px;
		min-height: 72px;
		max-height: 144px;
	}
	.mianlist {
		margin: 2px 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		background: #ffffff;
		position: absolute;
		z-index: 999;
		bottom: 0;
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	border-top: 1px solid #e3e3e3;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname1 {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
}
.lisfenge {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
}
</style>
