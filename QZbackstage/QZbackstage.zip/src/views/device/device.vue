<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<div class="listname"><el-button style="width: 78px;" @click="adddata">添加设备</el-button></div>
			<div class="listname1">
				<el-select v-model="status" style="width: 18rem;margin-right: 10px;" filterable  clearable placeholder="请选择设备状态">
					<el-option label="正常" value="1"></el-option>
					<el-option  label="故障" value="2"></el-option>
				</el-select>
				
				<el-input placeholder="输入名称" style="width: 18rem;margin-right: 10px;" v-model="name"></el-input>
				<el-button type="primary" style="width: 78px;background-color: #1E7FFF;" @click="queryfrom">查询</el-button>
				<el-button style="width: 78px;" @click="Reset">重置</el-button>
				<el-button style="width: 78px;" @click="exporttable">导出</el-button>
				<el-button style="width: 78px;" @click="Importtable">导入</el-button>
			</div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
					<el-table-column type='index' fixed="left" width="60" label="排序"></el-table-column>
					<el-table-column prop="name" min-width="100" label="名称"></el-table-column>
					<el-table-column prop="manufacturer" min-width="100" label="厂商"></el-table-column>
					<el-table-column prop="model" min-width="100" label="型号"></el-table-column>
					<el-table-column prop="total" min-width="100" label="总数"></el-table-column>
					<el-table-column prop="good" min-width="120" label="正常使用数量"></el-table-column>
					<el-table-column prop="status" min-width="100" label="状态">
						<template slot-scope="scope">
							<el-tag type="success" v-if="scope.row.status == 1">正常</el-tag>
							<el-tag type="info" v-else>故障</el-tag>
						</template>
					</el-table-column>
					<el-table-column prop="add_time" min-width="140" label="添加时间">
						<template slot-scope="scope">
							<el-tag type="success" v-if="scope.row.add_time">{{ scope.row.add_time }}</el-tag>
						</template>
					</el-table-column>
					<el-table-column label="操作" fixed="right" min-width="100">
						<template slot-scope="scope">
							<el-popover placement="top" popper-class="popper" trigger="hover" content="修改设备信息">
								<el-button slot="reference" icon="el-icon-edit" type="text" size="small" @click="updatas(scope.row.id)"></el-button>
							</el-popover>
							<el-popover placement="top" popper-class="popper" trigger="hover" content="申领设备">
								<el-button slot="reference" icon="el-icon-view" type="text" size="small" @click="applyrecord(scope.row)"></el-button>
							</el-popover>
							<el-popover placement="top" popper-class="popper" trigger="hover" content="删除设备">
								<el-button slot="reference" type="text" icon="el-icon-delete" @click="delects(scope.row)" size="small"></el-button>
							</el-popover>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		<dialogkey ref="dialogs" :title="title" :width="600" @Submits="Submits"/>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
import dialogkey from './dialogkey.vue'
export default {
	data() {
		return {
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			name: '',
			status:'',
			title:''
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		dialogkey
	},
	watch: {
		sid(news, val) {
			if (news != val) {
				this.setTropsteam();
			}
		}
	},
	activated() {
		sessionStorage.removeItem('titlekey');
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 150;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		Importtable() {
			this.title = '导入表格';
			this.$refs.dialogs.dialogVisible = true;
		},
		Submits(){
			this.getdata()
		},
		updatas(data) {
			this.Navtitle('智能训练/智能设备管理/修改设备');
			this.$router.push({
				path: '/device_up',
				query: {
					selectid: data
				}
			});
		},
		applyrecord(data) {
			this.Navtitle('智能训练/智能设备管理/' + data.name + '申领记录');
			this.$router.push({
				path: '/applyrecord',
				query: {
					selectid: data.id
				}
			});
		},
		delects(data) {
			this.$confirm('您确定要把当前设备名称为 :' + data.name + '  这条数据删除吗? 如果删除这条数据的申领数据也即将被删除，是否继续操作？', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.Devicedel({ id: data.id });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		...mapActions(['Navtitle', 'menutitle']),
		adddata() {
			this.Navtitle('智能训练/智能设备管理/添加设备');
			this.$router.push('/device_up');
		},
		queryfrom() {
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		Reset() {
			this.name = '';
			this.status = '';
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		async getdata() {
			let listdata = await api.Deviceindex({
				page: this.page,
				pagesize: this.pagesize,
				name: this.name,
				status:this.status
			});
			if (listdata) {
				this.tableData = listdata.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		exporttable() {
			this.$confirm('您确定要把当前表格导出吗？', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.Deviceindex({ page: this.page, pagesize: this.pagesize, excel: 1, name: this.name });
					if (listdata) {
						window.location.href=listdata.data.url
					}
				})
				.catch(() => {});
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	height: inherit;
	overflow: hidden;
	.mianlist {
		margin: 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: space-between;
	flex-wrap: wrap;
	width: 100%;
}
.listname {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;
	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname1 {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-right: 0.8rem;
	margin-left: 0.8rem;
	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
