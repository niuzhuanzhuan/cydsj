<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<div class="listname"><el-button style="width: 78px;" @click="adddata">申领设备</el-button></div>
			<div class="listname1">
				<el-input placeholder="申领人姓名查询" style="width: 18rem;margin-right: 10px;" suffix-icon="el-icon-search" v-model="apply_name"></el-input>
				<el-button type="primary" style="width: 78px;background-color: #1E7FFF;" @click="queryfrom">查询</el-button>
				<el-button style="width: 78px;" @click="Reset">重置</el-button>
			</div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
					<el-table-column type='index' fixed="left" width="60" label="排序"></el-table-column>
					<el-table-column prop="name" min-width="100" label="申领设备"></el-table-column>
					<el-table-column prop="manufacturer" min-width="100" label="设备厂商"></el-table-column>
					<el-table-column prop="model" min-width="100" label="设备型号"></el-table-column>
					<el-table-column prop="apply_name" min-width="80" label="申领人"></el-table-column>
					<el-table-column prop="apply_card" min-width="100" label="申领人证件"></el-table-column>
					<el-table-column prop="apply_phone" min-width="110" label="申领人电话"></el-table-column>
					<el-table-column prop="reason" min-width="100" label="申领事由"></el-table-column>
					<el-table-column prop="count" min-width="90" label="申领数量"></el-table-column>
					<!-- <el-table-column prop="end_count" min-width="90" label="归还数量"></el-table-column> -->
					<el-table-column prop="status" min-width="70" label="状态">
						<template slot-scope="scope">
							<el-tag type="success" v-if="scope.row.status == 1">申领</el-tag>
							<el-tag v-else>归还</el-tag>
						</template>
					</el-table-column>
					<el-table-column prop="create_time" min-width="150" label="申领时间">
						<template slot-scope="scope">
							<el-tag type="success" v-if="scope.row.create_time">{{ scope.row.create_time }}</el-tag>
						</template>
					</el-table-column>
					<el-table-column prop="update_time" min-width="150" label="归还时间">
						<template slot-scope="scope">
							<el-tag v-if="scope.row.update_time">{{ scope.row.update_time }}</el-tag>
							<el-tag type="warning" v-else>暂未归还</el-tag>
						</template>
					</el-table-column>
					<el-table-column prop="memo" min-width="120" label="备注"></el-table-column>
					<el-table-column label="操作" fixed="right" min-width="80">
						<template slot-scope="scope">
							<el-popover placement="top" popper-class="popper" trigger="hover" content="归还">
								<el-button v-if="scope.row.status == 1" slot="reference" icon="el-icon-s-claim" style="font-size: 16px;" type="text" size="small" @click="revert(scope.row.id)"></el-button>
							</el-popover>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		<dialogs ref="dialogskey" :title="title" :surplus="surplus" :width="700" @Submit="Submit" />
		<revertdialog ref="revertdialogs" :title="'归还设备'" :width="500" @revertkey="revertkey" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import dialogs from './dialog.vue';
import revertdialog from './revertdialog.vue';
export default {
	data() {
		return {
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			apply_name: '',
			device_id: null,
			title: '',
			surplus: 0
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		dialogs,
		revertdialog
	},
	watch: {},
	activated() {
		this.$nextTick(() => {
			if (this.$route.query.selectid) {
				this.device_id = this.$route.query.selectid;
				let scrollHeight = this.$refs.miancont.scrollHeight - 150;
				this.heights = scrollHeight;
				this.getdata();
			} else {
				this.$message.error('非法操作');
				this.$router.go(-1);
			}
		});
	},
	methods: {
		revert(data) {
			this.$nextTick(()=>{
				this.$refs.revertdialogs.dialogVisible = true;
				this.$set(this.$refs.revertdialogs.ruleForm, 'id', data);
			})
		},
		...mapActions(['Navtitle', 'menutitle']),
		Submit() {
			this.getdata();
		},
		revertkey(){
			this.getdata();
		},
		adddata() {
			this.$nextTick(() => {
				this.title = this.$store.state.Navigation[2].substring(0, this.$store.state.Navigation[2].length - 2) + '剩余数量：' + this.surplus;
				this.$refs.dialogskey.dialogVisible = true;
				this.$set(this.$refs.dialogskey.ruleForm, 'device_id', this.device_id);
			});
		},
		queryfrom() {
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		Reset() {
			this.apply_name = '';
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		async getdata() {
			let listdata = await api.Deviceapply_list({
				device_id: this.device_id,
				page: this.page,
				pagesize: this.pagesize,
				apply_name: this.apply_name
			});
			if(listdata){
				this.tableData = listdata.data.data;
				this.surplus = listdata.data.surplus;
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	height: 98%;
	.mianlist {
		margin: 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: space-between;
	flex-wrap: wrap;
	width: 100%;
}
.listname {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;
	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname1 {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-right: 0.8rem;
	margin-left: 0.8rem;
	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
