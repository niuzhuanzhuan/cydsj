<template>
	<div class="lindliog" v-if="dialogVisible">
		<el-dialog :title="title" :visible.sync="dialogVisible" :close-on-click-modal="false" :width="width + 'px'" :before-close="handleClose">
			<div style="width: 100%;display: flex;justify-content: center;">
				<div>
					<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-position="top" label-width="100px" class="demo-ruleForm">
						<el-form-item label="申领人姓名" prop="apply_name">
							<el-input placeholder="申领人姓名" style="width: 18.75rem;" v-model="ruleForm.apply_name"></el-input>
						</el-form-item>
						<el-form-item label="申领人电话" prop="apply_phone">
							<el-input placeholder="申领人电话" style="width: 18.75rem;" v-model="ruleForm.apply_phone"></el-input>
						</el-form-item>
						<el-form-item label="申领人证件号码">
							<el-input placeholder="申领人证件号码" style="width: 18.75rem;" v-model="ruleForm.apply_card"></el-input>
						</el-form-item>
						<el-form-item label="申领数量" prop="count">
							<el-input placeholder="申领数量" clearable style="width: 18.75rem;" v-model.number="ruleForm.count"></el-input>
						</el-form-item>
						<el-form-item label="申请事由" prop="reason">
							<el-input placeholder="请填写申领申请事由" type="textarea" :rows="5" clearable style="width: 18.75rem;" v-model="ruleForm.reason"></el-input>
						</el-form-item>
					</el-form>
				</div>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button type="primary" @click="Submit('ruleForm')">确 定</el-button>
				<el-button @click="handleClose">取 消</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
import define from '@/components/define/define';
import api from '@/utils/api.js';
export default {
	props: ['title', 'width','surplus'],
	data() {
		var phone = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('申请人电话不能为空'));
			} else {
				if (!define.phone.test(value)) {
					callback(new Error('电话号码格式不正确，请检查'));
				} else {
					callback();
				}
			}
		};
		let counts = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('申领数量不能为空'));
			} else {
				if (!Number.isFinite(value)) {
					callback(new Error('必须为数字值'));
				} else {
					if(value>this.surplus){
						callback(new Error('您输入的值已大于剩余数量，没有这么多哟'));
						return false
					}
					callback();
				}
			}
		};
		return {
			ruleForm: {},
			dialogVisible: false,
			rules: {
				apply_name: [{ required: true, message: '请输入申领人姓名', trigger: 'blur' }],
				count: [{ required: true, message: '申领数量不能为空' }, { type: 'number', message: '必须为数字值' }],
				count: [{ required: true, validator: counts, trigger: 'blur' }],
				apply_phone: [{ required: true, validator: phone, trigger: 'blur' }],
				reason: [{ required: true, message: '请填写申领申请事由', trigger: 'blur' }]
			}
		};
	},
	created() {},
	methods: {
		handleClose() {
			this.dialogVisible = false;
			this.ruleForm = {};
			this.$emit('Submit');
		},
		Submit(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					let datalist = await api.Devicedevice_apply(this.ruleForm);
					if (datalist) {
						this.$message.success(datalist.msg);
						this.handleClose();
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>

<style scoped>
.lindliog >>> .el-form-item {
	margin-bottom: 10px;
}
.lindliog >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.lindliog >>> .el-dialog__body {
	padding: 20px;
}
.lindliog >>> .el-dialog__header {
	border-bottom: 1px solid #e3e3e3;
}
.lindliog >>> .el-dialog__title {
	font-size: 16px;
}
.lindliog >>> .el-dialog__footer {
	background: #f5f5f5;
	padding: 18px 20px 12px;
}
.lindliog >>> .el-dialog__footer .el-button {
	width: 96px;
	font-size: 16px;
}
.lindliog >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}
</style>
