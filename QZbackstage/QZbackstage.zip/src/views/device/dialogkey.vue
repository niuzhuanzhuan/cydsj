<template>
	<div class="lindliog" v-if="dialogVisible">
		<el-dialog :title="title" :visible.sync="dialogVisible" :close-on-click-modal="false" :width="width + 'px'" :before-close="handleClose">
			<div style="width: 100%;display: flex;justify-content: center;">
				<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-position="top" label-width="100px" class="demo-ruleForm">
					<el-form-item label="上传excel表格" prop="fileObj">
						<el-upload class="upload-demo" drag accept=".xls" :on-exceed="handleExceed" :http-request="uploadFile" action :limit="1">
							<i class="el-icon-upload"></i>
							<div class="el-upload__text">
								将文件拖到此处，或
								<em>点击上传</em>
							</div>
						</el-upload>
					</el-form-item>
				</el-form>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button type="primary" @click="download">下载模板</el-button>
				<el-button type="primary" @click="Submit('ruleForm')">确 定</el-button>
				<el-button @click="handleClose">取 消</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
import define from '@/components/define/define';
import api from '@/utils/api.js';
import { URL } from '@/utils/doman.js';
export default {
	props: ['title', 'width'],
	data() {
		return {
			ruleForm: {
				fileObj: ''
			},
			token: '',
			dialogVisible: false,
			rules: {
				fileObj: [{ required: true, message: '请上传导入表格', trigger: 'change' }]
			}
		};
	},
	created() {
		this.token = this.$store.state.information.token;
	},
	methods: {
		download(){
			let url=URL+'images/设备导入模板.xls'
			window.location.href=url
		},
		handleClose() {
			this.dialogVisible = false;
		},
		handleExceed(file, fileList) {
			this.$message.warning(`当前限制选择 1 个文件，请删除后继续上传`);
		},
		async uploadFile(f) {
			this.$set(this.ruleForm, 'fileObj', f.file);
		},
		Submit(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					let fd = new FormData(); // FormData 对象
					fd.append('file', this.ruleForm.fileObj); // 文件对象
					let url = URL + 'user/device/import';
					let config = {
						headers: {
							'XX-Token': this.token,
							'XX-Device-Type': 'web',
							'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
						}
					};

					this.$axios.post(url, fd, config).then(res => {
						if (res.data.code == 0) {
							this.$message.success({
								message: res.data.msg,
								duration:5000
							});
							this.$emit('Submits');
							this.handleClose();
						} else {
							this.$message.warning(res.data.msg);
						}
					}).catch((error) => {
						this.$message.warning('格式不正确，请先下载模板，按照模板内容进行填写');
					});
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>

<style scoped>
.lindliog >>> .el-upload {
	width: 100%;
	height: 100%;
	padding: 0;
}
.lindliog >>> .el-form-item {
	margin-bottom: 10px;
}
.lindliog >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.lindliog >>> .el-dialog__body {
	padding: 20px;
}
.lindliog >>> .el-dialog__header {
	border-bottom: 1px solid #e3e3e3;
}
.lindliog >>> .el-dialog__title {
	font-size: 16px;
}
.lindliog >>> .el-dialog__footer {
	background: #f5f5f5;
	padding: 18px 20px 12px;
}
.lindliog >>> .el-dialog__footer .el-button {
	width: 96px;
	font-size: 16px;
}
.lindliog >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}
</style>
