<template>
	<div class="miancont">
		<div class="miantop">
			<el-form :model="ruleForm" :rules="rules" label-position="top" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<el-form-item label="设备名称" prop="name"><el-input v-model="ruleForm.name" style="width: 30rem;"></el-input></el-form-item>
				<el-form-item label="生产厂商" prop="manufacturer">
					<el-input v-model="ruleForm.manufacturer" style="width: 30rem;"></el-input></el-form-item>
				</el-form-item>
				<el-form-item label="型号" prop="model">
					<el-input v-model="ruleForm.model" style="width: 30rem;"></el-input></el-form-item>
				</el-form-item>
				<el-form-item :label="display?'设备正常数':'设备总数'" prop="good">
					<el-input v-model.number="ruleForm.good" style="width: 30rem;"></el-input></el-form-item>
				</el-form-item>
				<el-form-item label="状态" v-if="display" >
					<el-switch v-model="ruleForm.status" active-text="正常" inactive-text="故障"></el-switch>
				</el-form-item>
				<div style="width: 100%;height: 100px;"></div>
			</el-form>
		</div>
		<div class="bonslit">
			<div class="lisng">
				<el-button type="primary" style="width: 96px;" @click="getupdate('ruleForm')">确定</el-button>
				<el-button style="width: 96px;" @click="gobot">取消</el-button>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	data() {
		return {
			display:false,
			ruleForm: {},
			rules: {
				name: [{ required: true, message: '请输入设备名称', trigger: 'blur' }],
				manufacturer: [{ required: true, message: '请输入生产厂商', trigger: 'blur' }],
				model: [{ required: true, message: '请输入型号', trigger: 'blur' }],
				good: [{ required: true, message: '请输入设备总数', trigger: 'blur' }, { type: 'number', message: '必须为数字值'}],
			},
		};
	},
	computed: {},
	components: {},
	watch: {},
	deactivated() {
		for (let item in this.ruleForm) {
			this.ruleForm[item] = '';
		}
		this.display=false
	},
	activated() {
		this.display=false
		if (this.$route.query.selectid) {
			this.display=true
			this.setdata(this.$route.query.selectid);
		}
	},
	created() {},
	methods: {
		getupdate(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					if(this.display==true){
						if(this.ruleForm.status){
							this.ruleForm.status=1
						}else{
							this.ruleForm.status=2
						}
					}
					let listdata = await api.Devicesubmit(this.ruleForm);
					if (listdata) {
						this.$message.success(listdata.msg);
						this.$router.go(-1);
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		async setdata(data) {
			let datalist = await api.Deviceoperation({ id: data });
			if (datalist) {
				this.ruleForm=datalist.data
				this.$set(this.ruleForm,'status',datalist.data.status==1?true:false)
			}
		},
		gobot() {
			this.$router.go(-1);
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.fonco {
	color: #2196f3;
}
.bonslit {
	width: 99%;
	height: 60px;
	position: absolute;
	bottom: 0;
	z-index: 999;
	display: flex;
	justify-content: flex-start;
	align-items: center;
	background: #ffffff;
	.lisng {
		width: 30rem;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.miancont {
	width: calc(100% - 40px);
	padding: 20px;
	height: calc(100% - 40px);
	.miantop {
		width: 100%;
		padding: 20px 25px;
		.titles {
			padding-bottom: 30px;
			color: @co5;
			font-size: @fs16;
		}
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-bottom: 20px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
