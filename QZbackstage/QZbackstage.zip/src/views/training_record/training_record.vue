<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<!-- <div class="listname"><el-button type="text" icon="el-icon-plus" @click="adddata">导出</el-button></div> -->
			<div class="listname">
				<el-select v-model="sid" placeholder="组织选择" clearable filterable style="width: 18rem;">
					<el-option v-for="(item, index) in options" :key="index" :label="item.name" :value="item.sid"></el-option>
				</el-select>
			</div>
			<div class="listname">
				<el-select v-model="team_id" placeholder="运动队" clearable filterable style="width: 18rem;">
					<el-option v-for="(item, index) in teamarr" :key="index" :label="item.name" :value="item.team_id"></el-option>
				</el-select>
			</div>
			<div class="listname"><el-input placeholder="输入名字" style="width: 18rem;" v-model="name"></el-input></div>
			<div class="listname1">
				<el-button type="primary" style="width: 78px;background-color: #1E7FFF;" @click="queryfrom">查询</el-button>
				<el-button style="width: 78px;" @click="Reset">重置</el-button>
			</div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
					<el-table-column type="index" fixed="left" width="60" label="排序"></el-table-column>
					<el-table-column prop="user_name" min-width="100" label="姓名"></el-table-column>
					<el-table-column prop="user_logo" min-width="100" label="用户头像">
						<template slot-scope="scope">
							<el-avatar :src="scope.row.user_logo"></el-avatar>
						</template>
					</el-table-column>
					<el-table-column prop="zh" min-width="100" label="综合得分"></el-table-column>
					<el-table-column prop="sd" min-width="100" label="速度"></el-table-column>
					<el-table-column prop="ll" min-width="100" label="力量"></el-table-column>
					<el-table-column prop="nl" min-width="100" label="耐力"></el-table-column>
					<el-table-column prop="lm" min-width="100" label="灵敏"></el-table-column>
					<el-table-column prop="rr" min-width="100" label="柔韧"></el-table-column>
					<el-table-column prop="xt" min-width="100" label="协调"></el-table-column>
					<el-table-column prop="team_name" min-width="100" label="团队名称"></el-table-column>
					<el-table-column prop="team_logo" min-width="100" label="团队logo">
						<template slot-scope="scope">
							<el-avatar :src="scope.row.team_logo"></el-avatar>
						</template>
					</el-table-column>
					<el-table-column prop="school_name" min-width="100" label="组织"></el-table-column>
					<el-table-column label="操作" fixed="right" min-width="100">
						<template slot-scope="scope">
							<el-popover placement="top" popper-class="popper" trigger="hover" content="删除训练记录">
								<el-button slot="reference" type="text" icon="el-icon-delete" @click="delects(scope.row)" size="small"></el-button>
							</el-popover>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
export default {
	data() {
		return {
			sid: '',
			team_id: '',
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			name: '',
			options: [],
			teamarr: []
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination
	},
	watch: {
		sid(news, val) {
			if (news != val) {
				this.team_id = '';
				this.setTropsteam();
			}
		}
	},
	activated() {
		sessionStorage.removeItem('titlekey');
		this.setdata();
		this.setTropsteam();
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 150;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		delects(data) {
			this.$confirm('您确定要把当前姓名为 :' + data.user_name + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.Tropsdel({ id: data.id });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		async setdata() {
			let datalist = await api.Tropsschool();
			if (datalist) {
				this.options = datalist.data;
			}
		},
		async setTropsteam() {
			let datalist = await api.Tropsteam({ sid: this.sid });
			if (datalist) {
				this.teamarr = datalist.data;
			}
		},
		...mapActions(['Navtitle', 'menutitle']),
		queryfrom() {
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		Reset() {
			this.name = '';
			this.page = 1;
			(this.sid = ''), (this.team_id = ''), (this.pagesize = 20);
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		async getdata() {
			let listdata = await api.Tropsget_data({
				page: this.page,
				pagesize: this.pagesize,
				name: this.name,
				sid: this.sid,
				team_id: this.team_id
			});
			this.tableData = listdata.data.data;
			this.$nextTick(() => {
				this.$refs.pagination.total = listdata.data.count;
			});
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		adddata() {}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	height: 98%;
	.mianlist {
		margin: 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: space-between;
	flex-wrap: wrap;
	width: 100%;
}
.listname {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname1 {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-right: 0.8rem;
	margin-left: 0.8rem;
	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
