<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<div class="listname"><el-button icon="el-icon-plus" plain @click="adddata">添加账户</el-button></div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights">
					<el-table-column type='index' fixed="left" width="60" label="排序"></el-table-column>
					<el-table-column prop="user_nickname" label="用户昵称" min-width="120"></el-table-column>
					<el-table-column prop="user_type" min-width="120" label="用户类型">
						<template slot-scope="scope">
							{{ scope.row.user_type === 1 ? '管理员' : '普通用户' }}
						</template>
					</el-table-column>
					<el-table-column prop="mobile" min-width="120" label="手机号码"></el-table-column>
					<el-table-column prop="user_status" min-width="120" label="用户状态">
						<template slot-scope="scope">
							{{ scope.row.user_type === 0 ? '禁用' : scope.row.user_type === 1 ? '正常' : '未验证' }}
						</template>
					</el-table-column>
					<el-table-column label="操作" min-width="120" fixed="right">
						<template slot-scope="scope">
							<el-button type="text" v-show="scope.row.id != 1" size="small" @click="updatas(scope.row.id)">修改</el-button>
							<!-- <i class="el-icon-edit"></i> -->
							<el-button type="text" v-show="scope.row.id != 1" @click="delects(scope.row)" size="small">删除</el-button>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapActions } from 'vuex';
export default {
	data() {
		return {
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: []
		};
	},
	computed: {},
	components: {
		pagination
	},
	watch: {},
	created() {
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 220;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		...mapActions(['Navtitle']),
		async getdata() {
			api.userindex({
				page: this.page,
				pagesize: this.pagesize
			}).then(res => {
				if (res.data.code === 1) {
					res.data.data.data.map((item, index) => {
						item.create_time = define.timestampToTime(item.create_time);
						item.update_time = define.timestampToTime(item.update_time);
					});
					this.tableData = res.data.data.data;
					this.$nextTick(() => {
						this.$refs.pagination.total = res.data.data.count;
					});
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		updatas(data) {
			this.Navtitle('系统管理/账户管理/修改用户');
			this.$router.push({
				path: '/list_up',
				query: {
					selectid: data
				}
			});
		},
		adddata() {
			this.Navtitle('系统管理/账户管理/添加用户');
			this.$router.push('/list_up');
		},
		async delects(data) {
			this.$confirm('您确定要把当前角色名为 :' + data.user_nickname + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(() => {
					api.deleteuser({ id: data.id }).then(res => {
						if (res.data.code === 1) {
							this.$message.success(res.data.msg);
							this.getdata();
						} else {
							this.$message.warning(res.data.msg);
						}
					});
				})
				.catch(() => {
					this.$message({
						type: 'success',
						message: '已取消删除'
					});
				});
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	padding: 20px;
	height: inherit;
	.mianlist {
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-bottom: 20px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
