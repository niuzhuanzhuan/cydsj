<template>
	<div class="miancont">
		<div class="miantop">
			<div class="titles">基本信息</div>
			<el-form :model="ruleForm" :rules="rules" label-position="top" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<el-form-item label="用户昵称" prop="user_nickname"><el-input v-model="ruleForm.user_nickname" style="width: 38.375rem;"></el-input></el-form-item>
				<el-form-item label="手机号码" prop="mobile"><el-input v-model.number="ruleForm.mobile" style="width: 38.375rem;"></el-input></el-form-item>
				<el-form-item label="用户状态" prop="user_status">
					<el-radio-group v-model="ruleForm.user_status">
						<el-radio :label="0">禁用</el-radio>
						<el-radio :label="1">正常</el-radio>
						<el-radio :label="2">未验证</el-radio>
					</el-radio-group>
				</el-form-item>
				<el-form-item label="用户状态" prop="user_status">
					<el-radio-group v-model="ruleForm.user_status">
						<el-radio :label="0">禁用</el-radio>
						<el-radio :label="1">正常</el-radio>
						<el-radio :label="2">未验证</el-radio>
					</el-radio-group>
				</el-form-item>
				<el-form-item label="角色" prop="role_id">
					<el-checkbox-group v-model="ruleForm.role_id"><el-checkbox v-for="(item, index) in roles" :key="index" :label="item.name"></el-checkbox></el-checkbox-group>
				</el-form-item>
			</el-form>
		</div>
		<div class="bonslit">
			<el-button type="primary" style="width: 96px;" @click="getupdate('ruleForm')">确定</el-button>
			<el-button style="width: 96px;" @click="gobot">取消</el-button>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import { mapActions } from 'vuex';
export default {
	data() {
		const phone = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请填写手机号码'));
			} else if (!define.phone.test(value)) {
				callback(new Error('手机号码格式不正确'));
			} else {
				callback();
			}
		};
		return {
			roles: [],
			ruleForm: {},
			rules: {
				user_nickname: [{ required: true, message: '请输入用户昵称', trigger: 'blur' }],
				mobile: [{ required: true, validator: phone, trigger: 'blur' }],
				user_status: [{ required: true, message: '请选择用户状态', trigger: 'blur' }],
				role_id: [{ required: true, message: '请选择角色', trigger: 'blur' }]
			}
		};
	},
	computed: {},
	components: {},
	watch: {},
	created() {
		if (this.$route.query.selectid) {
			this.setdata(this.$route.query.selectid);
		}
	},
	methods: {
		...mapActions(['Navtitle']),
		async getupdate(ruleForm) {
			this.$refs[ruleForm].validate(valid => {
				if (valid) {
					api.updateuser(this.ruleForm).then(res => {
						if (res.data.code === 1) {
							this.$message.success(res.data.msg);
							this.$router.go(-1);
						} else {
							this.$message.warning(res.data.msg);
						}
					});
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		async setdata(data) {
			api.selectuser({ id: data }).then(res => {
				if (res.data.code === 1) {
					this.ruleForm = res.data.data.user;
					console.log(res.data.data);
					this.roles = res.data.data.roles;
					this.$set(this.ruleForm, 'role_id', '2,3');
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		},
		gobot() {
			this.$router.go(-1);
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.demo-ruleForm >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.demo-ruleForm >>> .el-form-item__label::before {
	margin-left: 5px;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	width: inherit;
	padding: 20px;
	height: inherit;
	.miantop {
		width: 100%;
		padding: 20px 25px;
		.titles {
			padding-bottom: 30px;
			color: @co5;
			font-size: @fs16;
		}
	}
	.bonslit {
		width: 100%;
		position: fixed;
		bottom: 60px;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-bottom: 20px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
