<template>
	<div class="mins">
		<el-form ref="form" label-position="top" :inline="true" :model="form" label-width="80px">
			<div class="itlim">
				<el-form-item label="用户名"><el-input clearable v-model="form.user_login"></el-input></el-form-item>
			</div>
			<div class="itlim">
				<el-form-item label="用户昵称"><el-input clearable v-model="form.user_nickname"></el-input></el-form-item>
			</div>
			<div class="itlim">
				<el-form-item label="是否启用">
					<el-select v-model="form.user_status" clearable placeholder="请选择">
						<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
					</el-select>
				</el-form-item>
			</div>
			<!-- <div class="itlim" v-if="rotate!=90">
				<el-form-item label="用户组"><el-input v-model="form.name"></el-input></el-form-item>
			</div> -->
			<!-- <div class="itlim" v-if="rotate!=90">
				<el-form-item label="是否启用"><el-input v-model="form.name"></el-input></el-form-item>
			</div> -->
			<!-- <div class="itlim" v-if="rotate!=90">
				<el-form-item label="是否启用">
					<el-select v-model="form.user_status" clearable placeholder="请选择">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				</el-form-item>
			</div> -->
			<div class="itlim" :style="{ width: rotate == 90 ? '25%' : '50%' }">
				<el-form-item>
					<div class="bonnoe">
						<el-button type="primary" style="width: 78px;background-color: #1E7FFF;" @click="queryfrom">查询</el-button>
						<el-button style="width: 78px;" @click="Reset">重置</el-button>
						<div class="lifroms" @click="setup"><i class="el-icon-d-arrow-left" v-if="displays" :style="{ transform: 'rotate(' + rotate + 'deg)' }"></i></div>
					</div>
				</el-form-item>
			</div>
		</el-form>
	</div>
</template>

<script>
export default {
	data() {
		return {
			form: {
				user_login: '',
				user_status: '',
				user_nickname: ''
			},
			options: [
				{
					value: '0',
					label: '禁用'
				},
				{
					value: '1',
					label: '启用'
				}
			],
			rotate: 90
		};
	},
	computed: {
		displays() {
			if(Object.keys(this.form).length<=3){
				return false
			}
			return true;
		}
	},
	methods: {
		setup() {
			if (this.rotate === 90) {
				this.rotate = 270;
			} else {
				this.rotate = 90;
			}
		},
		Reset(){
			for (let item in this.form) {
				this.form[item]=''
			}
			this.$emit('queryfrom',this.form)
		},
		queryfrom(){
			this.$emit('queryfrom',this.form)
		}
	}
};
</script>
<style>
.mins > .el-form {
	width: 100%;
	display: flex;
	/* flex-wrap: nowrap; */
	flex-wrap: wrap;
}
.mins > .el-form .el-form-item {
	width: 100%;
	margin-bottom: 5px;
	padding: 0 0 0 12px;
}
.mins > .el-form .el-form-item .el-form-item__label {
	padding: 0;
	line-height: 24px;
}
</style>

<style lang="less" scoped>
.lifroms {
	width: 30px;
	height: 32px;
	display: flex;
	justify-content: center;
	align-items: center;
	cursor: pointer;
	&:active {
		color: #1e7fff;
	}
}
.mins {
	width: 100%;
	display: flex;
	.itlim {
		width: 25%;
		display: flex;
		justify-content: flex-end;
	}
}
.bonnoe {
	width: 100%;
	height: 57px;
	display: flex;
	justify-content: flex-end;
	align-items: flex-end;
}
</style>
