<template>
	<div class="contex">
		<div class="contex_left"><trees @setorgan_id="setorgan_id" @setfromdata="setfromdata" /></div>
		<div class="miancont" ref="miancont">
			<div class="top_mian"><search @queryfrom="queryfrom" /></div>
			<div class="handle-box">
				<div class="listname"><el-button type="text" icon="el-icon-plus" @click="adddata">添加</el-button></div>
				<div class="listname"><el-button type="text" icon="el-icon-delete" :disabled="displays" @click="deletedata">删除</el-button></div>
				<div class="lisfenge"><el-divider direction="vertical"></el-divider></div>
				<div class="listname1"><el-button type="text" icon="el-icon-addedqiyong" :disabled="displays" @click="Enable">启用</el-button></div>
				<div class="listname"><el-button type="text" icon="el-icon-remove-outline" :disabled="displays" @click="Outofservice">禁用</el-button></div>
			</div>
			<div class="mianlist">
				<template>
					<el-table :data="tableData" stripe :height="heights" ref="multipleTable" @selection-change="handleSelectionChange">
						<el-table-column type="selection" min-width="80" :selectable="checkSelectable"></el-table-column>
						<el-table-column prop="user_login" min-width="100" label="用户名"></el-table-column>
						<el-table-column prop="user_type" min-width="100" label="用户类型">
							<template slot-scope="scope">
								{{ scope.row.user_type == 1 ? '管理员' : '普通用户' }}
							</template>
						</el-table-column>
						<el-table-column prop="user_nickname" min-width="100" label="用户昵称"></el-table-column>
						<el-table-column prop="organization_name" min-width="100" label="用户组"></el-table-column>
						<el-table-column prop="user_status" min-width="100" label="是否启用">
							<template slot-scope="scope">
								<el-tag type="success" v-if="scope.row.user_status == 1">启用</el-tag>
								<el-tag type="info" v-else>禁用</el-tag>
							</template>
						</el-table-column>
						<el-table-column label="操作" min-width="100" fixed="right">
							<template slot-scope="scope">
								<el-popover placement="top" popper-class="popper" trigger="hover" content="修改密码">
									<el-button
										slot="reference"
										icon="el-icon-addedicon_xiugaimima"
										type="text"
										v-show="scope.row.id != 1"
										size="small"
										@click="modify(scope.row.id)"
									></el-button>
								</el-popover>
								<el-popover placement="top" popper-class="popper" trigger="hover" content="修改账户">
									<el-button slot="reference" icon="el-icon-edit" type="text" v-show="scope.row.id != 1" size="small" @click="updatas(scope.row.id)"></el-button>
								</el-popover>
								<el-popover placement="top" popper-class="popper" trigger="hover" :content="scope.row.user_status == 1 ? '禁用' : '启用'">
									<el-button
										slot="reference"
										:icon="scope.row.user_status == 1 ? 'el-icon-remove-outline' : 'el-icon-addedqiyong'"
										type="text"
										v-show="scope.row.id != 1"
										size="small"
										@click="Enabledisable(scope.row)"
									></el-button>
								</el-popover>
								<el-popover placement="top" popper-class="popper" trigger="hover" content="删除账户">
									<el-button slot="reference" type="text" icon="el-icon-delete" v-show="scope.row.id != 1" @click="delects(scope.row)" size="small"></el-button>
								</el-popover>
							</template>
						</el-table-column>
					</el-table>
				</template>
			</div>
			<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		</div>
		<dialogs ref="dialogs" :title="'修改密码'" :width="390" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
import dialogs from './dialog.vue';
import search from './search.vue';
import trees from './trees.vue';
export default {
	data() {
		let validate = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('此项为必填项'));
			} else {
				var patrn = /[`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘'，。、]/im;
				if (patrn.test(value)) {
					callback(new Error('不允许输入特殊字符，请检查'));
				} else {
					callback();
				}
			}
		};
		return {
			display: false,
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			sum: [],
			displays: true,
			organ_id: null,
			fromdata: {},
			limi: 0,
			defaultProps: {
				children: 'list',
				label: 'name'
			}
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		search,
		dialogs,
		trees
	},
	watch: {
		sum(newval) {
			this.displays = true;
			if (newval.length > 0) {
				this.displays = false;
			}
		},
		organ_id(newval, val) {
			if (newval != val) {
				this.getdata();
			}
		}
	},
	activated() {
		if (this.limi == 1) {
			this.getdata();
		}
		this.$nextTick(() => {
			sessionStorage.removeItem('titlekey');
			let scrollHeight = this.$refs.miancont.scrollHeight - 180;
			this.heights = scrollHeight;
		});
	},
	methods: {
		setorgan_id(data) {
			this.organ_id = data;
		},
		setfromdata(data) {
			this.fromdata = data;
		},
		modify(data) {
			this.$nextTick(() => {
				this.$set(this.$refs.dialogs.ruleForm, 'id', data);
				this.$refs.dialogs.dialogVisible = true;
			});
		},
		Submit() {},
		Enabledisable(data) {
			this.$confirm(`您确定要${data.user_status == 1 ? '禁用' : '启用'} ${data.user_login} 吗?`, '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let datalist = await api.userban({ id: [data.id], user_status: data.user_status == 1 ? 0 : 1 });
					if (datalist) {
						this.$message.success(datalist.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		queryfrom(data) {
			let { user_login, user_nickname, user_status } = data;
			this.page = 1;
			this.getdata(user_login, user_nickname, user_status);
		},
		...mapActions(['Navtitle', 'menutitle', 'gettitles']),
		handleSelectionChange(data) {
			this.sum = data.map(item => item.id);
		},
		Enable() {
			this.$confirm('您确定要启用当前选中的数据吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.cancelBan({ id: this.sum, user_status: 1 });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		Outofservice() {
			this.$confirm('您确定要禁用当前选中的数据吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.userban({ id: this.sum, user_status: 0 });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		deletedata() {
			this.$confirm('您确定要把当前选中的数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.user_del({ id: this.sum });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		checkSelectable(row) {
			return row.id != 1;
		},
		async getdata(user_login = '', user_nickname = '', user_status) {
			let listdata = await api.userindex({
				organization_id: this.organ_id,
				page: this.page,
				pagesize: this.pagesize,
				user_login: user_login,
				user_nickname: user_nickname,
				user_status: user_status
			});
			if (listdata) {
				this.limi = 0;
				listdata.data.data.map((item, index) => {
					item.create_time = define.timestampToTime(item.create_time);
					item.update_time = define.timestampToTime(item.update_time);
				});
				this.tableData = listdata.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		updatas(data) {
			this.limi = 1;
			this.$set(this.fromdata, 'titlein', '目标用户组');
			this.gettitles(this.fromdata);
			this.Navtitle('系统管理/账户管理/修改账户');
			this.$router.push({
				path: '/addaccount',
				query: {
					selectid: data
				}
			});
		},
		adddata() {
			this.limi = 1;
			this.$set(this.fromdata, 'titlein', '目标用户组');
			this.gettitles(this.fromdata);
			this.Navtitle('系统管理/账户管理/添加账户');
			this.$router.push('/addaccount');
		},
		delects(data) {
			this.$confirm('您确定要把当前角色名为 :' + data.user_nickname + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.user_del({ id: [data.id] });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.filter-tree {
	margin-top: 10px;
}
.miansli {
	width: 100%;
	height: 100%;
}
.demo-ruleForm >>> {
}
.h-page-header {
	display: none !important;
}
.custom-tree-node {
	display: flex;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.mianling {
	width: 100%;
	height: auto;
	.lingku {
		color: #999999;
	}
}
.contex {
	width: 100%;
	height: inherit;
	position: relative;
	overflow: hidden;
	.contex_left {
		position: absolute;
		left: 0;
		top: -6px;
		width: 224px;
		height: 100%;
		border-right: 1px solid #e0e0e0;
		padding: 0 12px;
		.frolist {
			width: 100%;
			height: 100%;
			.frolist_top {
				width: 100%;
				height: 35px;
				display: flex;
			}
		}
	}
}

.miancont {
	width: calc(100%-250px);
	margin-left: 250px;
	height: inherit;
	position: relative;
	.top_mian {
		width: 100%;
		margin-top: 5px;
		min-height: 72px;
		max-height: 144px;
	}
	.mianlist {
		margin: 2px 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		background: #ffffff;
		border-top: 1px solid #e3e3e3;
		position: absolute;
		z-index: 999;
		bottom: 0;
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	border-top: 1px solid #e3e3e3;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname1 {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
}
.lisfenge {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
}
</style>
