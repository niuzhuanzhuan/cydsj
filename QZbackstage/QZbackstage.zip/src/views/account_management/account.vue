<template>
	<div class="miancont">
		<div class="miantop">
			<div class="fomnsli">
				<div class="titles">基本信息</div>
				<el-form :model="ruleForm" :rules="rules" label-position="top" ref="ruleForm" label-width="100px" class="demo-ruleForm">
					<el-form-item label="用户名" prop="user_login"><el-input v-model="ruleForm.user_login" style="width: 38.375rem;"></el-input></el-form-item>
					<el-form-item label="用户昵称" prop="user_nickname"><el-input v-model="ruleForm.user_nickname" style="width: 38.375rem;"></el-input></el-form-item>
					<el-form-item label="手机号码" prop="mobile"><el-input v-model.number="ruleForm.mobile" style="width: 38.375rem;"></el-input></el-form-item>
					<el-form-item label="密码" v-if="shows" prop="user_pass"><el-input v-model="ruleForm.user_pass" style="width: 38.375rem;"></el-input></el-form-item>
					<el-form-item label="确认密码" v-if="shows" prop="confirm_pass"><el-input v-model="ruleForm.confirm_pass" style="width: 38.375rem;"></el-input></el-form-item>
					<el-form-item label="描述"><el-input type="textarea" :rows="4" v-model.number="ruleForm.signature" style="width: 38.375rem;"></el-input></el-form-item>
					<el-form-item label="请为用户选择角色。用户可同时关联多个角色，取权限并集。">
						<el-select v-model="ruleForm.role_id" style="width: 38.375rem;" multiple clearable placeholder="选择角色">
							<el-option v-for="item in options" :key="item.id" :label="item.name" :value="item.id"></el-option>
						</el-select>
					</el-form-item>
				</el-form>
				<div style="height: 100px;"></div>
				<div class="bonslit">
					<div class="lisng">
						<el-button type="primary" style="width: 96px;background: #1E7FFF;" @click="getupdate('ruleForm')">确定</el-button>
						<el-button style="width: 96px;" @click="gobot">取消</el-button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import { mapActions } from 'vuex';
export default {
	data() {
		const validatePass2 = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('请输入密码'));
			} else {
				if (!define.depawss.test(value)) {
					callback(new Error('密码格式为6-16位数字或字母组成'));
				} else {
					callback();
				}
			}
		};
		const confirm_pass = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('请输入确认密码'));
			} else {
				if (value != this.ruleForm.user_pass) {
					callback(new Error('两次密码不一直，请检查'));
				} else {
					callback();
				}
			}
		};
		var validatephone = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入电话号码'));
			} else {
				if (!define.phone.test(value)) {
					callback(new Error('手机号码格式不正确请检查'));
				} else {
					callback();
				}
			}
		};
		return {
			shows: true,
			roles: [],
			ruleForm: {},
			options: [],
			rules: {
				mobile: [{ required: true, validator: validatephone, trigger: 'blur' }],
				user_nickname: [{ required: true, message: '请输入用户昵称', trigger: 'blur' }],
				user_login: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
				user_pass: [{ required: true, validator: validatePass2, trigger: 'change' }],
				confirm_pass: [{ required: true, validator: confirm_pass, trigger: 'change' }],
				role_id: [{ required: true, message: '请选择角色', trigger: 'blur' }]
			}
		};
	},
	computed: {},
	components: {},
	watch: {},
	deactivated() {
		this.ruleForm = {};
		this.shows = true;
	},
	activated() {
		this.getdata();
		this.$set(this.ruleForm, 'organization_id', this.$store.state.titlekeys.id);
		this.shows = true;
		if (this.$route.query.selectid) {
			this.shows = false;
			this.setdata(this.$route.query.selectid);
		}
	},
	methods: {
		async getdata() {
			let datalist = await api.selectuser();
			if (datalist) {
				this.options = datalist.data;
			}
		},
		...mapActions(['Navtitle']),
		getupdate(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					delete this.ruleForm.confirm_pass
					let datalist = await api.updateuser(this.ruleForm);
					if (datalist) {
						this.$message.success(datalist.msg);
						this.$router.go(-1);
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		async setdata(data) {
			let listdata = await api.selectuser({ id: data });
			if (listdata) {
				this.ruleForm = listdata.data.user;
				this.$set(this.ruleForm, 'role_id', listdata.data.role_ids);
			}
		},
		gobot() {
			this.$router.go(-1);
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.demo-ruleForm >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.demo-ruleForm >>> .el-form-item__label::before {
	margin-left: 5px;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	width: 98%;
	padding: 20px 1%;
	height: inherit;
	.miantop {
		width: 98%;
		padding: 20px 1%;
		display: flex;
		justify-content: center;
		.fomnsli {
			width: 100%;
			overflow: auto;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: flex-start;
			.titles {
				width: 614px;
				padding-bottom: 30px;
				color: @co5;
				font-size: @fs16;
			}
		}
	}
	.bonslit {
		width: 99%;
		height: 60px;
		position: absolute;
		bottom: 0;
		display: flex;
		justify-content: center;
		align-items: center;
		border-top: 1px solid #e0e0e0;
		background: #ffffff;
		.lisng {
			width: 614px;
			height: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
		}
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-bottom: 20px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
