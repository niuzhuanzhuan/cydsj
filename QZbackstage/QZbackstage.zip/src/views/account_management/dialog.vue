<template>
	<div class="lindliog" v-if="dialogVisible">
		<el-dialog :title="title" :visible.sync="dialogVisible" :close-on-click-modal="false" :width="width + 'px'" :before-close="handleClose">
			<div style="width: 100%;display: flex;justify-content: center;">
				<div style="width: 230px;">
					<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-position="top" label-width="100px" class="demo-ruleForm">
						<el-form-item label="管理员密码" prop="user_pass"><el-input v-model="ruleForm.user_pass"></el-input></el-form-item>
						<el-form-item label="新密码" prop="password1"><el-input v-model="ruleForm.password1"></el-input></el-form-item>
						<el-form-item label="确认密码" prop="password"><el-input v-model="ruleForm.password"></el-input></el-form-item>
					</el-form>
				</div>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button type="primary" @click="Submit('ruleForm')">确 定</el-button>
				<el-button @click="handleClose">取 消</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
import define from '@/components/define/define';
import api from '@/utils/api.js';
export default {
	props: ['title', 'width'],
	data() {
		var validatePass = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('请输入密码'));
			} else {
				if (!define.depawss.test(value)) {
					callback(new Error('密码格式为6-16位数字或字母组成'));
				} else {
					callback();
				}
			}
		};
		var validatePass2 = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('请再次输入密码'));
			} else if (value !== this.ruleForm.password1) {
				callback(new Error('两次输入密码不一致!'));
			} else {
				callback();
			}
		};
		return {
			ruleForm: {},
			dialogVisible: false,
			rules: {
				user_pass: [{ required: true, message: '请输入当前管理员密码', trigger: 'change' }],
				password1: [{ required: true, validator: validatePass, trigger: 'change' }],
				password: [{ required: true, validator: validatePass2, trigger: 'change' }]
			}
		};
	},
	methods: {
		handleClose() {
			this.dialogVisible = false;
			this.ruleForm = {};
		},
		Submit(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					// this.$emit('Submit', this.ruleForm);userpass
					let datalist = await api.userpass(this.ruleForm);
					if (datalist) {
						this.$message.success(datalist.msg);
						this.$emit('Submit');
						this.handleClose();
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>

<style scoped>
.lindliog >>> .el-form-item {
	margin-bottom: 10px;
}
.lindliog >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.lindliog >>> .el-dialog__body {
	padding: 20px;
}
.lindliog >>> .el-dialog__header {
	border-bottom: 1px solid #e3e3e3;
}
.lindliog >>> .el-dialog__title {
	font-size: 16px;
}
.lindliog >>> .el-dialog__footer {
	background: #f5f5f5;
	padding: 18px 20px 12px;
}
.lindliog >>> .el-dialog__footer .el-button {
	width: 96px;
	font-size: 16px;
}
.lindliog >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}
</style>
