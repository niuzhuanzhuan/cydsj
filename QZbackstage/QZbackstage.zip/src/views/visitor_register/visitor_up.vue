<template>
	<div class="miancont">
		<div class="miantop">
			<el-form :model="ruleForm" :rules="rules" label-position="top" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<el-form-item label="姓名" prop="visitorName"><el-input v-model="ruleForm.visitorName" style="width: 30rem;"></el-input></el-form-item>
				<el-form-item label="性别" prop="gender">
					<el-select v-model="ruleForm.gender" style="width: 30rem;" clearable placeholder="请选择性别">
						<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="证件号码" prop="certificateNo">
					<el-input v-model="ruleForm.certificateNo" style="width: 30rem;"></el-input></el-form-item>
				</el-form-item>
				<el-form-item label="正面免冠照">
					<el-upload class="avatar-uploader" action="" :show-file-list="false" accept="image/jpeg" :on-change="changeFile">
						<img v-if="ruleForm.imageUrl" :src="ruleForm.imageUrl" class="avatar" />
						<i v-else class="el-icon-plus avatar-uploader-icon"></i>
						<div slot="tip" class="el-upload__tip">请上传正面免冠照，露出眼睛和眉毛；</div>
						<div slot="tip" class="el-upload__tip">图片文件大小10 KB~200 KB。</div>
					</el-upload>
				</el-form-item>
				<el-form-item label="访问对象" prop="username">
					<el-autocomplete v-model="ruleForm.username" clearable :fetch-suggestions="querySearch" style="width: 30rem;"></el-autocomplete>
				</el-form-item>
				<el-form-item label="访问时间" prop="Time">
					<el-date-picker
						v-model="ruleForm.Time"
						type="datetimerange"
						style="width: 30rem;"
						start-placeholder="来访时间"
						end-placeholder="预计离开时间"
						value-format="yyyy-MM-dd HH:mm:ss"
						:default-time="['', '23:59:59']"
					></el-date-picker>
				</el-form-item>
				<el-form-item label="访问理由"><el-input type="textarea" style="width: 30rem;" rows="6" v-model="ruleForm.visitPurpose"></el-input></el-form-item>
				<div style="height: 100px;width: 100%;"></div>
			</el-form>
		</div>
		<div class="bonslit">
			<div class="lisng">
				<el-button type="primary" style="width: 96px;" @click="getupdate('ruleForm')">确定</el-button>
				<el-button style="width: 96px;" @click="gobot">取消</el-button>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import { mapActions } from 'vuex';
import {URL} from '@/utils/doman'
export default {
	data() {
		let validate = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('请输入访问对象'));
			} else {
				let indexof = this.list.find(item => item.personName == value);
				if (!indexof) {
					callback(new Error('当前访问对象不存在'));
				} else {
					this.$set(this.ruleForm, 'receptionistId', indexof.personId);
					callback();
				}
			}
		};
		let letcerti = (rule, value, callback) => {
			let p=/^[0-9a-zA-Z]{1,20}$/
			if (value === '') {
				callback(new Error('请输入证件号码'));
			} else {
				if (!p.test(value)) {
					callback(new Error('证件号码不能中文及特殊字符，且长度不能超过20位'));
				} else {
					callback();
				}
			}
		};
		return {
			ruleForm: {
				imageUrl: ''
			},
			rules: {
				visitorName: [{ required: true, message: '请输入来访姓名', trigger: 'blur' }],
				gender: [{ required: true, message: '请选择性别', trigger: 'blur' }],
				username: [{ required: true, validator: validate, trigger: 'change' }],
				certificateNo: [{ required: true, validator: letcerti, trigger: 'blur' }],
				Time: [{ required: true, message: '请选择到访时间及预计离开时间', trigger: 'blur' }]
			},
			list: [],
			options: [
				{
					value: 1,
					label: '男'
				},
				{
					value: 2,
					label: '女'
				}
			],
			Selectdata: []
		};
	},
	computed: {},
	components: {},
	watch: {},
	deactivated() {
		for (let item in this.ruleForm) {
			this.ruleForm[item] = '';
		}
	},
	activated() {
		if (this.$route.query.selectid) {
			this.setdata(this.$route.query.selectid);
		}
	},
	created() {
		this.getdata();
	},
	methods: {
		changeFile(f) {
			if (f.raw.type != 'image/jpeg') {
				this.$message.error('图片文件仅支持.jpg 格式');
				return false;
			}
			let that = this;
			let reader = new FileReader();
			reader.readAsDataURL(f.raw);
			reader.onload = function() {
				if (that.showSize(this.result) > 200) {
					that.$message.error('图片文件大小10 KB~200 KB,当前图片太大了');
				} else {
					that.ruleForm.imageUrl = this.result;
					that.ruleForm.visitorPhoto = this.result.replace('data:image/jpeg;base64,', '');
				}
			};
		},
		showSize(base64url) {
			//获取base64图片大小，返回KB数字
			var str = base64url.replace('data:image/jpeg;base64,', '');
			var equalIndex = str.indexOf('=');
			if (str.indexOf('=') > 0) {
				str = str.substring(0, equalIndex);
			}
			var strLength = str.length;
			var fileLength = parseInt(strLength - (strLength / 8) * 2);
			// 由字节转换为KB
			var size = '';
			size = (fileLength / 1024).toFixed(2);
			var sizeStr = size + ''; //转成字符串
			var index = sizeStr.indexOf('.'); //获取小数点处的索引
			var dou = sizeStr.substr(index + 1, 2); //获取小数点后两位的值
			if (dou == '00') {
				//判断后两位是否为00，如果是则删除00
				return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
			}
			return parseInt(size);
		},
		async getdata() {
			let datalist = await api.Visitorperson();
			if (datalist) {
				datalist.data.map(item => {
					this.$set(item, 'value', item.personName);
				});
				this.list = datalist.data;
			}
		},
		querySearch(queryString, cb) {
			var restaurants = this.list;
			var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
			// 调用 callback 返回建议列表的数据
			cb(results);
		},
		createFilter(queryString) {
			return restaurant => {
				return restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0;
			};
		},
		checkchange() {
			this.Selectdata = this.$refs.tree.getCheckedNodes().map(item => item.id);
			this.$set(this.ruleForm, 'menuId', this.Selectdata);
		},
		...mapActions(['Navtitle']),
		getupdate(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					this.$set(this.ruleForm, 'visitStartTime', this.ruleForm.Time[0]);
					this.$set(this.ruleForm, 'visitEndTime', this.ruleForm.Time[1]);
					let listdata = await api.Visitorsubmit(this.ruleForm);
					if (listdata) {
						this.$message.success(listdata.msg);
						this.$router.go(-1);
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		async setdata(data) {
			let datalist = await api.Visitorinfo({ id: data });
			if (datalist) {
				this.ruleForm=datalist.data
				this.$set(this.ruleForm, 'Time',[this.ruleForm.visitStartTime,this.ruleForm.visitEndTime]);
				this.$set(this.ruleForm, 'imageUrl',URL+this.ruleForm.visitorPhoto);
				this.$set(this.ruleForm, 'visitorPhoto','');
				let indexof = this.list.find(item => item.personId == this.ruleForm.receptionistId);
				if(!!indexof){
					this.$set(this.ruleForm, 'username',indexof.personName);
				}
			}
		},
		gobot() {
			this.$router.go(-1);
		}
	}
};
</script>
<style scoped>
.el-upload__tip {
	margin: 0;
	height: 20px !important;
}
.avatar-uploader .el-upload {
	width: 195px;
	height: 260px;
	border: 1px dashed #d9d9d9;
	border-radius: 6px;
	cursor: pointer;
	position: relative;
	overflow: hidden;
}
.avatar-uploader >>>.el-upload--text{
	display: flex;
		align-items: center;
		justify-content: center;
		width: 195px;
		height: 260px;
}

.avatar-uploader .el-upload:hover {
	border-color: #409eff;
}
.avatar-uploader-icon {
	font-size: 28px;
	color: #8c939d;
	width: 195px;
	height: 260px;
	line-height: 260px;
	text-align: center;
}
.avatar {
	width: 195px;
	height: 260px;
	display: block;
}
@import url('../../assets/css/tables.css');
.demo-ruleForm >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.demo-ruleForm >>> .el-form-item__label::before {
	margin-left: 5px;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.fonco {
	color: #2196f3;
}
.bonslit {
	width: 99%;
	height: 60px;
	position: absolute;
	bottom: 0;
	z-index: 999;
	display: flex;
	justify-content: flex-start;
	align-items: center;
	background: #ffffff;
	.lisng {
		width: 30rem;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.miancont {
	width: inherit;
	padding: 20px;
	height: inherit;
	.miantop {
		width: 100%;
		padding: 20px 25px;
		.titles {
			padding-bottom: 30px;
			color: @co5;
			font-size: @fs16;
		}
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-bottom: 20px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
