<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<div class="listname"><el-button type="text" icon="el-icon-plus" @click="adddata">录入</el-button></div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
					<el-table-column type='index' width="100"  label="排序"></el-table-column>
					<el-table-column prop="visitorName" label="姓名"></el-table-column>
					<el-table-column prop="visitorPhoto" min-width="100" label="正面免冠照">
						<template slot-scope="scope">
							<el-popover placement="right-start" trigger="hover">
								<el-image slot="reference" :src="scope.row.visitorPhoto" style="width: 60px; height: 60px" fit="contain" :alt="scope.row.visitorPhoto">
									<div slot="error" class="image-slot"><i class="el-icon-picture-outline"></i></div>
								</el-image>
								<el-image :src="scope.row.visitorPhoto" style="max-width: 250px">
									<div slot="error" class="image-slot"><i class="el-icon-picture-outline"></i></div>
								</el-image>
							</el-popover>
						</template>
					</el-table-column>
					<el-table-column prop="gender" label="性别">
						<template slot-scope="scope">
							{{ scope.row.gender == 1 ? '男' : scope.row.gender == 2 ? '女' : '保密' }}
						</template>
					</el-table-column>
					<el-table-column prop="personName" label="访问对象"></el-table-column>
					<el-table-column prop="status" min-width="100" label="审核状态">
						<template slot-scope="scope">
							<el-tag type="success" v-if="scope.row.status == 2">通过</el-tag>
							<el-tag v-if="scope.row.status == 1">未审核</el-tag>
							<el-tag type="info" v-if="scope.row.status == 0">未通过</el-tag>
						</template>
					</el-table-column>
					<el-table-column prop="visitStartTime" label="访问时间"></el-table-column>
					<el-table-column prop="visitPurpose" label="访问理由"></el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import define from '@/components/define/define';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import { pament } from '@/utils/doman.js';
export default {
	data() {
		return {
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			sum: [],
			displays: true
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination
	},
	watch: {
		sum(newval) {
			this.displays = true;
			if (newval.length > 0) {
				this.displays = false;
			}
		}
	},
	activated() {
		sessionStorage.removeItem('titlekey');
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 130;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		...mapActions(['Navtitle', 'menutitle']),
		async getdata() {
			let listdata = await api.Visitorindex({
				page: this.page,
				pagesize: this.pagesize
			});
			if(listdata){
				this.tableData = listdata.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = listdata.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		updatas(data) {
			this.Navtitle('访客计划/访客登记/修改访客信息');
			this.$router.push({
				path: '/visitor_up',
				query: {
					selectid: data
				}
			});
		},
		adddata() {
			this.Navtitle('访客计划/访客登记/录入');
			this.$router.push('/visitor_up');
		},
		delects(data) {
			this.$confirm('您确定要把当前姓名为 :' + data.personName + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.visitor_del({ id: data.id });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	height: inherit;
	overflow: hidden;
	.mianlist {
		margin: 0 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-start;
	flex-wrap: wrap;
	margin-top: 5px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
