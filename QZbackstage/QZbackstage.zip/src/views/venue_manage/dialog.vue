<template>
	<div class="lindliog" v-if="dialogVisible">
		<el-dialog :title="title" :visible.sync="dialogVisible" :close-on-click-modal="false" :width="width + 'px'" :before-close="handleClose">
			<div style="width: 100%;display: flex;justify-content: center;">
				<div>
					<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-position="top" label-width="100px" class="demo-ruleForm">
						<el-form-item label="训练馆名称" prop="name"><el-input placeholder="训练馆名称" style="width: 18.75rem;" v-model="ruleForm.name"></el-input></el-form-item>
						<el-form-item label="排序" prop="sort">
							<el-input placeholder="排序值越小越靠前" clearable style="width: 18.75rem;" v-model.number="ruleForm.sort"></el-input>
						</el-form-item>
						<el-form-item label="关联门禁" prop="door">
							<el-select v-model="ruleForm.door" multiple style="width: 18.75rem;" clearable placeholder="请选择关联门禁">
								<el-option v-for="(item, index) in options" :key="index" :label="item.name" :value="item.id"></el-option>
							</el-select>
						</el-form-item>

						<el-form-item label="训练馆图片" prop="imgae">
							<el-upload
								class="avatar-uploader"
								accept="image/jpeg"
								:action="urls"
								:show-file-list="false"
								:on-success="handleAvatarSuccess"
								:before-upload="beforeAvatarUpload"
							>
								<el-image fit="contain" v-if="ruleForm.imgae" :src="ruleForm.imgae"></el-image>
								<i v-else class="el-icon-plus avatar-uploader-icon"></i>
							</el-upload>
						</el-form-item>
					</el-form>
				</div>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button type="primary" @click="Submit('ruleForm')">确 定</el-button>
				<el-button @click="handleClose">取 消</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
import define from '@/components/define/define';
import api from '@/utils/api.js';
import { URL } from '@/utils/doman.js';
export default {
	props: ['title', 'width'],
	data() {
		return {
			ruleForm: {
				img: '',
				imgae: ''
			},
			dialogVisible: false,
			options: [],
			urls:'',
			rules: {
				name: [{ required: true, message: '请输入训练馆名称', trigger: 'blur' }],
				sort: [{ required: true, message: '排序不能为空' }, { type: 'number', message: '必须为数字值' }],
				door: [{ required: true, message: '请选择关联门禁', trigger: 'blur' }],
				imgae: [{ required: true, message: '请上传管理场地图片', trigger: 'change' }]
			}
		};
	},
	created() {
		this.urls=URL+'user/public/upfile'
		this.getdata();
	},
	methods: {
		async getdata() {
			let listdata = await api.venueget_door({});
			if (listdata) {
				this.options = listdata.data;
			}
		},
		handleClose() {
			this.dialogVisible = false;
			for (let item in this.ruleForm) {
				this.ruleForm[item] = '';
			}
		},
		Submit(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					let datalist = await api.venuesubmit(this.ruleForm);
					if (datalist) {
						this.$message.success(datalist.msg);
						this.$emit('Submit');
						this.handleClose();
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		handleAvatarSuccess(res, file) {
			this.ruleForm.imgae = URL + res.data;
			this.ruleForm.img = res.data;
		},
		beforeAvatarUpload(file) {
			// const isJPG = file.type === 'image/jpeg';
			const isLt2M = file.size / 1024 / 1024 < 2;

			// if (!isJPG) {
			// 	this.$message.error('上传头像图片只能是 JPG 格式!');
			// }
			if (!isLt2M) {
				this.$message.error('上传头像图片大小不能超过 2MB!');
			}
			return isLt2M;
		}
	}
};
</script>

<style scoped>
.avatar-uploader >>> .el-upload {
	display: flex;
	justify-content: center;
	width: 18.75rem;
}
.avatar-uploader >>> .el-upload img {
	display: inline-block;
}
.avatar-uploader .el-upload {
	border: 1px dashed #d9d9d9;
	border-radius: 6px;
	cursor: pointer;
	position: relative;
	overflow: hidden;
}
.avatar-uploader >>> .el-upload:hover {
	border-color: #409eff;
}
.avatar-uploader-icon {
	font-size: 30px;
	color: #8c939d;
	width: 178px;
	height: 178px;
	line-height: 178px;
	text-align: center;
}

.lindliog >>> .el-form-item {
	margin-bottom: 10px;
}
.lindliog >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.lindliog >>> .el-dialog__body {
	padding: 20px;
}
.lindliog >>> .el-dialog__header {
	border-bottom: 1px solid #e3e3e3;
}
.lindliog >>> .el-dialog__title {
	font-size: 16px;
}
.lindliog >>> .el-dialog__footer {
	background: #f5f5f5;
	padding: 18px 20px 12px;
}
.lindliog >>> .el-dialog__footer .el-button {
	width: 96px;
	font-size: 16px;
}
.lindliog >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}
</style>
