<template>
	<div class="contex">
		<div class="miancont">
			<div class="mianall">
				<div class="listall">
					<div class="imgeas" v-for="(item, index) in tableData" :key="index">
						<div class="ketimgae">
							<img class="limgks" :src="item.imgae" />
							<div class="litop">
								<el-popover placement="bottom-start" width="44" trigger="click">
									<div class="likeys">
										<!-- <div>
											<el-popover placement="left-start" width="40" trigger="hover">
												<div class="limins">查看</div>
												<img src="./imge/kan.png" slot="reference" />
											</el-popover>
										</div> -->
										<div>
											<el-popover placement="left-start" width="40" trigger="hover">
												<div class="limins">修改</div>
												<img src="./imge/gai.png" slot="reference" @click="updatas(item)"/>
											</el-popover>
										</div>
										<div>
											<el-popover placement="left-start" width="40" trigger="hover">
												<div class="limins">删除</div>
												<img src="./imge/shan.png" slot="reference" @click="delects(item.id)" />
											</el-popover>
										</div>
									</div>
									<div class="imglis" slot="reference"><img src="./imge/img.png" /></div>
								</el-popover>
							</div>
						</div>
					</div>
					<div class="imgeas">
						<div class="addlimt" @click="addto"><i class="el-icon-plus"></i></div>
					</div>
					<div style="height: 120px;width: 100%;"></div>
				</div>
				<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
			</div>
		</div>
		<dialogs ref="dialogs" :title="title" :width="600" @Submit="Submit" />
	</div>
</template>

<script>
import bus from '@/components/common/bus.js';
import api from '@/utils/api.js';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import dialogs from './dialog.vue';
import { URL } from '@/utils/doman.js';
export default {
	data() {
		return {
			page: 1,
			pagesize: 20,
			tableData: [],
			title: ''
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		dialogs
	},
	watch: {},
	activated() {
		bus.$emit('colour', '#ececec');
		this.getdata();
	},
	created() {},
	methods: {
		delects(data) {
			this.$confirm('您确定要把当前这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.venue_del({ id: data });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		Submit() {
			this.getdata();
		},
		addto() {
			this.title = '添加训练场';
			this.$refs.dialogs.dialogVisible = true;
		},
		updatas(data){
			this.title = '修改训练场';
			for(let i in data){
				this.$set(this.$refs.dialogs.ruleForm,i,data[i])
			}
			// this.$refs.dialogs.ruleForm=data
			this.$refs.dialogs.dialogVisible = true;
		},
		async getdata() {
			let datalist = await api.venue_list({
				page: this.page,
				pagesize: this.pagesize
			});
			if (datalist) {
				datalist.data.data.map(item => {
					this.$set(item,'imgae',URL + item.img)
				});
				this.tableData = datalist.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = datalist.data.count;
				});
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/per.css');
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.limins {
	width: 100%;
	height: 30px;
	display: flex;
	justify-content: center;
	align-items: center;
}
.likeys {
	width: 100%;
	height: 88px;
	overflow: hidden;
	display: flex;
	flex-direction: column;
	div {
		width: 100%;
		height: 44px;
		display: flex;
		justify-content: center;
		align-items: center;
		cursor: pointer;
		&:hover {
			background: #dfedff;
		}
		img {
			width: 20px;
			height: 22px;
			display: block;
		}
	}
}
.contex {
	width: 100%;
	height: inherit;
	background: #ececec;
	.miancont {
		width: 98%;
		height: 100%;
		padding: 0 1%;
		.mianall {
			width: 100%;
			height: 100%;
			position: relative;
			.listall {
				width: 100%;
				height: 100%;
				overflow: auto;
				display: flex;
				flex-wrap: wrap;
				&::-webkit-scrollbar {
					width: 2px;
					height: 5px;
					/**/
				}
				&::-webkit-scrollbar-track {
					background: #ececec;
					border-radius: 2px;
				}
				&::-webkit-scrollbar-thumb {
					background: #1e7fff;
					border-radius: 10px;
				}
				&::-webkit-scrollbar-thumb:hover {
					background: #1e7fff;
				}
				&::-webkit-scrollbar-corner {
					background: #1e7fff;
				}
				.imgeas {
					display: flex;
					justify-content: center;
					align-items: center;
					padding-top: 10px;
					width: 32%;
					padding-right: 1.33%;
					height: 40%;
					.addlimt {
						width: 220px;
						height: 220px;
						background: #ffffff;
						border: 1px dashed #d9d9d9;
						border-radius: 12px;
						display: flex;
						justify-content: center;
						align-items: center;
						transition: all 0.2s;
						-ms-transition: all 0.2s;
						cursor: pointer;
						i {
							color: #cecece;
							font-size: 150px;
							transition: all 0.2s;
							-ms-transition: all 0.2s;
						}
						&:hover {
							border: 1px dashed #409eff;
							i {
								color: #409eff;
							}
						}
					}
					.ketimgae {
						width: 100%;
						height: 100%;
						border-radius: 12px;
						overflow: hidden;
						background: #ffffff;
						position: relative;
						.litop {
							position: absolute;
							top: 20px;
							width: 100%;
							height: 50px;
							z-index: 9;
							display: flex;
							justify-content: flex-end;
							.imglis {
								cursor: pointer;
								margin-right: 30px;
								width: 44px;
								height: 44px;
								border-radius: 10px;
								overflow: hidden;
								background: floralwhite;
								border: 1px solid #ffffff;
								&:active {
									border: 1px solid #6bc7ff;
								}
								img {
									width: 100%;
									height: 100%;
								}
							}
						}
						&:hover {
							.limgks {
								transform: scale(1.1);
								-ms-transform: scale(1.1);
							}
						}
						.limgks {
							position: absolute;
							top: 0;
							z-index: 1;
							width: 100%;
							height: 100%;
							transition: all 0.6s;
							-ms-transition: all 0.8s;
						}
					}
				}
			}
			.bont {
				width: 100%;
				background: #ececec;
				border-top: 1px solid #dfdfdf;
				position: absolute;
				z-index: 1;
				bottom: 17px;
				display: flex;
				align-items: flex-start;
			}
		}
	}
}
</style>
