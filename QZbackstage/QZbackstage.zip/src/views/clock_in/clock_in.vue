<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<div class="listname"><el-button style="width: 76px;" @click="exporttable">导出</el-button></div>
			<div class="listname1">
				<el-input placeholder="搜索姓名" style="width: 18rem;margin-right: 10px;" v-model.trim="name"></el-input>
				<el-input placeholder="请输入您要查询得天数" style="width: 18rem;margin-right: 10px;" maxlength="5" show-word-limit v-model.trim="t_type"></el-input>
				<el-button type="primary" style="width: 78px;background-color: #1E7FFF;" @click="queryfrom">查询</el-button>
				<el-button style="width: 78px;" @click="Reset">重置</el-button>
			</div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
					<el-table-column type="index" label="排序"></el-table-column>
					<el-table-column prop="personName" label="姓名"></el-table-column>
					<el-table-column prop="gender" label="性别">
						<template slot-scope="scope">
							{{ scope.row.gender == 1 ? '男' : scope.row.gender == 2 ? '女' : '保密' }}
						</template>
					</el-table-column>
					<el-table-column prop="phoneNo" label="手机号码"></el-table-column>
					<el-table-column prop="company" label="所属单位"></el-table-column>
					<el-table-column prop="identityType" label="人员身份"></el-table-column>
					<el-table-column prop="jobPost" label="所属运动队"></el-table-column>
					<el-table-column prop="eventTime" label="打卡时间"></el-table-column>
					<el-table-column label="操作" min-width="100">
						<template slot-scope="scope">
							<el-popover placement="top" popper-class="popper" trigger="hover" content="修改打卡时间">
								<el-button slot="reference" icon="el-icon-edit" type="text" size="small" @click="updatas(scope.row)"></el-button>
							</el-popover>
							<el-popover placement="top" popper-class="popper" trigger="hover" content="删除打卡记录">
								<el-button slot="reference" type="text" icon="el-icon-delete" @click="delects(scope.row)" size="small"></el-button>
							</el-popover>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		<dialogs ref="dialogs" :title="title" :width="500" @Submit="Submit" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import pagination from '@/components/common/pagination';
import dialogs from './dialog.vue';
export default {
	data() {
		return {
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			name: '',
			title: '',
			t_type: '',
			after:true
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		dialogs
	},
	watch: {
		t_type(val) {
			if (val == '') {
				return false;
			}
			this.after = true;
			var reg = /^\d+$|^\d+[.]?\d+$/;
			if (!reg.test(val)) {
				this.after = false;
				this.$message.warning('只能输入数字值');
			}
		}
	},
	activated() {
		sessionStorage.removeItem('titlekey');
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 150;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		Submit() {
			this.getdata();
		},
		updatas(data) {
			this.$nextTick(() => {
				this.title = `修改 ${data.personName} 打卡时间`;
				this.$refs.dialogs.ruleForm.id = data.id;
				this.$set(this.$refs.dialogs.ruleForm, 'eventTime', data.eventTime);
				this.$refs.dialogs.dialogVisible = true;
			});
		},
		delects(data) {
			this.$confirm('您确定要把当前姓名为 :' + data.personName + '  这条数据删除吗?', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.events_del({ id: data.id });
					if (listdata) {
						this.$message.success(listdata.msg);
						this.getdata();
					}
				})
				.catch(() => {});
		},
		exporttable() {
			this.$confirm('您确定要把当前表格导出吗？', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.venueevents({ page: this.page, pagesize: this.pagesize,t_type:this.t_type, excel: 1 });
					if (listdata) {
						window.location.href = listdata.data.url;
					}
				})
				.catch(() => {});
		},
		queryfrom() {
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		Reset() {
			this.name = '';
			this.page = 1;
			this.t_type='';
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		async getdata() {
			let listdata = await api.venueevents({
				page: this.page,
				pagesize: this.pagesize,
				name: this.name,
				day:this.t_type
			});
			this.tableData = listdata.data.data;
			this.$nextTick(() => {
				this.$refs.pagination.total = listdata.data.count;
			});
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	height: 98%;
	.mianlist {
		margin: 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: space-between;
	flex-wrap: wrap;
	margin: 10px 10px 10px 0;
	width: 100%;
}
.listname1 {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-right: 0.8rem;
	margin-left: 0.8rem;
	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
