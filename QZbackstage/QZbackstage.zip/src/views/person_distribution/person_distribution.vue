<template>
	<div class="contex">
		<div class="miancont">
			<div class="mianall">
				<div class="listall">
					<div class="imgeas" v-for="(item, index) in imgData" :key="index">
						<div class="ketimgae" @click="choice(item)">
							<img class="limgks" :src="item.imgae" />
							<div class="litop">
								<div class="frost linhet">
									<div>人数：</div>
									<div>{{ item.count }}</div>
								</div>
								<div class="frost">
									<div>场馆名称：</div>
									<div>{{ item.name }}</div>
								</div>
								<div class="limgs" :style="{ background: '#' + item.color }"></div>
							</div>
						</div>
					</div>
					<div style="height: 400px;width: 100%;"></div>
				</div>
				<div class="miantable">
					<div class="handle-box">
						<div class="listname">
							<div style="width: 300px;margin-right: 10px;">
								当前表格数据：
								<el-tag>{{ title == '' ? '全部' : title }}</el-tag>
							</div>
							<el-button style="width: 78px;" @click="Reset">重置</el-button>
							<el-button style="width: 78px;" @click="exporttable">导出</el-button>
						</div>
					</div>
					<div class="maintables">
						<template>
							<el-table :data="tableData" stripe :height="210" ref="multipleTable">
								<el-table-column type="index" width="60" label="排序"></el-table-column>
								<el-table-column prop="personName" label="姓名"></el-table-column>
								<el-table-column prop="gender" label="性别">
									<template slot-scope="scope">
										{{ scope.row.gender == 1 ? '男' : scope.row.gender == 2 ? '女' : '保密' }}
									</template>
								</el-table-column>
								<el-table-column prop="phoneNo" label="手机号码"></el-table-column>
								<el-table-column prop="company" label="所属单位"></el-table-column>
								<el-table-column prop="identityType" label="人员身份"></el-table-column>
								<el-table-column prop="jobPost" label="所属运动队"></el-table-column>
							</el-table>
						</template>
					</div>
				</div>
				<div class="bont"><pagination style="padding-top: 20px;" ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
			</div>
		</div>
	</div>
</template>

<script>
import bus from '@/components/common/bus.js';
import api from '@/utils/api.js';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
// import dialogs from './dialog.vue';
import { URL } from '@/utils/doman.js';
export default {
	data() {
		return {
			displays: true,
			page: 1,
			pagesize: 20,
			imgData: [],
			tableData: [],
			title: '',
			venue_id: ''
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination
		// dialogs
	},
	watch: {},
	activated() {
		this.getdata();
		this.setdata();
	},
	created() {},
	methods: {
		exporttable() {
			this.$confirm('您确定要把当前表格导出吗？', '提示', {
				cancelButtonText: '取消',
				confirmButtonText: '确定',
				type: 'warning'
			})
				.then(async () => {
					let listdata = await api.venueevents({ page: this.page, venue_id: this.venue_id, title: this.title, pagesize: this.pagesize, excel: 1 });
					if (listdata) {
						window.location.href=listdata.data.url
					}
				})
				.catch(() => {});
		},
		choice(data) {
			this.title = data.name;
			this.venue_id = data.id;
			this.setdata();
		},
		Reset() {
			this.title = '';
			this.venue_id = '';
			this.setdata();
		},
		async setdata() {
			let list = await api.venueevents({ page: this.page, pagesize: this.pagesize, venue_id: this.venue_id });
			if (list) {
				this.tableData = list.data.data;
				this.$nextTick(() => {
					this.$refs.pagination.total = list.data.count;
				});
			}
		},
		async getdata() {
			let datalist = await api.venue_list1();
			if (datalist) {
				datalist.data.data.map(item => {
					this.$set(item, 'imgae', URL + item.img);
				});
				this.imgData = datalist.data.data;
			}
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.setdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.setdata();
		}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: flex-end;
	flex-wrap: wrap;
	margin-top: 5px;
}
.listname {
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-end;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.contex {
	width: 100%;
	height: inherit;
	.miancont {
		width: 98%;
		height: 100%;
		padding: 0 1%;
		.mianall {
			width: 100%;
			height: 100%;
			position: relative;
			.listall {
				width: 100%;
				height: 100%;
				overflow: auto;
				display: flex;
				flex-wrap: wrap;
				&::-webkit-scrollbar {
					width: 2px;
					height: 5px;
					/**/
				}
				&::-webkit-scrollbar-track {
					background: #ececec;
					border-radius: 2px;
				}
				&::-webkit-scrollbar-thumb {
					background: #1e7fff;
					border-radius: 10px;
				}
				&::-webkit-scrollbar-thumb:hover {
					background: #1e7fff;
				}
				&::-webkit-scrollbar-corner {
					background: #1e7fff;
				}
				.imgeas {
					display: flex;
					justify-content: center;
					align-items: center;
					padding-top: 20px;
					width: 32%;
					padding-right: 1.33%;
					height: 50%;
					.ketimgae {
						width: 100%;
						height: 100%;
						border-radius: 12px;
						overflow: hidden;
						background: #ffffff;
						position: relative;
						cursor: pointer;
						// &:hover {
						// 	.limgks {
						// 		transform: scale(.9);
						// 		-ms-transform: scale(.9);
						// 	}
						// }
						.litop {
							width: 100%;
							height: 25%;
							color: #595959;
							position: relative;
							.limgs {
								position: absolute;
								top: 0;
								width: 100%;
								height: 100%;
								opacity: 0.6;
							}
							.frost {
								width: 95%;
								padding: 0 0 0 5%;
								height: 50%;
								display: flex;
							}
							.linhet {
								display: flex;
								align-items: center;
							}
						}
						.limgks {
							width: 100%;
							height: 75%;
							display: block;
							transition: all 0.6s;
							-ms-transition: all 0.8s;
						}
					}
				}
			}
			.bont {
				width: 100%;
				background: #ffffff;
				position: absolute;
				bottom: 10px;
				display: flex;
				align-items: flex-start;
			}
			.miantable {
				width: 100%;
				position: absolute;
				bottom: 100px;
				border-top: 1px solid #dfdfdf;
				height: 250px;
				background: #ffffff;
				.maintables {
					margin-top: 5px;
					width: 100%;
					height: 219px;
				}
			}
		}
	}
}
</style>
