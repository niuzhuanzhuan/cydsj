<template>
	<div class="miancont" ref="miancont">
		<div class="handle-box">
			<!-- <div class="listname"><el-button type="text" icon="el-icon-plus" @click="adddata">导出</el-button></div> -->
			<div class="listname">
				<el-select v-model="sid" placeholder="组织选择" clearable filterable style="width: 18rem;">
					<el-option v-for="(item, index) in options" :key="index" :label="item.name" :value="item.sid"></el-option>
				</el-select>
			</div>
			<div class="listname">
				<el-select v-model="team_id" placeholder="运动队" clearable filterable style="width: 18rem;">
					<el-option v-for="(item, index) in teamarr" :key="index" :label="item.name" :value="item.team_id"></el-option>
				</el-select>
			</div>
			<div class="listname"><el-input placeholder="输入名字" style="width: 18rem;"  v-model="name"></el-input></div>
			<div class="listname1">
				<el-button type="primary" style="width: 78px;background-color: #1E7FFF;" @click="queryfrom">查询</el-button>
				<el-button style="width: 78px;" @click="Reset">重置</el-button>
			</div>
		</div>
		<div class="mianlist">
			<template>
				<el-table :data="tableData" stripe :height="heights" ref="multipleTable">
					<el-table-column type='index' fixed="left" width="60" label="排序"></el-table-column>
					<el-table-column prop="user_name" min-width="100" label="姓名"></el-table-column>
					<el-table-column prop="user_logo" min-width="100" label="用户头像">
						<template slot-scope="scope">
							<el-avatar :src="scope.row.user_logo"></el-avatar>
						</template>
					</el-table-column>
					<el-table-column prop="count" min-width="100" label="运动次数"></el-table-column>
					
					<el-table-column prop="s_zh" min-width="120" label="平均综合得分">
						<template slot-scope="scope">
							{{ scope.row.s_zh / scope.row.count.toFixed(2) }}
						</template>
					</el-table-column>
					<el-table-column prop="s_sd" min-width="100" label="平均速度">
						<template slot-scope="scope">
							{{ scope.row.s_sd / scope.row.count.toFixed(2) }}
						</template>
					</el-table-column>
					<el-table-column prop="s_ll" min-width="100" label="平均力量">
						<template slot-scope="scope">
							{{ scope.row.s_ll / scope.row.count.toFixed(2) }}
						</template>
					</el-table-column>
					<el-table-column prop="s_nl" min-width="100" label="平均耐力">
						<template slot-scope="scope">
							{{ scope.row.s_nl / scope.row.count.toFixed(2) }}
						</template>
					</el-table-column>
					<el-table-column prop="s_lm" min-width="100" label="平均灵敏">
						<template slot-scope="scope">
							{{ scope.row.s_lm / scope.row.count.toFixed(2) }}
						</template>
					</el-table-column>
					<el-table-column prop="s_rr" min-width="100" label="平均柔韧">
						<template slot-scope="scope">
							{{ scope.row.s_rr / scope.row.count.toFixed(2) }}
						</template>
					</el-table-column>
					<el-table-column prop="s_xt" min-width="100" label="平均协调">
						<template slot-scope="scope">
							{{ scope.row.s_xt / scope.row.count.toFixed(2) }}
						</template>
					</el-table-column>
					<el-table-column prop="team_name" min-width="100" label="团队名称"></el-table-column>
					<el-table-column prop="team_logo" min-width="100" label="团队logo">
						<template slot-scope="scope">
							<el-avatar :src="scope.row.team_logo"></el-avatar>
						</template>
					</el-table-column>
					<el-table-column prop="school_name" min-width="100" label="组织"></el-table-column>
					<el-table-column label="操作" fixed="right" min-width="100">
						<template slot-scope="scope">
							<el-button type="text" size="small" @click="see(scope.row)"><span style="color: #2772FF;">查看</span></el-button>
						</template>
					</el-table-column>
				</el-table>
			</template>
		</div>
		<div class="bont"><pagination ref="pagination" @handleCurrentChange="handleCurrentChange" @handleSizeChange="handleSizeChange" /></div>
		<dialogs ref="dialogs" :title="title" :width="1200" />
	</div>
</template>

<script>
import api from '@/utils/api.js';
import pagination from '@/components/common/pagination';
import { mapGetters, mapActions } from 'vuex';
import dialogs from './dialog.vue';
export default {
	data() {
		return {
			sid: '',
			team_id: '',
			heights: 0,
			page: 1,
			pagesize: 20,
			tableData: [],
			name: '',
			options: [],
			teamarr: [],
			title: ''
		};
	},
	computed: {},
	mounted() {},
	components: {
		pagination,
		dialogs
	},
	watch: {
		sid(news, val) {
			if (news != val) {
				this.setTropsteam();
			}
		}
	},
	activated() {
		sessionStorage.removeItem('titlekey');
		this.setdata();
		this.setTropsteam();
		this.$nextTick(() => {
			let scrollHeight = this.$refs.miancont.scrollHeight - 150;
			this.heights = scrollHeight;
			this.getdata();
		});
	},
	methods: {
		see(val) {
			console.log(val)
			this.$nextTick(() => {
				this.title = val.user_name + '的详细信息';
				// this.$refs.dialogs.ruleForm=val
				let max = 100;
				let froms = [
					{ name: `速度:${val.s_sd/val.count.toFixed(2)}`, max: max },
					{ name: `力量:${val.s_ll/val.count.toFixed(2)}`, max: max },
					{ name: `耐力:${val.s_nl/val.count.toFixed(2)}`, max: max },
					{ name: `灵敏:${val.s_lm/val.count.toFixed(2)}`, max: max },
					{ name: `柔韧:${val.s_rr/val.count.toFixed(2)}`, max: max },
					{ name: `协调:${val.s_xt/val.count.toFixed(2)}`, max: max }
				];
				let arr = [val.s_sd/val.count.toFixed(2), val.s_ll/val.count.toFixed(2), val.s_nl/val.count.toFixed(2), val.s_lm/val.count.toFixed(2), val.s_rr/val.count.toFixed(2), val.s_xt/val.count.toFixed(2)];
				this.$refs.dialogs.getdata(arr, froms);
				this.$refs.dialogs.dialogVisible = true;
			});
		},
		async setdata() {
			let datalist = await api.Tropsschool();
			if (datalist) {
				this.options = datalist.data;
			}
		},
		async setTropsteam() {
			let datalist = await api.Tropsteam({ sid: this.sid });
			if (datalist) {
				this.teamarr = datalist.data;
			}
		},
		...mapActions(['Navtitle', 'menutitle']),
		queryfrom() {
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		Reset() {
			this.name = '';
			this.page = 1;
			this.$nextTick(() => {
				this.$refs.pagination.input = 1;
			});
			this.getdata();
		},
		async getdata() {
			let listdata = await api.get_data1({
				page: this.page,
				pagesize: this.pagesize,
				name: this.name,
				sid: this.sid,
				team_id: this.team_id
			});
			this.tableData = listdata.data.data;
			this.$nextTick(() => {
				this.$refs.pagination.total = listdata.data.count;
			});
		},
		handleSizeChange(data) {
			this.pagesize = data;
			this.getdata();
		},
		handleCurrentChange(data) {
			this.page = data;
			this.getdata();
		},
		adddata() {}
	}
};
</script>
<style scoped>
@import url('../../assets/css/tables.css');
.miansli {
	width: 100%;
	height: 100%;
}
.h-page-header {
	display: none !important;
}
</style>
<style lang="less" scoped>
@fs14: 14px;
@fs16: 16px;
@fs12: 12px;
@co: #bbbebb;
@co5: #555555;
.miancont {
	height: 98%;
	.mianlist {
		margin: 10px;
		width: calc(100%-40px);
	}
	.bont {
		width: calc(100%-40px);
		display: flex;
		align-items: flex-start;
	}
}
.handle-box {
	display: flex;
	overflow: hidden;
	justify-content: space-between;
	flex-wrap: wrap;
	width: 100%;
}
.listname {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-left: 0.8rem;

	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
.listname1 {
	margin-top: 10px;
	display: flex;
	width: auto;
	align-items: center;
	justify-content: flex-start;
	margin-right: 0.8rem;
	margin-left: 0.8rem;
	.allname {
		min-width: 3rem;
		color: #409eff;
	}
}
</style>
