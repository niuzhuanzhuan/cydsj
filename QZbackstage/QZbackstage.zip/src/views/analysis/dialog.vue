<template>
	<div class="lindliog">
		<el-dialog :title="title" :visible.sync="dialogVisible" :close-on-click-modal="false" :width="width + 'px'" :before-close="handleClose">
			<div class="miall"><div id="radar"></div></div>
		</el-dialog>
	</div>
</template>

<script>
import define from '@/components/define/define';
import api from '@/utils/api.js';
import echarts from 'echarts';
export default {
	props: ['title', 'width'],
	data() {
		return {
			dialogVisible: false
		};
	},
	created() {},
	methods: {
		handleClose() {
			this.dialogVisible = false;
		},
		getdata(val, indicator) {
			this.$nextTick(async () => {
				let list = await document.getElementById('radar');
				let myChart = await echarts.init(list);
				let option = await {
					title: {},
					legend: {},
					radar: {
						indicator: indicator,
						splitNumber: 5,
						name: {
							textStyle: {
								color: '#ffffff'
							}
						},
						splitLine: {
							lineStyle: {
								color: [
									'rgba(15, 200, 97, 0.1)',
									'rgba(15, 200, 97, 0.2)',
									'rgba(15, 200, 97, 0.4)',
									'rgba(15, 200, 97, 0.6)',
									'rgba(15, 200, 97, 0.8)',
									'rgba(15, 200, 97, 1)'
								].reverse()
							}
						},
						splitArea: {
							show: false
						},
						axisLine: {
							lineStyle: {
								color: '#18B473'
							}
						}
					},
					series: [
						{
							type: 'radar',
							data: [val],
							itemStyle: {
								opacity: 0.5,
								color: new echarts.graphic.RadialGradient(0.5, 0.5, 1, [
									{
										color: 'rgb(238, 197, 102)',
										offset: 0
									},
									{
										color: '#18B473',
										offset: 1
									}
								])
							},
							areaStyle: {
								opacity: 0.3
							}
						}
					]
				};
				if (option && typeof option === 'object') {
					myChart.setOption(option, true);
				}
			});
		}
	}
};
</script>

<style scoped lang="less">
.miall {
	width: 100%;
	height: 600px;
	#radar {
		width: 100%;
		height: 100%;
		background: #0c2f54;
	}
}
</style>
