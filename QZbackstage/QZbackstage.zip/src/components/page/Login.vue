<template>
	<div class="login-wrap">
		<div class="mina_login">
		<div class="log_fonst">清镇训练基地管理系统</div>
			<div class="ms-login">
				<div class="ms-title">欢迎登录</div>
				<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="0px" class="ms-content">
					<el-form-item prop="username">
						<el-input v-model="ruleForm.username" placeholder="请输入用户名">
							<template slot="prepend">
								<el-button icon="el-icon-user"></el-button>
								</el-popover>
							</template>
						</el-input>
					</el-form-item>
					<el-form-item prop="password">
						<el-input type="password" show-password placeholder="请输入密码" v-model="ruleForm.password" @keyup.enter.native="submitForm('ruleForm')">
							<template slot="prepend">
								<el-button icon="el-icon-lock"></el-button>
							</template>
						</el-input>
					</el-form-item>
					<el-form-item >
						<template>
							<div class="fonslis">
								<el-checkbox v-model="checked">记住用户名</el-checkbox>
								<el-button type="text" @click="forget">忘记密码</el-button>
							</div>
						</template>
					</el-form-item>
					<div class="login-btn"><el-button type="primary" :disabled="disabled" @click="submitForm('ruleForm')">登录</el-button></div>
				</el-form>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import { mapActions,mapGetters } from 'vuex';
export default {
	data() {
		return {
			title: '获取验证码',
			checked: false,
			disabled: false,
			tcler: '',
			ruleForm: {
				username: '',
				password: ''
			},
			rules: {
				username: [
					{
						required: true,
						message: '请输入用户名',
						trigger: 'blur'
					}
				],
				password: [
					{
						required: true,
						message: '请输入密码',
						trigger: 'blur'
					}
				]
			}
		};
	},
	activated() {
		sessionStorage.clear();
		localStorage.clear();
		if(localStorage['checked']){
			this.ruleForm=JSON.parse(localStorage['checked'])
			this.checked=true
		}
	},
	watch:{
		checked(newval,val){
			if(newval){
				localStorage['checked']=JSON.stringify(this.ruleForm)
			}else{
				localStorage.removeItem('checked')
			}
		}
	},
	methods: {
		forget(){
			this.$message.warning('请联系管理员进行密码重置')
		},
		...mapActions(['token_get']),
		submitForm(ruleForm) {
			if(this.checked){
				localStorage['checked']=JSON.stringify(this.ruleForm)
			}
			this.$refs[ruleForm].validate(async(valid) => {
			          if (valid) {
						 let datalist = await api.login(this.ruleForm)
						 if(datalist){
							 this.$message.success('登录成功')
							 this.disabled=false;
							 this.token_get(datalist.data)
							 this.$router.push('/personal_center');
						 }
						
					  } else {
			            console.log('error submit!!');
			            return false;
			          }
			        });
		}
	}
};
</script>

<style scoped>
	.fonslis{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.ms-content>>>input::-webkit-input-placeholder{
	            color:#ADADAD;
	        }
	.ms-content>>> input::-moz-placeholder{   /* Mozilla Firefox 19+ */
	            color:#ADADAD;
	        }
	.ms-content>>> input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
	            color:#ADADAD;
	        }
	.ms-content>>> input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
	            color:#ADADAD;
	        }
	.ms-content>>>.el-input__inner{
		height: 60px;
		line-height: 60px;
		background: #EAEAEA;
		font-size: 24px;
		border: none;
	}
	.ms-content>>>.el-input-group__prepend{
		background: #EAEAEA;
		border: none;
		font-size: 24px;
	}
	.ms-content>>>.el-form-item{
		margin-bottom: 35px;
	}
	.ms-content>>>.el-form-item:nth-child(even){
		margin-bottom: 20px;
	}
	.ms-content>>>.el-checkbox{
		color: black;
	}
	.ms-content>>>.el-form-item__content{
		line-height: 0;
	}
.login-wrap {
	position: relative;
	width: 100%;
	height: 100vh;
	background-image: url(../../assets/login/login.png);
	background-size: 100%;
}

.ms-title {
	width: 486px;
	line-height: 50px;
	padding: 65px 60px 0 60px;
	font-size: 36px;
	color: black;
}

.mina_login{
	width: 100%;
	height: 100%;
	position: absolute;
}
.log_fonst{
	font-size: 48px;
	 color: #FFFFFF;
	 padding-left: 10%;
	 margin-top: 50px;
}
.ms-login {
	position: absolute;
	bottom: 0;
	width: 606px;
	height: 530px;
	margin: 0 0 140px 11%;
	border-radius: 5px;
	background: #FFFFFF;
	/* overflow: hidden; */
}

.ms-content {
	padding: 35px 60px;
}

.login-btn {
	text-align: center;
}

.login-btn button {
	width: 100%;
	height: 60px;
	font-size: 24px;
	background: #1084FF;
	margin: -10px 0 0 0;
}

.login-tips {
	font-size: 12px;
	line-height: 30px;
	color: #0d2d35;
}

.netxpwd :hover {
	/* color: red; */
	cursor: pointer;
}
</style>
