<template>
	<div class="header">
		<div class="her_left">
			<div class="left_font">清镇训练基地管理系统</div>
			<el-divider direction="vertical"></el-divider>
			<div class="shu">系统管理</div>
			<div class="shu active" @click="comithert">刷新页面</div>
		</div>
		<div class="her_rigth">
			<!-- <img style="margin-right: 24px;cursor: pointer;" src="../../assets/home/operation.png" /> -->

			<el-dropdown class="user-name" trigger="click" @command="handleCommand">
				<span class="el-dropdown-link">
					<img style="margin-right: 6px;" src="../../assets/home/user.png" />
					<!-- <i style="margin-right: 6px;color: #FFFFFF; font-size: 24px;" class="el-icon-user"></i> -->
					{{ setinformation?setinformation:'' }}
					<i style="margin-left: 12px;" class="el-icon-arrow-down"></i>
				</span>
				<el-dropdown-menu slot="dropdown">
					<el-dropdown-item divided command="modify">修改密码</el-dropdown-item>
					<el-dropdown-item divided command="loginout">退出登录</el-dropdown-item>
				</el-dropdown-menu>
			</el-dropdown>
		</div>
		<el-dialog title="修改密码" :visible.sync="dialogVisible" :close-on-click-modal="false" width="736px" :before-close="handleClose">
			<div style="width: 100%;display: flex;justify-content: center;">
				<div style="width: 350px;">
					<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-position="top" label-width="100px" class="demo-ruleForm">
						<el-form-item label="旧密码" prop="password"><el-input v-model="ruleForm.password" show-password autocomplete="off"></el-input></el-form-item>
						<el-form-item label="新密码" prop="password1"><el-input v-model="ruleForm.password1" show-password autocomplete="off"></el-input></el-form-item>
						<el-form-item label="确认密码" prop="password2"><el-input v-model="ruleForm.password2" show-password autocomplete="off"></el-input></el-form-item>
					</el-form>
				</div>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button type="primary" @click="updatepassword('ruleForm')">确 定</el-button>
				<el-button @click="handleClose">取 消</el-button>
			</span>
		</el-dialog>
	</div>
</template>
<script>
import bus from './bus';
import api from '@/utils/api';
import define from '../define/define';
import { mapActions, mapGetters } from 'vuex';
export default {
	data() {
		var validatePass = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('请输入密码'));
			} else {
				if (!define.depawss.test(value)) {
					callback(new Error('密码格式为6-16位数字或字母组成'));
				} else {
					callback();
				}
			}
		};
		var validatePass2 = (rule, value, callback) => {
			if (value === '') {
				callback(new Error('请再次输入密码'));
			} else if (value !== this.ruleForm.password1) {
				callback(new Error('两次输入密码不一致!'));
			} else {
				callback();
			}
		};
		return {
			dialogVisible: false,
			ruleForm: {
				password: '',
				password1: '',
				password2: ''
			},
			rules: {
				password: [{ required: true, message: '请输入旧密码', trigger: 'blur' }],
				password1: [{ required: true, validator: validatePass, trigger: 'blur' }],
				password2: [{ required: true, validator: validatePass2, trigger: 'blur' }]
			}
		};
	},
	watch:{},
	computed: {
		...mapGetters(['setinformation']),
	},
	created() {},
	methods: {
		...mapActions(['settion']),
		// 用户名下拉菜单选择事件
		comithert(){
			location.reload()
		},
		handleCommand(command) {
			if (command == 'loginout') {
				this.$confirm('确定退出系统吗?', '', {
					confirmButtonText: '取消',
					cancelButtonText: '确定',
					type: 'warning',
					showClose: false,
					customClass: 'customClass',
					iconClass: 'el-icon-question',
					cancelButtonClass: 'cancelButtonClass',
					confirmButtonClass: 'confirmButtonClass'
				})
					.then(() => {})
					.catch(() => {
						this.settion();
						this.$router.push('/Login');
					});
			} else {
				this.dialogVisible = true;
			}
		},
		// 侧边栏折叠
		collapseChage() {
			this.collapse = !this.collapse;
			bus.$emit('collapse', this.collapse);
		},
		updatepassword(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					let datalist = await api.passwordEdit({
						username: this.$store.state.information.user.mobile,
						password: this.ruleForm.password,
						password1: this.ruleForm.password1,
						password2: this.ruleForm.password2
					});
					datalist&&this.$message.success(datalist.msg)
					this.$router.push('/')
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		handleClose() {
			this.dialogVisible = false;
		}
	},
	mounted() {}
};
</script>
<style>
.customClass > .el-message-box__btns {
	padding: 5px 30px 30px !important;
}
.customClass > .el-message-box__content {
	padding: 40px 24px 40px 100px;
	font-size: 16px;
	color: black;
}
.customClass > .el-message-box__content .el-message-box__message {
	padding-left: 45px !important;
}
.el-icon-question {
	color: #ffcc00;
	font-size: 30px !important;
}
.cancelButtonClass {
	background: #1e7fff !important;
	color: #ffffff;
	width: 96px;
	height: 42px;
	font-size: 16px;
}
.cancelButtonClass:hover {
	background: #409eff !important;
	color: #ffffff;
}
.confirmButtonClass {
	background-color: #ffffff !important;
	color: #000000 !important;
	width: 96px;
	height: 42px;
	font-size: 16px;
	border: 1px solid #cccccc !important;
}
.confirmButtonClass:hover {
	background-color: #f4f4f5 !important;
}
</style>
<style scoped>
.header >>> .el-form-item {
	margin-bottom: 10px;
}
.header >>> .el-form-item__label {
	padding: 0;
	display: flex;
	flex-direction: row-reverse;
	justify-content: flex-end;
}
.header >>> .el-form-item__label::before {
	margin-left: 5px;
}
.header >>> .el-dialog__body {
	padding: 20px;
}
.header >>> .el-dialog__header {
	border-bottom: 1px solid #e3e3e3;
}
.header >>> .el-dialog__title {
	font-size: 16px;
}
.header >>> .el-dialog__footer {
	background: #f5f5f5;
	padding: 18px 20px 12px;
}
.header >>> .el-dialog__footer .el-button {
	width: 96px;
	font-size: 16px;
}
.el-dropdown-menu {
	top: 35px !important;
	padding: 0;
}
.el-dropdown-menu__item--divided:before {
	height: 0;
}
.el-dropdown-menu li {
	border-top: none !important;
	height: 38px;
	line-height: 38px;
}
.el-dropdown-menu li:nth-child(1) {
	border-top: none !important;
	border-bottom: 1px solid #ebeef5 !important;
}
</style>
<style scoped lang="less">
@fs24: 24px;
.dlog {
	display: flex;
	// height: 48px;
	align-items: center;
	font-size: 16px;
	i {
		font-size: 24px;
		color: #ffcc00;
	}
}
.header {
	position: relative;
	box-sizing: border-box;
	width: 100%;
	height: 60px;
	color: #fff;
	background: #2772ff;
	display: flex;
	justify-content: space-between;
	position: relative;
	.her_left {
		height: inherit;
		font-size: 18px;
		display: flex;
		align-items: center;
		.left_font {
			padding: 0 30px 0 24px;
		}
		.shu {
			width: 92px;
			height: 34px;
			font-size: 14px;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 4px;
			color: #ffffff;
			opacity: 0.9;
			margin-left: 20px;
			background: rgba(255, 255, 255, 0.2);
		}
		.active{
			user-select: none;
			cursor: pointer;
			&:active{
				background: rgba(11, 141, 255, 0.2);
				color: #ffffff;
			}
		}
	}
	.her_rigth {
		height: inherit;
		padding: 0 12px 0 0;
		display: flex;
		align-items: center;
		color: #ffffff;
		.el-dropdown-link {
			color: #ffffff;
			font-size: 16px;
			cursor: pointer;
		}
	}
}
</style>
