<template>
	<div class="paginas">
		<el-pagination
			:class="setcolour == '' ? '' : 'getcolour'"
			@size-change="handleSizeChange"
			:current-page="currentPage4"
			:page-sizes="[20, 40, 60, 80, 120]"
			:page-size="pagesize"
			layout="total, sizes"
			:total="total"
		></el-pagination>
		<div class="listpaginas">
			<el-input style="width: 88px;" :class="setcolour == '' ? '' : 'getcolour'" v-model.number="input" @blur="inputblur(input)"></el-input>
			<span style="margin-left: 30px;margin-right: 30px;font-size: 14px;color: #606266;">/ {{ sum }}页</span>
			<el-button :class="setcolour == '' ? '' : 'getcolour'" @click="handleCurrentChange(input)">跳转</el-button>
		</div>
	</div>
</template>
<script>
import bus from '@/components/common/bus.js';
export default {
	data() {
		return {
			currentPage4: 1,
			pagesize: 20,
			total: 0,
			input: 1,
			setcolour: ''
		};
	},
	computed: {
		sum() {
			if (this.total % this.pagesize != 0) {
				return parseInt(this.total / this.pagesize) + 1;
			}
			return parseInt(this.total / this.pagesize);
		}
	},
	watch:{},
	created() {
		bus.$on('colour', item => {
			this.setcolour = item;
		});
	},
	methods: {
		handleSizeChange(val) {
			this.pagesize=val
			this.$emit('handleSizeChange', val);
		},
		handleCurrentChange(val) {
			this.$emit('handleCurrentChange', val);
		},
		inputblur(val) {
			if (val === '') {
				this.input = 1;
			}
			if (val >= this.sum) {
				this.input = this.sum;
			}
		}
	},
	mounted() {}
};
</script>

<style scoped>
.getcolour {
	background: #ececec;
}
.getcolour >>> .el-input__inner {
	background-color: #ececec !important;
}
.paginas {
	width: inherit;
	display: flex;
	justify-content: space-between;
	align-items: flex-start;
	padding: 10px;
}
.paginas >>> .el-input--mini .el-input__inner {
	height: 42px !important;
}
.paginas >>> .el-pagination__total {
	height: 42px !important;
	line-height: 42px;
}
.listpaginas >>> .el-input__inner {
	height: 42px !important;
}
.listpaginas >>> .el-button {
	height: 42px !important;
}
</style>
