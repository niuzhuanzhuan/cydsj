<template>
	<div class="wrapper">
		<v-head />
		<v-sidebar />
		<div
			class="content-box"
			:class="{ 'content-collapse': collapse }"
			v-loading="loading"
			:element-loading-text="titles"
			element-loading-spinner="el-icon-loading"
			element-loading-background="rgba(255, 255, 255)"
		>
			<v-tags></v-tags>
			<div class="content">
				<transition name="move" mode="out-in">
					<keep-alive ><router-view v-if="isRouterAlive" /></keep-alive>
				</transition>
			</div>
		</div>
	</div>
</template>

<script>
import vHead from './Header.vue';
import vSidebar from './Sidebar.vue';
import vTags from './Tags.vue';
import bus from './bus';
export default {
	data() {
		return {
			tagsList: [],
			collapse: false,
			isRouterAlive: true,
			loading: false,
			titles:'拼命加载中'
		};
	},
	components: {
		vHead,
		vSidebar,
		vTags
	},
	provide() {
		return {
			reload: this.reload
		};
	},
	created() {
		bus.$on('collapse', msg => {
			this.collapse = msg;
		});
		bus.$on('loading', msg => {
			this.loading = msg.msg;
			if(msg.titles){
				this.titles =msg.titles
			}
		});
		// // 只有在标签页列表里的页面才使用keep-alive，即关闭标签之后就不保存到内存中了。
		// bus.$on('tags', msg => {
		// 	let arr = [];
		// 	for(let i = 0, len = msg.length; i < len; i++) {
		// 		msg[i].name && arr.push(msg[i].name);
		// 	}
		// 	this.tagsList = arr;
		// })
	},
	methods: {
		reload() {
			this.isRouterAlive = false;
			this.$nextTick(() => {
				this.isRouterAlive = true;
			});
		}
	}
};
</script>
<style scoped>
.wrapper {
	width: 100%;
	height: 100vh;
	overflow: hidden;
}
.content {
	width: 100%;
	background: #ffffff;
	overflow-y: auto;
	padding: 0 !important;
}
</style>
<style lang="less" scoped>
.content{
	width: 100%;
	background: #ffffff;
	overflow-y: auto;
	padding: 0 !important;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #1E7FFF;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #1E7FFF;
	}
	&::-webkit-scrollbar-corner {
		background: #1E7FFF;
	}
}
</style>
