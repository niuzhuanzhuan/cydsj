<template>
	<div class="sidebar">
		<el-menu
			class="sidebar-el-menu"
			:default-active="onRoutes"
			:collapse="collapse"
			background-color="#262626"
			text-color="#565656"
			active-text-color="#ffffff"
			unique-opened
			router
		>
			<div class="leftmian"><img @click="collapseChage" src="../../assets/home/operation.png" /></div>
			<template v-for="(item, index) in itemss">
				<template v-if="item.items">
					<el-submenu :index="item.params" :key="index">
						<template slot="title">
							<img class="imgs" :src="urls+item.icon" />
							<span slot="title" style="margin-left: 10px;">{{ item.name }}</span>
						</template>
						<template v-for="(subItem, sjindex) in item.items">
							<el-submenu v-if="subItem.items" :index="subItem.params" :key="sjindex">
								<template slot="title">
									{{ subItem.name }}
								</template>
								<el-menu-item v-for="(threeItem, i) in subItem.items" :key="i" :index="threeItem.params">
									<span>{{ threeItem.name }}</span>
								</el-menu-item>
							</el-submenu>
							<el-menu-item v-else :index="subItem.params" :key="sjindex">{{ subItem.name }}</el-menu-item>
						</template>
					</el-submenu>
				</template>
				<template v-else>
					<el-menu-item :index="item.params" :key="index">
						<img class="imgs" :src="item.icon" />
						<span slot="title" style="margin-left: 10px;">{{ item.name }}</span>
					</el-menu-item>
				</template>
			</template>
		</el-menu>
	</div>
</template>

<script>
import bus from '../common/bus';
import api from '@/utils/api';
import { mapActions } from 'vuex';
import { URL } from '@/utils/doman.js';
export default {
	data() {
		return {
			collapse: false,
			itemss: [],
			routenums: '',
			urls:URL
		};
	},
	computed: {
		onRoutes() {
			if (this.$route.meta.title) {
				this.Navtitle(this.$route.meta.title);
			}
			if(this.$route.path.replace('/', '')!='venue_manage'){
				bus.$emit('colour','')
			}
			return this.$route.path.replace('/', '');
		}
	},
	watch: {},
	created() {
		if(sessionStorage['itemss']){
			this.itemss=JSON.parse(sessionStorage['itemss'])
		}else{
			this.getmeue();
		}
	},
	mounted() {
		if (document.body.clientWidth < 1500) {
			this.collapseChage();
		}
	},
	methods: {
		...mapActions(['Navtitle', 'menutitle']),
		async getmeue() {
			let listdata = await api.menuindex();
			if (listdata) {
				listdata.data.map((item, index) => {
					if (!item.params) {
						this.$set(item, 'params', `${(index += 1)}`);
					}
					if (item.items) {
						item.items.map(jtem => {
							if (!jtem.params) {
								this.$set(jtem, 'params', `${(index += 1)}`);
							}
							if (jtem.items) {
								jtem.items.map(ktem => {
									if (!ktem.params) {
										this.$set(ktem, 'params', `${(index += 1)}`);
									}
								});
							}
						});
					}
				});
				this.itemss = listdata.data;
				sessionStorage['itemss']=JSON.stringify(listdata.data)
			}
		},
		collapseChage() {
			this.collapse = !this.collapse;
			bus.$emit('collapse', this.collapse);
			this.collapses(this.collapse);
		},
		collapses(msg) {
			this.collapse = msg;
		}
	}
};
</script>

<style scoped>
.imgs {
	width: 24px;
}
.sidebar {
	display: block;
	position: absolute;
	left: 0;
	top: 60px;
	height: 100%;
	bottom: 0;
	overflow-y: scroll;
	width: 220px;
}

.sidebar::-webkit-scrollbar {
	width: 0;
}

.sidebar-el-menu:not(.el-menu--collapse) {
	width: 220px;
}

.sidebar > ul {
	height: 100%;
}
.sidebar > ul li ul .el-menu-item {
	padding-left: 60px !important;
}
.sidebar > ul li .el-submenu__title img {
	filter: brightness(70%);
}
.sidebar >>> ul li .el-menu--inline .el-submenu .el-submenu__title {
	padding-left: 60px !important;
}
.sidebar >>> ul li .el-menu--inline .el-submenu ul li {
	padding-left: 70px !important;
}
</style>
<style lang="less" scoped>
.leftmian {
	width: auto;
	background: #262626;
	padding: 26px 26px 0 20px;
	img {
		cursor: pointer;
	}
}
</style>
