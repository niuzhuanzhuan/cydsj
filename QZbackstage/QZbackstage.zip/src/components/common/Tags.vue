<template>
	<div class="tags" :style="{ background: setcolour }">
		<div class="mianlitop">
			<div class="likd">
				<i v-if="decision" @click="$router.go(-1)" class="el-icon-addedbuoumaotubiao09" style="margin-right: 10px;cursor: pointer;font-size: 20px;"></i>
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item v-for="(item, index) in list" :key="index">{{ item }}</el-breadcrumb-item>
				</el-breadcrumb>
			</div>
			<div v-if="decision" v-show="tifrom.titlein" class="toplings">{{ tifrom.titlein }}：{{ tifrom.name }}</div>
		</div>
	</div>
</template>

<script>
import bus from '@/components/common/bus.js';
import { mapActions, mapGetters } from 'vuex';
export default {
	data() {
		return {
			decision: false,
			setcolour: ''
		};
	},
	methods: {},
	created() {
		bus.$on('colour', item => {
			this.setcolour = item;
		});
	},
	computed: {
		tifrom() {
			return this.$store.state.titlekeys;
		},
		list() {
			let that = this;
			if (this.$store.getters.getNavigation.length == 0) {
				return ['系统管理', '个人中心'];
			} else {
				that.decision = false;
				if (this.$store.getters.getNavigation.length > 2) {
					that.decision = true;
				}
				return this.$store.getters.getNavigation;
			}
		}
	},
	watch: {},
	activated() {}
};
</script>
<style lang="less" scoped>
@fs12: 12px;
@fs14: 14px;
@fs16: 16px;
.tags {
	height: inherit;
	.mianlitop {
		.likd {
			display: flex;
			align-items: center;
			font-size: @fs16 !important;
			padding: 15px 0 10px 0;
		}
		.toplings {
			font-size: @fs12 !important;
			color: #bfbfbf;
		}
	}
}
</style>
<style scoped>
.tags {
	position: relative;
	min-height: 45px;
	overflow: hidden;
	background: #fff;
	padding-right: 120px;
	padding-left: 20px;
	padding-top: 5px;
	display: flex;
	align-items: center;
	border-bottom: 1px solid #e3e3e3;
	/* box-shadow: 0 5px 10px #ddd;
		 */
}
.tags >>> .el-breadcrumb .el-breadcrumb__item:last-child span {
	color: black !important;
}
.toplings {
	margin-left: 30px;
	padding: 0 0 14px 0;
}
.likd > .el-breadcrumb .el-breadcrumb__item {
	font-size: 16px;
}
</style>
