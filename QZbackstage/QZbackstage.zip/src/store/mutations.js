const mutations = {
	gettoken: (state, data) => {
		state.information = data;
	},
	Nav_title: (state, data) => {
		state.Navigation = data;
	},
	menu_title: (state, data) => {
		state.menu = data
	},
	titlekeys: (state, data) => {
		state.titlekeys = data
	},
	setinformation(state) {
		state.information = {}
	},
	settoken(state, data = {}) {
		const users = JSON.parse(sessionStorage['information'])
		users.user = data
		state.information.user = data
		sessionStorage['information'] = JSON.stringify(users)
	}
}
export default mutations
