/*保存在vuex同时,也保存在sessionStorage里面,页面关闭同时清空*/
const actions = {
	token_get(state, data = '') {
		state.commit('gettoken', data)
		sessionStorage['information'] = JSON.stringify(data)
	},
	Navtitle(state, data = '') {
		state.commit('Nav_title', data.split('/'))
		sessionStorage['Nav_title'] = JSON.stringify(data.split('/'))
	},
	menutitle(state, data = '') {
		state.commit('menu_title', data)
		sessionStorage['menu_title'] = JSON.stringify(data)
	},
	gettitles(state, data = '') {
		state.commit('titlekeys', data)
		sessionStorage['titlekey'] = JSON.stringify(data)
	},
	settion(state, data = '') {
		state.commit('setinformation', data)
	},
	settoken(state, data = {}) {
		state.commit('settoken', data)
	}

}
export default actions
