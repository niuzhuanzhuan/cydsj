import router from '@/router';
const getters = {
	deletetoken: (state) => {
		return state.information = {}
	},
	setinformation: (state) => {
		if(!!state.information.user){
			return state.information.user.user_nickname
		}else{
			setTimeout(() => {
				if (router.currentRoute.name != 'Login') {
					router.replace({
						path: '/Login'
					});
				}
			}, 500)
		}
	},
	getNavigation: (state) => {
		return state.Navigation
	},
	menutitles:(state)=>{
		return state.menu
	},
	gettitles:(state)=>{
		return state.titlekeys
	}
}
export default getters
