const state = {
	information:{},
	Navigation:[],
	menu:'',
	titlekeys:{}
}
export default state
