import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)
//解决路由重复
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
	return originalPush.call(this, location).catch(err => err)
}

const routes = [{
		path: '/',
		redirect: '/Login'
	},
	{
		path: '/Login',
		name: 'Login',
		component: resolve => require(['../components/page/Login.vue'], resolve)
	},
	{
		path: '/home',
		component: resolve => require(['@/components/common/Home.vue'], resolve),
		meta: {
			title: '自述文件'
		},
		children: [{
				path: '/personal_center',
				component: resolve => require(['@/views/system/personal'], resolve),
				meta: {
					title: '系统管理/个人中心'
				}
			},
			{
				path: '/dashboard/addpers',
				component: resolve => require(['@/views/system/addpers.vue'], resolve),
				meta: {
					title: '系统管理/个人中心/添加角色'
				}
			},
			{
				path: '/role_management',
				component: resolve => require(['@/views/role_management/role_management.vue'], resolve),
				meta: {
					title: '系统管理/角色管理'
				}
			},
			{
				path: '/role_up',
				component: resolve => require(['@/views/role_management/role_up.vue'], resolve),
				meta: {}
			},
			{
				path: '/list',
				component: resolve => require(['@/views/list/list.vue'], resolve),
				meta: {
					title: '系统管理/账户管理'
				}
			},
			{
				path: '/account_management',
				component: resolve => require(['@/views/account_management/account_management.vue'], resolve),
				meta: {
					title: '系统管理/账户管理'
				}
			},
			{
				path: '/addaccount',
				component: resolve => require(['@/views/account_management/account.vue'], resolve),
				meta: {}
			},
			{
				path: '/log_management',
				component: resolve => require(['@/views/journal/journal.vue'], resolve),
				meta: {
					title: '系统管理/日志管理'
				}
			},
			{
				path: '/dict',
				component: resolve => require(['@/views/dict/dict.vue'], resolve),
				meta: {
					title: '人员管理/人员身份管理'
				}
			},
			{
				path: '/company',
				component: resolve => require(['@/views/company/company.vue'], resolve),
				meta: {
					title: '人员管理/单位管理'
				}
			},
			{
				path: '/sports',
				component: resolve => require(['@/views/sports/sports.vue'], resolve),
				meta: {
					title: '人员管理/运动队管理'
				}
			},
			{
				path: '/person_list',
				component: resolve => require(['@/views/person_list/person_list.vue'], resolve),
				meta: {
					title: '人员管理/基本信息'
				}
			},
			{
				path: '/person_check',
				component: resolve => require(['@/views/person_check/person_check'], resolve),
				meta: {
					title: '人员管理/人员审核'
				}
			},
			{
				path: '/person_up',
				component: resolve => require(['@/views/person_list/updatas'], resolve),
				meta: {}
			},
			{
				path: '/list_up',
				component: resolve => require(['@/views/list/list_up.vue'], resolve),
				meta: {}
			},
			{
				path: '/door',
				component: resolve => require(['@/views/door/door.vue'], resolve),
				meta: {
					title: '智能训练/门禁管理'
				}
			},
			{
				path: '/venue_manage',
				component: resolve => require(['@/views/venue_manage/venue_manage.vue'], resolve),
				meta: {
					title: '训练地管理/训练场地管理'
				}
			},
			{
				path: '/person_distribution',
				component: resolve => require(['@/views/person_distribution/person_distribution'], resolve),
				meta: {
					title: '训练地管理/人员分布统计'
				}
			},
			{
				path: '/visitor_register',
				component: resolve => require(['@/views/visitor_register/visitor_register.vue'], resolve),
				meta: {
					title: '访客计划/访客登记'
				}
			},
			{
				path: '/visitor_up',
				component: resolve => require(['@/views/visitor_register/visitor_up.vue'], resolve),
				meta: {
					title: ''
				}
			},
			{
				path: '/visitor_manage',
				component: resolve => require(['@/views/visitor_manage/visitor_manage.vue'], resolve),
				meta: {
					title: '训练地管理/访客管理'
				}
			},
			{
				path: '/monitor',
				component: resolve => require(['@/views/monitor/monitor.vue'], resolve),
				meta: {
					title: '访客计划/实时监控'
				}
			},
			{
				path: '/training_record',
				component: resolve => require(['@/views/training_record/training_record.vue'], resolve),
				meta: {
					title: '智能训练/训练记录'
				}
			},
			{
				path: '/device',
				component: resolve => require(['@/views/device/device.vue'], resolve),
				meta: {
					title: '智能训练/智能设备管理'
				}
			},
			{
				path: '/device_up',
				component: resolve => require(['@/views/device/device_up.vue'], resolve),
				meta: {}
			},
			{
				path: '/applyrecord',
				component: resolve => require(['@/views/device/applyrecord.vue'], resolve),
				meta: {}
			},
			{
				path: '/analysis',
				component: resolve => require(['@/views/analysis/analysis.vue'], resolve),
				meta: {
					title: '智能训练/综合体能分析'
				}
			},
			{
				path: '/clock_in',
				component: resolve => require(['@/views/clock_in/clock_in.vue'], resolve),
				meta: {
					title: '智能训练/打卡入场'
				}
			},
			{
				path: '/writemail',
				component: resolve => require(['@/views/journal/writemail.vue'], resolve),
				meta: {}
			},
			{
				path: '/404',
				component: resolve => require(['@/components/page/404.vue'], resolve),
				meta: {
					title: '404'
				}
			},
		]
	},
	{
		path: '*',
		redirect: '/404'
	},
]

const router = new VueRouter({
	routes
})

export default router
