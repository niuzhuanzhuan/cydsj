import Vue from 'vue'
import router from './router';
import store from './store/index';
import vuex from 'vuex';

if(sessionStorage['titlekey']){
	let titlekey=JSON.parse(sessionStorage['titlekey'])
	store.commit('titlekeys', titlekey);
}

if (!!sessionStorage['information']) {
	let users = JSON.parse(sessionStorage['information']);
	let Nav_title = JSON.parse(sessionStorage['Nav_title']);
	store.commit('gettoken', users);
	store.commit('Nav_title', Nav_title);
} else {
	setTimeout(() => {
		if (router.currentRoute.name != 'Login') {
			router.replace({
				path: '/Login'
			});
		}
	}, 500)
}
