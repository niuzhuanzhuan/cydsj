import request from "./http";
import qs from "qs";
import store from "../store/index";
import VueCookies from 'vue-cookies';
import {
	Message
} from 'element-ui';

const login = (data, suc) => { //用户登录
	return request({
		method: 'post',
		url: 'user/public/login',
		data: qs.stringify(data),
	})
};

const logout = (data, suc) => { //退出登录
	return request({
		method: 'post',
		url: 'user/public/logout',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const passwordEdit = (data, suc) => { //修改密码
	return request({
		method: 'post',
		url: 'user/public/passwordEdit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const menuindex = (data, suc) => { //菜单
	return request({
		method: 'post',
		url: 'user/Menu',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const rbacindex = (data, suc) => { //角色列表接口
	return request({
		method: 'post',
		url: 'user/rbac/index',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const roleDelete = (data, suc) => { //删除角色
	return request({
		method: 'post',
		url: 'user/rbac/roleDeletes',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const updaterole = (data, suc) => { //添加修改角色
	return request({
		method: 'post',
		url: 'user/rbac/updaterole',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const selectrole = (data, suc) => { //查询角色
	return request({
		method: 'post',
		url: 'user/rbac/selectrole',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const userindex = (data, suc) => { //账户列表
	return request({
		method: 'post',
		url: 'user/user/index',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const deleteuser = (data, suc) => { //删除账户
	return request({
		method: 'post',
		url: 'user/user/delete',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const selectuser = (data, suc) => { //查询账户
	return request({
		method: 'post',
		url: 'user/user/selectuser',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const updateuser = (data, suc) => { //添加修改
	return request({
		method: 'post',
		url: 'user/user/updateuser',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

// http://www.qingzhen.com/user/Haikang/getdata?url=/portal/front/menu/getConfigMenu&data={}&method=GET
const Haikanggetdata = (data, parameter, todata = '{}') => { //公共获取页面数据
	return request({
		method: 'post',
		url: `user/Haikang/getdata?url=${parameter}&data=${todata}&method=GET`,
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	})
};

const geturl = (data, parameter) => { //公共获取页面数据
	return request({
		method: 'post',
		url: `user/Haikang/geturl?url=${parameter}`,
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	})
};

const organization = (data, suc) => { //账户组织列表
	return request({
		method: 'post',
		url: 'user/user/organization',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const user_del = (data, suc) => { //删除账户
	return request({
		method: 'post',
		url: 'user/user/user_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const cancelBan = (data, suc) => { //启用账户
	return request({
		method: 'post',
		url: 'user/user/cancelBan',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const userban = (data, suc) => { //停用账户
	return request({
		method: 'post',
		url: 'user/user/ban',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const organization_del = (data, suc) => { //账户组织删除
	return request({
		method: 'post',
		url: 'user/user/organization_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const organization_add = (data, suc) => { //账户组织添加
	return request({
		method: 'post',
		url: 'user/user/organization_add',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const organization_edit = (data, suc) => { //账户组织修改
	return request({
		method: 'post',
		url: 'user/user/organization_edit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const userpass = (data, suc) => { //修改账户密码
	return request({
		method: 'post',
		url: 'user/user/pass',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const authorize = (data, suc) => { //角色权限设置
	return request({
		method: 'post',
		url: 'user/rbac/authorize',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const log_list = (data, suc) => { //日志列表
	return request({
		method: 'post',
		url: 'user/Message/log_list',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const log_del = (data, suc) => { //日志删除
	return request({
		method: 'post',
		url: 'user/Message/log_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const log_editPost = (data, suc) => { //日志修改提交
	return request({
		method: 'post',
		url: 'user/Message/log_editPost',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const dictindex = (data, suc) => { //字典列表
	return request({
		method: 'post',
		url: 'user/dict/index',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const dictdel = (data, suc) => { //字典删除
	return request({
		method: 'post',
		url: 'user/dict/del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const dictsubmit = (data, suc) => { //添加或修改字典提交啊
	return request({
		method: 'post',
		url: 'user/dict/submit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personorganization = (data, suc) => { //人员组织列表
	return request({
		method: 'post',
		url: 'user/Person/organization',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personorganization_del = (data, suc) => { //人员组织删除
	return request({
		method: 'post',
		url: 'user/Person/organization_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personorganization_submit = (data, suc) => { //人员组织添加修改
	return request({
		method: 'post',
		url: 'user/Person/organization_submit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personindex = (data, suc) => { //人员列表
	return request({
		method: 'post',
		url: 'user/Person/index',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personsubmit = (data, suc) => { //人员添加修改
	return request({
		method: 'post',
		url: 'user/Person/submit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personoperation = (data, suc) => { //人员查询
	return request({
		method: 'post',
		url: 'user/Person/operation',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Haikangs = (data, suc) => { //
	return request({
		method: 'post',
		url: 'user/Haikang/geturl?url=/acs/app/auth',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personperson_del = (data, suc) => { //人员删除(批量)
	return request({
		method: 'post',
		url: 'user/Person/person_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const venue_list = (data, suc) => { //训练场列表
	return request({
		method: 'post',
		url: 'user/venue/venue_list',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const venueoperation = (data, suc) => { //训练馆操作
	return request({
		method: 'post',
		url: 'user/venue/operation',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const venueget_door = (data, suc) => { //获取门禁
	return request({
		method: 'post',
		url: 'user/venue/get_door',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const venuesubmit = (data, suc) => { //训练管提交(添加,修改)
	return request({
		method: 'post',
		url: 'user/venue/submit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const venue_del = (data, suc) => { //训练馆删除
	return request({
		method: 'post',
		url: 'user/venue/venue_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};
const Haikangspreview = (data, suc) => { //
	return request({
		method: 'post',
		url: 'user/Haikang/geturl?url=/vms/preview',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const venue_list1 = (data, suc) => { //训练场列表(带当日人次)
	return request({
		method: 'post',
		url: 'user/venue/venue_list1',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const venueevents = (data, suc) => { //场馆实时人流数据
	return request({
		method: 'post',
		url: 'user/venue/events',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Visitorindex = (data, suc) => { //场馆实时人流数据
	return request({
		method: 'post',
		url: 'user/Visitor/index',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const visitor_del = (data, suc) => { //场馆实时人流数据
	return request({
		method: 'post',
		url: 'user/Visitor/visitor_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Visitorsubmit = (data, suc) => {
	return request({
		method: 'post',
		url: 'user/Visitor/submit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Visitorperson = (data, suc) => {
	return request({
		method: 'post',
		url: 'user/Visitor/person',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Visitorinfo = (data, suc) => {
	return request({
		method: 'post',
		url: 'user/Visitor/info',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Tropsschool = (data, suc) => { //获取组织
	return request({
		method: 'post',
		url: 'user/Trops/school',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Tropsteam = (data, suc) => { //获取团队
	return request({
		method: 'post',
		url: 'user/Trops/team',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Tropsget_data = (data, suc) => { //训练记录
	return request({
		method: 'post',
		url: 'user/Trops/get_data',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const get_data1 = (data, suc) => { //综合训练数据
	return request({
		method: 'post',
		url: 'user/Trops/get_data1',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Tropsdel = (data, suc) => { //删除训练记录
	return request({
		method: 'post',
		url: 'user/Trops/del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const message_list = (data, suc) => { //收件箱
	return request({
		method: 'post',
		url: 'user/message/message_list',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const message_del = (data, suc) => { //删除单条信息
	return request({
		method: 'post',
		url: 'user/message/message_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const message_send_list = (data, suc) => { //已发送
	return request({
		method: 'post',
		url: 'user/message/message_send_list',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const message_send_del = (data, suc) => { //删除单条已发
	return request({
		method: 'post',
		url: 'user/message/message_send_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const message_read = (data, suc) => { //读取消息
	return request({
		method: 'post',
		url: 'user/message/message_read',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const message_add = (data, suc) => { //发送消息
	return request({
		method: 'post',
		url: 'user/message/message_add',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const message_add_post = (data, suc) => { //发送消息
	return request({
		method: 'post',
		url: 'user/message/message_add_post',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Deviceindex = (data, suc) => { //智能设备列表
	return request({
		method: 'post',
		url: 'user/Device/index',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Devicesubmit = (data, suc) => { //智能设备添加提交
	return request({
		method: 'post',
		url: 'user/Device/submit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Devicedel = (data, suc) => { //设备删除
	return request({
		method: 'post',
		url: 'user/Device/del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Deviceoperation = (data, suc) => { //智能设备修改前查询
	return request({
		method: 'post',
		url: 'user/Device/operation',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Deviceapply_list = (data, suc) => { //申领列表
	return request({
		method: 'post',
		url: 'user/Device/apply_list',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Devicedevice_apply = (data, suc) => { //设备申领
	return request({
		method: 'post',
		url: 'user/Device/device_apply',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Devicedevice_return = (data, suc) => { //设备申领
	return request({
		method: 'post',
		url: 'user/Device/device_return',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personcheck = (data, suc) => { //人员审核
	return request({
		method: 'post',
		url: 'user/Person/check',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Visitorcheck = (data, suc) => { //访客审核
	return request({
		method: 'post',
		url: 'user/Visitor/check',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const task_start = (data, suc) => { //人脸信息同步
	return request({
		method: 'post',
		url: 'user/door/task_start',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const events_del = (data, suc) => { //打卡数据删除
	return request({
		method: 'post',
		url: 'user/venue/events_del',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const events_edit = (data, suc) => { //打卡数据修改
	return request({
		method: 'post',
		url: 'user/venue/events_edit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const userinfoEdit = (data, suc) => { //修改个人信息
	return request({
		method: 'post',
		url: 'user/user/userinfoEdit',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

const Personimport = (data, suc) => { //
	return request({
		method: 'post',
		url: 'user/Person/import',
		data: qs.stringify(data),
		headers: {
			'XX-Token': store.state.information.token
		}
	}).then(suc).catch((error) => {})
};

export default {
	Personimport,
	userinfoEdit,
	events_edit,
	events_del,
	task_start,
	Visitorcheck,
	Personcheck,
	Devicedevice_return,
	Devicedevice_apply,
	Deviceapply_list,
	Deviceoperation,
	Devicedel,
	Devicesubmit,
	Deviceindex,
	message_add_post,
	message_add,
	message_read,
	message_send_del,
	message_send_list,
	message_del,
	message_list,
	Tropsdel,
	get_data1,
	Tropsget_data,
	Tropsteam,
	Tropsschool,
	Visitorinfo,
	Visitorperson,
	Visitorsubmit,
	visitor_del,
	Visitorindex,
	venueevents,
	venue_list1,
	Haikangspreview,
	venue_del,
	venuesubmit,
	venueget_door,
	venueoperation,
	venue_list,
	Personperson_del,
	Haikangs,
	Personoperation,
	Personsubmit,
	Personindex,
	Personorganization_submit,
	Personorganization_del,
	Personorganization,
	dictsubmit,
	dictdel,
	dictindex,
	log_editPost,
	log_del,
	log_list,
	authorize,
	userpass,
	organization_edit,
	organization_add,
	organization_del,
	userban,
	cancelBan,
	user_del,
	organization,
	geturl,
	Haikanggetdata,
	updateuser,
	selectuser,
	deleteuser,
	userindex,
	selectrole,
	updaterole,
	roleDelete,
	rbacindex,
	menuindex,
	passwordEdit,
	login,
	logout,
}
