// 网站全局变量
let URL=' http://qz.yongdongli.net:9100/'//正式服
// let URL = ' http://127.0.0.1/' //测试服
// let URL = ' http://192.168.0.166/' //测试服
// const pament = 'https://192.168.1.100'
module.exports = {
	URL,
	// pament
};
