'use strict'
import Vue from 'vue'
import axios from 'axios'
import router from '../router'
import doman from './doman'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import bus from '@/components/common/bus.js'
import s from './gcs.js';
import {
	Message
} from 'element-ui';
const timeout = 10000;


if (navigator && navigator.onLine === false) { //检查设备是否能够上网
	Message({
		message: '当前设备网络没有连接，请检查',
		duration: 0,
		type: 'error'
	})
}


const service = axios.create({
	baseURL: doman.URL,
	timeout: timeout, // 请求超时时间
	headers: {
		'XX-Device-Type': 'web',
		'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
	},
});
// console.log(s.s)
//request请求拦截器
service.interceptors.request.use(
	config => {
		NProgress.start();
		bus.$emit('loading', {
			msg: true
		});
		return config
	},
	error => {
		console.log(error)
		return Promise.error(error);
	});
//响应拦截器
service.interceptors.response.use(res => {
	bus.$emit('loading', {
		msg: false
	});
	if (res.status === 200) {
		NProgress.done()
		if (res.data.code === 0) {
			return Promise.resolve(res.data);
		} else if (res.data.code === -1) {
			Message({
				message: '当前登录信息已过期，请您重新登录',
				type: 'error'
			})
			router.push('/Login')
		} else {
			Message({
				message: res.data.msg,
				type: 'warning'
			})
		}
	} else {
		return Promise.reject(res);
	}
}, error => {
	if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) { //超时提示
		Message({
			message: '请求超时',
			type: 'warning'
		})
		bus.$emit('loading', {
			msg: false,
			titles: '当前网络不是太好哦！请重新刷新页面试试'
		});
	}
	// bus.$emit('loading', false);
	if(error.response){
		switch (error.response.status) {
			case 500:
				Message({
					message: '数据错误',
					duration: 0,
					type: 'warning'
				})
				break;
		}
	}
	return Promise.reject(error.response);
})



export default service
