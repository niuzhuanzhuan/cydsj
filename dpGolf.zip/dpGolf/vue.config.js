module.exports = {
	// publicPath: '/golf/dp/',
	publicPath: '/dpGolf',
}
