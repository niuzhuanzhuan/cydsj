import api from '@/utils/api.js';
import {
	Toast
} from 'vant';
const user = {
	state: {
		userinfo: {},
		heatlist:[],
		tiems:'',
	},
	actions: {},
	mutations: {
		getheat:(state,data)=>{
			state.heatlist=data;
			localStorage['heatlist']=JSON.stringify(state.heatlist)
		},
		gettiems:(state,data)=>{
			state.tiems=data;
		}
	},
	getters: {
		settime:(state)=>{
			if(!!state.tiems){
				return state.tiems;
			}
		}
	}
}
export default user;
