/**
 * Created by worktime on 2018/3/15.
 */
import Vue from 'vue'
const sendTeamId = (obj) => {
  var u = navigator.userAgent
  if (u.indexOf('EasyDo') > -1) {
    if (u.indexOf('Android') > -1 || u.indexOf('Adr') > -1) {
      android.getChooseTeamWithTeamEnrollForm(obj);
    } else if (!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
      //native.getChooseTeamWithTeamEnrollForm(val);
      WebViewJavascriptBridge.callHandler('getChooseTeamWithTeamEnrollForm',JSON.stringify(obj),function(response) {
        document.getElementById("returnValue").value = response;
      });
    }
  }
}
export {
    sendTeamId
}
