/**
 * Created by worktime on 2017/12/14.
 */
import Vue from 'vue'
//import qs from 'qs'
const toShare = (goodsGuid, pageType, itemguid, teamId) =>
{
  let u = navigator.userAgent
  if (u.indexOf('EasyDo') > -1) {
    return 1
  } else {
    return 0
  }
}
export {
    toShare
}