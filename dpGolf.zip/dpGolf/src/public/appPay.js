/**
 * Created by worktime on 2018/3/14.
 */
/**
 * Created by worktime on 2017/12/14.
 */
import Vue from 'vue'
//import qs from 'qs'
const appPay = (obj) => {
  var u = navigator.userAgent
  if (u.indexOf('EasyDo') > -1) {
    if (u.indexOf('Android') > -1 || u.indexOf('Adr') > -1) {
      android.showOrderPayIntent(JSON.stringify(obj))
    } else if (!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
      //native.takeTradeNo(JSON.stringify(obj))
      WebViewJavascriptBridge.callHandler('takeTradeNo',JSON.stringify(obj),function(response) {
        document.getElementById("returnValue").value = response;
      });
    }
  }
}

export {
    appPay
}
