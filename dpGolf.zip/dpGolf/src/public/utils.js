/**
 * Created by worktime on 2017/11/17.
 */
const sayHello = () => {
  console.log('greet', 'hello')
}
export {
  sayHello
}
