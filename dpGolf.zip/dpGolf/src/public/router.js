/**
 * Created by worktime on 2018/3/29.
 */
const router = new VueRouter({
  history: false,
  hashbang: true
})
export {
  router
}
