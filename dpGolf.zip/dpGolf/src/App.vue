<template>
	<div id="app"><router-view /></div>
</template>

<style lang="less">

#app {
}
html,
body {
	margin: 0;
	padding: 0;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #09f0e2;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #09f0e2;
	}
	&::-webkit-scrollbar-corner {
		background: #09f0e2;
	}
}
</style>
