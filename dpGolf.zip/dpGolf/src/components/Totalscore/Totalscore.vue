<template>
	<div class="alls" v-loading="loading" :element-loading-text="text" element-loading-spinner="el-icon-loading" element-loading-background="#ffffff">
		<div class="lingk" id="message">
			<div v-for="(item, index) in datalist" :key="(index += 1)" class="keylisnt">
				<div class="leftmian ct">{{ item.top }}</div>
				<div class="leftlimg">
					<div class="mianimgs">
					<el-avatar :size="50" :src="item.avatar"></el-avatar>
					</div>
					<div class="miantielt">
						<div class="font">{{ item.name }}</div>
					</div>
				</div>
				<div class="lipokey">
					<div class="lefttop" v-for="(jitem, index) in item.list.sum" :key="index">{{ jitem }}</div>
				</div>
				<div class="rigthmians ct">{{ item.count }}</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	props: ['form', 'formdata'],
	name: 'automatic',
	data() {
		return {
			bout: '',
			title: '无',
			text: '拼命加载中',
			loading: false,
			t: null,
			tiem: 50,
			mosi: 1,
			whether: false,
			datalist: [],
			keyfreon: true
		};
	},
	computed: {},
	watch: {},
	destroyed() {
		window.clearInterval(this.t);
	},
	filters: {},
	methods: {
		getdata() {
			if (this.mosi == 1) {
				this.loading = true;
			}
			JSON.parse(sessionStorage['form'])
			const grous = JSON.parse(sessionStorage['form']);
			const { matcharr, rank,type } = grous;
			api.teamTop({
				match_id: matcharr[0],
				group_id: matcharr[1],
				bout: matcharr[2],
				type:type,
				rank: rank
			}).then(res => {
				if (res.data.xcode === 0) {
					this.mosi = 2;
					if (res.data.data.istop == 1) {
						this.whether = true;
					}
					if (res.data.data.list) {
						this.$emit('stand', res.data.data.bout);
						this.$emit('imagekeys', res.data.data.banner);
						this.$emit('groupkey', res.data.data.group_name);
						this.$emit('Types', res.data.data.topType);
						this.loading = false;
						this.datalist = res.data.data.list;
						if (this.datalist.length === 0) {
							this.text = '暂无更多数据请等待....';
							this.loading = true;
							setTimeout(() => {
								this.getdata();
							}, 3000);
						} else {
							if (this.datalist.length > 8) {
								this.roll();
							} else {
								setTimeout(() => {
									//小于3条时候
									this.getdata();
								}, 5000);
							}
						}
					} else {
						this.text = '暂无更多数据请等待....';
						setTimeout(() => {
							//小于3条时候
							this.getdata();
						}, 5000);
					}
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		},
		roll() {
			let that = this;
			this.$nextTick(() => {
				this.t = setInterval(() => {
					var message = document.getElementById('message');
					let scrollTop = message.scrollTop;
					let windowHeight = message.clientHeight;
					let scrollHeight = message.scrollHeight;
					message.scrollTop += 1.5;
					if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight) - 2) {
						clearInterval(this.t);
						message.scrollTop = 0;
						this.getdata();
					}
				}, that.tiem);
				message.onmouseover = () => {
					this.keyfreon = false;
					clearInterval(this.t, that.tiem);
				};
				message.onmouseout = () => {
					this.keyfreon = true;
					if (this.keyfreon) {
						this.t = null;
						this.t = window.setInterval(this.rollStart, that.tiem);
					}
				};
			});
		},
		rollStart() {
			this.$nextTick(() => {
				let message = document.getElementById('message');
				let scrollTop = message.scrollTop;
				let windowHeight = message.clientHeight;
				let scrollHeight = message.scrollHeight;
				message.scrollTop += 1.5;
				if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight) - 2) {
					window.clearInterval(this.t);
					this.getdata();
					message.scrollTop = 0;
				}
			});
		}
	},
	mounted() {},
	created() {
		this.getdata();
	}
};
</script>
<style scoped>
	.el-avatar {
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.el-avatar>>>img{
		width: 100%;
	}
</style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 16px;
@color09: #3f4a4e;
@ba041728: none;
@baE9E9E9: #e9e9e9;
@baCBD4E1: #cbd4e1;
.ct {
	display: flex;
	justify-content: center;
	align-items: center;
}
.alls {
	width: 100%;
	height: 100%;

	.lingtops {
		background: #0d5e89;
		width: 100px;
		height: 37px;
		line-height: 37px;
		border-radius: 5px;
		position: absolute;
		left: 80%;
		top: -45px;
		text-align: center;
		color: @color09;
		font-size: @fonst18;
	}

	.lingk {
		width: 100%;
		height: 100%;
		overflow: auto;
		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
			/**/
		}
		.keylisnt {
			width: 100%;
			height: 12%;
			display: flex;
			&:nth-child(odd) {
				.leftmian {
					background: @baE9E9E9;
				}
				.rigthmians {
					background: @baE9E9E9;
				}
			}
			&:nth-child(even) {
				.leftmian {
					background: @baCBD4E1;
				}
				.leftlimg {
					background: #ebeff5;
				}
				.lipokey {
					background: #ebeff5;
				}
				.rigthmians {
					background: @baCBD4E1;
				}
			}
			.leftmian {
				width: 8%;
				height: 100%;
			}
			.leftlimg {
				width: 26%;
				height: 100%;
				display: flex;
				.mianimgs {
					width: 120px;
					height: 100%;
					display: flex;
					justify-content: center;
					align-items: center;
				}
				.miantielt {
					width: calc(100% - 140px);
					height: 100%;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					.font {
						width: 100%;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}
				}
			}
			.lipokey {
				width: 53%;
				height: 100%;
				display: flex;
				justify-content: space-around;
				align-items: center;
				.lefttop {
					width: 25%;
				}
			}
			.rigthmians {
				width: 13%;
				height: 100%;
				color: #ff6363;
			}
		}
	}
}
</style>
