<template>
	<div class="alls" v-loading="loading" :element-loading-text="text" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)">
		<div class="lingk" id="message">
			<div v-for="(item, index) in datalist" :key="(index += 1)" class="keylisnt">
				<div v-if="whether" class="hui">
					<span v-if="index > 3">{{ index }}</span>
					<img v-else :src="index === 1 ? top1 : index === 2 ? top2 : index === 3 ? top3 : ''" />
				</div>
				<div v-else class="hui">
					<span>{{ index }}</span>
				</div>
				<div>{{ item.enroll_name ? item.enroll_name : '无' }}</div>
				<div>{{ item.gender === 0 ? '女' : item.gender == 1 ? '男' : '暂无信息' }}</div>
				<div>{{ item.age ? item.age : 0 }}</div>
				<div>第{{ item.bout ? item.bout : 0 }}场</div>
				<div class="ho">{{ item.differ ? item.differ : 0 }}</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	name: 'Viceanv',
	data() {
		return {
			loading: false,
			t: null,
			tiem: 18,
			datalist: [],
			mosi: 1,
			text: '',
			whether:false,
			top1: require('../../assets/mianimage/top1.png'),
			top2: require('../../assets/mianimage/top2.png'),
			top3: require('../../assets/mianimage/top3.png')
		};
	},
	computed: {},
	watch: {},
	destroyed() {
		clearInterval(this.inter);
		clearInterval(this.t);
	},
	methods: {
		getdata() {
			if (this.mosi == 1) {
				this.loading = true;
			}
			api.golf_score_rank({
				bout: this.$route.query.bout,
				match_id: this.$route.query.match_id,
				level: this.level,
			}).then(res => {
				if (res.data.xcode === 0) {
					this.mosi = 2;
					this.datalist = res.data.data.score;
					this.loading = false;
					if (this.datalist.length === 0) {
						this.text = '暂无更多数据请等待....';
						this.loading = true;
						setTimeout(() => {
							this.getdata();
						}, 5000);
					} else {
						if (this.datalist.length > 7) {
							this.roll();
						} else {
							setTimeout(() => {
								this.getdata();
							}, 5000);
						}
					}
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		},
		roll() {
			let that = this;
			this.$nextTick(() => {
				this.t = setInterval(() => {
					var message = document.getElementById('message');
					let scrollTop = message.scrollTop;
					let windowHeight = message.clientHeight;
					let scrollHeight = message.scrollHeight;
					message.scrollTop++;
					if (scrollTop + windowHeight >= scrollHeight) {
						clearInterval(this.t);
						message.scrollTop = 0;
						this.getdata();
					}
				}, that.tiem);
				message.onmouseover = () => {
					clearInterval(this.t, that.tiem);
				};
				message.onmouseout = () => {
					this.t = null;
					this.t = setInterval(this.rollStart, that.tiem);
				};
			});
		},
		rollStart() {
			var message = document.getElementById('message');
			let scrollTop = message.scrollTop;
			let windowHeight = message.clientHeight;
			let scrollHeight = message.scrollHeight;
			message.scrollTop++;
			if (scrollTop + windowHeight >= scrollHeight) {
				clearInterval(this.t);
				this.getdata();
				message.scrollTop = 0;
			}
		}
	},
	created() {
		if(this.$route.query.whether==1){
			this.whether=true
		}
		this.getdata();
		// this.roll(this.tiem);
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 18px;
@color09: #0acecb;
.alls {
	width: 100%;
	height: 100%;
	.lingk {
		width: 100%;
		height: 100%;
		background: #123769;
		overflow: auto;
		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
			/**/
		}
		.keylisnt {
			font-size: @fonst18;
			width: 100%;
			height: 110px;
			display: flex;
			align-items: center;
			justify-content: space-around;
			color: @color09;
			&:nth-child(odd) {
				background: #0f2d56;
			}
			div {
				width: 16.67%;
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			img {
				width: 40px;
			}
			.ho {
				color: #fa3d5c;
			}
			.hui {
				color: #c0bdbb;
			}
		}
	}
}
</style>
