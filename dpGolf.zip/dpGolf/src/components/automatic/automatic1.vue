<template>
	<div class="alls" v-loading="loading" :element-loading-text="text" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)">
		<div class="lingk" id="message">
			<!-- <div class="lingtops">{{ title }}</div> -->
			<div v-for="(item, index) in datalist" :key="(index += 1)" class="keylisnt">
				<div class="sonmianll">
					<div class="sonleft">
						<div v-if="whether">
							<span v-if="index > 3">{{ index }}</span>
							<img v-else :src="index === 1 ? top1 : index === 2 ? top2 : index === 3 ? top3 : ''" />
						</div>
						<div v-else>
							<span>{{ index }}</span>
						</div>
						<div>
							<ul>
								<li>{{ item.enroll_name }}</li>
								<!-- <li>{{ item.gender }}</li>
								<li>{{ item.age ? item.age + '岁' : '' }}</li>
								<li>R{{ item.bout }}</li> -->
							</ul>
						</div>
						<!-- <div>{{ item.total }}</div> -->
					</div>

					<!-- 成绩卡片 -->
					<div class="sonrigth">
						<div class="linhert">
							<div class="linhertleft">
								<!-- <div class="linstop">
									<div v-for="(item, index) in 18" :key="item">{{ item }}</div>
								</div>
								<div class="lisnav">
									<div v-if="jndex <= 19" v-for="(jtem, jndex) in item.stand" :key="jndex">{{ jtem }}</div>
								</div> -->
								<div class="lisbont">
									<div style="width: 40px;"></div>
									<div v-for="(atem, andex) in item.score.hole_score" :key="andex">
										<div style="width: 22px;text-align: center;color: #ffffff !important;" v-if="atem == parseInt(item.stand[andex])">{{ atem }}</div>
										<!-- 标准杆 -->
										<div style="width: 22px;text-align: center;" v-if="atem == 0">-</div>
										<!-- 等于0的情况下 -->

										<div class="noekong" v-if="atem - parseInt(item.stand[andex]) == 1">{{ atem }}</div>
										<!-- 帕吉 -->
										<div class="noekonger" v-if="atem - parseInt(item.stand[andex]) > 1">{{ atem }}</div>
										<!-- 扒鸡加 -->
										<div class="yuan" v-if="parseInt(item.stand[andex]) - atem == 1">{{ atem }}</div>
										<!-- 小鸟 -->
										<div class="pajier" v-if="parseInt(item.stand[andex]) - atem > 1 && atem != 0">{{ atem }}</div>
									</div>
								</div>
							</div>
							<div class="linhertrigth">
								<div style="height: 33%;"></div>
								<div class="navmyall" style="color: red;">
									{{ item.total }}
									<!-- {{ item.stand | stand8 }} -->
								</div>
								<!-- <div class="navmyallkey">{{ item.score.hole_score | stand8 }}</div> -->
							</div>
						</div>
						<!-- <div class="linhert">
							<div class="linhertleft">
								<div class="linstop">
									<div v-for="(item, index) in 18" :key="item" v-if="item > 9">{{ item }}</div>
								</div>
								<div class="lisnav">
									<div v-if="bndex <= 17 && bndex > 8" v-for="(btem, bndex) in item.stand" :key="bndex">{{ btem }}</div>
								</div>
								<div class="lisbont">
									<div v-if="cndex > 8 && cndex <= 17" v-for="(ctem, cndex) in item.score.hole_score" :key="cndex">
										<div style="width: 22px;text-align: center;color: #ffffff !important;" v-if="parseInt(item.stand[cndex]) == ctem">{{ ctem }}</div>
										<div class="yuan" v-if="ctem < parseInt(item.stand[cndex]) && ctem != 0">{{ ctem }}</div>
										<div style="width: 22px;text-align: center;" v-if="ctem == 0">-</div>
										<div class="noekong" v-if="ctem - parseInt(item.stand[cndex]) == 1">{{ ctem }}</div>
										<div class="noekong" v-if="ctem - parseInt(item.stand[cndex]) > 1">
											<div>{{ ctem }}</div>
										</div>
									</div>
								</div>
							</div>
							<div class="linhertrigth">
								<div style="height: 33%;"></div>
								<div class="navmyall">{{ item.stand | stand18 }}</div>
								<div class="navmyallkey">{{ item.score.hole_score | stand18 }}</div>
							</div>
						</div> -->
						<!-- <div class="bonmet">
							<div class="bonmetleft">
								<div class="lisngleft">
									<div class="lisnj">
										<div class="wli">{{ item.score.number.lyq }}</div>
										<div class="wli">老鹰球</div>
									</div>
									<div class="lisnj">
										<div class="wli">{{ item.score.number.xnq }}</div>
										<div class="wli">小鸟球</div>
									</div>
								</div>
								<div class="lisng">
									<div class="wli">{{ item.score.number.bzg }}</div>
									<div class="wli">标准杆</div>
								</div>
								<div class="lisng">
									<div class="wli">{{ item.score.number.pj1 }}</div>
									<div class="wli">帕忌</div>
								</div>
								<div class="lisng">
									<div class="wli">{{ item.score.number.pj2 }}</div>
									<div class="wli">帕忌+</div>
								</div>
							</div>
							<div class="bonmetrigth">{{ item.differ }}</div>
						</div> -->
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	props: ['form', 'formdata'],
	name: 'automatic',
	data() {
		return {
			bout: '',
			title: '无',
			text: '拼命加载中',
			loading: false,
			t: null,
			tiem: 50,
			mosi: 1,
			whether: false,
			datalist: [],
			top1: require('../../assets/mianimage/top1.png'),
			top2: require('../../assets/mianimage/top2.png'),
			top3: require('../../assets/mianimage/top3.png'),
			keyfreon: true
		};
	},
	computed: {},
	watch: {},
	destroyed() {
		window.clearInterval(this.t);
	},
	filters: {
		stand8(data) {
			let num = 0;
			data.map((item, index) => {
				if (index <= 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		},
		stand18(data) {
			let num = 0;
			data.map((item, index) => {
				if (index <= 17 && index > 8) {
					num = parseInt(item) + num;
				}
			});
			return num;
		}
	},
	methods: {
		getdata() {
			if (this.mosi == 1) {
				this.loading = true;
			}
			api.golf_score_rank(this.form).then(res => {
				if (res.data.xcode === 0) {
					this.formdata.group_id.map(item => {
						if (item.name == res.data.data.group_id) {
							// this.title=item.value
							this.$emit('titles', item.value);
						}
					});
					this.mosi = 2;
					if (res.data.data.istop == 1) {
						this.whether = true;
					}
					this.datalist = res.data.data.score;
					this.datalist.map((item, index) => {
						item.stand = item.stand.split(',');
						this.$emit("stand",item.stand)
						item.score.hole_score = item.score.hole_score.split(',');
					});
					this.loading = false;
					if (this.datalist.length === 0) {
						this.text = '暂无更多数据请等待....';
						this.loading = true;
						setTimeout(() => {
							this.getdata();
						}, 3000);
					} else {
						if (this.datalist.length > 5) {
							this.roll();
						} else {
							setTimeout(() => {
								//小于3条时候
								this.getdata();
							}, 5000);
						}
					}
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		},
		roll() {
			let that = this;
			this.$nextTick(() => {
				this.t = setInterval(() => {
					var message = document.getElementById('message');
					let scrollTop = message.scrollTop;
					let windowHeight = message.clientHeight;
					let scrollHeight = message.scrollHeight;
					message.scrollTop+=1;
					if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight) - 2) {
						clearInterval(this.t);
						message.scrollTop = 0;
						this.getdata();
					}
				}, that.tiem);
				message.onmouseover = () => {
					this.keyfreon = false;
					clearInterval(this.t, that.tiem);
				};
				message.onmouseout = () => {
					this.keyfreon = true;
					if (this.keyfreon) {
						this.t = null;
						this.t = window.setInterval(this.rollStart, that.tiem);
					}
				};
			});
		},
		rollStart() {
			this.$nextTick(() => {
				let message = document.getElementById('message');
				let scrollTop = message.scrollTop;
				let windowHeight = message.clientHeight;
				let scrollHeight = message.scrollHeight;
				message.scrollTop+=1.5;
				if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight) - 2) {
					window.clearInterval(this.t);
					this.getdata();
					message.scrollTop = 0;
				}
			});
		}
	},
	mounted() {},
	created() {
		this.getdata();
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 15px;
@color09: #0acecb;
@ba041728: none;
@ba123769: none;
@ba0e2b53: none;
// @ba0e2b53:rgba(18,55,105,.5);

.alls {
	width: 100%;
	height: 100%;

	.lingtops {
		background: #0d5e89;
		width: 100px;
		height: 37px;
		line-height: 37px;
		border-radius: 5px;
		position: absolute;
		left: 80%;
		top: -45px;
		text-align: center;
		color: @color09;
		font-size: @fonst18;
	}

	.lingk {
		width: 100%;
		height: 100%;
		background: @ba123769;
		overflow: auto;
		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
			/**/
		}
		.keylisnt {
			width: 100%;
			height: 20%;
			&:nth-child(odd) {
				// background: @ba123769;
				background: #06233c4d;
				.sonrigth {
					.linhert {
						.linhertleft {
							background: @ba0e2b53;
						}
						.linhertrigth {
							background: @ba0e2b53;
						}
					}
					.bonmet {
						.bonmetleft {
							.lisngleft {
								background: @ba0e2b53;
							}
							.lisng {
								background: @ba0e2b53;
							}
						}
						.bonmetrigth {
							background: @ba0e2b53;
						}
					}
				}
			}
			&:nth-child(even) {
				// background: #06233c4d;
				.sonmianll {
					.sonrigth {
						.linhert {
							.linhertleft {
								background: @ba041728;
							}
							.linhertrigth {
								background: @ba041728;
							}
						}
						.bonmet {
							.bonmetleft {
								.lisngleft {
									background: @ba041728;
								}
								.lisng {
									background: @ba041728;
								}
							}
							.bonmetrigth {
								background: @ba041728;
							}
						}
					}
				}
			}
			.sonmianll {
				width: 100%;
				height: 100%;
				display: flex;
				justify-content: space-between;
				font-size: @fonst18;
				color: @color09;
				.sonleft {
					width: 20%;
					height: 100%;
					display: flex;
					justify-content: space-around;
					align-items: center;
					div {
						width: 30%;
						height: 100%;
						display: flex;
						align-items: center;
						justify-content: center;
						font-size: 18px;
						&:nth-child(2) {
							justify-content: flex-start !important;
						}
						&:nth-child(3) {
							justify-content: center !important;
						}
						ul {
							width: 100%;
							margin: 0;
							padding: 0;
							li {
								width: 100%;
								list-style: none;
								line-height: 40px;
							}
						}
					}
				}
				.sonrigth {
					width: 78%;
					height: 100%;
					font-size: @fonst18;
					display: flex;
					flex-wrap: wrap;
					align-content: space-between;
					.linhert {
						width: 100%;
						height: 100%;
						display: flex;
						justify-content: space-around;
						.linhertleft {
							width: 84.5%;
							height: 100%;
							.linstop {
								width: 100%;
								height: 33%;
								display: flex;
								justify-content: space-around;
								align-items: center;
								color: #8d91a6;
							}
							.lisnav {
								width: 100%;
								height: 33%;
								display: flex;
								align-items: center;
								justify-content: space-around;
							}
							.lisbont {
								width: 100%;
								height: 100%;
								display: flex;
								align-items: center;
								justify-content: space-around;
								color: #bb385a;
								.yuan {
									width: 22px;
									height: 22px;
									display: flex;
									justify-content: center;
									border-radius: 50%;
									background: #e80000;
									color: #ffff;
								}
								.pajier {
									width: 22px;
									height: 22px;
									display: flex;
									justify-content: center;
									border-radius: 50%;
									background: hotpink;
									color: #ffff;
								}
								.noekong {
									width: 22px;
									height: 22px;
									background: #215bff;
									border-radius: 50%;
									color: #ffffff;
									display: flex;
									align-items: center;
									justify-content: center;
								}
								.noekonger {
									width: 22px;
									height: 22px;
									background: #6393ff;
									border-radius: 50%;
									color: #ffffff;
									display: flex;
									align-items: center;
									justify-content: center;
								}
								.towkong {
									width: 22px;
									height: 22px;
									border: 1px solid #7f879e;
									display: flex;
									align-items: center;
									justify-content: center;
									div {
										width: 16px;
										height: 16px;
										border: 1px solid #7f879e;
										display: flex;
										justify-content: center;
										align-items: center;
									}
								}
							}
						}
						.linhertrigth {
							width: 15%;
							height: 100%;
							.navmyall {
								width: 100%;
								height: 33%;
								display: flex;
								justify-content: center;
								align-items: center;
							}
							.navmyallkey {
								width: 100%;
								height: 33%;
								display: flex;
								justify-content: center;
								align-items: center;
								color: #fa3d5c;
							}
						}
					}
					.bonmet {
						width: 100%;
						height: 22%;
						display: flex;
						justify-content: space-around;
						.bonmetleft {
							width: 84.5%;
							height: 100%;
							display: flex;
							justify-content: space-between;
							.lisngleft {
								width: 40.5%;
								height: 100%;
								display: flex;
								justify-content: space-between;
								.lisnj {
									width: 45%;
									height: 100%;
									.wli {
										font-size: 14px;
										width: 100%;
										height: 45%;
										display: flex;
										justify-content: center;
										align-items: center;
									}
								}
							}
							.lisng {
								width: 19.5%;
								height: 100%;
								.wli {
									width: 100%;
									height: 45%;
									display: flex;
									justify-content: center;
									align-items: center;
									font-size: 14px;
								}
							}
						}
						.bonmetrigth {
							width: 15%;
							height: 100%;
							display: flex;
							justify-content: center;
							align-items: center;
							color: #fa3d5c;
						}
					}
				}
			}
		}
	}
}
</style>
