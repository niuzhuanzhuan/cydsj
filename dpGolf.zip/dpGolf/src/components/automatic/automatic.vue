<template>
	<div class="alls" v-loading="loading" :element-loading-text="text" element-loading-spinner="el-icon-loading" element-loading-background="#ffffff">
		<div class="lingk" id="message">
			<div v-for="(item, index) in datalist" :key="(index += 1)" class="keylisnt">
				<div class="sonmianll">
					<div class="sonleft">
						<div v-if="whether">
							<span v-if="index > 3">{{ index }}</span>
							<img v-else :src="index === 1 ? top1 : index === 2 ? top2 : index === 3 ? top3 : ''" />
						</div>
						<div v-else>
							<span>{{ item.top }}</span>
						</div>
						<div>{{ item.name }}</div>
						<div>{{ item.sex }}</div>
					</div>

					<!-- 成绩卡片 -->
					<div class="sonrigth">
						<div class="linhert">
							<div class="linhertleft">
								<div class="lisbont">
									<div style="width: 40px;"></div>
									<div v-for="(atem, andex) in item.list.data" :key="andex">
										<div style="width: 30px;text-align: center;color: #3F4A4E !important;" v-if="atem.state == 3">{{ atem.score }}</div>
										<div style="width: 30px;text-align: center; color: #3F4A4E;font-size: 20px;" v-if="atem.score == 0">-</div>
										<!-- 等于0的情况下 -->

										<div class="noekonger" v-if="atem.state == 4">{{ atem.score }}</div>

										<div class="noekong" v-if="atem.state == 5">{{ atem.score }}</div>

										<div class="pajier" v-if="atem.state == 1">{{ atem.score }}</div>

										<div class="yuan" v-if="atem.state == 2">{{ atem.score }}</div>
									</div>
								</div>
							</div>
							<div class="linhertrigth">
								<div class="navmyall">
									<div v-for="(ktem, kndex) in item.extend.list" :key="kndex" :style="{ color: ktem.flag ? 'red' : '' }">{{ ktem.number }}</div>
									<div class="nums" style="color: red;">{{ item.extend.sum }}</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	props: ['form', 'formdata'],
	name: 'automatic',
	data() {
		return {
			bout: '',
			title: '无',
			text: '拼命加载中',
			loading: false,
			t: null,
			tiem: 50,
			mosi: 1,
			whether: false,
			datalist: [],
			top1: require('../../assets/mianimage/top1.png'),
			top2: require('../../assets/mianimage/top2.png'),
			top3: require('../../assets/mianimage/top3.png'),
			keyfreon: true
		};
	},
	computed: {},
	watch: {},
	destroyed() {
		window.clearInterval(this.t);
	},
	methods: {
		getdata() {
			if (this.mosi == 1) {
				this.loading = true;
			}
			const grous = JSON.parse(sessionStorage['form']);
			const { matcharr, rank } = grous;
			api.pcwebindex({
				match_id: matcharr[0],
				group_id: matcharr[1],
				bout: matcharr[2],
				rank: rank
			}).then(res => {
				if (res.data.xcode === 0) {
					if (res.data.data.istop == 1) {
						this.whether = true;
					}
					if (res.data.data.list) {
						this.datalist = res.data.data.list;
						if (this.mosi == 1) {
							if(this.datalist.length>0){
								this.$emit('titles', this.datalist[0].extend.list);
							}
							this.$emit('stand', res.data.data.holes.split(','));
							this.$emit('imagekey', res.data.data.banner);
							this.$emit('groupkey', res.data.data.group_name);
							this.$emit('Types', res.data.data.topType);
							this.mosi = 2;
						}
						this.loading = false;
						if (this.datalist.length === 0) {
							this.text = '暂无更多数据请等待....';
							this.loading = true;
							setTimeout(() => {
								this.getdata();
							}, 3000);
						} else {
							if (this.datalist.length > 8) {
								this.roll();
							} else {
								setTimeout(() => {
									//小于3条时候
									this.getdata();
								}, 5000);
							}
						}
					} else {
						this.text = '暂无更多数据请等待....';
						setTimeout(() => {
							//小于3条时候
							this.getdata();
						}, 5000);
					}
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		},
		roll() {
			let that = this;
			this.$nextTick(() => {
				this.t = setInterval(() => {
					var message = document.getElementById('message');
					let scrollTop = message.scrollTop;
					let windowHeight = message.clientHeight;
					let scrollHeight = message.scrollHeight;
					message.scrollTop += 1.5;
					if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight) - 2) {
						clearInterval(this.t);
						message.scrollTop = 0;
						this.getdata();
					}
				}, that.tiem);
				message.onmouseover = () => {
					this.keyfreon = false;
					clearInterval(this.t, that.tiem);
				};
				message.onmouseout = () => {
					this.keyfreon = true;
					if (this.keyfreon) {
						this.t = null;
						this.t = window.setInterval(this.rollStart, that.tiem);
					}
				};
			});
		},
		rollStart() {
			this.$nextTick(() => {
				let message = document.getElementById('message');
				let scrollTop = message.scrollTop;
				let windowHeight = message.clientHeight;
				let scrollHeight = message.scrollHeight;
				message.scrollTop += 1.5;
				if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight)) {
					window.clearInterval(this.t);
					this.getdata();
					message.scrollTop = 0;
				}
			});
		}
	},
	mounted() {},
	created() {
		this.getdata();
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 16px;
@color09: #3f4a4e;
@ba041728: none;
@ba123769: none;
@ba0e2b53: none;
@import '../../assets/mian.css';

.alls {
	width: 100%;
	height: 100%;

	.lingtops {
		background: #0d5e89;
		width: 100px;
		height: 37px;
		line-height: 37px;
		border-radius: 5px;
		position: absolute;
		left: 80%;
		top: -45px;
		text-align: center;
		color: @color09;
		font-size: @fonst18;
	}

	.lingk {
		width: 100%;
		height: 100%;
		background: @ba123769;
		overflow: auto;

		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
			/**/
		}

		.keylisnt {
			width: 100%;
			height: 12%;

			&:nth-child(odd) {
				background: #f7f7f7;

				.nums {
					background: #e9e9e9;
				}

				.sonmianll {
					.sonleft {
						div {
							&:nth-of-type(1) {
								background: #e9e9e9;
							}
						}
					}
				}
			}

			&:nth-child(even) {
				background: #ebeef5;

				.nums {
					background: #cbd4e5;
				}

				.sonmianll {
					.sonleft {
						div {
							&:nth-of-type(1) {
								background: #cbd4e5;
							}
						}
					}
				}
			}

			.sonmianll {
				width: 100%;
				height: 100%;
				display: flex;
				justify-content: space-between;
				font-size: @fonst18;
				color: @color09;

				.sonleft {
					width: 15%;
					height: 100%;
					display: flex;
					justify-content: space-between;
					align-items: center;

					div {
						height: 100%;
						display: flex;
						align-items: center;
						justify-content: center;
						font-size: 21px;

						&:nth-of-type(1) {
							width: 25%;
						}

						&:nth-of-type(2) {
							width: calc(45% - 10px);
							justify-content: flex-start;
						}

						&:nth-of-type(3) {
							width: 30%;
							justify-content: flex-start;
						}
					}
				}

				.sonrigth {
					width: 85%;
					height: 100%;
					font-size: @fonst18;
					display: flex;
					flex-wrap: wrap;
					align-content: space-between;

					.linhert {
						width: 100%;
						height: 100%;
						display: flex;
						justify-content: space-around;

						.linhertleft {
							width: 80%;
							height: 100%;

							.linstop {
								width: 100%;
								height: 33%;
								display: flex;
								justify-content: space-around;
								align-items: center;
								color: #8d91a6;
							}

							.lisnav {
								width: 100%;
								height: 33%;
								display: flex;
								align-items: center;
								justify-content: space-around;
							}

							.lisbont {
								width: 100%;
								height: 100%;
								display: flex;
								align-items: center;
								justify-content: space-around;
								font-size: 20px;
							}
						}

						.linhertrigth {
							width: 20%;
							height: 100%;

							.navmyall {
								width: 100%;
								font-size: 18px;
								display: flex;
								height: 100%;
								justify-content: space-around;
								align-items: center;

								div {
									width: 50%;
									display: flex;
									height: 100%;
									justify-content: center;
									align-items: center;
								}

								.nums {
								}
							}
						}
					}
				}
			}
		}
	}
}
</style>
