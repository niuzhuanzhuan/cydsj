<template>
	<div class="alls" v-loading="loading" :element-loading-text="text" element-loading-spinner="el-icon-loading" element-loading-background="#ffffff">
		<div class="lingk" id="message">
			<div v-for="(item, index) in datalist" :key="(index += 1)" class="keylisnt">
				<div class="sonmianll">
					<div class="sonleft">
						<div class="lileft">{{ item.top }}</div>
						<div class="contnum">{{ item.name }}</div>
						<div class="qiue"><el-avatar style="width: 60px;height: 60px;" :src="item.avatar"></el-avatar></div>
					</div>

					<!-- 成绩卡片 -->
					<div class="sonrigth">
						<div class="linhert">
							<div class="linhertleft">
								<div class="lisbont">
									<div style="width: 40px;"></div>
									<div v-for="(atem, andex) in item.list.data" :key="andex">
										<div style="width: 30px;text-align: center;color: #3F4A4E !important;" v-if="atem.state == 3">{{ atem.score }}</div>
										<!-- 标准杆 -->
										<div style="width: 30px;text-align: center; color: #3F4A4E;font-size: 20px;" v-if="atem.score == 0">-</div>
										<!-- 等于0的情况下 -->
										<!-- 扒鸡加 -->
										<div class="noekong" v-if="atem.state == 5">{{ atem.score }}</div>
										<!-- 帕吉 -->
										<div class="noekonger" v-if="atem.state == 4">{{ atem.score }}</div>
										<!-- 老鹰球 -->
										<div class="yuan" v-if="atem.state == 2">{{ atem.score }}</div>
										<!-- 小鸟 -->
										<div class="pajier" v-if="atem.state == 1">{{ atem.score }}</div>
									</div>
								</div>
							</div>
							<div class="linhertrigth">
								<div class="navmyall" style="color: #FF4B38;font-weight: 600;">{{ item.differ }}</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
export default {
	props: ['form', 'formdata'],
	name: 'automatic',
	data() {
		return {
			bout: '',
			title: '无',
			text: '暂无更多数据正在，拼命加载中',
			loading: false,
			t: null,
			tiem: 50,
			mosi: 1,
			whether: false,
			datalist: [],
			top1: require('../../assets/mianimage/top1.png'),
			top2: require('../../assets/mianimage/top2.png'),
			top3: require('../../assets/mianimage/top3.png'),
			keyfreon: true
		};
	},
	computed: {},
	watch: {},
	destroyed() {
		window.clearInterval(this.t);
	},
	filters: {},
	methods: {
		getdata() {
			if (this.mosi == 1) {
				this.loading = true;
			}
			const grous = JSON.parse(sessionStorage['form']);
			const { matcharr, rank, type } = grous;
			api.getFourTeam({
				match_id: matcharr[0],
				group_id: matcharr[1],
				bout: matcharr[2],
				type: type,
				rank: rank
			}).then(res => {
				if (res.data.xcode === 0) {
					this.mosi = 2;
					if (res.data.data.istop == 1) {
						this.whether = true;
					}

					this.$emit('stand', res.data.data.holes.split(','));
					this.$emit('imagekey', res.data.data.banner);
					if (res.data.data.list) {
						this.loading = false;
						this.datalist = res.data.data.list;
					}
					if (!this.datalist) {
						this.text = '暂无更多数据请等待....';
						this.loading = true;
						setTimeout(() => {
							this.getdata();
						}, 3000);
					} else {
						if (this.datalist.length > 8) {
							this.roll();
						} else {
							setTimeout(() => {
								//小于3条时候
								this.getdata();
							}, 5000);
						}
					}
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		},
		roll() {
			let that = this;
			this.$nextTick(() => {
				this.t = setInterval(() => {
					var message = document.getElementById('message');
					let scrollTop = message.scrollTop;
					let windowHeight = message.clientHeight;
					let scrollHeight = message.scrollHeight;
					message.scrollTop += 1.5;
					if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight) - 2) {
						clearInterval(this.t);
						message.scrollTop = 0;
						this.getdata();
					}
				}, that.tiem);
				message.onmouseover = () => {
					this.keyfreon = false;
					clearInterval(this.t, that.tiem);
				};
				message.onmouseout = () => {
					this.keyfreon = true;
					if (this.keyfreon) {
						this.t = null;
						this.t = window.setInterval(this.rollStart, that.tiem);
					}
				};
			});
		},
		rollStart() {
			this.$nextTick(() => {
				let message = document.getElementById('message');
				let scrollTop = message.scrollTop;
				let windowHeight = message.clientHeight;
				let scrollHeight = message.scrollHeight;
				message.scrollTop += 1.5;
				if (parseInt(scrollTop) + parseInt(windowHeight) == parseInt(scrollHeight) - 2) {
					window.clearInterval(this.t);
					this.getdata();
					message.scrollTop = 0;
				}
			});
		}
	},
	mounted() {},
	created() {
		this.getdata();
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 16px;
@color09: #3f4a4e;
@ba041728: none;
@ba123769: none;
@ba0e2b53: none;
@import '../../assets/mian.css';
.alls {
	width: 100%;
	height: 100%;
	.lingk {
		width: 100%;
		height: 100%;
		background: @ba123769;
		overflow: auto;
		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
			/**/
		}
		.keylisnt {
			width: 100%;
			height: 12%;
			&:nth-child(odd) {
				.sonleft {
					.lileft {
						background: #e9e9e9;
					}
				}
				.sonrigth {
					.linhert {
						.linhertleft {
							background: @ba0e2b53;
						}
						.linhertrigth {
							background: @ba0e2b53;
							.navmyall {
								background: #e9e9e9;
							}
						}
					}
				}
			}
			&:nth-child(even) {
				background: #ebeff5;
				.sonmianll {
					.sonleft {
						.lileft {
							background: #cbd4e1;
						}
					}
					.sonrigth {
						.linhert {
							.linhertleft {
								background: #ebeff5;
							}
							.linhertrigth {
								background: @ba041728;
								.navmyall {
									background: #cbd4e1;
								}
							}
						}
					}
				}
			}
			.sonmianll {
				width: 100%;
				height: 100%;
				display: flex;
				justify-content: space-between;
				font-size: @fonst18;
				color: @color09;
				.sonleft {
					width: 23%;
					height: 100%;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					font-size: 20px;
					.lileft {
						width: 20%;
						height: 100%;
						display: flex;
						justify-content: center;
						align-items: center;
					}
					.contnum {
						width: 60%;
						height: 100%;
						display: flex;
						justify-content: center;
						align-items: center;
					}
					.qiue {
						width: 20%;
						height: 100%;
						display: flex;
						justify-content: center;
						align-items: center;
					}
				}
				.sonrigth {
					width: 77%;
					height: 100%;
					font-size: @fonst18;
					display: flex;
					flex-wrap: wrap;
					align-content: space-between;
					.linhert {
						width: 100%;
						height: 100%;
						display: flex;
						justify-content: space-around;
						.linhertleft {
							width: 95%;
							height: 100%;
							.lisbont {
								width: 100%;
								height: 100%;
								display: flex;
								align-items: center;
								justify-content: space-around;
								font-size: 20px;
							}
						}
						.linhertrigth {
							width: 5%;
							height: 100%;
							.navmyall {
								width: 100%;
								height: 100%;
								display: flex;
								justify-content: center;
								align-items: center;
								font-size: 18px;
							}
						}
					}
				}
			}
		}
	}
}
</style>
