<template>
	<div class="indexmain">
		<div class="linst">
			<div class="linsstdome">
				<img src="../../assets/mianimage/banner.png" />
				<div class="lingtops">{{ title }}</div>
				<div class="linamo">
					<div class="minaall">
						<div class="fromag">
							<div class="fromtop">
								<div class="leftlisnt">
									<div>排名</div>
									<div>基本信息</div>
									<!-- <div>场次</div> -->
									<div v-for="(item, index) in formdata.ranks" :key="index" v-show="index!=0" v-if="form.rank == item.name">{{ item.value }}</div>
								</div>
								<div class="rigthfron">
									<div class="linstop">
										<div style="width: 40px;">洞号</div>
										<div v-for="(item, index) in 18" :key="item">{{ item }}</div>
									</div>
									<div class="lisnav">
										<div style="width: 40px;">标杆</div>
										<div v-if="jndex <= 19" v-for="(jtem, jndex) in listdata" :key="jndex">{{ jtem }}</div>
									</div>
									<div class="rigthlist">成绩</div>
								</div>
							</div>
							<div class="mianbonnt">
								<roll ref="rolls" :form="form" @titles="titles" @stand="stand" :formdata="formdata" />
								<!-- <automatic ref="rolls" :form="form" @titles="titles" @stand="stand" :formdata="formdata" /> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import roll from '@/components/automatic/automatic1.vue';
import automatic from '@/components/automatic/automatic.vue';
import { mapMutations } from 'vuex';
export default {
	name: 'Home',
	data() {
		return {
			form: {},
			formdata: {},
			title: '',
			listdata: []
		};
	},
	components: {
		roll,
		automatic
	},
	methods: {
		titles(data) {
			this.title = data;
		},
		stand(data) {
			this.listdata = data;
			console.log(this.listdata)
		}
	},
	created() {
		this.formdata = JSON.parse(sessionStorage['formdata']);
		this.form = JSON.parse(sessionStorage['form']);
		this.formdata.match_id.map(item => {
			if (item.id == this.form.match_id) {
				document.title = item.title;
			}
		});
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 18px;
@fonst30: 30px;
@color09: #0acecb;
.conetleft_top {
}
.indexmain {
	width: 100%;
	height: 100vh;
	background: #090f30;
	overflow: auto;
	// padding-bottom: 1.25rem;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #09f0e2;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #09f0e2;
	}
	&::-webkit-scrollbar-corner {
		background: #09f0e2;
	}
	.linst {
		width: 92%;
		height: 98%;
		padding: 0 4% 2% 4%;
		.linsstdome {
			width: 100%;
			height: 100%;
			position: relative;
			display: flex;
			justify-content: center;
			.lingtops {
				background: #0d5e89;
				width: 100px;
				height: 37px;
				line-height: 37px;
				border-radius: 5px;
				position: absolute;
				left: 82%;
				top: 110px;
				text-align: center;
				color: @color09;
				font-size: @fonst18;
			}
			img {
				width: 100%;
				height: 100%;
			}
			.linamo {
				width: 100%;
				height: 84%;
				bottom: 0;
				position: absolute;
				.minaall {
					width: 96%;
					height: 98%;
					padding: 0 2% 2% 2%;
					.fromag {
						width: 100%;
						height: 100%;
						background: #0c475f;
						border-radius: 10px;
						.fromtop {
							width: 100%;
							height: 10%;
							display: flex;
							justify-content: space-between;
							color: @color09;
							font-size: 20px;
							.leftlisnt {
								width: 20%;
								height: 100%;
								display: flex;
								align-items: center;
								justify-content: space-around;
								div {
									width: 40%;
									display: flex;
									align-items: center;
									justify-content: center;
									&:nth-child(2) {
										justify-content: flex-start !important;
									}
									&:nth-child(3) {
										justify-content: center !important;
									}
								}
							}
							.rigthfron {
								width: 78%;
								height: 100%;
								font-size: 15px;
								position: relative;
								.rigthlist {
									position: absolute;
									width: 15%;
									right: 0;
									top: 0;
									height: 100%;
									display: flex;
									justify-content: center;
									align-items: center;
								}
								.linstop {
									width: 84.5%;
									height: 50%;
									display: flex;
									justify-content: space-around;
									align-items: center;
									color: #8d91a6;
									div {
										width: 22px;
										height: 22px;
										display: flex;
										justify-content: space-around;
										align-items: center;
									}
								}
								.lisnav {
									width: 84.5%;
									height: 50%;
									display: flex;
									align-items: center;
									justify-content: space-around;
									div {
										width: 22px;
										height: 22px;
										display: flex;
										justify-content: space-around;
										align-items: center;
									}
								}
							}
						}
						.mianbonnt {
							width: 100%;
							height: 90%;
						}
					}
				}
			}
		}
	}
}
</style>
