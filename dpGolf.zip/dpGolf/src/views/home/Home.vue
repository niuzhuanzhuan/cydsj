<template>
	<div class="indexmain">
		<div class="linst">
			<div class="linsstdome">
				<img :src="images" v-if="images"/>
				<div class="linamo">
					<div class="minaall">
						<div class="fromag">
							<div class="fromtop">
								<div class="leftlisnt">
									<div>排名</div>
									<div>姓名</div>
									<div>性别</div>
									<div v-for="(item, index) in formdata.ranks" :key="index" v-show="index != 0" v-if="form.rank == item.name">{{ item.value }}</div>
								</div>
								<div class="rigthfron">
									<div class="linstop">
										<div style="width: 40px;">Hole</div>
										<div v-for="(item, index) in 18" :key="item">{{ item }}</div>
									</div>
									<div class="lisnav">
										<div style="width: 40px;">par</div>
										<div v-if="jndex <= 19" v-for="(jtem, jndex) in listdata" :key="jndex">{{ jtem }}</div>
									</div>
									<div class="rigthlist">
										<div v-for="(item,index) in titlearr" :key="index" :style="{color:item.flag?'red':''}">
											{{item.r}}
										</div>
										<div>总成绩</div>
									</div>
								</div>
								<div class="lefts">{{ group }}</div>
								<div class="rgith">{{ topType }}</div>
							</div>
							<div class="mianbonnt">
								<automatic ref="rolls" :form="form" @groupkey="groupkey" @imagekey="imagekey" @stand="stand" :formdata="formdata"
								@titles="titles"
								 @Types="Types" />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import api from '@/utils/api.js';
	import automatic from '@/components/automatic/automatic.vue';
	import {
		mapMutations
	} from 'vuex';
	export default {
		name: 'Home',
		data() {
			return {
				form: {},
				formdata: {},
				listdata: [],
				images: '',
				group: '',
				topType: '',
				titlearr:[]
			};
		},
		components: {
			automatic
		},
		methods: {
			stand(data) {
				this.listdata = data;
			},
			imagekey(data) {
				this.images = data;
			},
			groupkey(data) {
				this.group = data;
			},
			Types(data) {
				this.topType = data;
			},
			titles(data){
				this.titlearr=data
			}
		},
		created() {}
	};
</script>
<style scoped>
	.lefts {
		position: absolute;
		top: 0;
		left: 0;
		color: #ffffff;
		background-color: #7a88a1;
		padding: 5px 40px;
		font-size: 18px;
		border-bottom-right-radius: 18px;
	}

	.rgith {
		position: absolute;
		top: 0;
		right: 0;
		color: #ffffff;
		background-color: #7a88a1;
		padding: 5px 40px;
		font-size: 18px;
		border-bottom-left-radius: 18px;
	}
</style>
<style lang="less" scoped>
	@fonst24: 24px;
	@fonst18: 18px;
	@fonst30: 30px;
	@color09: #16395b;

	.indexmain {
		width: 100%;
		height: 100vh;
		background: #090f30;
		overflow: auto;

		// padding-bottom: 1.25rem;
		&::-webkit-scrollbar {
			width: 2px;
			height: 5px;
			/**/
		}

		&::-webkit-scrollbar-track {
			background: rgb(239, 239, 239);
			border-radius: 2px;
		}

		&::-webkit-scrollbar-thumb {
			background: #09f0e2;
			border-radius: 10px;
		}

		&::-webkit-scrollbar-thumb:hover {
			background: #09f0e2;
		}

		&::-webkit-scrollbar-corner {
			background: #09f0e2;
		}

		.linst {
			width: 92%;
			height: 98%;
			padding: 0 4% 2% 4%;

			.linsstdome {
				width: 100%;
				height: 100%;
				position: relative;
				display: flex;
				justify-content: center;

				.lingtops {
					background: #0d5e89;
					width: 100px;
					height: 37px;
					line-height: 37px;
					border-radius: 5px;
					position: absolute;
					left: 82%;
					top: 110px;
					text-align: center;
					color: @color09;
					font-size: @fonst18;
				}

				img {
					width: 100%;
					height: 100%;
				}

				.linamo {
					width: 100%;
					height: 84%;
					bottom: 0;
					position: absolute;

					.minaall {
						width: 96%;
						height: 98%;
						padding: 0 2% 2% 2%;

						.fromag {
							width: 100%;
							height: 99%;
							background: #ffffff;
							border-radius: 10px;
							overflow: hidden;
							margin-top: 10px;

							.fromtop {
								width: 100%;
								height: 15%;
								display: flex;
								justify-content: space-between;
								color: @color09;
								font-size: 20px;
								font-weight: 500;
								background: #A4B0C8;
								position: relative;

								.leftlisnt {
									font-size: 20px;
									width: 15%;
									height: 100%;
									display: flex;
									align-items: center;
									justify-content: space-around;

									div {
										display: flex;
										padding-top: 10%;
										justify-content: center;
										&:nth-of-type(1){
											width: 25%;
										}
										&:nth-of-type(2){
											width: calc(45% - 10px);
											padding-left: 10px;
											justify-content: flex-start;
										}
										&:nth-of-type(3){
											width: 30%;
											justify-content: flex-start;
										}
									}
								}

								.rigthfron {
									width: 85%;
									height: 100%;
									font-size: 18px;
									display: flex;
									flex-direction: column;
									justify-content: space-between;
									position: relative;

									.rigthlist {
										position: absolute;
										width: 20%;
										right: 0;
										top: 0;
										height: 100%;
										display: flex;
										justify-content: space-around;
										align-items: center;
										div {
											width: 50%;
											display: flex;
											padding-top: 10%;
											height: 90%;
											justify-content: center;
											align-items: center;
										}
									}

									.linstop {
										width: 80%;
										height: 60%;
										display: flex;
										justify-content: space-around;
										align-items: flex-end;

										div {
											width: 30px;
											height: 30px;
											display: flex;
											justify-content: space-around;
											align-items: center;
										}
									}

									.lisnav {
										width: 80%;
										height: 40%;
										display: flex;
										align-items: flex-start;
										justify-content: space-around;

										div {
											width: 30px;
											height: 30px;
											display: flex;
											justify-content: space-around;
											align-items: center;
										}
									}
								}
							}

							.mianbonnt {
								width: 100%;
								height: 87%;
							}
						}
					}
				}
			}
		}
	}
</style>
