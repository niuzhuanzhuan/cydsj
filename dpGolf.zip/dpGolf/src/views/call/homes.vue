<template>
	<div class="indexmain">
		<div class="linst">
			<div class="linsstdome">
				<div class="lisba">
					<el-form ref="form" :model="form" :rules="rules" label-width="80px">
						<el-form-item label="赛事类型" prop="type">
							<el-select v-model="form.type" style="width: 40rem;" clearable placeholder="请选择赛事活动">
								<el-option v-for="(item, index) in typearr" :key="index" :label="item.name" :value="item.type"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="选择赛事" prop="matcharr" v-show="form.type">
							<el-cascader style="width: 40rem;" :key="inmians" clearable v-model="form.matcharr" :options="options" @change="handleChange"></el-cascader>
						</el-form-item>
						<!-- <el-form-item label="赛事名称" prop="match_id">
							<el-select v-model="form.match_id" clearable placeholder="请选择赛事活动">
								<el-option v-for="(item, index) in match_id" :key="index" :label="item.name" :value="item.match_id"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="组别" prop="group_id">
							<el-select v-model="form.group_id" clearable placeholder="请选择组别">
								<el-option v-for="(item, index) in group_id" :key="index" :label="item.group_name" :value="item.group_id"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="赛事场次" prop="bout">
							<el-select v-model="form.bout" clearable placeholder="请选择赛事场次">
								<el-option v-for="(item, index) in bout" :key="index" :label="item.bout_name" :value="item.bout_id"></el-option>
							</el-select>
						</el-form-item> -->
						<el-form-item label="排序方式" prop="rank">
							<el-select v-model="form.rank" style="width: 40rem;" clearable placeholder="请选择排序方式">
								<el-option v-for="(item, index) in ranks" :key="index" :label="item.order_name" :value="item.order_id"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="排名类型" prop="show_type_id" v-if="form.type == 2">
							<el-select v-model="form.show_type_id" style="width: 40rem;" clearable placeholder="请选择排序方式">
								<el-option v-for="(item, index) in show_types" :key="index" :label="item.show_type_name" :value="item.show_type_id"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item><el-button type="primary" @click="onSubmit('form')">立即查看</el-button></el-form-item>
					</el-form>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import { URL } from '@/utils/doman.js';
export default {
	name: 'call',
	data() {
		return {
			form: {},
			fromdata: {},
			match_id: [],
			bout: [],
			ranks: [],
			group_id: [],
			typearr: [],
			show_types: [],
			options: [],
			inmians: 1,
			rules: {
				type: [{ required: true, message: '请选择赛事类型', trigger: 'change' }],
				matcharr: [{ required: true, message: '请选择赛事', trigger: 'change' }],
				rank: [{ required: true, message: '请选择排序方式', trigger: 'change' }],
				show_type_id: [{ required: true, message: '请选择排名类型', trigger: 'change' }]
			}
		};
	},
	watch: {
		'form.type'(newval, val) {
			if (newval != val) {
				this.$set(this.form, 'matcharr', []);
				this.inmians += 1;
				if (newval == '') {
					return false;
				}
				this.typearr.forEach(item => {
					if (item.type === newval) {
						item.list.forEach(ktem => {
							ktem.value = ktem.match_id;
							ktem.label = ktem.name;
							if (ktem.list) {
								ktem.children = ktem.list;
								ktem.children.forEach(jtem => {
									jtem.value = jtem.group_id;
									jtem.label = jtem.group_name;
									if (jtem.list) {
										jtem.children = jtem.list;
										jtem.children.forEach(mitem => {
											mitem.value = mitem.bout_id;
											mitem.label = mitem.bout_name;
										});
									}
								});
							}
						});
						this.options = item.list;
					}
				});
			}
		}
	},
	methods: {
		handleChange(data) {
			// console.log(data);
		},
		onSubmit(formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					sessionStorage['form'] = JSON.stringify(this.form);
					if (this.form.type == 10) {
						open(`/dpGolf/#/Totalscore`);
					}
					if (this.form.type == 1) {
						open(`#/home1`); //个人赛
					}
					if (this.form.type == 2) {
						if (this.form.show_type_id == 1) {
							open(`#/home1`); //个人赛
						} else {
							open(`#/Totalscore`);
						}
					}
					if (this.form.type == 3) {
						open(`#/team`); //四人两球人赛
					}
					if (this.form.type == 4) {
						open(`#/team`); //四人4球人赛
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		getdata() {
			api.getMatchType().then(res => {
				if (res.data.xcode === 0) {
					this.fromdata = res.data.data;
					this.show_types = this.fromdata.show_type;
					this.ranks = this.fromdata.order;
					this.typearr = this.fromdata.data;
					sessionStorage['zong'] = JSON.stringify(res.data.data);
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		}
	},
	created() {
		document.title = '选择活动赛事';
		this.getdata();
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 18px;
@fonst30: 30px;
@color09: #0acecb;
.conetleft_top {
}
.indexmain {
	width: 100%;
	height: 100vh;
	// background: #090f30;
	overflow: auto;
	// padding-bottom: 1.40rem;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #09f0e2;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #09f0e2;
	}
	&::-webkit-scrollbar-corner {
		background: #09f0e2;
	}
	.linst {
		width: 92%;
		height: 98%;
		padding: 0 4% 2% 4%;
		.linsstdome {
			width: 100%;
			height: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			.lisba {
				background: #ffffff;
				padding: 50px;
			}
		}
	}
}
</style>
