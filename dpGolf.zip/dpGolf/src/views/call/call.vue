<template>
	<div class="indexmain">
		<div class="linst">
			<div class="linsstdome">
				<div class="lisba">
					<el-form ref="form" :model="form" :rules="rules" label-width="80px">
						<el-form-item label="赛事活动" prop="match_id">
							<el-select v-model="form.match_id" style="width: 40rem;" placeholder="请选择赛事活动">
								<el-option v-for="(item, index) in match_id" :key="index" :label="item.title" :value="item.id"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="赛事场次" prop="bout">
							<el-select v-model="form.bout" style="width: 40rem;" placeholder="请选择赛事场次">
								<el-option v-for="(item, index) in bout" :key="index" :label="item.value" :value="item.name"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="排序方式" prop="rank">
							<el-select v-model="form.rank" style="width: 40rem;" placeholder="请选择排序方式">
								<el-option v-for="(item, index) in ranks" :key="index" :label="item.value" :value="item.name"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="组别" prop="group_id">
							<el-select v-model="form.group_id" style="width: 40rem;" placeholder="请选择组别">
								<el-option v-for="(item, index) in group_id" :key="index" :label="item.value" :value="item.name"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item><el-button type="primary" @click="onSubmit('form')">立即查看</el-button></el-form-item>
					</el-form>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import { URL } from '@/utils/doman.js';
export default {
	name: 'call',
	data() {
		return {
			form: {},
			formdata: {},
			match_id: [],
			bout: [],
			ranks: [],
			group_id: [],
			rules: {
				match_id: [{ required: true, message: '请选择赛事活动', trigger: 'blur' }],
				bout: [{ required: true, message: '请选择赛事场次', trigger: 'blur' }],
				rank: [{ required: true, message: '请选择排序方式', trigger: 'blur' }],
				group_id: [{ required: true, message: '请选择组别', trigger: 'blur' }]
			}
		};
	},
	methods: {
		onSubmit(formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					// URL
					sessionStorage['formdata'] = JSON.stringify(this.formdata);
					sessionStorage['form'] = JSON.stringify(this.form);
					window.open(`/golf/dp/#/home`);
					// window.open(`/dpGolf/#/home`);
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		getdata() {
			api.golf_score_rank().then(res => {
				if (res.data.xcode === 1) {
					this.formdata = res.data.data;
					this.match_id = res.data.data.match_id;
					this.bout = res.data.data.bouts;
					this.ranks = res.data.data.ranks;
					this.group_id = res.data.data.group_id;
				} else {
					this.$message.warning(res.data.msg);
				}
			});
		}
	},
	created() {
		document.title = '选择活动赛事';
		this.getdata();
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 18px;
@fonst30: 30px;
@color09: #0acecb;
.conetleft_top {
}
.indexmain {
	width: 100%;
	height: 100vh;
	// background: #090f30;
	overflow: auto;
	// padding-bottom: 1.25rem;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #09f0e2;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #09f0e2;
	}
	&::-webkit-scrollbar-corner {
		background: #09f0e2;
	}
	.linst {
		width: 92%;
		height: 98%;
		padding: 0 4% 2% 4%;
		.linsstdome {
			width: 100%;
			height: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			.lisba {
				background: #ffffff;
				padding: 50px;
			}
		}
	}
}
</style>
