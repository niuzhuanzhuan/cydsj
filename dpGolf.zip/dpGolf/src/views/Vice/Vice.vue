<template>
	<div class="indexmain">
		<div class="linst">
			<div class="linsstdome">
				<img src="../../assets/mianimage/banner.png" />
				<div class="lingtops">级别：{{ title ? title : '无' }}</div>
				<div class="linamo">
					<div class="minaall">
						<div class="fromag">
							<div class="fromtop">
								<div class="leftlisnt">
									<div>排名</div>
									<div>姓名</div>
									<div>性别</div>
									<div>年龄</div>
									<div>场次</div>
									<div>差点</div>
								</div>
							</div>
							<div class="mianbonnt"><roll /></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import roll from '@/components/automatic/Viceanv.vue';
import { mapMutations } from 'vuex';
export default {
	name: 'Vice',
	data() {
		return {};
	},
	computed: {
		title() {
			let level = this.$route.query.level;
			if (level == 1) {
				return '金T';
			} else if (level == 2) {
				return '蓝T';
			} else if (level == 3) {
				return '白T';
			} else if (level == 4) {
				return '红T';
			}
		}
	},
	components: {
		roll
	},
	watch: {},
	methods: {},
	created() {}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 18px;
@fonst30: 30px;
@color09: #0acecb;
.conetleft_top {
}
.indexmain {
	width: 100%;
	height: 100vh;
	background: #090f30;
	overflow: auto;
	// padding-bottom: 1.25rem;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #09f0e2;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #09f0e2;
	}
	&::-webkit-scrollbar-corner {
		background: #09f0e2;
	}
	.linst {
		width: 92%;
		height: 98%;
		padding: 0 4% 2% 4%;
		.linsstdome {
			width: 100%;
			height: 100%;
			position: relative;
			display: flex;
			justify-content: center;
			.lingtops {
				background: #0d5e89;
				height: 37px;
				line-height: 37px;
				position: absolute;
				left: 80%;
				top: 110px;
				width: 100px;
				text-align: center;
				color: @color09;
				font-size: @fonst18;
			}
			img {
				width: 100%;
				height: 100%;
			}
			.linamo {
				width: 100%;
				height: 84%;
				bottom: 0;
				position: absolute;
				.minaall {
					width: 96%;
					height: 98%;
					padding: 0 2% 2% 2%;
					.fromag {
						width: 100%;
						height: 100%;
						background: #0c475f;
						border-radius: 10px;
						.fromtop {
							width: 100%;
							height: 10%;
							display: flex;
							color: @color09;
							font-size: 20px;
							.leftlisnt {
								width: 100%;
								height: 100%;
								display: flex;
								align-items: center;
								justify-content: space-around;
							}
						}
						.mianbonnt {
							width: 100%;
							height: 90%;
						}
					}
				}
			}
		}
	}
}
</style>
