<template>
	<div class="indexmain">
		<div class="linst">
			<div class="linsstdome">
				<img :src="images" v-if="images"/>
				<div class="linamo">
					<div class="minaall">
						<div class="fromag">
							<div class="fromtop">
								<div class="leftlisnt">
									<div class="lileft">排名</div>
									<div class="contnum">姓名</div>
									<div class="qiue">球队</div>
								</div>
								<div class="rigthfron">
									<div class="linstop">
										<div style="width: 40px;">Hole</div>
										<div v-for="(item, index) in 18" :key="item">{{ item }}</div>
									</div>
									<div class="lisnav">
										<div style="width: 40px;">par</div>
										<div v-if="jndex <= 19" v-for="(jtem, jndex) in listdata" :key="jndex">{{ jtem }}</div>
									</div>
									<div class="rigthlist">总成绩</div>
								</div>
								<div class="rgith">{{ type }}</div>
								<div class="lefts">组别：{{ group }}</div>
							</div>
							<div class="mianbonnt"><team ref="rolls" :form="form" @imagekey="imagekey" @stand="stand" :formdata="formdata" /></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import team from '@/components/team/team.vue';
import { mapMutations } from 'vuex';
export default {
	name: 'Home',
	data() {
		return {
			form: {},
			formdata: {},
			listdata: [],
			images:''
		};
	},
	components: {
		team
	},
	methods: {
		stand(data) {
			this.listdata = data;
		},
		imagekey(data) {
			this.images = data;
		},
	},
	computed: {
		group() {
			const grous = JSON.parse(sessionStorage['form']);
			const zong = JSON.parse(sessionStorage['zong']);
			let nema = '';
			zong.data.forEach(item => {
				if (item.type == grous.type) {
					item.list.forEach(jtem => {
						if (jtem.match_id === grous.matcharr[0]) {
							jtem.list.forEach(kitem => {
								if (kitem.group_id === grous.matcharr[1]) {
									nema = kitem.group_name;
								}
							});
						}
					});
				}
			});
			return nema;
		},
		type() {
			const grous = JSON.parse(sessionStorage['form']);
			const zong = JSON.parse(sessionStorage['zong']);
			let nema = '';
			zong.data.forEach(item => {
				if (item.type == grous.type) {
					item.list.forEach(jtem => {
						if (jtem.match_id === grous.matcharr[0]) {
							jtem.list.forEach(kitem => {
								if (kitem.group_id === grous.matcharr[1]) {
									kitem.list.forEach(initem => {
										if (initem.bout_id === grous.matcharr[2]) {
											nema = initem.bout_name;
										}
									});
								}
							});
						}
					});
				}
			});
			return nema;
		}
	},
	created() {
		this.form = JSON.parse(sessionStorage['form']);
	}
};
</script>
<style scoped></style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 18px;
@fonst30: 30px;
@color09: #073054;
.indexmain {
	width: 100%;
	height: 100vh;
	background: #090f30;
	overflow: auto;
	// padding-bottom: 1.25rem;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #09f0e2;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #09f0e2;
	}
	&::-webkit-scrollbar-corner {
		background: #09f0e2;
	}
	.linst {
		width: 92%;
		height: 98%;
		padding: 0 4% 2% 4%;
		.linsstdome {
			width: 100%;
			height: 100%;
			position: relative;
			display: flex;
			justify-content: center;
			.lingtops {
				background: #a5aec9;
				width: 100px;
				height: 37px;
				line-height: 37px;
				border-radius: 5px;
				position: absolute;
				left: 82%;
				top: 110px;
				text-align: center;
				color: @color09;
				font-size: @fonst18;
			}
			img {
				width: 100%;
				height: 100%;
			}
			.linamo {
				width: 100%;
				height: 84%;
				bottom: 0;
				position: absolute;
				.minaall {
					width: 96%;
					height: 98%;
					padding: 0 2% 2% 2%;
					.fromag {
						width: 100%;
						height: 99%;
						background: #ffffff;
						border-radius: 10px;
						overflow: hidden;
						margin-top: 10px;
						position: relative;
						.rigthtitle {
							position: absolute;
							top: 0;
							right: 0;
							color: #ffffff;
							font-size: 14px;
							background-color: #7b889f;
							padding: 5px 15px;
							border-bottom-left-radius: 18px;
						}
						.letftitle {
							position: absolute;
							top: 0;
							left: 0;
							color: #ffffff;
							font-size: 14px;
							background-color: #7b889f;
							padding: 5px 15px;
							border-bottom-right-radius: 18px;
						}
						.fromtop {
							width: 100%;
							height: 14%;
							display: flex;
							justify-content: space-between;
							color: @color09;
							font-size: 20px;
							font-weight: 500;
							background: rgba(164, 176, 198, 0.6);
							position: relative;
							.rgith {
								position: absolute;
								top: 0;
								right: 0;
								color: #ffffff;
								background-color: #7a88a1;
								padding: 2px 20px;
								font-size: 18px;
								border-bottom-left-radius: 18px;
							}
							.lefts {
								position: absolute;
								top: 0;
								left: 0;
								color: #ffffff;
								background-color: #7a88a1;
								padding: 2px 20px;
								font-size: 18px;
								border-bottom-right-radius: 18px;
							}
							.leftlisnt {
								font-size: 20px;
								width: 23%;
								height: 100%;
								display: flex;
								align-items: center;
								justify-content: space-around;
								.lileft {
									width: 20%;
									height: 100%;
									display: flex;
									justify-content: center;
									align-items: center;
								}
								.contnum {
									width: 60%;
									height: 100%;
									display: flex;
									justify-content: center;
									align-items: center;
								}
								.qiue {
									width: 20%;
									height: 100%;
									display: flex;
									justify-content: center;
									align-items: center;
								}
							}
							.rigthfron {
								width: 77%;
								height: 100%;
								font-size: 18px;
								display: flex;
								flex-direction: column;
								justify-content: space-between;
								position: relative;
								.rigthlist {
									position: absolute;
									width: 5%;
									right: 0;
									top: 0;
									height: 100%;
									display: flex;
									justify-content: center;
									align-items: center;
								}
								.linstop {
									width: 95%;
									height: 60%;
									display: flex;
									justify-content: space-around;
									align-items: flex-end;
									div {
										width: 30px;
										height: 30px;
										display: flex;
										justify-content: space-around;
										align-items: center;
									}
								}
								.lisnav {
									width: 95%;
									height: 40%;
									display: flex;
									align-items: flex-start;
									justify-content: space-around;
									div {
										width: 30px;
										height: 30px;
										display: flex;
										justify-content: space-around;
										align-items: center;
									}
								}
							}
						}
						.mianbonnt {
							width: 100%;
							height: 87%;
						}
					}
				}
			}
		}
	}
}
</style>
