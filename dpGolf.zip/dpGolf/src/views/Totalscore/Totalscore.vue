<template>
	<div class="indexmain">
		<div class="linst">
			<div class="linsstdome">
				<img :src="imagess" v-if="imagess"/>
				<!-- <div class="lingtops">{{ title }}</div> -->
				<div class="linamo">
					<div class="minaall">
						<div class="fromag">
							<div class="fromtop">
								<div class="leftmian">排名</div>
								<div class="leftlimg"><span>球队名称</span></div>
								<div class="lipokey">
									<div class="lefttop" v-for="(item, index) in listdata" :key="index">
										<span>{{ item }}</span>
									</div>
								</div>
								<div class="rigthmians">总成绩</div>
								<div class="lefts" v-if="group">{{ group }}</div>
								<div class="rgith"  v-if="topType">{{ topType }}</div>
							</div>
							<div class="mianbonnt"><Totalscore ref="rolls" :form="form" @groupkey="groupkey" @stand="stand" @imagekeys="imagekeys" :formdata="formdata" @Types="Types"/></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import Totalscore from '@/components/Totalscore/Totalscore.vue';
import { mapMutations } from 'vuex';
export default {
	name: 'Home',
	data() {
		return {
			form: {},
			formdata: {},
			title: '',
			listdata: [],
			imagess: '',
			group:'',
			topType:''
		};
	},
	components: {
		Totalscore
	},
	methods: {
		titles(data) {
			this.title = data;
		},
		stand(data) {
			this.listdata = data;
		},
		imagekeys(data) {
			this.imagess = data;
		},
		groupkey(data){
			this.group=data
		},
		Types(data) {
			this.topType = data;
		}
	},
	created() {}
};
</script>
<style scoped>
	.lefts {
		position: absolute;
		top: 0;
		left: 0;
		color: #ffffff;
		background-color: #7a88a1;
		padding: 5px 40px;
		font-size: 18px;
		border-bottom-right-radius: 18px;
	}
	.rgith {
		position: absolute;
		top: 0;
		right: 0;
		color: #ffffff;
		background-color: #7a88a1;
		padding: 5px 40px;
		font-size: 18px;
		border-bottom-left-radius: 18px;
	}
</style>
<style lang="less" scoped>
@fonst24: 24px;
@fonst18: 18px;
@fonst30: 30px;
@color09: #073054;
.indexmain {
	width: 100%;
	height: 100vh;
	background: #090f30;
	overflow: auto;
	// padding-bottom: 1.25rem;
	&::-webkit-scrollbar {
		width: 2px;
		height: 5px;
		/**/
	}
	&::-webkit-scrollbar-track {
		background: rgb(239, 239, 239);
		border-radius: 2px;
	}
	&::-webkit-scrollbar-thumb {
		background: #09f0e2;
		border-radius: 10px;
	}
	&::-webkit-scrollbar-thumb:hover {
		background: #09f0e2;
	}
	&::-webkit-scrollbar-corner {
		background: #09f0e2;
	}
	.linst {
		width: 92%;
		height: 98%;
		padding: 0 4% 2% 4%;
		.linsstdome {
			width: 100%;
			height: 100%;
			position: relative;
			display: flex;
			justify-content: center;
			.lingtops {
				background: #0d5e89;
				width: 100px;
				height: 37px;
				line-height: 37px;
				border-radius: 5px;
				position: absolute;
				left: 82%;
				top: 110px;
				text-align: center;
				color: @color09;
				font-size: @fonst18;
			}
			img {
				width: 100%;
				height: 100%;
			}
			.linamo {
				width: 100%;
				height: 84%;
				bottom: 0;
				position: absolute;
				.minaall {
					width: 96%;
					height: 98%;
					padding: 0 2% 2% 2%;
					.fromag {
						width: 100%;
						height: 99%;
						background: #ffffff;
						border-radius: 10px;
						overflow: hidden;
						margin-top: 10px;
						.fromtop {
							width: 100%;
							height: 15%;
							display: flex;
							color: @color09;
							font-size: 20px;
							font-weight: 500;
							background: #a4b0c6;
							align-items: center;
							position: relative;
							.leftmian {
								width: 8%;
								text-align: center;
							}
							.leftlimg {
								width: 26%;
								span {
									margin-left: 17%;
								}
							}
							.lipokey {
								width: 53%;
								display: flex;
								justify-content: space-around;
								align-items: center;
								.lefttop {
									width: 25%;
								}
							}
							.rigthmians {
								width: 13%;
								text-align: center;
							}
						}
						.mianbonnt {
							width: 100%;
							height: 87%;
						}
					}
				}
			}
		}
	}
}
</style>
