import Vue from 'vue'
import VueRouter from 'vue-router'
import Store from "../vuex/store";
import {
	Toast
} from "vant";
Vue.use(VueRouter)

const routes = [{
		path: '/home',
		name: 'home',
		component: resolve => require(['@/views/home/Home1'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/Totalscore',
		component: resolve => require(['@/views/Totalscore/Totalscore'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/team',
		component: resolve => require(['@/views/team/team'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/home1',
		name: 'home1',
		component: resolve => require(['@/views/home/Home'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/',
		name: 'call',
		component: resolve => require(['@/views/call/homes'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/Vice',
		name: 'Vice',
		component: resolve => require(['@/views/Vice/Vice'], resolve),
		meta: {
			keepAlive: true
		}
	},
	{
		path: '/404',
		name: '404',
		component: resolve => require(['@/components/404'], resolve),
	},
	{
		path: '*',
		redirect: '/404'
	},
]

const router = new VueRouter({
	base: process.env.BASE_URL,
	routes
})


// router.beforeEach((to, from, next) => {
// 	// let token = Store.state.user.userinfo;
// 	if (!Store.state.user.userinfo) {
// 		if (to.path === '/userLogin') {
// 			next()
// 		} else {
// 			Toast('您当前未登录，或登录已过期，请您重新登录')
// 			next({
// 				path: '/userLogin'
// 			})
// 		}
// 	} else {
// 		next()
// 	}
// });

export default router
