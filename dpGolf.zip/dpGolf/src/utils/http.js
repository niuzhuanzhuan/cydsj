'use strict'
import Vue from 'vue'
import axios from 'axios'
import router from '../router'
import doman from './doman'
import Store from "@/vuex/store";
import {
	Message
} from 'element-ui';

if (navigator && navigator.onLine === false) { //检查设备是否能够上网
	Message({
		message: '当前设备网络没有连接，请检查',
		duration: 0,
		type: 'error'
	})
}


const service = axios.create({
	baseURL: doman.URL,
	timeout: 10000, // 请求超时时间
	headers: {
		'XX-Device-Type': 'web',
		'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
	},
});

//request请求拦截器
service.interceptors.request.use(
	config => {
		return config
	},
	error => {
		return Promise.error(error);
	});
//响应拦截器
service.interceptors.response.use(res => {
	if (res.status === 200) {
		return Promise.resolve(res);
	} else {
		return Promise.reject(res);
	}
}, error => {
	if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) { //超时提示
		Message({
			message: '当前网络不是太好哦！请重新刷新页面试试！！',
			duration: 0,
			type: 'warning'
		})
	}
	return Promise.reject(error.response);
})


export default service
