import request from "./http";
import qs from "qs";
import store from "../vuex/store";


let golf_score_rank = (data, suc) => { //成绩排名
	return request({
		method: 'post',
		// url: 'portal/golf20/golf_score_rank',
		url: 'portal/golf20/match_rank',
		data: qs.stringify(data),
	}).then(suc).catch((error) => {})
};

let pcwebindex = (data, suc) => { //个人排名
	return request({
		method: 'post',
		url: 'pcweb/golf/index',
		data: qs.stringify(data),
	}).then(suc).catch((error) => {})
};

let getMatchType = (data, suc) => { //类型-类型-组别-轮次-排序
	return request({
		method: 'post',
		url: 'pcweb/golf/getMatchType',
		data: qs.stringify(data),
	}).then(suc).catch((error) => {})
};

let teamTop = (data, suc) => { //大屏团队净杆排名
	return request({
		method: 'post',
		url: 'pcweb/golf/teamTop',
		data: qs.stringify(data),
	}).then(suc).catch((error) => {})
};

let getFourTeam = (data, suc) => { //团队净杆排名-四球两球
	return request({
		method: 'post',
		url: 'pcweb/golf/getFourTeam',
		data: qs.stringify(data),
	}).then(suc).catch((error) => {})
};
export default {
	getFourTeam,
	teamTop,
	getMatchType,
	golf_score_rank,
	pcwebindex,
}
