// 网站全局变量
// let URL=' https://api.live.yongdongli.net/'//正式服
let URL = ' https://api.live.sportbd.cn/' //测试服

module.exports = {
	URL
};
