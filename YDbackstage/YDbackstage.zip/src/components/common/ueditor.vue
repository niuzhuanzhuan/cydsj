<template lang="html">
	<div class="ueditor"><vue-ueditor-wrap v-model="values" id="ueditor" :config="myConfig"></vue-ueditor-wrap></div>
</template>

<script>
import VueUeditorWrap from 'vue-ueditor-wrap';
const path = process.env.NODE_ENV !== 'development' ? '/pc/ydl/ueditor/' : '/ueditor/';
export default {
	name: 'UEditor',
	props: {
		height: {
			type: Number,
			default: 300
		},
		width: {
			type: String,
			default: '100%'
		},
		value: {
			type: String,
			default: ''
		}
	},
	components: {
		VueUeditorWrap
	},
	data() {
		return {
			values: this.value,
			myConfig: {
				toolbars: [
					[
						'undo', //撤销
						'bold', //加粗
						'indent', //首行缩进
						'simpleupload', //单图上传
						'justifycenter',
						// 'insertimage' //多图上传
					]
				],

				// 编辑器不自动被内容撑高
				autoHeightEnabled: false,
				// 初始容器高度
				initialFrameHeight: this.height,
				// 初始容器宽度
				initialFrameWidth: this.width,
				// UEDITOR_HOME_URL: '/YDbackstage/ueditor/'
				UEDITOR_HOME_URL: path,
				wordCount: false,
				elementPathEnabled: false
			}
		};
	},
	methods: {},
	mounted() {
		this.myConfig.UEDITOR_HOME_URL = path;
	},
	destroyed() {},
	watch: {
		values(newValue, oldValue) {
			this.$emit('update:value', newValue);
		}
	}
};
</script>

