<template>
	<div class="header">
		<div class="her_left">
			<div class="left_font">
				<img src="../../assets/home/banner.png" />
			</div>
		</div>
		<div class="her_rigth">
			<el-dropdown class="user-name" trigger="click" @command="handleCommand">
				<span class="el-dropdown-link">
					{{domian}}
					<i style="margin-left: 12px;font-weight: bold;" class="el-icon-arrow-down"></i>
				</span>
				<el-dropdown-menu slot="dropdown">
					<el-dropdown-item divided command="loginout">退出登录</el-dropdown-item>
				</el-dropdown-menu>
			</el-dropdown>
		</div>
	</div>
</template>
<script>
import bus from './bus';
import api from '@/utils/api';
import define from '../define/define';
import { mapActions, mapGetters } from 'vuex';
export default {
	data() {
		return {};
	},
	watch: {},
	computed: {
		domian(){
			if(this.$store.state.initfromdata.mobile){
				return this.$store.state.initfromdata.mobile
			}else{
				return "未登录"
			}
		}
	},
	created() {},
	methods: {
		handleCommand(command) {
			if (command == 'loginout') {
				this.$confirm('确定退出系统吗?', '', {
					confirmButtonText: '取消',
					cancelButtonText: '确定',
					type: 'warning',
					showClose: false,
					customClass: 'customClass',
					iconClass: 'el-icon-question',
					cancelButtonClass: 'cancelButtonClass',
					confirmButtonClass: 'confirmButtonClass'
				})
					.then(() => {})
					.catch(() => {
						this.$router.push('/Login');
					});
			} else {
			}
		},
		// 侧边栏折叠
		collapseChage() {
			this.collapse = !this.collapse;
			bus.$emit('collapse', this.collapse);
		}
	},
	mounted() {}
};
</script>
<style>
.customClass > .el-message-box__btns {
	padding: 5px 30px 30px !important;
}
.customClass > .el-message-box__content {
	padding: 40px 24px 40px 100px;
	font-size: 16px;
	color: black;
}
.customClass > .el-message-box__content .el-message-box__message {
	padding-left: 45px !important;
}
.el-icon-question {
	color: #ffcc00;
	font-size: 30px !important;
}
.cancelButtonClass {
	background: #1e7fff !important;
	color: #ffffff;
	width: 96px;
	height: 42px;
	font-size: 16px;
}
.cancelButtonClass:hover {
	background: #409eff !important;
	color: #ffffff;
}
.confirmButtonClass {
	background-color: #ffffff !important;
	color: #000000 !important;
	width: 96px;
	height: 42px;
	font-size: 16px;
	border: 1px solid #cccccc !important;
}
.confirmButtonClass:hover {
	background-color: #f4f4f5 !important;
}
</style>
<style scoped>
.el-dropdown-menu {
	top: 35px !important;
	padding: 0;
}
.el-dropdown-menu__item--divided:before {
	height: 0;
}
.el-dropdown-menu li {
	border-top: none !important;
	height: 38px;
	line-height: 38px;
}
.el-dropdown-menu li:nth-child(1) {
	border-top: none !important;
	border-bottom: 1px solid #ebeef5 !important;
}
</style>
<style scoped lang="less">
@fs24: 24px;

.header {
	position: relative;
	box-sizing: border-box;
	width: 100%;
	height: 72px;
	color: #fff;
	background: #FFFFFF;
	display: flex;
	justify-content: space-between;
	position: relative;
	.her_left {
		height: inherit;
		font-size: 18px;
		display: flex;
		align-items: center;
		.left_font {
			padding: 0 30px 0 24px;
			img{
				width: 136px;
			}
		}
		.shu {
			width: 92px;
			height: 34px;
			font-size: 14px;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 4px;
			color: #ffffff;
			opacity: 0.9;
			margin-left: 20px;
			background: rgba(255, 255, 255, 0.2);
		}
		.active {
			user-select: none;
			cursor: pointer;
			&:active {
				background: rgba(11, 141, 255, 0.2);
				color: #ffffff;
			}
		}
	}
	.her_rigth {
		height: inherit;
		padding: 0 40px 0 0;
		display: flex;
		align-items: center;
		color: #ffffff;
		.el-dropdown-link {
			color: #1A1717;
			font-size: 16px;
			cursor: pointer;
		}
	}
}
</style>
