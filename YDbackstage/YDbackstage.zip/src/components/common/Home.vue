<template>
    <div class="wrapper">
        <v-head/>
        <div class="w">
            <ul class="box" ref="box">
                <li class="left" ref="left">
                    <v-sidebar/>
                </li>
                <li class="resize" ref="resize">
                    <div class="tips"></div>
                </li>
                <li class="mid" ref="mid">
                    <v-tags></v-tags>
                    <div
                            :class="{ 'content-collapse': collapse }"
                            :element-loading-text="titles"
                            element-loading-background="rgba(255, 255, 255)"
                            element-loading-spinner="el-icon-loading"
                            style="height:  calc(100% - 56px)"
                            v-loading="loading"
                    >
                        <div class="content" ref="contents" style="height: 100%;overflow: scroll">
                            <transition mode="out-in" name="move">
                                <keep-alive :include="tagsList">
                                    <router-view v-if="isRouterAlive"/>
                                </keep-alive>
                            </transition>
							<el-backtop target=".content" style="z-index: 9999;" :visibility-height="100"></el-backtop>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

        <!--	<v-sidebar />
        <div
            class="content-box"
            :class="{ 'content-collapse': collapse }"
            v-loading="loading"
            :element-loading-text="titles"
            element-loading-spinner="el-icon-loading"
            element-loading-background="rgba(255, 255, 255)"
        >
            <v-tags></v-tags>
            <div class="content">
                <transition name="move" mode="out-in">
                    <keep-alive :include="tagsList"><router-view v-if="isRouterAlive" /></keep-alive>
                </transition>
            </div>
        </div>-->
    </div>
</template>

<script>
    import vHead from './Header.vue';
    import vSidebar from './Sidebar.vue';
    import vTags from './Tags.vue';
    import bus from './bus';

    export default {
        data() {
            return {
                tagsList: [],
                collapse: false,
                isRouterAlive: true,
                loading: false,
                titles: '拼命加载中'
            };
        },
        components: {
            vHead,
            vSidebar,
            vTags
        },
        provide() {
            return {
                reload: this.reload
            };
        },
        created() {
            bus.$on('loading', msg => {
                this.loading = msg.msg;
                if (msg.titles) {
                    this.titles = msg.titles;
                }
            });
            // // 只有在标签页列表里的页面才使用keep-alive，即关闭标签之后就不保存到内存中了。
            bus.$on('tags', msg => {
                let arr = [];
                for (let i = 0, len = msg.length; i < len; i++) {
					msg[i].name && arr.push(msg[i].name.replace('/', ''));
                }
                this.tagsList = arr;
            });
			bus.$on('srrtop',()=>{
				this.$nextTick(()=>{
					this.$refs.contents.scrollTop=0
				})
			})
        },
		mounted() {
			
		},
        methods: {
            reload() {
                this.isRouterAlive = false;
                this.$nextTick(() => {
                    this.isRouterAlive = true;
                });
            },
            dragControllerDiv: function () {
                let resize = document.getElementsByClassName('resize');
                let left = document.getElementsByClassName('left');
                let mid = document.getElementsByClassName('mid');
                let box = document.getElementsByClassName('box');
                for (let i = 0; i < resize.length; i++) {
                    // 鼠标按下事件
                    resize[i].onmousedown = function (e) {
                        let startX = e.clientX;
                        resize[i].left = resize[i].offsetLeft;
                        // 鼠标拖动事件
                        document.onmousemove = function (e) {
                            let endX = e.clientX;
                            let moveLen = resize[i].left + (endX - startX); // （endx-startx）=移动的距离。resize[i].left+移动的距离=左边区域最后的宽度
                            let maxT = box[i].clientWidth - resize[i].offsetWidth; // 容器宽度 - 左边区域的宽度 = 右边区域的宽度

                            if (moveLen < 1) moveLen = 1; // 左边区域的最小宽度为150px
                            if (moveLen > maxT - 150) moveLen = maxT - 150; //右边区域最小宽度为150px

                            resize[i].style.left = moveLen; // 设置左侧区域的宽度

                            for (let j = 0; j < left.length; j++) {
                                left[j].style.width = moveLen + 'px';
                                mid[j].style.width = box[i].clientWidth - moveLen - 10 + 'px';
                            }
                        };
                        // 鼠标松开事件
                        document.onmouseup = function (evt) {
                            document.onmousemove = null;
                            document.onmouseup = null;
                            resize[i].releaseCapture && resize[i].releaseCapture(); //当你不在需要继续获得鼠标消息就要应该调用ReleaseCapture()释放掉
                        };
                        resize[i].setCapture && resize[i].setCapture(); //该函数在属于当前线程的指定窗口里设置鼠标捕获
                        return false;
                    };
                }
            }
        },
        mounted() {
            this.dragControllerDiv();
        }
    };
</script>
<style scoped>


    .w {
        height: calc(100% - 72px);
        width: 100%;
    }

    ul,
    li {
        list-style: none;
        display: block;
        margin: 0;
        padding: 0;
    }

    .box {
        width: 100%;
        height: 100%;
        overflow: hidden;
    }

    .left {
        width: calc(12% - 1px);
        height: 100%;
        background: #c9c9c9;
        float: left;
    }

    .resize {
        width: 1px;
        height: 100%;
        cursor: w-resize;
        float: left;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

	.tips {
		height: 350px;
		border-radius: 5px;
		position: relative;
		background: #cdcdcd;
		opacity: 0;
		left: -2px;
		width: 5px;
	}
	.tips:hover {
		opacity: 1;
	}

    .mid {
        float: left;
        width: 88%;
        height: 100%;
        overflow: hidden;
        background: #ffffff;
    }

    .wrapper {
        width: 100%;
        height: 100vh;
        overflow: hidden;
    }
</style>
<style lang="less" scoped>
    .content {
        width: 100%;
        background: #ffffff;
        overflow-y: auto;
        padding: 0 !important;
    }

    * {
        &::-webkit-scrollbar {
            width: 4px;
            height: 5px;
            /**/
        }

        &::-webkit-scrollbar-track {
            background: rgb(239, 239, 239);
            border-radius: 2px;
        }

        &::-webkit-scrollbar-thumb {
            background: #1e7fff;
            border-radius: 10px;
        }

        &::-webkit-scrollbar-thumb:hover {
            background: #1e7fff;
        }

        &::-webkit-scrollbar-corner {
            background: #1e7fff;
        }
    }
</style>
