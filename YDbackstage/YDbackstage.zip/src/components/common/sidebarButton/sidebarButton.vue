<template>
    <div style="width: 100%;margin-top: 10px;margin-bottom: 10px;"  >
        <div :class="selected?'selectMenu':''" style="display:flex;flex-direction: column;height:40px;justify-content: center;width: 100%;color: white;cursor: pointer;">
            <div  style="display: flex;flex-direction: row;justify-content: left">
                <div v-if="showLeft">
                    <span  style="height: 20px;width: 20px;margin-left:10px;margin-right: 15px;line-height: 22px;" :class="leftIcon"/>
                </div>
                <div v-else>
                    <span  style="height: 20px;width: 20px;margin-left:10px;margin-right: 15px;line-height: 22px;" />
                </div>
                <span style="white-space: nowrap;">{{name}}</span>
                <div style="flex: 1;text-align: right;margin-right: 30px">
                    <span v-if="showRight" style="height: 20px;width: 20px;margin-left:20px;line-height: 22px;" :class="rightIcon"/>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "sidebarButton",
        props:{
            name:String,
            icon:String,
            path:String,
            showLeft:Boolean,
            showRight:Boolean,
            rightIcon:String,
            data:Object,
            leftIcon:String,
            selected:Boolean
        },
        methods:{

        }
    }
</script>

<style scoped>
.selectMenu{
    background: white;
    color:#3861DB !important;
    border-bottom-left-radius: 20px;
    border-top-left-radius: 20px;
}
</style>