<template>
	<div class="sidebarA" >
		<!--一级-->
		<div @click.stop="clickA(indexA)" v-for="(itemA, indexA) in meues" :key="indexA">
			<sidebar-button
				:selected="itemA.path == currentSelected.path"
				:data="itemA"
				:show-left="true"
				:name="itemA.name"
				:left-icon="itemA.image ? itemA.image : 'el-icon-c-scale-to-original'"
				:show-right="itemA.list.length >= 1"
				:right-icon="itemA.show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'"
			/>
			<!--二级-->
			<div :style="'padding-left:' + 40 * 1 + 'px;display:' + (itemA.show ? 'block' : 'none')">
				<div @click.stop="clickA(indexA, indexB)" v-for="(itemB, indexB) in itemA.list" :key="indexB">
					<sidebar-button
						:selected="itemB.path == currentSelected.path"
						:data="itemB"
						:show-left="false"
						:name="itemB.name"
						:show-right="itemB.list.length >= 1"
						:right-icon="itemB.show ? 'el-icon-arrow-up' : 'el-icon-arrow-down'"
					/>
					<!--三级-->
					<div :style="'padding-left:' + 30 * 2 + 'px;display:' + (itemB.show ? 'block' : 'none')">
						<div @click.stop="clickA(indexA, indexB, indexC)" v-for="(itemC, indexC) in itemB.list" :key="indexC">
							<sidebar-button :selected="itemC.path == currentSelected.path" :data="itemC" :name="itemC.name" :show-left="false" />
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import sidebarButton from './sidebarButton/sidebarButton';
export default {
	components: {
		sidebarButton
	},
	data() {
		return {
			collapse: false,
			meues: [],
			routenums: '',
			urls: URL,
			currentSelected: ''
		};
	},
	computed: {},
	watch: {},
	created() {
		this.getmeue();
	},
	mounted() {},
	methods: {
		//判断菜单的
		clickA(iA, iB, iC) {
			if (iC !== undefined) {
				//三级菜单点击
				this.currentSelected = this.meues[iA].list[iB].list[iC];
				this.$router.push(`/${this.meues[iA].list[iB].list[iC].path}`);
			} else if (iB !== undefined) {
				//二级菜单点击,如果有下一级则不打开，没有就打开相应页
				if (this.meues[iA].list[iB].list.length >= 1) {
					if (this.meues[iA].list[iB].show) {
						this.meues[iA].list[iB].show = false;
					} else {
						this.meues[iA].list[iB].show = true;
					}
				} else {
					this.currentSelected = this.meues[iA].list[iB];
					this.$router.push(`/${this.meues[iA].list[iB].path}`);
				}
			} else {
				// 一级菜单如果有下一级则不打开，没有就打开相应页

				if (this.meues[iA].list.length >= 1) {
					if (this.meues[iA].show) {
						this.meues[iA].show = false;
					} else {
						this.meues[iA].show = true;
					}
				} else {
					//选择中时
					this.currentSelected = this.meues[iA];
					this.$router.push(`/${this.meues[iA].path}`);
				}
			}
			this.$forceUpdate();
		},
		getmeue() {
			this.meues = this.$store.state.initfromdata.menu;
		},
		collapses(msg) {
			this.collapse = msg;
		}
	}
};
</script>

<style scoped>
.sidebarA {
	display: flex;
	background: #3861db;
	height: 100%;
	flex-direction: column;
	width: 100%;
	padding-left: 10px;
	overflow-y: scroll;
	scrollbar-width: none; /* firefox */
	-ms-overflow-style: none; /* IE 10+ */
	overflow-x: hidden;
}
.sidebarA::-webkit-scrollbar {
	display: none; /* Chrome Safari */
}
</style>
<style lang="less" scoped>
.leftmian {
	width: auto;
	background: #262626;
	padding: 26px 26px 0 20px;
	user-select: none;
}
</style>
