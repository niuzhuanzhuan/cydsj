<template>
	<div><uploadimage /></div>
</template>

<script>
import uploadimage from '../custom/uploadimage.vue';
export default {
	name: 'dashboard',
	data() {
		return {};
	},
	components: {
		uploadimage
	},
	created() {}
};
</script>

<style lang="less"></style>

<style scoped></style>
