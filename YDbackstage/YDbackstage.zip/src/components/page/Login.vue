<template>
	<div class="login-wrap">
		<div class="miantitle">
			<div class="mianlit">
				<img src="../../assets/login/logon.png" />
				永动力商家服务平台
			</div>
		</div>
		<div class="mianall">
			<div class="mianfs">
				<img src="../../assets/login/banners.png" />
				<div class="miannums">
					<div class="mianfols">
						<div class="titlei">欢迎登录</div>
						<div class="minalis">
							<el-form ref="ruleForm" :model="ruleForm">
								<el-form-item>
									<template>
										<div class="lisnt">
											<el-input
												v-model="ruleForm.mobile"
												@blur="blurmobile(ruleForm.mobile)"
												placeholder="请输入手机号"
												prefix-icon="el-icon-date"
											></el-input>
										</div>
									</template>
								</el-form-item>
								<el-form-item>
									<template>
										<div class="lisnt">
											<el-input style="width: 15rem;" v-model="ruleForm.code" placeholder="请输入验证码" prefix-icon="el-icon-date"></el-input>
											<div @click="senmian" class="bonst" v-if="Decision">{{ sends }}</div>
											<el-button style="width: 140px;height: 44px;" v-else type="primary" round disabled plain>{{ sends }}</el-button>
										</div>
									</template>
								</el-form-item>
							</el-form>
						</div>
						<div class="bonnets"><el-button type="primary" @click="submitForm('ruleForm')" round>登录</el-button></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import api from '@/utils/api';
import define from '../define/define.js';
import { mapActions } from 'vuex';
export default {
	data() {
		return {
			sends: '获取验证码',
			disabled: false,
			tcler: null,
			ruleForm: {
				mobile: '',
				code: ''
			},
			timeskey: 60,
			Decision: true,
			rules: {
				mobile: [
					{
						required: true,
						message: '请输入用户名',
						trigger: 'blur'
					}
				],
				code: [
					{
						required: true,
						message: '请输入密码',
						trigger: 'blur'
					}
				]
			}
		};
	},
	created() {
		sessionStorage.removeItem('initfromdata');
		if (sessionStorage['timeskey']) {
			this.Decision = false;
			this.$set(this.ruleForm, 'mobile', JSON.parse(sessionStorage['mobile']));
			this.timeskey = sessionStorage['timeskey'];
			this.tcler = setInterval(() => {
				this.timeskey--;
				sessionStorage['timeskey'] = this.timeskey;
				this.sends = `${this.timeskey--} 秒`;
				if (this.timeskey <= 0) {
					sessionStorage.removeItem('timeskey');
					this.sends = '获取验证码';
					clearInterval(this.tcler);
					this.Decision = true;
					this.timeskey = 60;
				}
			}, 1000);
		} else {
			sessionStorage['mobile'] ? this.$set(this.ruleForm, 'mobile', JSON.parse(sessionStorage['mobile'])) : '';
		}
	},
	activated() {
		
	},
	methods: {
		...mapActions(['token_get']),
		blurmobile(data) {
			if (!data) return '';
			if (define.phone.test(this.ruleForm.mobile)) {
				sessionStorage['mobile'] = this.ruleForm.mobile;
			} else {
				sessionStorage.removeItem('mobile');
			}
		},
		async senmian() {
			if (this.ruleForm.mobile === '') {
				this.$message.warning('请填写您的手机号！');
				return false;
			} else if (!define.phone.test(this.ruleForm.mobile)) {
				this.$message.warning('手机号有误请检查！');
				return false;
			}
			const datalist = await api.getVerify({ mobile: this.ruleForm.mobile });
			datalist && this.$message.success(datalist.msg);
			this.Decision = false;
			this.tcler = setInterval(() => {
				this.timeskey--;
				sessionStorage['timeskey'] = this.timeskey;
				this.sends = `${this.timeskey--} 秒`;
				if (this.timeskey == 0) {
					sessionStorage.removeItem('timeskey');
					this.sends = '获取验证码';
					clearInterval(this.tcler);
					this.Decision = true;
					this.timeskey = 60;
				}
			}, 1000);
		},
		submitForm(ruleForm) {
			this.$refs[ruleForm].validate(async valid => {
				if (valid) {
					let datalist = await api.mobileLogin(this.ruleForm);
					if(datalist){
						clearInterval(this.tcler);
						sessionStorage.removeItem('timeskey');
						this.$message.success('登录成功')
						this.token_get(datalist.data)
						// 俱乐部登录跳转俱乐部首页
						if(datalist.data.type === 'car_club'){
							this.$router.push('/homeclub');
							return ;
						}
						switch (datalist.data.state) {
							case 2:
								this.$router.push('/certificationindex');
								break;
							case 4:
								this.$router.push('/certificationindex');
								break;
							case 8:
								this.$router.push('/certificationindex');
								break;
							default:
								this.$router.replace('/');
						}
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>

<style scoped>
.bonst {
	width: 140px;
	display: flex;
	justify-content: center;
	align-items: center;
	cursor: pointer;
	height: 42px;
	font-size: 14px;
	font-weight: 500;
	transform: 1s;
	color: #3861db;
	user-select: none;
	border-color: #3861db;
	border-radius: 20px;
	border: 1px solid #3861db;
}
.bonsts {
	width: 140px;
	display: flex;
	justify-content: center;
	align-items: center;
	cursor: pointer;
	height: 42px;
	font-size: 14px;
	font-weight: 500;
	transform: 1s;
	color: #3861db;
	user-select: none;
	border-color: #3861db;
	border-radius: 20px;
	border: 1px solid #3861db;
}
.bonst:hover {
	background: #8daaff;
	border-color: #8daaff;
	color: #ffffff;
}
.bonst:active {
	background: #3861db;
	border-color: #3861db;
	color: #ffffff;
}
.lisnt >>> .el-input__inner {
	background-color: #f1f2f7;
	border: none;
}
.lisnt >>> .el-input--small .el-input__inner {
	height: 44px;
	line-height: 44px;
}
.lisnt >>> .el-input--small {
	border-radius: 22px;
	overflow: hidden;
}
.lisnt >>> .el-input--prefix .el-input__inner {
	padding-left: 50px;
}
.lisnt >>> .el-input__prefix {
	left: 20px;
}
.lisnt >>> .el-input--small .el-input__inner::-webkit-input-placeholder {
	font-size: 14px;
}
.minalis >>> .el-form-item {
	margin: 0;
}
.minalis >>> .el-form {
	width: 100%;
	height: 100%;
	display: flex;
	flex-direction: column;
	justify-content: space-evenly;
}
</style>
<style scoped lang="less">
@media screen and (max-width: 1300px) {
}
.lisnt {
	display: flex;
	justify-content: space-between;
	align-items: center;
}
.login-wrap {
	width: 100%;
	height: 100vh;
	background: #8daaff;
	overflow: auto;
	position: relative;
	.miantitle {
		width: 100%;
		height: 150px;
		display: flex;
		align-items: flex-end;
		.mianlit {
			width: calc(100% - 94px);
			height: 122px;
			font-weight: bold;
			padding-left: 94px;
			display: flex;
			font-size: 40px;
			align-items: center;
			color: #ffffff;
			img {
				width: 122px;
				margin-right: 28px;
			}
		}
	}
	.mianall {
		position: absolute;
		top: 100px;
		width: 100%;
		height: calc(100% - 150px);
		display: flex;
		justify-content: center;
		.mianfs {
			position: relative;
			.miannums {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 730px;
				display: flex;
				justify-content: center;
				align-items: center;
				.mianfols {
					width: 40%;
					height: 60%;
					.titlei {
						width: 100%;
						height: 15%;
						font-weight: bold;
						font-size: 28px;
						color: #313639;
						user-select: none;
						display: flex;
						align-items: center;
					}
					.minalis {
						width: 100%;
						height: 45%;
					}
					.bonnets {
						width: 100%;
						height: 30%;
						display: flex;
						align-items: center;
						justify-content: center;
						.fonst {
							color: #3861db;
							font-size: 14px;
							user-select: none;
							cursor: pointer;
							&:hover {
								color: #409eff;
							}
						}
						.el-button {
							width: 100%;
							height: 44px;
							font-size: 18px;
							background-color: #3861db;
							border-color: #3861db;
							&:active {
								background-color: #409eff;
								border-color: #409eff;
							}
						}
					}
				}
			}
		}
	}
}
</style>
