<template>
	<el-pagination
		background
		@size-change="handleSizeChange"
		@current-change="handleCurrentChange"
		:current-page.sync="pageIndex"
		:page-size="pageSize"
		:total="total"
		layout="total, prev, pager, next">
	</el-pagination>
</template>

<script>
	/**
	 * TODO
	 * 直接包含index，不再需要从props注入
	 * 暴露几个跳转分页方法 如回到第一页
	 */
	
	export default {
		props:{
			total:{
				type:Number,
				default:0,
			}
		},
		data(){
			return {
				pageSize:10,
				pageIndex:0,
			};
		},
		methods:{
			/**
			 * 触发页码变更
			 * 提供参数 {size:单页数据条数，index:当前索引}
			 */
			triggerPageChange(){
				this.$emit('pageChange',{
					pageSize:this.pageSize,
					page:this.pageIndex,
				})
			},
			// 页面size改变时触发
			handleSizeChange(){
				this.triggerPageChange();
			},
			// 页面index改变时触发
			handleCurrentChange(){
				this.triggerPageChange();
			},
			/**
			 * 外部调用 跳转指定页码
			 */
			goTo(index){
				if(typeof index !== 'number'){
					console.warn(`分页索引需要数字! 当前type：${typeof index } ,value: ${index.toString()}`);
					return ;
				}
				this.pageIndex = index;
				this.triggerPageChange();
			},
			/**
			 * 外部调用 刷新当前页
			 */
			refresh(){
				this.triggerPageChange();
			}
		}
	}
</script>
