<template>
	<div class="component-main">
		<el-upload
			class="uploader-main"
			:action="baseDomain + '/api/rest/upload/upload'"
			:show-file-list="false"
			:headers="{ 'XX-Device-Type': 'web' }"
			:on-success="handleSuccess"
			accept=".jpeg,.png,.jpg"
			:before-upload="beforeUpload"
			:style="{ width: width + 'px', height: height + 'px' }"
		>
			<img v-if="imageUrl !== ''" :src="imageUrl" class="uploader-img" :style="{ width: width + 'px', height: height + 'px' }" />
			<img v-else-if="bgUrl !== ''" :src="bgUrl" class="uploader-img" :style="{ width: width + 'px', height: height + 'px' }" />
			<div v-else class="uploader-title" :style="{ width: width + 'px', height: height + 'px' }">{{ title }}</div>
			<div class="fixed-tip">点击上传</div>
		</el-upload>
		<p v-if="square" class="path-tip">{{ square }}</p>
	</div>
</template>

<script>
import { URL } from '@/utils/doman.js';

export default {
	props: {
		// 上传域宽度
		width: {
			type: Number,
			default: 178
		},
		// 上传域高度
		height: {
			type: Number,
			default: 178
		},
		// 上传域默认标题
		title: {
			type: String,
			default: 'LOGO'
		},
		// 大小限制
		size: {
			type: Number,
			default: 4
		},
		// 上传图片url目标字段
		imageUrl: {
			type: String,
			default: ''
		},
		// 上传区域背景图片url
		bgUrl: {
			type: String,
			default: ''
		},
		// 右侧提示语
		square: {
			type: String,
			default: ''
		},
		limit: {
			type: Array,
			default: () => []
		}
	},
	data() {
		return {
			baseDomain: URL
		};
	},
	methods: {
		// 上传之前检查
		async beforeUpload(file) {
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			const isLtSize = file.size / 1024 / 1024 < this.size;
			if (!isJPG && !isPNG) {
				this.$message.error('上传图片只能是 JPG 或者 PNG 格式!');
			}
			if (!isLtSize) {
				this.$message.error(`上传图片大小不能超过 ${this.size}MB!`);
			}
			if (this.limit != '') {
				let init = await this.restrict(this.limit, file);
			} else {
				return (isLtSize && isPNG) || isJPG;
			}
		},
		restrict(data, file) {
			//限制大小
			const isSize = new Promise((resolve, reject) => {
				let _URL = window.URL || window.webkitURL;
				let img = new Image();
				img.onload = () => {
					data.forEach(item => {
						if (img.width == item.split('*')[0] && img.height == item.split('*')[1]) {
							resolve();
						} else {
							reject();
						}
					});
				};
				img.src = _URL.createObjectURL(file);
			}).then(
				() => {
					return file;
				},
				() => {
					this.$message.error({
						duration: 3000,
						message: `上传的图片尺寸必须是等于${data.join()}尺寸!`,
						type: 'error'
					});
					return Promise.reject(false);
				}
			);
			return isSize;
		},
		// 成功回调
		handleSuccess(res) {
			if (res.code === 1) {
				this.$emit('update:imageUrl', res.data[0]);
				this.$message.success('上传成功');
			} else {
				this.$message.error(`上传图片失败，错误提示：${res.msg}`);
			}
		}
	}
};
</script>

<style lang="less" scoped>
* {
	box-sizing: border-box;
}
.component-main {
	display: inline-flex;
	align-items: flex-end;
	overflow: hidden;

	.path-tip {
		padding-left: 10px;
		font-size: 12px;
		color: #999999;
	}
}
.uploader-main {
	position: relative;
	background-color: #e1e1e1;
	overflow: hidden;
}
.fixed-tip {
	position: absolute;
	bottom: 0;
	height: 18px;
	line-height: 18px;
	width: 100%;
	background-color: rgba(0, 0, 0, 0.5);
	font-size: 12px;
	color: #ffffff;
	text-align: center;
}
.uploader-title {
	display: flex;
	justify-content: center;
	align-items: center;
	padding: 0 15px;
	background: #e1e1e1;
	font-size: 1.125rem;
	line-height: 1.5rem;
	font-weight: bold;
	color: #ffffff;
}
.uploader-img {
	object-fit: scale-down;
}
</style>
<style scoped>
.uploader-main >>> .el-upload {
	height: 100%;
	cursor: pointer;
	overflow: hidden;
}
</style>
