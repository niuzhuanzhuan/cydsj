import {
	Message
} from 'element-ui';
const define = {
	depawss: /^(?=.*\d)(?=.*[A-Za-z])[a-zA-Z0-9]{6,16}$/,
	timestampToTime(data) {
		if (data == 0) return '无'
		let date = new Date(data * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
		let Y = date.getFullYear() + '/';

		let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '/';

		let D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + '';

		let h = date.getHours() + ':';

		let m = date.getMinutes() + ':';

		let s = date.getSeconds();

		return Y + M + D;
	},
	month(data) {
		if (data == 0) return '无'
		let date = new Date(data * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
		let Y = date.getFullYear();

		let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);

		let D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate());

		let h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours());

		let m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());

		let s = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());

		return `${M}月${D}日  ${h}：${m}`;
	},
	year(data) {
		var date = new Date(data);
		var YY = date.getFullYear() + '-';
		var MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
		var DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
		var hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
		var mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
		var ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
		return YY + MM + DD;
	},
	getPreMonthDay(date, monthNum) {
		var sdtime1 = new Date(date)
		var sdtime4 = sdtime1.setMonth(new Date(date).getMonth() - monthNum)
		var dates = new Date(sdtime4);
		var YY = dates.getFullYear() + '-';
		var MM = (dates.getMonth() + 1 < 10 ? '0' + (dates.getMonth() + 1) : dates.getMonth() + 1) + '-';
		var DD = (dates.getDate() < 10 ? '0' + (dates.getDate()) : dates.getDate());
		return YY + MM + DD;
	},
	gettate(data) {
		let datas = new Date(data);
		let times = datas.getTime();
		return times;
	},
	phone: /^1[3456789]\d{9}$/, //验证手机号
	money: /(^[1-9](\d+)?(\.\d{1,2})?$)|(^[1-9]$)|(^\d\.[1-9]{1,2}$)|(^\d\.[0]{1}[1-9]{1}$|(^\d\.[1-9]{1}[0]{1}$)$)/,
	formatDate(date) {
		var date = new Date(date);
		var YY = date.getFullYear() + '-';
		var MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
		var DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
		return YY + MM + DD;
	},
	moneys(data) {
		let inits=/(^[1-9](\d+)?(\.\d{1,2})?$)|(^\d\.\d{1,2}$)/
		let datainit=""
		if (inits.test(data)) {
			if(data<=20000){
				datainit=data
			}else{
				Message.warning('您输入的格式有误，请输入大于0且小于20000的正确金额，小数且保留两位')
			}
		} else {
			Message.warning('您输入的格式有误，请输入大于0且小于20000的正确金额，小数且保留两位')
		}
		return datainit
	}
}
export default define
