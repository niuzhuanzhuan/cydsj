<template>
	<div class="conimgs">
		<el-upload
			class="avatar-uploader"
			action="https://yapi.test.yongdongli.net/api/rest/upload/upload"
			:show-file-list="false"
			:on-success="handleAvatarSuccess"
			:before-upload="beforeAvatarUpload"
			:style="{ width: width + 'px', height: height + 'px' }"
		>
			<img v-if="imageUrl || definition == 2" :src="imageUrl" class="avatar" :style="{ height: height + 'px' }" />
			<div v-else class="fonst" :style="{ width: width + 'px', height: height + 'px' }">{{ title }}</div>
			<div class="bnomr">点击上传</div>
		</el-upload>
		<div class="mianalls" :style="{ height: height + 26 + 'px' }">{{ square }}</div>
	</div>
</template>

<script>
import api from '@/utils/api.js';
import {URL} from '@/utils/doman.js'
export default {
	props: {
		width: {
			type: Number,
			default: 178
		},
		height: {
			type: Number,
			default: 178
		},
		title: {
			type: String,
			default: 'LOGO'
		},
		definition: {
			type: Number,
			default: 1
		},
		size: {
			type: Number,
			default: 2
		},
		imageUrl: {
			type: String,
			default: ''
		},
		square: {
			type: String,
			default: '400*400'
		}
	},
	data() {
		return {
			urls:''
		};
	},
	created() {},
	methods: {
		handleAvatarSuccess(res, file) {
			console.log(res)
			console.log(file)
			// this.imageUrl = URL.createObjectURL(file.raw);
		},
		beforeAvatarUpload(file) {
			const isLt2M = file.size / 1024 / 1024 < this.size;

			if (!isLt2M) {
				this.$message.error(`上传图片大小不能超过 ${this.size}MB!`);
			}
			return isLt2M;
		}
	}
};
</script>

<style lang="less">
.conimgs {
	width: 100%;
	display: flex;
	.mianalls {
		width: 100%;
		height: inherit;
		display: flex;
		align-items: flex-end;
		margin-left: 14px;
		font-size: 12px;
		color: #999999;
	}
}
.avatar-uploader {
	position: relative;
}
.bnomr {
	position: absolute;
	bottom: -18px;
	width: 100%;
	background: #b0b0b0;
	font-size: 12px;
	color: #ffffff;
	height: 18px;
	display: flex;
	align-items: center;
	justify-content: center;
}
.fonst {
	background: #e1e1e1;
	font-size: 1.125rem;
	font-weight: bold;
	color: #ffffff;
	display: flex;
	justify-content: center;
	align-items: center;
}
</style>

<style scoped>
.avatar-uploader .el-upload {
	border-radius: 6px;
	cursor: pointer;
	position: relative;
	overflow: hidden;
}
.avatar-uploader .el-upload:hover {
	border-color: #409eff;
}
.avatar-uploader-icon {
	font-size: 28px;
	color: #8c939d;
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
}
.avatar {
	display: block;
	height: 100%;
}
</style>
