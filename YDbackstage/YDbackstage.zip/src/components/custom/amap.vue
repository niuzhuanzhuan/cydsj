<template>
	<div class="mark-map" id="mark-map">
		<el-cascader v-model="inputslind" :options="maparrs" :props="{ expandTrigger: 'hover' }" clearable style="margin-bottom: 10px;" @change="handleChange"></el-cascader>
		<el-input v-model="inputs" @change="inputgne(inputs)" clearable style="margin-bottom: 10px;" placeholder="请输入详细地址">
			<el-button slot="append" @click="inputgne(inputs)" icon="el-icon-search"></el-button>
		</el-input>

		<!-- <el-amap vid="mark-map" :plugin="plugin" :zoom="currentZoom" :events="events"></el-amap> -->
		<div id="mapkeys"></div>
	</div>
</template>

<script>
import Vue from 'vue';
import VueAMap from 'vue-amap';
import { mapActions } from 'vuex';
import maps from '@/assets/amap/map';

Vue.use(VueAMap);
VueAMap.initAMapApiLoader({
	key: 'ab5a6a5b5dd62730ed7e9bb0c84b3599',
	// 插件集合 （插件按需引入）
	plugin: ['AMap.Geocoder', 'AMap.PlaceSearch', 'AMap.container']
});

export default {
	name: 'amap',
	props: {
		zoom: {
			type: Number,
			default: 11,
			validator: val => val > 2 && val < 19
		},
		markable: {
			type: Boolean,
			default: true
		},
		inputis: {
			type: String,
			default: ''
		},
		froms: {
			type: Object,
			default: () => {}
		}
	},
	watch: {},
	data() {
		return {
			inputs: '',
			inputslind: [],
			maparrs: [],
			mapkey: {},
			mapfrom: {
				province: '',
				city: '',
				region: '',
				detail: '',
				longitude: '',
				latitude: ''
			},
			markers: [],
			timemisr: null
		};
	},
	watch: {},
	methods: {
		settime(funfion, stops) {
			if (this.timemisr) {
				clearTimeout(this.timemisr);
			}
			this.timemisr = setTimeout(() => {
				funfion();
				this.timemisr = null;
			}, stops);
		},
		...mapActions(['set_mapkey']),
		inputgne(data) {
			if (data == '') return '';
			this.handleChange(data);
		},
		async handleChange(data) {
			let that = this;
			let inits = '';
			if (Array.isArray(data)) {
				inits = data.join('');
			} else {
				inits = data;
			}
			that.$nextTick(() => {
				that.mapkey.remove(that.markers);
			});
			var placeSearch = new AMap.PlaceSearch();

			placeSearch.search(inits, function(status, result) {
				// 查询成功时，result即对应匹配的POI信息
				if (result.poiList) {
					var pois = result.poiList.pois;
					if (pois.length >= 1) {
						that.markers = new AMap.Marker({
							position: pois[0].location, // 经纬度对象，也可以是经纬度构成的一维数组[116.39, 39.9]
							title: pois[0].name
						});
						that.setclick([pois[0].location.lng, pois[0].location.lat]);
						that.mapkey.add(that.markers);
					}
					that.mapkey.setFitView();
				}
			});
		},
		getmap() {
			let that = this;
			let Maps = new AMap.Map('mapkeys', {
				zoom: this.zoom //初始化地图层级
			});

			that.mapkey = Maps;
			that.set_mapkey(Maps);
			that.markers = new AMap.Marker({
				position: []
			});
			that.mapkey.on('click', e => {
				that.mapkey.remove(that.markers);
				that.markers = new AMap.Marker({
					position: [e.lnglat.lng, e.lnglat.lat],
					offset: new AMap.Pixel(-10, -20)
				});
				that.setclick([e.lnglat.lng, e.lnglat.lat]);
				that.mapkey.add([that.markers]);
			});
		},
		setclick(data) {
			let that = this;
			var geocoder = new AMap.Geocoder({
				radius: 1000,
				extensions: 'all'
			});
			geocoder.getAddress(data, (status, result) => {
				if (status === 'complete' && result.info === 'OK') {
					if (result && result.regeocode) {
						let distmian = '';
						that.inputslind = [];
						if (result.regeocode.addressComponent.province == '台湾省') {
							this.$message.warning({
								message:'高德地图暂不支持台湾详细信息，请在输入框输入详细地址',
								duration:5000
							})
						}
						if (result.regeocode.addressComponent.province == '重庆市') {
							let district = result.regeocode.addressComponent.district;
							if (district.charAt(district.length - 1) == '区') {
								that.$set(that.mapfrom, 'city', '市辖区');
								distmian = '市辖区';
							} else {
								that.$set(that.mapfrom, 'city', '县');
								distmian = '县';
							}
						} else if (result.regeocode.addressComponent.province == '香港特别行政区') {
							distmian = '香港';
						} else if (result.regeocode.addressComponent.province == '澳门特别行政区') {
							distmian = '澳门';
						} else {
							that.$set(that.mapfrom, 'city', result.regeocode.addressComponent.city ? result.regeocode.addressComponent.city : '市辖区');
							distmian = result.regeocode.addressComponent.city ? result.regeocode.addressComponent.city : '市辖区';
						}

						that.inputslind.push(result.regeocode.addressComponent.province, distmian, result.regeocode.addressComponent.district);
						that.$set(that.mapfrom, 'province', result.regeocode.addressComponent.province);
						that.$set(that.mapfrom, 'region', result.regeocode.addressComponent.district);
						that.$set(that.mapfrom, 'detail', result.regeocode.formattedAddress);
						that.$set(that.mapfrom, 'longitude', data[1]);
						that.$set(that.mapfrom, 'latitude', data[0]);
						that.inputs = result.regeocode.formattedAddress;
					}
				}
			});
		},
		getinit() {
			let { province, city, region, detail, latitude, longitude } = this.froms;
			this.$set(this.mapfrom, 'province', province);
			this.$set(this.mapfrom, 'city', city);
			this.$set(this.mapfrom, 'region', region);
			this.$set(this.mapfrom, 'detail', detail);
			this.$set(this.mapfrom, 'longitude', longitude);
			this.$set(this.mapfrom, 'latitude', latitude);
			this.inputslind.push(province, city, region);
			this.inputs = detail;
			this.$nextTick(() => {
				if (!!detail) {
					this.inputgne(detail);
				}
			});
		},
		getdata() {
			this.getmap();
			maps.map(item => {
				item.value = item.label;
				item.children.map(jtem => {
					jtem.value = jtem.label;
					jtem.children.map(ktem => {
						ktem.value = ktem.label;
					});
				});
			});
			this.maparrs = maps;
			if (this.froms.longitude) {
				this.getinit();
			}
		}
	},
	created() {},
	mounted() {
		this.getdata();
	},
	destroyed() {}
};
</script>

<style scoped>
.mark-map {
	width: 100%;
}
.mark-map >>> .el-vue-amap {
	height: 400px;
}
#mapkeys {
	width: 100%;
	height: 400px;
}
.search-box {
	position: relative;
	top: 48px;
	left: 4px;
	width: 276px;
}
.search-regth {
	position: absolute;
	right: 30px;
	width: 276px;
}
</style>
