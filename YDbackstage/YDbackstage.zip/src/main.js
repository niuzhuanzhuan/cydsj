import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'
Vue.config.productionTip = false
import '@/utils/http';
import VueCompositionApi from '@vue/composition-api'
Vue.use(VueCompositionApi)
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import "./assets/iconfont/iconfont.css";
import "./assets/iconfont/iconfont.js";

import './assets/theme/index.css'

// Vue.prototype.$axios = axios
Vue.use(ElementUI, {
	size: 'small'
});
import VueDND from 'awe-dnd';
Vue.use(VueDND);
import './urls.js';
import api from "./utils/api.js"
Vue.prototype.$api = api


new Vue({
	router,
	store,
	render: function(h) {
		return h(App)
	}
}).$mount('#app')
