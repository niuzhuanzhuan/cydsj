<template>
	<div><router-view /></div>
</template>
<style>
	@import "./assets/css/main.css";
	html,body{
		margin: 0;
	}
</style>
