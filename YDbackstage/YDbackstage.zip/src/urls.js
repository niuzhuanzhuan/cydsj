import Vue from 'vue'
import router from './router';
import store from './store/index';
import vuex from 'vuex';
import {
	Message
} from 'element-ui';
if (!!sessionStorage['initfromdata']) {
	const users = JSON.parse(sessionStorage['initfromdata']);
	store.commit('gettoken', users);
} else {
	setTimeout(() => {
		if (router.currentRoute.name != 'Login') {
			router.replace({
				path: '/Login'
			});
		}
	}, 500)
}
