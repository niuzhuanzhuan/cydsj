import request from "./http";
import qs from "qs";
import store from "../store/index";

export default {
	saveClubInfo(data) { //保存俱乐部
		return request({
			method: 'post',
			url: '/api/portal/club/saveClub',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	//平衡车赛事兼报优惠
	// 	type	是	string	list列表 save保存 delete删除 detail详情
	// 	XX-token	是	string	token 头部自带
	// 	match_id	是	string	赛事id
	carMatchGroupPrice(data) {
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchGroupPrice',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	getVerify(data, suc) { //获取手机验证码
		return request({
			method: 'post',
			url: '/api/portal/passport/getVerify',
			data: qs.stringify(data),
		})
	},

	mobileLogin(data, suc) { //手机验证码登录
		return request({
			method: 'post',
			url: '/api/portal/passport/mobileLogin',
			data: qs.stringify(data),
		})
	},
	price(data, suc) { //财务管理页面数据
		return request({
			method: 'post',
			url: '/api/portal/price/price',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	clubPrice(data, suc) { // 俱乐部财务管理页面数据
		return request({
			method: 'post',
			url: '/api/portal/club/price',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	income(data, suc) { //发起提现
		return request({
			method: 'post',
			url: '/api/portal/price/income',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	carMatch(data, suc) { //创建平衡车赛事
		return request({
			method: 'post',
			url: '/api/portal/car/carMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	getCarMatchDetail(data, suc) { //获得赛事详情-编辑回填
		return request({
			method: 'post',
			url: '/api/portal/car/getCarMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	carMatchGroups(data, suc) { //平衡车赛事分组
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchGroup',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	updateCarMatch(data, suc) { //平衡车赛事编辑
		return request({
			method: 'post',
			url: '/api/portal/car/updateCarMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	carMatchGroupRely(data, suc) { //平衡车赛事分组依赖配置
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchGroupRely',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	getContent(data, suc) { //平衡车赛事分组依赖配置
		return request({
			method: 'post',
			url: '/api/portal/index/getContent',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	/*****************************************/

	companyAuth(data, suc) { //用户登录
		return request({
			method: 'post',
			url: '/api/portal/company/companyAuth',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	getCompanyAuth(data) { // 获取企业认证回填数据
		return request({
			method: 'post',
			url: '/api/portal/company/getcompanyinfo',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	getHome(data) { // 首页数据展示
		return request({
			method: 'post',
			url: '/api/portal/index/index',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	getClubHome(data) { // 俱乐部首页数据展示
		return request({
			method: 'post',
			url: '/api/portal/club/index',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},

	getAccount(data) { // 获取账户信息
		return request({
			method: 'post',
			url: '/api/portal/user/updateUser',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	getExportList(data) { // 获取导出列表
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchDownList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getExportUrl(data) { // 获取导出文件下载地址
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchDown',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getExportFile(data) { // 生成导出文件
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchDownFile',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	clubApi(data) { // 俱乐部管理 统一接口
		return request({
			method: 'post',
			url: '/api/portal/club/club',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	getInsurance(data) {
		return request({
			method: 'post',
			url: '/api/portal/insurance/getInsurance',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取赛事列表
	getCarMatchList(data) {
		return request({
			method: 'post',
			url: '/api/portal/car/getCarMatchList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单详情
	getCarMatchOrderDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/car/getCarMatchOrderDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取赛事概览
	carMatchDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单列表
	carMatchGroupList(data) {
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchGroupList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 发起订单退款
	carMatchRefundOrder(data) {
		return request({
			method: 'post',
			url: '/api/portal/car/carMatchRefundOrder',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getClubDetail(data) { //获得俱乐部详情
		return request({
			method: 'post',
			url: '/api/portal/club/getClubDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getOcrInfo(data) { //身份证和营业执照识别
		return request({
			method: 'post',
			url: '/api/portal/index/getOcrInfo',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getMatchGroupScoreData(data) { //成绩录入数据
		return request({
			method: 'post',
			url: '/api/portal/car/getMatchGroupScoreData',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getClubTotalList(data) { //获得赛事发布方
		return request({
			method: 'post',
			url: '/api/portal/car/getClubTotalList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
}
