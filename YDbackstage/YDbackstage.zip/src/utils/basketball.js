import request from "./http";
import qs from "qs";
import store from "../store/index";


export default {
	// 获取赛事列表
	getBasketballMatchList(data) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/getMatchList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	//创建足球赛事
	saveBasketballMatch(data, suc) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/match',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	//获取足球赛事详情
	getBasketballMatchDetail(data, suc) { //获得赛事详情-编辑回填
		return request({
			method: 'post',
			url: '/api/portal/basketball/getMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	//足球赛事编辑
	updateBasketballMatch(data, suc) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/updateMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	//保险
	getBasketballInsurance(data) {
		return request({
			method: 'post',
			url: '/api/portal/insurance/getInsurance',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单详情
	getBasketballMatchOrderDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/getMatchOrderDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取赛事概览
	basketballDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/matchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单列表
	basketballMatchGroupList(data) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/matchGroupList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 发起订单退款
	basketballMatchRefundOrder(data) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/matchRefundOrder',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	//足球赛事分组
	basketballMatchGroups(data, suc) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/matchGroup',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	// 获取导出列表
	getBasketballExportList(data) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/matchDownList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 生成导出文件
	getBasketballExportFile(data) { // 生成导出文件
		return request({
			method: 'post',
			url: '/api/portal/basketball/matchDownFile',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取导出文件下载地址
	getBasketballExportUrl(data) {
		return request({
			method: 'post',
			url: '/api/portal/basketball/matchDown',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
}
