import request from "./http";
import qs from "qs";
import store from "../store/index";

export default {
	// 获取赛事列表
	getFootballMatchList(data) {
		return request({
			method: 'post',
			url: '/api/portal/football/getMatchList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	//创建足球赛事
	saveFootballMatch(data, suc) {
		return request({
			method: 'post',
			url: '/api/portal/football/match',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	//获取足球赛事详情
	getFootballMatchDetail(data, suc) { //获得赛事详情-编辑回填
		return request({
			method: 'post',
			url: '/api/portal/football/getMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	//足球赛事编辑
	updateFootballMatch(data, suc) {
		return request({
			method: 'post',
			url: '/api/portal/football/updateMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	//保险
	getFootballInsurance(data) {
		return request({
			method: 'post',
			url: '/api/portal/insurance/getInsurance',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单详情
	getFootballMatchOrderDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/football/getMatchOrderDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取赛事概览
	footballDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/football/matchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单列表
	footballMatchGroupList(data) {
		return request({
			method: 'post',
			url: '/api/portal/football/matchGroupList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 发起订单退款
	footballMatchRefundOrder(data) {
		return request({
			method: 'post',
			url: '/api/portal/football/matchRefundOrder',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	//足球赛事分组
	footballMatchGroups(data, suc) {
		return request({
			method: 'post',
			url: '/api/portal/football/matchGroup',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	// 获取导出列表
	getFootballExportList(data) {
		return request({
			method: 'post',
			url: '/api/portal/football/matchDownList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 生成导出文件
	getFootballExportFile(data) { // 生成导出文件
		return request({
			method: 'post',
			url: '/api/portal/football/matchDownFile',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取导出文件下载地址
	getFootballExportUrl(data) {
		return request({
			method: 'post',
			url: '/api/portal/football/matchDown',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},



}
