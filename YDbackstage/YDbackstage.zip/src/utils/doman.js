// 网站全局变量
// let URL = ' https://yapi.yongdongli.net' //正式服
let URL = ' https://yapi.test.yongdongli.net' //测试服
module.exports = {
	URL,
};
