import request from "./http";
import qs from "qs";
import store from "../store/index";

export default {

	// ---------------------------------------------------------- 导出 -------------------------------------------------------

	badmintonMatchDownList(data) { //数据列表
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchDownList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	badmintonMatchDown(data) { //下载文件
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchDown',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	badmintonMatchDownFile(data) { //生成文件
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchDownFile',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	// ---------------------------------------------------------- 赛事 -------------------------------------------------------

	getBadmintonMatchList(data) { //赛事列表
		return request({
			method: 'post',
			url: '/api/portal/badminton/getBadmintonMatchList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	badmintonMatch(data) { //赛事创建
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	updateBadmintonMatch(data) { //赛事编辑
		return request({
			method: 'post',
			url: '/api/portal/badminton/updateBadmintonMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	getBadmintonMatchDetail(data) { //赛事详情-编辑回填
		return request({
			method: 'post',
			url: '/api/portal/badminton/getBadmintonMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	badmintonMatchDetail(data) { //赛事概览
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	badmintonMatchGroup(data) { //赛事分组
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchGroup',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	badmintonMatchRefundOrder(data) { //发起退款
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchRefundOrder',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	getBadmintonMatchOrderDetail(data) { //订单信息
		return request({
			method: 'post',
			url: '/api/portal/badminton/getBadmintonMatchOrderDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	badmintonMatchGroupList(data) { //分组订单
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchGroupList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	badmintonMatchGroupPrice(data) { //兼报优惠
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchGroupPrice',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	badmintonMatchGroupRely(data) { //分组依赖配置
		return request({
			method: 'post',
			url: '/api/portal/badminton/badmintonMatchGroupRely',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
}
