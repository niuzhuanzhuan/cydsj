import request from "./http";
import qs from "qs";
import store from "../store/index";

export default {

	// ---------------------------------------------------------- 导出 -------------------------------------------------------

	pingPongMatchDownList(data) { //数据列表
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchDownList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	pingPongMatchDown(data) { //下载文件
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchDown',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	pingPongMatchDownFile(data) { //生成文件
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchDownFile',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	// ---------------------------------------------------------- 赛事 -------------------------------------------------------

	getpingPongMatchList(data) { //赛事列表
		return request({
			method: 'post',
			url: '/api/portal/pingPong/getpingPongMatchList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	pingPongMatch(data) { //赛事创建
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	updatepingPongMatch(data) { //赛事编辑
		return request({
			method: 'post',
			url: '/api/portal/pingPong/updatepingPongMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	getpingPongMatchDetail(data) { //赛事详情-编辑回填
		return request({
			method: 'post',
			url: '/api/portal/pingPong/getpingPongMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	pingPongMatchDetail(data) { //赛事概览
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	pingPongMatchGroup(data) { //赛事分组
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchGroup',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	pingPongMatchRefundOrder(data) { //发起退款
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchRefundOrder',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	getpingPongMatchOrderDetail(data) { //订单信息
		return request({
			method: 'post',
			url: '/api/portal/pingPong/getpingPongMatchOrderDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	pingPongMatchGroupList(data) { //分组订单
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchGroupList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	pingPongMatchGroupPrice(data) { //兼报优惠
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchGroupPrice',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},

	pingPongMatchGroupRely(data) { //分组依赖配置
		return request({
			method: 'post',
			url: '/api/portal/pingPong/pingPongMatchGroupRely',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
}
