import balance from './balance.js'
import badminton from './badminton.js'
import football from './football.js'
import sanda from './sanda.js'
import pingpongball from './pingpongball.js'
import basketball from './basketball.js'

let apiAll={}

Object.assign(apiAll,balance)
Object.assign(apiAll,badminton)
Object.assign(apiAll,basketball)
Object.assign(apiAll,pingpongball)
Object.assign(apiAll,sanda)
Object.assign(apiAll,football)

export default apiAll
