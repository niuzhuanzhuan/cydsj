import request from "./http";
import qs from "qs";
import store from "../store/index";

export default {
	//平衡车赛事兼报优惠
	// 	type	是	string	list列表 save保存 delete删除 detail详情
	// 	XX-token	是	string	token 头部自带
	// 	match_id	是	string	赛事id
	sandaMatchGroupPrice(data) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/MatchGroupPrice',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	sandaMatch(data, suc) { //创建平衡车赛事
		return request({
			method: 'post',
			url: '/api/portal/Grappling/match',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	
	getSandaMatchDetail(data, suc) { //获得赛事详情-编辑回填
		return request({
			method: 'post',
			url: '/api/portal/Grappling/getMatchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	
	sandaMatchGroups(data, suc) { //平衡车赛事分组
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchGroup',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	
	updateSandaMatch(data, suc) { //平衡车赛事编辑
		return request({
			method: 'post',
			url: '/api/portal/Grappling/updateMatch',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	
	sandaMatchGroupRely(data, suc) { //平衡车赛事分组依赖配置
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchGroupRely',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	getSandaContent(data, suc) { //平衡车赛事分组依赖配置
		return request({
			method: 'post',
			url: '/api/portal/index/getContent',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			}
		})
	},
	
	getSandaExportList(data) { // 获取导出列表
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchDownList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getSandaExportUrl(data) { // 获取导出文件下载地址
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchDown',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	getSandaExportFile(data) { // 生成导出文件
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchDownFile',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	
	getSandaInsurance(data) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/getInsurance',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取赛事列表
	getSandaMatchList(data) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/getMatchList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单详情
	getSandaMatchOrderDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/getMatchOrderDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取赛事概览
	sandaMatchDetail(data) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchDetail',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 获取订单列表
	sandaMatchGroupList(data) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchGroupList',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 发起订单退款
	sandaMatchRefundOrder(data) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/matchRefundOrder',
			data: qs.stringify(data),
			headers: {
				'XX-Token': store.state.initfromdata.token
			},
		})
	},
	// 导入分组信息
	sandaImportGroup(data,processCB) {
		return request({
			method: 'post',
			url: '/api/portal/Grappling/upGroup',
			data: data,
			headers: {
				"Content-Type":"multipart/form-data",
				'XX-Token': store.state.initfromdata.token
			},
			onUploadProgress: function (pEvent) {
				if(typeof processCB === 'function'){
					processCB((pEvent.loaded/pEvent.total).toFixed(2) * 100 )
				}
			  },
		})
	},
}
