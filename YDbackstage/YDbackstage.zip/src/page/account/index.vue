<template>
	<div class="page-main">
		<div class="account-line">
			<img :src="image" class="account-logo" />
			<div class="account-content">
				<p>{{company_name}}</p>
				<p>超级管理员：{{mobile}}</p>
			</div>
			<div class="account-aside">
				<el-button type="primary" @click="toChange">更改管理员</el-button>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				company_name: "",
				image: "",
				mobile: ""
			}
		},
		created() {
			this.$api.getAccount({type:'detail'}).then(res => {
				// console.log(res);
				if(res.code === 1){
					this.company_name = res.data.company_name
					this.image = res.data.image
					this.mobile = res.data.mobile
				}
			})
		},
		methods:{
			// 跳转变更页面
			toChange(){
				this.$router.push({name:'accountChange',params:{mobile:this.mobile}});
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	
	.page-main{
		height: calc(100% - 28px);
		padding: 10px 20px;
		background-color: #f5f5f5;
	}
	
	.el-button--primary{
		background-color: #3861DB;
	}
	
	.account-line{
		display: flex;
		justify-content: flex-start;
		align-items: center;
		width: 100%;
		height: 160px;
		background-color: white;
		border-radius: 10px;
		padding: 10px 20px;
		
		.account-logo{
			width: 92px;
			height: 92px;
			border-radius: 46px;
			margin-right: 20px;
		}
		
		.account-content{
			
			p{
				font-size: 24px;
				color: #1A1717;
			}
			p+p{
				font-size: 16px;
				color: #999999;
			}
		}
		.account-aside{
			margin-left: auto;
		}
	}
</style>
