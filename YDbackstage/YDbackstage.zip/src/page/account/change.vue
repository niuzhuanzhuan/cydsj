<template>
	<div class="page-main">
		<el-form class="club-form" 
			ref="clubForm"
			:model="formData"
			label-position="left"
			label-width="100px"
			status-icon
		>
			<el-form-item label="原超级管理人" prop="originTel">
				<el-input v-model="formData.originTel" readonly placeholder="请输入管理人手机号码"></el-input>
			</el-form-item>
			<el-form-item label="变更管理人" prop="newTel"
				:rules="[{required:true,message:'新管理人电话号码不能为空'}]"
			>
				<el-input v-model="formData.newTel" placeholder="请输入新管理人电话号码"></el-input>
			</el-form-item>
			<el-form-item label="获取验证码">
				<el-col :span="14">
					<el-input v-model="formData.code" placeholder="请输入验证码"></el-input>
				</el-col>
				<el-col class="btn-field" :span="10">
					<el-button class="code-btn"  type="primary" plain @click="sendCode" :disabled="!canISend">{{codeText}}</el-button>
				</el-col>
			</el-form-item>
			<div class="club-submit" @click="submitData">确认更改</div>
		</el-form>
		
	</div>
</template>

<script>
	export default {
		data() {
			return {
				formData:{
					originTel:'',
					newTel:'',
					code:'',
				},
				codeText:'获取验证码',
				baseCooldown:60, // 默认 发送验证码的cd
				canISend:true, // 能否重新发送短信
				countdownTimer:null, // 倒计时计时器
			}
		},
		created() {
			const params = this.$route.params;
			this.formData.originTel = params.mobile;
		},
		methods:{
			/**
			 * 发送验证码
			 */
			sendCode(){
				if(this.canISend){
					// console.log('send msg');
					if(this.formData.newTel === ''){
						this.$message({ message: '请输入变更管理人手机号', type: 'warning' });
						return ;
					}
					this.$api.getVerify({
						mobile:this.formData.newTel
					}).then(res => {
						// console.log(res);
						if(res.code === 1){
							this.$message({ message: res.msg, type: 'success' });
							this.canISend = false;
							this.setCooldown();
						}
						
					})
				}
			},
			/**
			 * 发送验证码倒计时
			 */
			setCooldown(){
				let countDown = this.baseCooldown;
				this.codeText = `重新获取验证码(${countDown})`;
				this.countdownTimer = setInterval(()=>{
					countDown -= 1;
					if(countDown > 0){
						this.codeText = `重新获取验证码(${countDown})`;
					}else{
						this.codeText = `重新获取验证码`;
						this.canISend = true;
						clearInterval(this.countdownTimer);
					}
				},1000);
			},
			/**
			 * 提交表单
			 */
			submitData(){
				this.$refs['clubForm'].validate(valid => {
					if(valid){
						this.$api.getAccount({
							mobile:this.formData.newTel,
							code:this.formData.code,
							type:'',
						}).then(res => {
							if(res.code === 1){
								this.$message({ message: '管理人变更成功，请重新登录', type: 'success' });
								this.$router.replace('/Login');
							}
						})
					}
				});
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	
	.page-main{
		width: 100% ;
		height: 100%;
		background-color: white;
		padding-top: 200px;
	}
	
	.club-form{
		width: 500px;
		padding:0 20px;
		margin: 0 auto;
		
		
		.btn-field{
			text-align: right;
			.code-btn{
				width: 140px;
			}
		}
		
		.el-button--primary.is-plain:hover{
			background: #3861DB;
			border-color: #3861DB;
		}
		
		
		.club-submit{
			width: 100%;
			height: 40px;
			line-height: 40px;
			border-radius: 4px;
			background-color: #3861DB;
			color: white;
			text-align: center;
			cursor: pointer;
			transition: background-color .3s; 
			
			&:hover{
				background-color: #3f70f8;
			}
		}
	}
</style>
