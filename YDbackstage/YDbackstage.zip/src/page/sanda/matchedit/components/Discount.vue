<template>
	<div class="limst">
		<el-table
			:data="tableData"
			:header-cell-style="{
				'background-color': '#fafafa',
				color: '#333333',
				padding: '16px'
			}"
			style="width: 100%"
		>
			<el-table-column align="center" fixed label="分组名称" prop="name"></el-table-column>
			<el-table-column align="center" label="显示状态" prop="is_show_text"></el-table-column>
			<el-table-column align="center" label="报名状态" prop="is_start_text"></el-table-column>
			<el-table-column align="center" label="原价(元)" prop="price"></el-table-column>
			<el-table-column align="center" label="折扣后最终需付金额(元)" prop="discount_price"></el-table-column>
			<el-table-column align="center" fixed="right" label="操作">
				<template slot-scope="scope">
					<el-button @click="setting(scope.row)" size="small" style="font-size: 14px;" type="text">兼报优惠配置</el-button>
				</template>
			</el-table-column>
		</el-table>

		<el-dialog :before-close="handleClose" :close-on-click-modal="false" :destroy-on-close="true" :visible="dialogVisible" title="兼报优惠" width="1100px">
			<el-form :model="ruleForm" :rules="rules" label-width="300px" ref="ruleForm">
				<el-form-item label="分组名称:" prop="group_name">
					<el-input readonly style="width: 20rem;margin-left: 50px;" v-model="ruleForm.group_name"></el-input>
				</el-form-item>
				<el-form-item label="原价:" prop="price">
					<el-input placeholder="请输入价格" readonly style="width: 20rem;margin-left: 50px;" v-model="ruleForm.price"></el-input>
				</el-form-item>
				<el-form-item label="成功报名以下任意勾选组别:" prop="checkGroup">
					<el-checkbox-group v-model="checkGroup">
						<el-checkbox :key="e.id" :label="e.id" :value="e.is_checked" v-for="e in ruleForm.group_list">{{ e.name }}</el-checkbox>
					</el-checkbox-group>
				</el-form-item>
				<el-form-item label="折扣后最终需付金额:" prop="discount_price">
					<el-input placeholder="请输入最终需付金额" style="width: 20rem;margin-left: 50px;" maxlength="10" show-word-limit v-model="ruleForm.discount_price"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button @click="handleClose">取 消</el-button>
					<el-button @click="submitForm" type="primary">保 存</el-button>
				</el-form-item>
			</el-form>
		</el-dialog>
	</div>
</template>

<script>
export default {
	name: 'Discount',
	data() {
		let validateGroup = (rule, value, callback) => {
			if (this.checkGroup.length >= 1) {
				callback();
			} else {
				// callback(new Error('请选择兼报优惠组!'));
				callback(); //不校验
			}
		};
		return {
			dialogVisible: false,
			match_id: '',
			tableData: [
				{
					date: '2016-05-03',
					name: '王小虎',
					province: '上海',
					city: '普陀区',
					address: '上海市普陀区金沙江路 1518 弄',
					zip: 200333
				},
				{
					date: '2016-05-02',
					name: '王小虎',
					province: '上海',
					city: '普陀区',
					address: '上海市普陀区金沙江路 1518 弄',
					zip: 200333
				},
				{
					date: '2016-05-04',
					name: '王小虎',
					province: '上海',
					city: '普陀区',
					address: '上海市普陀区金沙江路 1518 弄',
					zip: 200333
				},
				{
					date: '2016-05-01',
					name: '王小虎',
					province: '上海',
					city: '普陀区',
					address: '上海市普陀区金沙江路 1518 弄',
					zip: 200333
				},
				{
					date: '2016-05-08',
					name: '王小虎',
					province: '上海',
					city: '普陀区',
					address: '上海市普陀区金沙江路 1518 弄',
					zip: 200333
				},
				{
					date: '2016-05-06',
					name: '王小虎',
					province: '上海',
					city: '普陀区',
					address: '上海市普陀区金沙江路 1518 弄',
					zip: 200333
				},
				{
					date: '2016-05-07',
					name: '王小虎',
					province: '上海',
					city: '普陀区',
					address: '上海市普陀区金沙江路 1518 弄',
					zip: 200333
				}
			],
			ruleForm: {},
			rules: {
				checkGroup: [{ required: true, trigger: 'blur', validator: validateGroup }],
				discount_price: [
					{
						required: true,
						type: 'number',
						min: 0,
						max: 10000,
						message: '请输入0~10000的数字',
						trigger: 'blur',
						transform(value) {
							return Number(value);
						}
					}
				]
			},
			checkGroup: [],
			selectItem: ''
		};
	},
	components: {
		//	Disfrom
	},
	methods: {
		handleClose() {
			this.dialogVisible = false;
		},
		async getList() {
			this.tableData = [];
			let data = {
				type: 'list',
				match_id: this.match_id
			};
			let list = await this.$api.sandaMatchGroupPrice(data);
			list && list.code == 1 && (this.tableData = list.data);
		},
		async setting(item) {
			this.checkGroup = [];
			this.selectItem = item.id;
			let data = {
				type: 'detail',
				match_id: this.match_id,
				id: item.id
			};
			let list = await this.$api.sandaMatchGroupPrice(data);
			list && list.code == 1 && (this.dialogVisible = true) && (this.ruleForm = list.data);
			this.ruleForm.group_list.map(i => {
				if (i.is_checked) {
					this.checkGroup.push(i.id);
				}
			});
		},
		submitForm() {
			this.$refs['ruleForm'].validate(valid => {
				if (valid) {
					let data = {
						type: 'save',
						id: this.selectItem,
						match_id: this.match_id,
						group_id: this.checkGroup.join(','),
						price: this.ruleForm.discount_price
					};
					this.$api.sandaMatchGroupPrice(data).then(res => {
						console.log(res);
						if (res.code == 1) {
							this.$alert('保存成功!', '', { type: 'success' });
							this.dialogVisible = false;
							this.getList();
						}
					});
				} else {
					this.$message.error('数据校验失败，请检查输入的信息是否正确！');
				}
			});
		}
	},

	created() {
		this.match_id = this.$route.query.match_id;
		this.getList();
	}
};
</script>

<style scoped>
.limst >>> .el-dialog__body {
	padding: 20px;
}

.limst >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}

.limst >>> .el-dialog {
	border-radius: 10px;
}

.limst >>> .el-dialog__header {
	border-bottom: 1px dashed #e8e8e8;
}

.limst >>> .el-dialog__title {
	font-size: 14px;
	font-weight: bold;
	color: #333333;
}

.limst >>> .el-table__header {
	font-size: 14px;
}

.limst >>> .el-table__row {
	font-size: 14px;
}
</style>
<style lang="less" scoped>
.minatiltle {
	width: 100%;
	height: 46px;
	background: rgba(238, 64, 55, 0.1);
	border: 1px solid #ee4037;
	border-radius: 6px;
	display: flex;
	align-items: center;
	justify-content: center;
	color: #444242;
	font-size: 14px !important;
	opacity: 0.8;

	i {
		color: #3861db;
		margin-right: 6px;
		font-size: 16px !important;
	}
}

.limst {
	padding-top: 6px;
	width: 100%;
	border-top: 1px #e8e8e8 dashed;
}

.miantilte {
	margin-bottom: 8px;
	padding-top: 24px;
	padding-left: 22px;

	span {
		font-size: 14px;
		color: #333333;

		&:nth-child(1) {
			font-weight: bold;
		}

		&:nth-child(2) {
			color: #707070;
		}
	}
}
</style>
