<template>
	<div class="page-main">
		<el-button type="primary" class="new-btn" @click="toNew">创建赛事</el-button>
		<!-- 表头 -->
		<div class="table-head">
			<span class="thead-first">赛事名称</span>
			<div class="_hideLine"></div>
			<span>报名费</span>
			<div class="_hideLine"></div>
			<span>总名额</span>
			<div class="_hideLine"></div>
			<span>状态</span>
			<div class="_hideLine"></div>
			<span>操作</span>
		</div>
		<!-- 赛事列表 -->
		<img v-if="listData.length === 0" class="table-empty" src="@/assets/imgs/empty_table.png" />
		
		<div v-else class="table-body">
			<div class="table-tr" v-for="li of listData" :key="li.id">
				<marchTableRow class="match-row" :data="li" >
					<el-button class="match-btn manage-btn" size="mini" @click="toInfo(li)">赛事管理</el-button>
					<el-button class="match-btn edit-btn" size="mini" @click="toEdit(li)">编辑赛事</el-button>
				</marchTableRow>
				<div class="match-path">
					<div class="club-info">
						<img class="club-logo" :src="li.club_image !== null ? li.club_image: li.company_image" />
						<span class="club-name">{{li.club_name !== null ? li.club_name : li.company_name}}</span>
					</div>
					<el-link type="primary" @click="toCopy(li)">复制赛事</el-link>
					<el-popconfirm
						title="确定导出报名列表？"
						@onConfirm="exportEnrollList(li)"
					>
						<el-link slot="reference" type="primary" >导出报名列表</el-link>
					</el-popconfirm>
					<!-- 暂时没有成绩上传 -->
					<!-- <el-button class="match-btn score-btn" size="mini">成绩上传</el-button> -->
				</div>
			</div>
		</div>
		<self-pagination ref="pagination" class="page-bar" :total="listTotal" @pageChange="pageChange"></self-pagination>
	</div>
</template>

<script>
	import marchTableRow from './components/matchTableRow.vue';
	import selfPagination from '@/components/BaseComponents/Pagination.vue';
	
	export default {
		components:{
			marchTableRow,
			selfPagination
		},
		data() {
			return {
				listData: [],
				listTotal: 0,
			}
		},
		mounted() {
			this.$refs.pagination.goTo(1);
		},
		methods:{
			// 切换分页
			pageChange(params) {
				this.$api.getSandaMatchList({
					...params
				}).then(res => {
					if(res.code === 1){
						this.listData = res.data.data;
						this.listTotal = res.data.total;
					}
				})
			},
			// 跳转创建赛事
			toNew(){
				this.$router.push({path:'/sanda_establish'});
			},
			// 跳转赛事管理页面
			toInfo(item){
				this.$router.push({path:'/sanda_matchinfo',query:{match_id:item.id}});
			},
			// 跳转编辑
			toEdit(item){
				this.$router.push({path:'/sanda_edit',query:{match_id:item.id}});
			},
			// 跳转创建赛事做复制操作，带match_id
			toCopy(item){
				this.$router.push({path:'/sanda_establish',query:{match_id:item.id}});
			},
			exportEnrollList(item){
				this.$api.getSandaExportFile({match_id:item.id}).then(res => {
					if(res.code === 1){
						this.$confirm('请到导出记录里下载','导出成功',{ 
							confirmButtonText: '立即进入',
							cancelButtonText: '取消',
							type: 'success' ,
							center:true,
							confirmButtonClass:'spec-pop-btn',
						}).then(() => {
							this.$router.push({path:'/sanda_export'});
						}).catch(()=>{
							
						});
					}
				})
			},
		}
	}
</script>

<style>
	.spec-pop-btn {
		background-color: #3861DB;
	}
</style>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	.page-main{
		padding: 0 20px 20px;
	}
	.new-btn{
		width: 120px;
		margin-bottom: 10px;
		font-size: 16px;
		background-color: #3861DB;
	}
	.el-link{
		color: #3861DB;
	}
	
	.page-bar{
		text-align: right;
	}
	.table-empty{
		margin: 20px 0;
		margin-left: calc(50% - 30px);
	}
	// 表头
	.table-head{
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 56px;
		padding: 0 20px;
		background-color: #FAFAFA;
		font-size: 14px;
		color: #333333;
		border: solid 1px white;
		
		span{
			flex-grow: 1;
			text-align: center;
		}
		span.thead-first{
			flex-basis: 460px;
			padding-right: 20px;
			text-align: left;
		}
		// 分割线占位
		._hideLine{
			width: 1px;
			height: 100%;
		}
	}
	// 表格 行样式 与插槽样式
	.table-tr{
		margin: 10px 0;
		border: solid 1px #E8E8E8;
		background-color: white;
		
		
		.match-row{
			
		}
		.match-btn{
			margin: 0;
			color: white;
			
			&.manage-btn{
				background-color: #3861DB;
			}
			&.edit-btn{
				background-color: #FF696A;
			}
			&.score-btn{
				background-color: #589DF8;
			}
		}
		.match-path{
			display: flex;
			justify-content: flex-end;
			align-items: center;
			height: 40px;
			padding: 0 20px;
			border-top: solid 1px #E4E7ED;
			
			.el-link{
				margin-left: 20px;
				font-size: 12px;
			}
			.club-info{
				display: inline-flex;
				align-items: center;
				margin-right: auto;
				
				.club-logo{
					width: 32px;
					height: 32px;
					border-radius: 16px;
					margin-right: 10px;
				}
			}
			
		}
		
	}
</style>
