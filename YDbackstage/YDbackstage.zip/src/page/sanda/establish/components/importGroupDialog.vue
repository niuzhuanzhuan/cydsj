<template>
	<el-dialog
		title="批量上传分组" 
		:visible.sync="showDialog"
		width="80%"
		:center="true"
	>
		<div class="top-tip">
			<span>请按以下示例上传分组表格</span>
			<el-button type="primary" @click="dlTemplate" icon="el-icon-download" style="background-color: #3861DB;font-size: 16px;">下载模板</el-button>
			<el-button type="primary" @click="importGroup" :loading="uploadFlag" icon="el-icon-upload2" style="background-color: #3861DB;font-size: 16px;">上传表格</el-button>
			<div class="upload-process">{{UpProcess}}%</div>
			<input hidden type="file" accept=".xls" ref="fileInput" @change="importFileChange" />
		</div>
		<el-table 
			border 
			:data="templateData" 
		>
			<el-table-column property="name" label="分组名称" align="center" width="100" ></el-table-column>
			<el-table-column property="age_s" label="年龄开始" align="center" width="100" ></el-table-column>
			<el-table-column property="age_e" label="年龄结束" align="center" width="100"></el-table-column>
			<el-table-column property="sex" label="性别" align="center" width="100"></el-table-column>
			<el-table-column label="重量级" header-align="center" class-name="mix-trow" label-class-name="none-mix-header">
				<template slot-scope="scope">
					<div class="mix-cell">{{scope.row.a}}</div>
					<div class="mix-cell">{{scope.row.b}}</div>
					<div class="mix-cell">{{scope.row.c}}</div>
					<div class="mix-cell">{{scope.row.d}}</div>
					<div class="mix-cell">{{scope.row.e}}</div>
				</template>
			</el-table-column>
		</el-table>
		<span slot="footer" class="dialog-footer">
		    <el-button @click="showDialog = false">取 消</el-button>
		    <el-button class="close-btn" type="primary" @click="showDialog = false">确 定</el-button>
		</span>
		
	</el-dialog>
</template>

<script>
	export default {
		data() {
			return {
				uploadFlag:false,
				showDialog:false,
				UpProcess:'---',
				// 批量导入示例表格数据
				templateData:[
					{name:'男子a组',age_s:9,age_e:10,sex:'男',a:'27',b:'30',c:'36',d:'......',e:'51+',},
					{name:'女子b组',age_s:9,age_e:10,sex:'女',a:'27',b:'30',c:'36',d:'......',e:'51+',},
					{name:'男子c组',age_s:9,age_e:10,sex:'男',a:'27',b:'30',c:'36',d:'......',e:'51+',},
					{name:'女子d组',age_s:9,age_e:10,sex:'女',a:'27',b:'30',c:'36',d:'......',e:'51+',},
					{name:'......',age_s:'......',age_e:'......',sex:'......',a:'......',b:'......',c:'......',d:'......',e:'......',},
				],
			}
		},
		methods:{
			/**
			 * 打开弹窗
			 */
			open(){
				this.showDialog = true;
			},
			/**
			 * 关闭弹窗
			 */
			close(){
				this.showDialog = false;
				this.UpProcess = '---';
			},
			/**
			 * 下载模板
			 */
			dlTemplate(){
				window.location.href="https://easyimgs.oss-cn-gz-ysgzlt-d01-a.ltops.gzdata.com.cn/images/grappling.xls";
			},
			/**
			 * 触发文件选择
			 */
			importGroup(){
				this.$refs.fileInput.click()
			},
			/**
			 * 上传文件
			 * @param {Object} event 文件选择事件
			 */
			importFileChange(event){
				const files = event.target.files;
				 
				if(files.length === 0){
					return ;
				}
				// 组装表单数据
				let uploadForm = new FormData();
				uploadForm.append('myfile',files[0])
				// 比赛开始时间
				if(sessionStorage['match_time'] !== undefined){
					uploadForm.append('match_start_time',sessionStorage['match_time'])
				}
				// 生日当天是否升组
				if(sessionStorage['is_birthday'] !== undefined){
					uploadForm.append('is_birthday',sessionStorage['is_birthday'])
				}
				// 提交
				this.uploadFlag = true
				this.$api.sandaImportGroup(uploadForm,(per) => {
					this.UpProcess = per
					if(per === 100){
						this.uploadFlag = false
					}
				}).then(res => {
					if(res !== undefined && res.code === 1){
						this.$emit('complete',res.data)
					}
				})
				event.target.value = '';
				
			}
		}
	}
</script>

<style lang="less" scoped>
	.upload-process{
		width: 60px;
		text-align: center;
	}
	
	/deep/ .mix-trow{
			width: 100%;
			height: 100%;
			padding:0px 0;
			
			.cell{
				display: inline-flex;
				align-items: stretch;
				justify-content: space-between;
				width: 100%;
				height: 100%;
				padding: 0;
			}
			
			.none-mix-header{
				justify-content: center;
			}
			.mix-cell{
				flex-grow: 1;
				padding: 8px 0;
				border-right: 1px solid #EBEEF5;
				text-align: center;
				
				&:last-of-type{
					border-right: none;
				}
				
			}
		}
	.top-tip{
		display: flex;
		justify-content: flex-end;
		align-items: center;
		margin-bottom: 20px;
		
		span{
			margin-right: auto;
		}
	}	
</style>
