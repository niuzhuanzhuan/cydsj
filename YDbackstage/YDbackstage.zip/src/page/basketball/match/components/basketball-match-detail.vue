<template>
	<div class="component-main">
		<div class="total-bar">
			<div class="title">汇总信息</div>
			<div class="total-line">
				<total-box label="浏览次数" alt="说明说明" >{{data.view}}</total-box>
				<total-box label="已报名人数" alt="说明说明" >{{data.sign_total_num}}<span>/{{data.total_num}}</span></total-box>
				<total-box label="老用户回头率" alt="说明说明" >{{data.old_user}}<span>%</span></total-box>
				<total-box label="已收报名费" alt="说明说明" >￥{{data.sign_total_price}}<span>(含渠道费￥{{data.sign_total_price_hand}})</span></total-box>
			</div>
		</div>
		
		<div class="enroll-statistic">
			<!-- 性别比例 -->
			<div class="stc-box">
				<div class="stc-title">性别比例</div>
				<div class="stc-content sex-stc">
					<match-sex-per :boy="data.boy" :girl="data.girl"></match-sex-per>
				</div>
			</div>
			<!-- 组别人数分布图 -->
			<div class="stc-box">
				<div class="stc-title">组别人数分布图</div>
				<div class="stc-content">
					<div ref="groupChart" class="group-chart"></div>
				</div>
			</div>
		</div>
		
		<el-table
			class="enroll-table"
			:data="tableData"
			:header-cell-style="{'background-color':'#FAFAFA'}"
		>
			<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
			
			<el-table-column prop="group_name" label="组别" align="center"></el-table-column>
			<el-table-column prop="price" label="报名费" align="center"></el-table-column>
			<el-table-column prop="limit_num" label="已报名人数" align="center"></el-table-column>
			<el-table-column prop="sex" label="男生/女生" align="center"></el-table-column>
			<el-table-column prop="old_user" label="回头率" align="center"></el-table-column>
			<el-table-column prop="price_sum" label="已收报名费" align="center"></el-table-column>
		</el-table>
	</div>
</template>

<script>
	import totalBox from './basketball-match-total-box.vue'
	import matchSexPer from './basketball-match-sex-per.vue'
	
	import echarts from 'echarts'
	
	export default {
		components:{
			totalBox,
			matchSexPer
		},
		props:['data'],
		data(){
			return {
				total:0,
				chartData:[],
			};
		},
		computed:{
			tableData:{
				get:function(){
					return this.data.group !== undefined ? this.data.group : [];
				},
				set:function(){
					return [];
				}
			},
		},
		watch: {
			data(newValue, oldValue) {
				let xaxis = newValue.group.map(dt => dt.group_name);
				let chartData = newValue.group.map(dt => dt.limit_num);
				this.setChart(xaxis,chartData);
			}
		},
		mounted() {
			// this.tableData = this.data.group;
		},
		methods:{
			// 设置柱状图
			setChart(xaxis,data){
				const target = echarts.init(this.$refs.groupChart)
				target.setOption({
					tooltip: {},
					xAxis: {
						type: 'category',
						name:'组别',
						data: xaxis,
						axisTick: {
							alignWithLabel:true,
							interval:0,
						},
					},
					yAxis:{
						name:'人数',
						type:'value',
						min:0,
						minInterval: 1
					},
					dataZoom: [{
						type: 'slider',
						xAxisIndex: [0],
					},{
						type: 'inside',
						xAxisIndex: [0],
					}],
					tooltip: {
						trigger: 'item',
						formatter: '{b}：{c} 人'
					},
					grid: {
						width:'80%',
						height:260,
					},
					series: [{
						name: '组别',
						type: 'bar',
						data: data,
						itemStyle:{
							color:'#7D9EFF',
							barBorderRadius:[6,6,0,0]
						}
					}]
				});
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	.icon {
		width: 1em; height: 1em;
		vertical-align: -0.15em;
		fill: currentColor;
		overflow: hidden;
	}
	
	.component-main{
		
	}
	.total-bar{
		border: 1px solid #E4E7ED;
		padding: 20px;
		
		.total-line{
			height: 60px;
			line-height: 30px;
			display: flex;
			justify-content: space-between;
		}
	}
	.enroll-statistic{
		display: flex;
		margin-top: 10px;
		
		.stc-box{
			width: 50%;
			height: 450px;
			border: solid 1px #E8E8E8;
			
			&:first-of-type{
				border-right: none;
			}
			
			.stc-title{
				height: 40px;
				line-height: 40px;
				padding-left: 20px;
				font-size: 14px;
				border-bottom: solid 1px #E8E8E8;
			}
			
			.group-chart{
				width: 100%;
				height: 380px;
			}
			
		}
		.sex-stc{
			height: 100%;
			display: flex;
			flex-direction: column;
			justify-content: center;
		}
	}
	.enroll-table{
		width: 100%;
		margin-top: 20px;
	}
	.page-bar{
		text-align: right;
		margin-top: 10px;
	}
	
</style>
