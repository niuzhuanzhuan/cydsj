<template>
    <div class="initmians">
        <!--<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="200px">
            <el-form-item label="组别名称" prop="name"><el-input v-model.trim="ruleForm.name"></el-input></el-form-item>
            <el-form-item label="价格" prop="price"><el-input v-model.trim="ruleForm.price"></el-input></el-form-item>
            <el-form-item label="名额" prop="limit"><el-input v-model.trim="ruleForm.limit"></el-input></el-form-item>
            <el-form-item label="团队成员" prop="team_limit">
                <el-input v-model.trim="ruleForm.team_limit"><span slot="append">人</span></el-input>
            </el-form-item>

            <el-form-item label="快速生成出生日期" required>
                <el-col :span="11">
                    <el-form-item prop="age_start">
                        <el-select style="width: 350px;" v-model="ruleForm.age_start" @change="ageval(ruleForm.age_start)" placeholder="请选择">
                            <el-option v-for="(items, index) in datainit" :key="index" :label="items.name" :value="items.name"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col class="line" :span="2">至</el-col>
                <el-col :span="11">
                    <el-form-item prop="age_end">
                        <el-select style="width: 350px;" v-model="ruleForm.age_end" @change="age_ends(ruleForm.age_end)" placeholder="请选择">
                            <el-option v-for="(items, index) in arrage_end" :key="index" :label="items.name" :value="items.name"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-form-item>

            <el-form-item label="单个选手生日范围" required>
                <el-col :span="11">
                    <el-form-item prop="age_date_start">
                        <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="请选择开始时间" v-model="ruleForm.age_date_start" style="width: 100%;"></el-date-picker>
                    </el-form-item>
                </el-col>
                <el-col class="line" :span="2">至</el-col>
                <el-col :span="11">
                    <el-form-item prop="age_date_end">
                        <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="请选择结束时间" v-model="ruleForm.age_date_end" style="width: 100%;"></el-date-picker>
                    </el-form-item>
                </el-col>
            </el-form-item>

            <el-form-item label="年龄累计配置">
                <el-radio-group v-model="ruleForm.total_age">
                    <el-radio :label="0">不配置</el-radio>
                    <el-radio :label="1">按年累计</el-radio>
                    <el-radio :label="2">按月累计</el-radio>
                </el-radio-group>
                <template v-if="ruleForm.total_age != 0">
                    <div class="mianlist">
                        <div class="itelis">
                            <div style="margin-right: 8px;">累计年龄</div>
                            <el-select style="width: 120px;margin-right: 8px;" v-model="ruleForm.total_age_json.where1">
                                <el-option label="大于" value=">"></el-option>
                                <el-option label="大于等于" value=">="></el-option>
                                <el-option label="小于" value="<"></el-option>
                                <el-option label="小于等于" value="<="></el-option>
                                <el-option label="等于" value="="></el-option>
                            </el-select>
                            <el-input style="width: 120px;margin-right: 8px;" placeholder="请填写年龄" v-model.trim="ruleForm.total_age_json.num1"></el-input>
                            <div style="margin-right: 8px;">{{ ruleForm.total_age == 1 ? '岁' : '月' }}</div>

                            <el-select
                                style="width: 120px;margin-right: 8px;"
                                v-if="ruleForm.total_age_json.where1 == '>' || ruleForm.total_age_json.where1 == '>='"
                                v-model="ruleForm.total_age_json.where2"
                            >
                                <el-option label="小于" value="<"></el-option>
                                <el-option label="小于等于" value="<="></el-option>
                            </el-select>
                            <el-input
                                v-if="ruleForm.total_age_json.where1 == '>' || ruleForm.total_age_json.where1 == '>='"
                                style="width: 120px;margin-right: 8px;"
                                placeholder="请填写年龄"
                                v-model.trim="ruleForm.total_age_json.num2"
                            ></el-input>
                            <div v-if="ruleForm.total_age_json.where1 == '>' || ruleForm.total_age_json.where1 == '>='" style="margin-right: 8px;">
                                {{ ruleForm.total_age == 1 ? '岁' : '月' }}
							</div>
						</div>
					</div>
				</template>
			</el-form-item>
			<el-form-item label="性别限制">
				<el-radio-group v-model="ruleForm.sex">
					<el-radio :label="0">不限</el-radio>
					<el-radio :label="1">限制</el-radio>
				</el-radio-group>
				<template>
					<div class="litiems" v-show="ruleForm.sex == 1"><Gender ref="Genders" /></div>
				</template>
			</el-form-item>
			<el-form-item label="年龄计算截止日期" v-if="ruleForm.sex == 1" prop="user_age_end_date">
				<el-date-picker
					style="width: 760px;"
					value-format="yyyy-MM-dd"
					v-model="ruleForm.user_age_end_date"
					type="date"
					placeholder="请选择年龄计算截止日期(一般为赛事开始日期)"
				></el-date-picker>
			</el-form-item>
			<el-form-item>
				<el-button @click="$emit('handleClose')">取 消</el-button>
				<el-button type="primary" @click="submitForm('ruleForm')">保 存</el-button>
			</el-form-item>
		</el-form>-->
        <el-form :model="ruleForm" :rules="rules" label-width="180px" ref="basketballRuleForm">

            <el-form-item label="组别名称" prop="name">
                <el-input v-model.trim="ruleForm.name"></el-input>
            </el-form-item>

            <el-form-item prop="price_type">
                <el-radio-group v-model="ruleForm.price_type">
                    <el-radio :label="2">团队总价</el-radio>
                    <el-radio :label="1">团队单价<span style="color: #c0c0c0">（团队报名按个人收费）</span></el-radio>
                </el-radio-group>
            </el-form-item>

            <el-form-item label="报名费/人" prop="price" v-if="ruleForm.price_type===1">
                <el-input v-model.trim="ruleForm.price"></el-input>
            </el-form-item>
            <el-form-item label="报名费" prop="price" v-else>
                <el-input v-model.trim="ruleForm.price"></el-input>
            </el-form-item>

            <el-form-item label="团队名额" prop="limit">
                <el-input v-model.trim="ruleForm.limit"></el-input>
            </el-form-item>

            <el-form-item label="每队成员人数" prop="team_limit_json">
                <div style="flex-direction: row;display: flex">
                    <el-select style="width: 180px;margin-right: 8px;"
                               v-model="ruleForm.team_limit_json.where1">
                        <el-option label="大于" value=">"></el-option>
                        <el-option label="大于等于" value=">="></el-option>
                        <el-option label="小于" value="<"></el-option>
                        <el-option label="小于等于" value="<="></el-option>
                        <el-option label="等于" value="="></el-option>
                    </el-select>
                    <el-input placeholder="请填写每队人数" style="width: 220px;margin-right: 70px;"
                              v-model.trim="ruleForm.team_limit_json.num1">
                        <template slot="append">人</template>
                    </el-input>

                    <el-select style="width: 180px;margin-right: 8px;"
                               v-if="ruleForm.team_limit_json.where1 == '>' || ruleForm.team_limit_json.where1 == '>='"
                               v-model="ruleForm.team_limit_json.where2">
                        <el-option label="小于" value="<"></el-option>
                        <el-option label="小于等于" value="<="></el-option>
                    </el-select>
                    <el-input placeholder="请填写每队人数" style="width: 220px;margin-right: 8px;"
                              v-if="ruleForm.team_limit_json.where1 == '>' || ruleForm.team_limit_json.where1 == '>='"
                              v-model.trim="ruleForm.team_limit_json.num2">
                        <template slot="append">人</template>
                    </el-input>
                </div>
            </el-form-item>

            <el-form-item label="年龄限制" required>
                <el-col :span="11">
                    <el-form-item prop="age_start">
                        <el-select @change="ageval(ruleForm.age_start)" placeholder="请选择"
                                   style="width: 350px;" v-model="ruleForm.age_start">
                            <el-option :key="index" :label="items.name" :value="items.name"
                                       v-for="(items, index) in datainit"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="2" class="line">至</el-col>
                <el-col :span="11">
                    <el-form-item prop="age_end">
                        <el-select @change="age_ends(ruleForm.age_end)" placeholder="请选择" style="width: 350px;"
                                   v-model="ruleForm.age_end">
                            <el-option :key="index" :label="items.name" :value="items.name"
                                       v-for="(items, index) in arrage_end"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-form-item>

            <el-form-item label="选手生日范围" required>
                <el-col :span="11">
                    <el-form-item prop="age_date_start">
                        <el-date-picker placeholder="请选择开始时间" style="width: 100%;" type="date"
                                        v-model="ruleForm.age_date_start" value-format="yyyy-MM-dd"></el-date-picker>
                    </el-form-item>
                </el-col>
                <el-col :span="2" class="line">至</el-col>
                <el-col :span="11">
                    <el-form-item prop="age_date_end">
                        <el-date-picker placeholder="请选择结束时间" style="width: 100%;" type="date"
                                        v-model="ruleForm.age_date_end" value-format="yyyy-MM-dd"></el-date-picker>
                    </el-form-item>
                </el-col>
            </el-form-item>


            <el-form-item label="性别限制" prop="sex" required>
                <el-radio-group v-model="ruleForm.sex">
                    <el-radio :label="0">不限制</el-radio>
                    <el-radio :label="1">仅限男</el-radio>
                    <el-radio :label="2">仅限女</el-radio>
                </el-radio-group>
            </el-form-item>

            <el-form-item>
                <el-button @click="$emit('handleClose')">取 消</el-button>
                <el-button @click="submitForm('basketballRuleForm')" type="primary">保 存</el-button>
            </el-form-item>

        </el-form>

    </div>
</template>

<script>
    import * as frominit from './index';
    import Gender from './basketball-create-gender.vue';
    import define from '@/components/define/define';

    export default {
        name: 'basketball-create-team-form',
        props: {
            is_birthday: {
                type: Number,
                default: 1
            }
        },
        data() {
            //价格
            let price = (rule, value, callback) => {
                if (!value) {
                    callback(new Error('请输入大于0的金额(小数限制两位)'));
                } else {
                    if (define.money.test(value)) {
                        this.$set(this.ruleForm, 'price', value);
                        callback();
                    } else {
                        callback(new Error('您输入金额有误请检查(小数限制两位)'));
                    }
                }
            };
            //团队名额限制
            let limit = (rule, value, callback) => {
                if (!value) {
                    callback(new Error('请输入大于0整数'));
                } else {
                    if (/^[1-9]\d*$/.test(value)) {
                        if (value > 0) {
                            this.$set(this.ruleForm, 'limit', value);
                            callback();
                        } else {
                            callback(new Error('请输入大于0整数'));
                        }
                    } else {
                        callback(new Error('请输入大于0整数'));
                    }
                }
            };
            //团队队员数量限制
            let team_limit = (rule, value, callback) => {

                if (!value.num1) {
                    callback(new Error('请输入完整的限制条件！'));

                }
                if (value.where1 === '>' || value.where1 === '>=') {
                    if ((!value.num2) || ((value.num2 - value.num1) < 1)) {
                        callback(new Error('请输入第二个正确的限制条件！'));
                    } else {
                        callback();
                    }
                } else {
                    value.num2 = '';
                    value.where2 = '';
                    callback();
                }

            };

            return {
                ruleForm: {
                    key: Date.now(),
                    visible: false,
                    team_limit_json: {
                        where1: '>',
                        num1: '',
                        where2: '<',
                        num2: '',
                        type: 0
                    },
                },
                datainit: [],
                arrage_end: [],
                rules: {
                    name: [{required: true, message: '请输入组别名称!', trigger: 'blur'}],
                    price_type: [{required: true, message: '请选择价格类型!', trigger: 'blur'}],
                    price: [{required: true, validator: price, trigger: 'change'}],
                    limit: [{required: true, validator: limit, trigger: 'change'}],
                    team_limit_json: [{required: true, validator: team_limit, trigger: 'blur'}],
                    age_start: [{required: true, message: '请选择年龄!', trigger: 'change'}],
                    age_end: [{required: true, message: '请选择年龄!', trigger: 'change'}],
                    age_date_start: [{required: true, message: '请选择开始时间!', trigger: 'blur'}],
                    age_date_end: [{required: true, message: '请选择结束时间!', trigger: 'blur'}],
                    sex: [{required: true, message: '请选择性别限制!', trigger: 'blur'}],

                }
            };
        },
        mounted() {
            this.datainit = frominit.default.datainit;
            this.arrage_end = frominit.default.datainit;
        },
        components: {
            Gender
        },
        methods: {
            ageval(data) {
                this.$set(this.ruleForm, 'age_end', '');
                this.$set(this.ruleForm, 'age_date_start', '');
                this.$set(this.ruleForm, 'age_date_end', '');
                this.datainit = frominit.default.datainit;
                this.arrage_end = frominit.default.datainit;
                let indexs = this.datainit.findIndex(item => item.name == data);
                let inarr = [];
                for (let i = 0; i < this.datainit.length; i++) {
                    if (i > indexs) {
                        inarr.push(this.arrage_end[i]);
                    }
                }
                this.arrage_end = inarr;
            },
            age_ends(data) {
                if (sessionStorage['match_time']) {
                    let match_time = JSON.parse(sessionStorage['match_time']);//要有赛事创建时间才可以
                    let starts = '';
                    let endtiem = '';
                    if (!!this.ruleForm.age_start) {
                        this.datainit.forEach(item => {
                            if (item.name == data) {
                                let age_date_start = define.getPreMonthDay(define.year(match_time), item.index * 12);
                                if (this.is_birthday == 1) {
                                    starts = define.year(define.gettate(age_date_start) + 24 * 3600 * 1000);
                                } else {
                                    starts = age_date_start;
                                }
                                console.log('starts', starts);
                                this.$set(this.ruleForm, 'age_date_start', starts);
                            }
                            if (item.name == this.ruleForm.age_start) {
                                let age_date_end = define.getPreMonthDay(define.year(match_time), item.index * 12);
                                if (this.is_birthday == 1) {
                                    endtiem = age_date_end;
                                } else {
                                    endtiem = define.year(define.gettate(age_date_end) - 24 * 3600 * 1000);
                                }

                                this.$set(this.ruleForm, 'age_date_end', endtiem);
                            }
                        });
                    }
                }
            },
            submitForm(formName) {
                this.ruleForm.team_limit = this.ruleForm.limit;//写死这个给后台
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.$emit('handleClose', this.ruleForm);
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },

        }
    };
</script>

<style lang="less" scoped>
    .initmians {
        width: 100%;
    }

    .line {
        display: flex;
        justify-content: center;
    }

    .mianlist {
        width: 100%;
        height: 100px;
        display: flex;
        align-items: center;

        .itelis {
            width: 100%;
            height: 50px;
            display: flex;
        }
    }

    .litiems {
        width: 100%;
        padding: 10px 0;
    }
</style>
