<template>
	<div class="initmian">
		<div class="inittip">
			<span>报名表单</span>
			<span>（点击组件可拖拽排序）</span>
		</div>
		<div class="mianlist">
			<div class="listleft">
				<div class="leftall">
					<div class="liitem">
						<div><el-checkbox disabled>必填</el-checkbox></div>
						<div>姓名</div>
					</div>
					<div class="liitem">
						<div><el-checkbox disabled>必填</el-checkbox></div>
						<div>性别</div>
					</div>
					<div class="liitem">
						<div><el-checkbox disabled>必填</el-checkbox></div>
						<div>出生日期</div>
					</div>
					<div class="liitem">
						<div><el-checkbox disabled>必填</el-checkbox></div>
						<div>证件类型、证件号码</div>
					</div>
					<div class="liitem">
						<div><el-checkbox disabled>必填</el-checkbox></div>
						<div>联系手机号</div>
					</div>
					<div class="limu">以上信息系统默认已收集，如需收集更多信息(请从右侧选择自定义组件)</div>
				</div>
				<div class="mianinit">
					<div v-for="(item, index) in datalist" :key="item.key" v-dragging="{ item: item, list: datalist, group: 'item' }">
						<component ref="miandata" :is="item.text" :key="item.key" :sign="item.text" :fromkey="item.key" @control="control"></component>
					</div>
				</div>
			</div>
			<div class="listrigth">
				<div class="titlie">自定义组件</div>
				<div class="miandli">
					<div class="miansleift" @click="addtitles">
						<i class="el-icon-fork-spoon"></i>
						<span>单行文本</span>
					</div>
					<div class="fotsli">
						<el-popover placement="left" width="300" offset="20" trigger="hover">
							<img src="./img/contacts.png" style="width: 300px;" />
							<span slot="reference">示例</span>
						</el-popover>
					</div>
				</div>
				<div class="miandli">
					<div class="miansleift" @click="addindividual">
						<i class="el-icon-fork-spoon"></i>
						<span>单项选择</span>
					</div>
					<div class="fotsli">
						<el-popover placement="left" width="300" offset="20" trigger="hover">
							<img src="./img/Competition.png" style="width: 300px;" />
							<span slot="reference">示例</span>
						</el-popover>
					</div>
				</div>
				<div class="miandli">
					<div class="miansleift" @click="adddrop">
						<i class="el-icon-fork-spoon"></i>
						<span>下拉框</span>
					</div>
					<div class="fotsli">
						<el-popover placement="left" width="300" offset="20" trigger="hover">
							<img src="./img/individual.png" style="width: 300px;" />
							<span slot="reference">示例</span>
						</el-popover>
					</div>
				</div>
				<div class="miandli">
					<div class="miansleift" @click="adduploads">
						<i class="el-icon-fork-spoon"></i>
						<span>上传图片</span>
					</div>
					<div class="fotsli">
						<el-popover placement="left" width="300" offset="20" trigger="hover">
							<img src="./img/updates.png" style="width: 300px;" />
							<span slot="reference">示例</span>
						</el-popover>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import titlekeys from './basketball-create-title.vue';
import uploads from './basketball-create-uploads.vue';
import individual from './basketball-create-individual.vue';
import dropdown from './basketball-create-dropdown.vue';
export default {
	name:'signup',
	data() {
		return {
			datalist: [],
			datakey: [],
			listinit: [],
			id: 1,
			getdatalist: [],
			inkey: 1
		};
	},
	mounted() {
		this.$dragging.$on('dragged', ({ value }) => {
			if (this.id != 1) {
				let arr = [];
				value.list.find(item => {
					arr.push(item.key);
				});
				this.listinit = value.list;
				let inimt = this.$refs.miandata;
				this.$nextTick(() => {
					inimt.sort((a, b) => {
						let mianintkey = arr.indexOf(a.fromkey);
						let next = arr.indexOf(b.fromkey);
						return mianintkey - next;
					});
				});
				this.datakey = inimt;
			}
		});
	},
	components: {
		titlekeys,
		uploads,
		individual,
		dropdown
	},
	methods: {
		getsiunp() {
			if (this.$route.query.match_id) {
				if (this.inkey === 1) {
					this.inkey += 1;
					this.datakey = this.$store.state.match.form;
					if(this.datakey.length>0){
						this.datakey.map((item, index) => {
							this.datalist.push({ text: item.sign, key: index });
						});
						this.$nextTick(()=>{
							this.$refs.miandata.map((item,index)=>{
								this.datakey.map((jitm,jindex)=>{
									if(jindex==index){
										if(typeof jitm.must==="string"){
											this.$set(jitm,'must',JSON.parse(jitm.must))
										}
										if(jitm.list){
											if(jitm.list.length>0){
												jitm.list.forEach(ktem=>{
													for (let inits in ktem) {
														if(inits=="visible"){
															if(typeof ktem['visible']==="string"){
																this.$set(ktem,'visible',JSON.parse(ktem['visible']))
															}
														}
													}
												})
											}
										}
										item.domian=jitm
									}
								})
							})
						})
					}
				}
			}
		},
		control(item) {
			this.id += 1;
			this.datakey.map((items, indexs) => {
				if (items.fromkey == item) {
					this.datakey.splice(indexs, 1);
				}
			});

			this.datalist.map((items, indexs) => {
				if (items.key == item) {
					this.datalist.splice(indexs, 1);
				}
			});
		},
		addtitles() {
			this.id += 1;
			this.datalist.push({ text: 'titlekeys', key: Date.now() });
			this.$nextTick(() => {
				this.datakey = this.$refs.miandata;
			});
		},
		addindividual() {
			this.id += 1;
			this.datalist.push({ text: 'individual', key: Date.now() });
			this.$nextTick(() => {
				this.datakey = this.$refs.miandata;
			});
		},
		adddrop() {
			this.id += 1;
			this.datalist.push({ text: 'dropdown', key: Date.now() });
			this.$nextTick(() => {
				this.datakey = this.$refs.miandata;
			});
		},
		adduploads() {
			this.id += 1;
			this.datalist.push({ text: 'uploads', key: Date.now() });
			this.$nextTick(() => {
				this.datakey = this.$refs.miandata;
			});
		}
	}
};
</script>

<style lang="less" scoped>
.initmian {
	width: 100%;
	min-width: 1300px;
	.mianlist {
		width: 86%;
		padding: 0 5% 5% 9%;
		display: flex;
		.listleft {
			width: calc(100% - 288px);
			padding-right: 18px;

			.leftall {
				width: 100%;
				font-size: 14px;
				color: #333333;
				.liitem {
					margin-top: 3px;
					display: flex;
					align-items: center;
					height: 20px;
					div {
						&:nth-child(2) {
							margin-left: 12px;
							line-height: 19px;
						}
					}
				}
				.limu {
					width: 100%;
					height: 45px;
					font-size: 16px;
					display: flex;
					align-items: flex-end;
				}
			}
		}
		.listrigth {
			width: 268px;
			height: 240px;
			border: 1px dashed #c8c8c8;
			color: #333333;
			.titlie {
				padding: 18px 0 0 10px;
			}
			.miandli {
				margin-top: 8px;
				padding: 0 18px 0 10px;
				display: flex;
				font-size: 14px;
				.miansleift {
					width: 80%;
					padding: 8px 0;
					border: 1px solid #e5e5e5;
					cursor: pointer;
					display: flex;
					justify-content: center;
					align-items: center;
					user-select: none;
					span {
						margin-left: 8px;
					}
				}
				.fotsli {
					width: 20%;
					color: #3861db;
					display: flex;
					justify-content: center;
					align-items: center;
					cursor: pointer;
				}
			}
		}
	}
	.inittip {
		padding: 20px 0 20px 40px;
		span {
			&:nth-child(1) {
				font-size: 14px;
				color: #333333;
				font-weight: bold;
			}
			&:nth-child(2) {
				color: #666666;
				font-size: 12px;
			}
		}
	}
}
</style>
