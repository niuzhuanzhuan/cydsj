<template>
	<div class="page-main">
		<el-form class="club-form" ref="clubForm" :model="formData" label-position="left" label-width="150px" status-icon>
			<el-form-item label="选择创建类别" prop="play_type_id">
				<el-select class="form-select" v-model="formData.play_type_id" placeholder="请选择俱乐部类别">
					<el-option v-for="(item,index) of typeSelector" :key="index" :label="item.name" :value="item.value"></el-option>
				</el-select>
			</el-form-item>
			<el-form-item label="俱乐部管理人" prop="mobile" :rules="[{required:true,message:'管理人手机号不能为空'}]">
				<el-input v-model="formData.mobile" placeholder="请输入管理人手机号码"></el-input>
			</el-form-item>
			<!-- <el-form-item label="获取验证码">
				<el-col :span="14">
					<el-input v-model="formData.code" placeholder="请输入验证码"></el-input>
				</el-col>
				<el-col class="btn-field" :span="10">
					<el-button class="code-btn"  type="primary" plain @click="sendCode" :disabled="!canISend">{{codeText}}</el-button>
				</el-col>
			</el-form-item> -->
			<el-form-item label="俱乐部名称（选填）">
				<el-input v-model="formData.club_name" type="textarea" maxlength="20" show-word-limit placeholder="请输入俱乐部名称"></el-input>
			</el-form-item>
			<el-form-item label="上传logo（选填）">
				<image-uploader
					:width="84"
					:height="84"
					title="LOGO"
					:limit="['400*400']"
					:size="2"
					square="提示：建议尺寸400*400，图片小于2M"
					:imageUrl.sync="formData.image"
				></image-uploader>
			</el-form-item>
			<div class="club-submit" @click="submitData">{{btnText}}</div>
		</el-form>

	</div>
</template>

<script>
	import imageUploader from '@/components/BaseComponents/imageUploader.vue'
	
	export default {
		components:{
			imageUploader
		},
		data() {
			return {
				btnText:'立即添加',
				typeSelector:[],
				formData: {
					id:'',
					club_name: '',
					play_type_id: '',
					mobile: '',
					image: '',
				},
			}
		},
		async mounted() {
			await this.$api.clubApi({
				type:'getPlayType',
			}).then(res => {
				// console.log(res);
				if(res.code === 1){
					this.typeSelector = res.data.map(dt => ({name:dt.name,value:dt.id}));
				}
			})
			const query = this.$route.query;
			if(query.id !== undefined){
				this.$api.clubApi({
					type:'detail',
					id:query.id,
				}).then(res => {
					// console.log(res);
					if(res.code === 1){
						this.formData = res.data;
						this.btnText = '保存修改'
					}
				})
			}
		},
		methods: {
			// 提交数据
			submitData() {
				this.$refs['clubForm'].validate(valid => {
					// console.log(this.formData);
					if(valid){
						this.$api.clubApi(Object.assign({type:'save'},this.formData)).then(res => {
							if(res.code === 1){
								this.$message({message: '添加成功',type: 'success'});
								this.$router.back();
							}
						});
					}
				});
			}
		}
	}
</script>

<style lang="less" scoped>
	* {
		box-sizing: border-box;
	}

	.page-main {
		width: 100%;
		height: 100%;
		background-color: white;
		padding-top: 200px;
	}

	.club-form {
		width: 500px;
		padding: 0 20px;
		margin: 0 auto;
		
		.form-select{
			width: 100%;
		}

		.club-submit {
			width: 100%;
			height: 40px;
			line-height: 40px;
			border-radius: 4px;
			background-color: #3861DB;
			color: white;
			text-align: center;
			cursor: pointer;
			transition: background-color .3s;

			&:hover {
				background-color: #3f70f8;
			}
		}
	}
</style>
