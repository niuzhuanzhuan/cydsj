<template>
	<div class="page-main">
		<el-button type="primary" class="new-btn" @click="toAdd">添加</el-button>
		<el-table 
			class="export-table" 
			:data="tableData" 
			:header-cell-style="{ 'background-color': '#FAFAFA','font-size':'14px' }"
		>
			<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
			
			<el-table-column fixed prop="image" label="俱乐部logo" width="150" align="center">
				<template slot-scope="scope">
					<img class="table-img" v-if="scope.row.image !== ''" :src="scope.row.image" />
					<P v-else></P>
				</template>
			</el-table-column>
			<el-table-column prop="club_name" label="俱乐部名称" align="center"></el-table-column>
			<el-table-column prop="name" label="俱乐部类型" align="center"></el-table-column>
			<el-table-column prop="mobile" label="俱乐部管理人" align="center"></el-table-column>
			<el-table-column fixed="right" label="操作" width="200" align="center">
				<template slot-scope="scope">
					<el-button type="text" size="small" @click="toEdit(scope.row)">编辑</el-button>
					<span class="table-cutline">|</span>
					<el-button slot="reference" class="del-btn" type="text" size="small" @click="delItem(scope.row)">删除</el-button>
				</template>
			</el-table-column>
		</el-table>
		<self-pagination ref="pagination" class="page-bar" :total="tableTotal" @pageChange="pageChange"></self-pagination>
	</div>
</template>

<script>
import selfPagination from '@/components/BaseComponents/Pagination.vue';

export default {
	components: {
		selfPagination
	},
	data() {
		return {
			tableData: [],
			tableTotal: 0,
		};
	},
	mounted() {
		// 加载第一页
		this.$refs.pagination.goTo(1);
	},
	methods: {
		pageChange(params) {
			this.$api.clubApi({
				type:'list',
				...params,
			}).then(res => {
				if(res.code === 1){
					this.tableData = res.data.data;
					this.tableTotal = res.data.total;
				}
			})
		},
		delItem(item) {
			this.$confirm(`确定删除${item.club_name}账号吗？删除后该账号不再存在！`, '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				this.$api.clubApi({
					type:'delete',
					id:item.id,
				}).then(res => {
					if(res.code === 1){
						this.$message({ message: '删除成功', type: 'success' });
						this.$refs.pagination.refresh();
					}
				})
			}).catch(() =>{
				
			})
		},
		toAdd(){
			this.$router.push({ path:'/club/edit' });
		},
		toEdit(item) {
			this.$router.push({ 
				path:'/club/edit',
				query:{id:item.id,},
			});
		}
	}
};
</script>

<style lang="less" scoped>

* {
	box-sizing: border-box;
}
.page-main {
	// min-height: 100%;
	height: 100%;
	padding: 10px 20px 20px;
}
.export-table {
	min-height: calc(100% - 76px);
	margin-bottom: 10px;
}
.page-bar{
	text-align: right;
}
.table-img {
	width: 54px;
	height: 54px;
	border-radius: 27px;
}
.new-btn{
	width: 120px;
	margin-bottom: 10px;
	font-size: 16px;
	background-color: #3861DB;
}
.table-cutline{
	margin: 0 5px;
}

.el-button--text{
	color: #3861DB;
}
.del-btn{
	color: red;
	transition: color .3s;
	
	&:hover{
		color: orangered;
	}
}
</style>
