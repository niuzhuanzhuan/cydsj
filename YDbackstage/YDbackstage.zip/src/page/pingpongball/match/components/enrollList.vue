<template>
	<div class="component-main">
		<!-- 上方统计信息 -->
		<div class="total-bar">
			<div class="title">汇总信息</div>
			<div class="total-line">
				<total-box label="已报名人数" alt="说明说明" >{{data.sign_total_num}}</total-box>
				<total-box label="总名额" alt="说明说明" >{{data.total_num}}</total-box>
				<total-box label="老用户回头率" alt="说明说明" >{{data.old_user}}<span>%</span></total-box>
				<total-box label="已收报名费" alt="说明说明" >￥{{data.sign_total_price}}</total-box>
				<total-box label="渠道费" alt="说明说明" >￥{{data.sign_total_price_hand}}</total-box>
			</div>
		</div>
		<!-- 只使用el-tab组件的样式和切换效果 -->
		<el-tabs v-model="groupKey" @tab-click="groupChange">
			<el-tab-pane :label="`全部(${data.sign_total_num})`" :name="`user_team`"></el-tab-pane>
			<el-tab-pane v-for="gp of data.group" :key="gp.key" :label="gp.group_name + `(${gp.limit_num})`" :name="gp.key"></el-tab-pane>
		</el-tabs>
		
		<div class="group-body">
			<!-- 筛选 -->
			<enroll-search-bar ref="searchBar" @search="searchOrder"></enroll-search-bar>
			<!-- 订单列表 -->
			<el-table
				class="enroll-table"
				:data="tableData"
				:header-cell-style="{'background-color':'#FAFAFA','text-align':'center'}"
				:cell-style="{'text-align':'center'}"
			>
				<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
				
			    <el-table-column  prop="out_trade_no" label="订单编号" width="200"></el-table-column>
			    <el-table-column  prop="user_name" label="参赛者姓名" width="100"></el-table-column>
			    <el-table-column prop="sex" label="性别" width="60"></el-table-column>
			    <el-table-column prop="id_card_type" label="证件类型" ></el-table-column>
			    <el-table-column prop="id_card" label="参赛者证件号码" ></el-table-column>
			    <el-table-column prop="birthday" label="出生日期" width="90"></el-table-column>
				<el-table-column prop="phone" label="手机号" ></el-table-column>
				<el-table-column prop="name" label="组别名称" ></el-table-column>
				<el-table-column prop="price" label="报名费(元)" ></el-table-column>
				
				<el-table-column  prop="state" label="订单状态" width="100">
					<template slot-scope="scope"> <p>{{orderStateMap.get(scope.row.state)}} </p> </template>
				</el-table-column>
				<el-table-column  prop="update_time" label="支付时间" width="90"></el-table-column>
			    <el-table-column  label="操作" width="100">
					<template slot-scope="scope">
						<el-button type="text" size="small" @click="openOrderInfo(scope.row)">详情</el-button>
						<span>|</span>
						<el-popconfirm
						  title="确定退款？"
						  @onConfirm="refund(scope.row)"
						>
						  <el-button slot="reference" type="text" size="small">退款</el-button>
						</el-popconfirm>
					</template>
				</el-table-column>
			</el-table>
			<self-pagination ref="pagination" class="page-bar" :total="enrollTotal" @pageChange="pageChange"></self-pagination>
		</div>
		
		<!-- 侧边订单详情抽屉 -->
		<el-drawer
			title="订单详情"
			:visible.sync="showDrawer"
			custom-class="order-drawer"
			size="50%"
		>
			<div class="order-drawer__content">
				<div class="od-field">
					<div class="od-title">基本信息</div>
					<div class="od-content">
						<p><span>订单编号：</span>{{orderInfo.order.out_trade_no}}</p>
						<p><span>支付时间：</span>{{orderInfo.order.update_time}}</p>
						<p><span>报名费：</span>{{orderInfo.order.price}}</p>
						<p><span>订单状态：</span>{{orderStateMap.get(orderInfo.order.state)}}</p>
						<!-- 个人报名 -->
						<template v-if="orderInfo.user_type === 1">
							<p><span>参赛者姓名：</span>{{orderInfo.car_user.user_name}}</p>
							<p><span>性别：</span>{{orderInfo.car_user.sex}}</p>
							<p><span>证件类型：</span>{{orderInfo.car_user.id_card_type}}</p>
							<p><span>参赛者证件号码：</span>{{orderInfo.car_user.id_card}}</p>
						</template>
						<!-- 团队报名 -->
						<p v-else><span>代报人姓名：</span>{{orderInfo.car_user.user_name}}</p>
					</div>
				</div>
				<div class="od-field">
					<div class="od-title">分组管理</div>
					<div class="od-content">
						<p><span>组别名称：</span>{{orderInfo.group_name}}</p>
					</div>
				</div>
				<div class="od-field">
					<div class="od-title">退款信息</div>
					<div class="od-content">
						<p><span>退款金额：</span>{{orderInfo.refund.price}}</p>
						<p><span>退款状态：</span>{{orderInfo.refund.state}}</p>
						<p><span>退款申请时间：</span>{{orderInfo.refund.create_time}}</p>
					</div>
				</div>
				<div class="od-field" v-if="orderInfo.user_type !== 1">
					<div class="od-title">团队信息</div>
					<div class="od-content">
						<template v-for="(item,idx) of orderInfo.car_team">
							<p><span>成员{{idx + 1}}：</span>{{item.user_name}}</p>
							<p><span>手机号：</span>{{item.phone}}</p>
							<p><span>证件类型：</span>{{item.id_card_type}}</p>
							<p><span>参赛者证件号码：</span>{{item.id_card}}</p>
							<p><span>出生日期：</span>{{item.birthday}}</p>
							<p><span>性别：</span>{{item.sex}}</p>
							<div class="_divider"></div>
						</template>
					</div>
				</div>
				<div class="od-field">
					<div class="od-title">自定义字段</div>
					<div class="od-content">
						<p v-for="(field,idx) of orderInfo.order.detail">
							<span>{{field.name}}：</span>
							<img class="od-inline-img" v-if="field.type === 'image'" :src="field.content" />
							<template v-else >{{field.content}}</template>
								
						</p>
					</div>
				</div>
				<div class="od-field">
					<div class="od-title">备注信息</div>
					<div class="od-content od-remark">
						<p>
							<span>备注：</span>
							<el-input class="od-input" type="textarea" v-model="orderInfo.order.remarks" :autosize="{ minRows: 4, maxRows: 6}" placeholder="请输入备注" ></el-input>
						</p>
					</div>
				</div>
		  </div>
		  <div class="order-drawer__footer">
		        <el-button @click="showDrawer = false">取消</el-button>
		        <el-button type="primary" @click="saveRemark">确定</el-button>
		      </div>
		</el-drawer>
		
	</div>
</template>

<script>
	import totalBox from './totalBox.vue'
	import enrollSearchBar from './enrollSearchBar.vue'
	import selfPagination from '@/components/BaseComponents/Pagination.vue'
	
	export default {
		components:{
			totalBox,
			enrollSearchBar,
			selfPagination
		},
		props:['data'],
		data(){
			return {
				groupKey:'0',
				tableData:[],
				enrollTotal:0,
				showDrawer:false,
				// 订单列表自定义字段类型
				orderTableDivField:[],
				// 订单状态map
				orderStateMap:new Map([
					[1,'成功'],
					[6,'退款中'],
					[7,'退款成功'],
					[8,'退款失败'],
				]),
				// 筛选条件
				searchData:{
					out_trade_no:'',
					user_name:'',
					sex:'',
					id_card:'',
					phone:'',
					state:'',
				},
				// 当前订单id
				orderId:'',
				// 当前订单详情
				orderInfo:{
					car_team: [],
					car_user: {},
					group_name: "",
					order: {
						detail:[]
					},
					refund: {price: "", state: "", create_time: ""},
					user_type: 1,
				},
			}
		},
		watch: {
			data(newValue, oldValue) {
				if(newValue.group !== undefined && newValue.group.length !== 0){
					this.groupKey = 'user_team';
					this.$refs.pagination.goTo(1);
				}
			}
		},
		methods:{
			// 切换分组
			groupChange(tab,par){
				this.$refs.searchBar.reset();
			},
			// 触发搜索
			searchOrder(params){
				this.searchData = params;
				this.$refs.pagination.goTo(1);
			},
			// 切换分页
			pageChange(params){
				this.$api.pingPongMatchGroupList({
					id:this.data.id,
					key:this.groupKey,
					...params,
					...this.searchData,
				}).then(res => {
					// 获取 统一的 自定义字段名称与类型
					if(res.data.total !== 0){
						let detail = res.data.data[0].detail;
						this.orderTableDivField = detail.map(dt => ({name:dt.name,type:dt.type}));
						// 处理数据中的自定义字段值
						this.tableData = res.data.data.map(dt => Object.assign({},dt,{
							detail:dt.detail.map(it => it.content)
						}));
						this.enrollTotal = res.data.total;
					}else{
						this.tableData = [];
						this.enrollTotal = 0;
					}
				})
			},
			/**
			 * @description 打开订单详情
			 * @param {Object} item
			 */
			openOrderInfo(item){
				// console.log(item);
				this.$api.getpingPongMatchOrderDetail({id:item.id}).then(res => {
					if(res.code === 1){
						this.orderId = item.id
						let tempOrderInfo = res.data
						// 处理 自定义字段的值
						// console.log(res.data);
						// tempOrderInfo.order.detail = tempOrderInfo.order.detail.map(dt => dt.content)
						// console.log(tempOrderInfo)
						this.orderInfo = tempOrderInfo;
						this.showDrawer = true;
					}
				})
			},
			// 发起退款
			refund(item){
				this.$api.pingPongMatchRefundOrder({id:item.id}).then(res => {
					if(res.code === 1){
						this.$message({ message: '已申请退款，审核中', type: 'success' });
						this.$refs.pagination.refresh();
					}else{
						
					}
				})
			},
			// 保存订单备注
			saveRemark(){
				this.$api.getpingPongMatchOrderDetail({
					id:this.orderId,
					remarks:this.orderInfo.order.remarks,
				}).then(res => {
					if(res.code === 1){
						this.$message({ message: '订单备注保存成功', type: 'success' });
						this.showDrawer = false;
					}
				})
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	
	/deep/ :focus {
	    outline: 0;
	  }
	
	.el-button--text{
		color: #3861DB;
	}
	.el-button--primary{
		background-color: #3861DB;
	}
	.component-main{
		
	}
	// 分页
	.page-bar{
		margin-top: 10px;
		text-align: right;
	}
	// 顶部统计栏
	.total-bar{
		border: 1px solid #E4E7ED;
		padding: 20px;
		
		.total-line{
			height: 60px;
			line-height: 30px;
			display: flex;
			justify-content: space-between;
		}
	}
	// 报名订单表
	.enroll-table{
		margin-top: 20px;
		
		.enroll-thead{
			background-color: #FBFBFB;
		}
		
		.table-inline-img{
			width: 60px;
			height: 60px;
			object-fit: contain;
		}
	}
	// 侧边抽屉
	.order-drawer{
		.order-drawer__content{
			height: calc(100vh - 140px);
			overflow-y: scroll;
			padding: 0 20px;
			border-top: solid 1px #DCDCDC;
			
			.od-title{
				height: 50px;
				line-height: 50px;
				font-size: 16px;
			}
			
			.od-content{
				display: flex;
				flex-wrap: wrap;
				justify-content: space-between;
				
				p{
					display: inline-flex;
					flex-wrap: wrap;
					align-items: center;
					width: calc(50% - 5px);
					margin-bottom: 10px;
					font-size: 14px;
					color: #999999;
					
					span{
						color: #333333;
					}
				}
				._divider{
					width: 100%;
					height: 1px;
					background-color: #dcdfe6;
					margin-bottom: 10px;
					
					&:last-of-type{
						display: none;
					}
				}
			}
			.od-inline-img{
				width: 80px;
				height: 80px;
				object-fit: contain;
			}
			
			.od-remark{
				p{
					width: 100%;
					display: inline-flex;
					
					span{
						flex-shrink: 0;
					}
				}
			}
			
		}
		.order-drawer__footer{
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 60px;
			padding: 0 20px;
			border-top: solid 1px #DCDCDC;
			
			.el-button{
				width: calc(50% - 10px);
			}
		}
	}
	
</style>
