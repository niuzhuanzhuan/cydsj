<template>
	<div class="page-main">
		<!-- 顶部赛事信息栏 -->
		<marchTableRow :data="data">
			<el-popconfirm title="确定导出参赛名单？" @onConfirm="exportEnrollList">
				<el-link slot="reference" class="match-link" type="primary">导出报名列表</el-link>
			</el-popconfirm>
			<el-button class="match-btn edit-btn" size="mini" @click="toEdit">编辑赛事</el-button>
		</marchTableRow>
		<!-- tab 分栏 -->
		<el-tabs class="tab-line" v-model="activeName" type="card">
			<el-tab-pane label="赛事概览" name="detail"><match-detail :data="data"></match-detail></el-tab-pane>
			<el-tab-pane label="报名列表" name="list"><enroll-list :data="data"></enroll-list></el-tab-pane>
		</el-tabs>
	</div>
</template>

<script>
import marchTableRow from './components/matchTableRow.vue';
import matchDetail from './components/matchDetail.vue';
import enrollList from './components/enrollList.vue';

export default {
	components: {
		marchTableRow,
		matchDetail,
		enrollList
	},
	data() {
		return {
			activeName: 'detail',
			data: {
				share_url: ''
			},
			match_id: 1
		};
	},
	async created() {
		const query = this.$route.query;
		this.match_id = query.match_id;
		let res = await this.$api.pingPongMatchDetail({ id: this.match_id });
		if (res.code === 1) {
			this.data = res.data;
			this.activeName = 'detail';
		}
	},
	methods: {
		/**
		 * 导出报名列表
		 */
		exportEnrollList() {
			this.$api.pingPongMatchDownFile({ match_id: this.match_id }).then(res => {
				if (res.code === 1) {
					this.$confirm('请到导出记录里下载', '导出成功', {
						confirmButtonText: '立即进入',
						cancelButtonText: '取消',
						type: 'success',
						center: true,
						confirmButtonClass: 'spec-pop-btn'
					})
					.then(() => {
						this.$router.push({ path: '/pingpongball_export' });
					})
					.catch(() => {});
				}
			});
		},
		toEdit() {
			this.$router.push({ path: '/pingpongball_edit', query: { match_id: this.match_id } });
		}
	}
};
</script>

<style>
.spec-pop-btn {
	background-color: #3861db;
}
</style>

<style lang="less" scoped>
* {
	box-sizing: border-box;
}

.page-main {
	min-height: 100%;
}

.el-link {
	color: #3861db;
}
.tab-line {
	background-color: white;
	padding: 20px;
}

.match-link {
	font-size: 14px;
}

.match-btn {
	margin: 0;
	color: white;

	&.edit-btn {
		background-color: #ff696a;
	}
}
</style>
