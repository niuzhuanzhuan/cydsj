<template>
	<div class="mianall" v-cloak ref="tops">
		<div class="minav">
			<el-form :model="ruleForm" :rules="rules" ref="ruleForm" class="fruleForm" label-width="230px">
				<template>
					<div class="mianitem">
						<el-form-item label="羽毛球赛制:" prop="format">
							<el-select class="demo-ruleForm" style="width: 43.75rem;" v-model="ruleForm.format" placeholder="请选择乒乓球赛制" >
								<el-option label="杯赛" value="1"></el-option>
								<el-option label="联赛" value="2"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="赛事名称:" prop="title">
							<el-input class="demo-ruleForm" style="width: 43.75rem;" v-model="ruleForm.title" placeholder="请输入赛事名称"></el-input>
						</el-form-item>
						<el-form-item label="赛事咨询电话:" prop="phone">
							<el-input class="demo-ruleForm" style="width: 43.75rem;" v-model="ruleForm.phone" placeholder="请输入赛事咨询电话"></el-input>
						</el-form-item>
						<el-form-item label="报名时间:" required>
							<template>
								<div class="froall">
									<div style="width: 43.75rem;display: flex;justify-content: space-between;">
										<el-col :span="11">
											<el-form-item prop="sign_start_time">
												<el-date-picker
													type="datetime"
													value-format="yyyy-MM-dd HH:mm:ss"
													placeholder="报名开始时间"
													v-model="ruleForm.sign_start_time"
													style="width: 100%;"
													:disabled="signtimeinit"
												></el-date-picker>
											</el-form-item>
										</el-col>
										<el-col :span="11">
											<el-form-item prop="sign_end_time">
												<el-date-picker
													type="datetime"
													value-format="yyyy-MM-dd HH:mm:ss"
													placeholder="报名结束时间"
													v-model="ruleForm.sign_end_time"
													style="width: 100%;"
													:disabled="signtimeinit"
												></el-date-picker>
											</el-form-item>
										</el-col>
									</div>
									<div class="fonsts">
										<i class="el-icon-warning-outline"></i>
										报名开始前3小时内不能修改
									</div>
								</div>
							</template>
						</el-form-item>
						<el-form-item label="赛事时间:" required>
							<template>
								<div class="froall">
									<div style="width: 43.75rem;display: flex;justify-content: space-between;">
										<el-col :span="11">
											<el-form-item prop="match_start_time">
												<el-date-picker
													type="datetime"
													value-format="yyyy-MM-dd HH:mm:ss"
													placeholder="请选择赛事开始时间"
													v-model="ruleForm.match_start_time"
													style="width: 100%;"
													:disabled="matchtimeinit"
												></el-date-picker>
											</el-form-item>
										</el-col>
										<el-col :span="11">
											<el-form-item prop="match_end_time">
												<el-date-picker
													type="datetime"
													value-format="yyyy-MM-dd HH:mm:ss"
													placeholder="请选择赛事结束时间"
													v-model="ruleForm.match_end_time"
													style="width: 100%;"
													:disabled="matchtimeinit"
												></el-date-picker>
											</el-form-item>
										</el-col>
									</div>
									<div class="fonsts">
										<i class="el-icon-warning-outline"></i>
										报名开始前3小时内不能修改
									</div>
								</div>
							</template>
						</el-form-item>
						<el-form-item label="赛事地址:" prop="detail">
							<el-input
								class="demo-ruleForm"
								style="width: 43.75rem;"
								v-model="ruleForm.detail"
								placeholder="点击设置主办方地址"
								readonly
								@click.native="address"
							></el-input>
						</el-form-item>
						<el-form-item label="赛事海报:" prop="image">
							<upload :height="106" :square="'提示：建议长宽比1.75：1，图片小于4M'" :size="4" :width="246" :definition="1" :imageUrl.sync="ruleForm.image" />
						</el-form-item>

						<el-form-item label="是否允许退款:" required>
							<template>
								<div class="froall">
									<div>
										<el-radio-group v-model="ruleForm.is_back">
											<el-radio :label="1">支持</el-radio>
											<el-radio :label="0">不支持</el-radio>
										</el-radio-group>
									</div>
									<div class="fonsts" style="width: 408px;">
										<i class="el-icon-warning-outline"></i>
										注意：赛事发布后不允许修改：此设置尽在参赛报名是展示说明 参赛者不能再小程序中主动申请退款，如需退款需联系主办方处理
									</div>
								</div>
							</template>
						</el-form-item>
						<el-form-item label=" " prop="back_desc">
							<template>
								<div>
									<el-input
										class="demo-ruleForm"
										type="textarea"
										style="width: 43.75rem;"
										rows="8"
										placeholder="请输入退款说明"
										v-model="ruleForm.back_desc"
									></el-input>
								</div>
								<div class="fonsts">
									<i class="el-icon-warning-outline"></i>
									案例：1、一旦报名成功后，不允许取消，不予退赛，若因个人原因或其他不可控因素无法按时参赛者，报名费不退还
									<br />
									2、报名通道开启后24小时内(xxx年xx月xx日xx点- -xxx年xx月xx日xx点) 如有特殊情况，可以退费。过期一律不予退费
									<br />
									3、报名成功后，24小时内无条件退款;超过24小时不支持退款
									<br />
									4、如赛事出现不可控原因，赛事将会延期举办，报名费不退回;所有视为放弃、中止、取消资格、禁止参加等终止的行为，报名费一概不退还
									<br />
									5、个人组/团队组一旦报名成功后，不允退款;若因参赛人数不足导致对应组取消赛事，将退还报名费
								</div>
							</template>
						</el-form-item>
						<el-form-item label="赛事简介:" prop="desc">
							<el-input class="demo-ruleForm" type="textarea" style="width: 43.75rem;" rows="8" placeholder="请输入赛事简介" v-model="ruleForm.desc"></el-input>
						</el-form-item>
					</div>
				</template>
				<div class="mianboont"></div>
				<template>
					<div class="initmian">
						<div class="inittip">
							<span>普通分组列表</span>
							<span>（点击分组可拖拽排序）</span>
						</div>
						<div class="initall">
							<div class="allfonts">
								<el-form-item label="报名时是否强制校验年龄:" required>
									<template>
										<div class="froalls">
											<div>
												<el-radio-group v-model="ruleForm.is_age">
													<el-radio :label="1">是</el-radio>
													<el-radio :label="0">否</el-radio>
												</el-radio-group>
											</div>
											<div class="fonsts1">
												<i class="el-icon-warning-outline"></i>
												强制校验：选手报名只能选择符合自己年龄段的组别；不强制校验：选手可以选择任意组别。
												<br />
												<span style="color: #333333;font-size: 14px;font-weight: bold;margin-left: 28px;">
													注意：请确保每组选手出生日期范围设置无误，避免强制校验后无法正常报名
												</span>
											</div>
										</div>
									</template>
								</el-form-item>
								<el-form-item label="是否支持低年龄段报名高年龄段:" required>
									<template>
										<div class="froalls">
											<div>
												<el-radio-group v-model="ruleForm.is_small_age">
													<el-radio :label="1">支持</el-radio>
													<el-radio :label="0">不支持</el-radio>
												</el-radio-group>
											</div>
											<div class="fonsts1">
												<i class="el-icon-warning-outline"></i>
												强制校验：选手报名只能选择符合自己年龄段的组别；不强制校验：选手可以选择任意组别。
												<br />
												<span style="color: #333333;font-size: 14px;font-weight: bold; margin-left: 28px;">
													注意：请确保每组选手出生日期范围设置无误，避免强制校验后无法正常报名
												</span>
											</div>
										</div>
									</template>
								</el-form-item>
								<el-form-item label="是否隐藏已报名人数:" required>
									<template>
										<div class="froalls">
											<div>
												<el-radio-group v-model="ruleForm.is_hide_sign">
													<el-radio :label="1">显示</el-radio>
													<el-radio :label="0">隐藏</el-radio>
												</el-radio-group>
											</div>
											<div class="fonsts1">
												<i class="el-icon-warning-outline"></i>
												隐藏报名人数：参赛选手看不到分组总名额数和剩余报名人数
											</div>
										</div>
									</template>
								</el-form-item>
								<el-form-item label="生日当天是否升组:" required>
									<template>
										<div class="froalls">
											<div>
												<el-radio-group v-model="ruleForm.is_birthday">
													<el-radio :label="1">升组</el-radio>
													<el-radio :label="0">不升组</el-radio>
												</el-radio-group>
											</div>
											<div class="fonsts1">
												<i class="el-icon-warning-outline"></i>
												注意：跨多天的赛事请自行调整报名年龄范围
											</div>
										</div>
									</template>
								</el-form-item>
								<el-form-item label="快速生成分组:"><el-switch v-model="ruleForm.delivery"></el-switch></el-form-item>
							</div>
						</div>
					</div>
				</template>
				<template v-if="designate == 1">
					<ordinary ref="ordinarys" :is_birthday="ruleForm.is_birthday" />
				</template>
				<div class="mianboont"></div>
				<template v-if="designate == 1">
					<team ref="teams" :is_birthday="ruleForm.is_birthday" />
				</template>
				<div class="mianboont" v-if="designate == 1"></div>
				<template v-if="designate == 1">
					<signup ref="signups" />
				</template>
				<div class="mianboont" v-if="designate == 1"></div>
				<template>
					<match ref="matchs" />
				</template>
				<template>
					<div class="bonts" v-if="designate == 1">
						<div>
							<el-button @click="generate('ruleForm', 5)">保存草稿</el-button>
							<el-button @click="generate('ruleForm', 6)">预览并生成赛事码</el-button>
							<el-button @click="generate('ruleForm', 4)" type="primary">发布赛事</el-button>
						</div>
					</div>
					<div v-else><el-button type="primary" @click="modify('ruleForm')">确认修改</el-button></div>
				</template>
			</el-form>
		</div>

		<div v-if="showMarkMap">
			<el-dialog :visible="true" title="活动地址" :show-close="false" :close-on-click-modal="false" append-to-body>
				<div class="map-container"><amap ref="amaps" :froms="ruleForm" /></div>

				<div slot="footer" class="map-footer">
					<el-button @click="handleClose(0)">取消</el-button>
					<el-button type="primary" @click="handleClose(1)">确定</el-button>
				</div>
			</el-dialog>
		</div>
	</div>
</template>

<script>
import amap from '@/components/custom/amap.vue';
import upload from '@/components/BaseComponents/imageUploader.vue';
import ordinary from './components/ordinary.vue';
import team from './components/team.vue';
import match from './components/match.vue';
import signup from './components/signup.vue';
import bus from '@/components/common/bus';
import define from '@/components/define/define';
import { mapActions } from 'vuex';
let timestamp = Date.parse(new Date());
export default {
	name: 'establish',
	props: {
		designate: {
			type: Number,
			default: 1
		}
	},
	data() {
		let start = ''; //报名开始时间
		let endtime = ''; //报名结束时间
		let matchtime = ''; //赛事开始时间
		let phone = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入赛事咨询电话!'));
			} else {
				let isPhone = /^([0-9]{3,4}-)?[0-9]{7,8}$/;
				if (define.phone.test(value) || isPhone.test(value)) {
					callback();
				} else {
					callback(new Error('请输入正确的电话号码!'));
				}
			}
		};
		let starttime = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请选择报名开始时间!'));
			} else {
				start = this.gettate(value);
				if (timestamp > start) {
					callback(new Error('报名时间不能小于当前时间!'));
				} else {
					callback();
				}
			}
		};
		let signtime = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请选择报名结束时间!'));
			} else {
				endtime = this.gettate(value);
				if (endtime < start + 3600 * 1000) {
					callback(new Error('报名结束时间不能小于等于报名开始时间,且区间最少为一个小时!'));
					return false;
				}
				if (!!this.ruleForm.sign_start_time) {
					callback();
				} else {
					callback(new Error('请选择报名开始时间!'));
				}
			}
		};

		let matchstarttime = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请选择赛事开始时间!'));
			} else {
				if (!this.ruleForm.sign_start_time && !this.ruleForm.sign_end_time) {
					callback(new Error('请先选择赛事报名开始时间和报名结束时间!'));
				} else {
					matchtime = this.gettate(value);
					if (matchtime < endtime) {
						callback(new Error('赛事开始时间不能小于报名结束时间'));
					} else {
						callback();
					}
				}
			}
		};

		let matchendtime = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请选择赛事结束时间!'));
			} else {
				if (!this.ruleForm.match_start_time) {
					callback(new Error('请先选择赛事开始时间!'));
				} else {
					let matchend = this.gettate(value);
					if (matchtime + 3600 * 1000 > matchend) {
						callback(new Error('赛事结束时间不能小于赛事开始时间，且区间最少为一个小时!'));
					} else {
						callback();
					}
				}
			}
		};
		return {
			inindex: 1,
			checked: false,
			showMarkMap: false,
			signtimeinit: false,
			matchtimeinit: false,
			ruleForm: {
				is_age: 1,
				is_small_age: 0,
				is_hide_sign: 0,
				is_birthday: 1,
				is_back: 0
			},
			rules: {
				format: [{ required: true, message: '请选着一个赛制!', trigger: 'change' }],
				title: [{ required: true, message: '请输入赛事名称!', trigger: 'blur' }],
				phone: [{ required: true, validator: phone, trigger: 'change' }],
				sign_start_time: [{ required: true, validator: starttime, trigger: 'blur' }],
				sign_end_time: [{ required: true, validator: signtime, trigger: 'change' }],
				match_start_time: [{ required: true, validator: matchstarttime, trigger: 'change' }],
				match_end_time: [{ required: true, validator: matchendtime, trigger: 'change' }],
				detail: [{ required: true, message: '请设置赛事地址!', trigger: 'change' }],
				image: [{ required: true, message: '请上传赛事海报图片!', trigger: 'blur' }],
				back_desc: [{ required: true, message: '请输入退款说明!', trigger: 'blur' }],
				desc: [{ required: true, message: '请输入赛事简介!', trigger: 'blur' }]
			}
		};
	},
	components: {
		upload,
		ordinary,
		team,
		match,
		signup,
		amap
	},
	created() {
		sessionStorage.removeItem('match_time');
		sessionStorage.removeItem('is_birthday');
		if (this.$route.query.match_id) {
			this.setdata(this.$route.query.match_id);
		}
		if(!!this.ruleForm.match_start_time){
			let match_time = this.gettate(this.ruleForm.match_start_time);
			sessionStorage['match_time'] = match_time;
		}
	},
	activated() {
		sessionStorage.removeItem('match_time');
		sessionStorage.removeItem('is_birthday');
		if(!!this.ruleForm.match_start_time){
			let match_time = this.gettate(this.ruleForm.match_start_time);
			sessionStorage['match_time'] = match_time;
		}
	},
	watch: {
		'ruleForm.sign_start_time'(newval, val) {
			if (!!newval) {
				if (this.designate != 1) {
					let sign_time = this.gettate(newval);
					if (sign_time < timestamp) {
						this.signtimeinit = true;
					} else if (sign_time < timestamp - 1800 * 1000) {
						this.signtimeinit = true;
					}
				}
			}
		},
		'ruleForm.match_start_time'(newval, val) {
			if (!!newval) {
				let match_time = this.gettate(newval);
				sessionStorage['match_time'] = match_time;
				sessionStorage['is_birthday'] = this.ruleForm.is_birthday;
				if (this.designate != 1) {
					if (match_time < timestamp) {
						this.matchtimeinit = true;
					} else if (match_time < timestamp - 1800 * 1000) {
						this.matchtimeinit = true;
					}
				}
			}
		},
		'ruleForm.is_birthday'(newval, val) {
			sessionStorage['is_birthday'] = newval;
		}
	},
	methods: {
		gettate(data) {
			let datas = new Date(data);
			let times = datas.getTime();
			return times;
		},
		...mapActions(['set_match']),
		async setdata(data) {
			const datalist = await this.$api.getpingPongMatchDetail({ id: data });
			if (datalist) {
				this.ruleForm = datalist.data;
				this.ruleForm.format = this.ruleForm.format.toString()
				this.set_match(this.ruleForm);
				this.$nextTick(() => {
					if (this.designate === 1) {
						let arr = [];
						this.ruleForm.team_group.forEach(item => {
							if (typeof item.total_age == 'string') {
								if (!item.total_age) {
									item.total_age = 0;
								} else {
									item.total_age = JSON.parse(item.total_age);
								}
							}

							if (typeof item.total_age_json == 'string') {
								item.total_age_json = JSON.parse(item.total_age_json);
								if (typeof item.total_age_json == 'string') {
									item.total_age_json = JSON.parse(item.total_age_json);
								}
							}
							if (typeof item.sex == 'string') {
								if (!item.sex) {
									item.sex = 0;
								} else {
									item.sex = JSON.parse(item.sex);
								}
							}
							if (typeof item.sex_json == 'string') {
								item.sex_json = JSON.parse(item.sex_json);
								if (typeof item.sex_json == 'string') {
									item.sex_json = JSON.parse(item.sex_json);
								}
								if (item.sex_json != '') {
									item.sex_json.forEach(jitem => {
										jitem.visible = JSON.parse(jitem.visible);
										jitem.key = Number.parseInt(jitem.key);
										jitem.age = jitem.age != '' ? Number.parseInt(jitem.age) : '';
										jitem.num = jitem.num != '' ? Number.parseInt(jitem.num) : '';
									});
								}
							}
						});
						this.$refs.teams.datalist = this.ruleForm.team_group;
						this.$refs.ordinarys.datalist = this.ruleForm.user_group;
						this.$refs.signups.getsiunp();
					}
					this.$refs.matchs.$refs.ues.values = this.ruleForm.content;
				});
			}
		},
		address(data) {
			this.showMarkMap = true;
		},
		handleClose(data) {
			if (data == 1) {
				this.$nextTick(() => {
					for (let i in this.$refs.amaps.mapfrom) {
						this.$set(this.ruleForm, i, this.$refs.amaps.mapfrom[i]);
					}
				});
			}
			this.showMarkMap = false;
		},
		generate(data, val) {
			let datalist = [];
			let user_group = [];
			let team_group = [];
			this.$set(this.ruleForm, 'state', val);
			let adopt = true;
			this.$refs[data].validate(async valid => {
				if (valid) {
					user_group = this.$refs.ordinarys.datalist;
					datalist = this.$refs.signups.datakey;
					team_group = this.$refs.teams.datalist;
					if (user_group.length == 0 && team_group.length == 0) {
						this.$message.warning('检测到您的普通分组，及团队分组都为空程序不允许通过，温馨提示二者必须存在一个有值');
						return false;
					}
					if (user_group.length > 0) {
						user_group.forEach(item => {
							for (let init in item) {
								if (init != 'create_time' && init != 'update_time' && init != 'is_del' && init != 'sex') {
									if (item[init] == '') {
										this.$message.warning('检查到您的普通分组列表有未填项，系统不允许通过，请检查！');
										adopt = false;
									}
								}
							}
						});
					}
					let fromdata = [];
					if (datalist.length > 0) {
						if (datalist[0].name) {
							for (let i = 0; i < datalist.length; i++) {
								if (datalist[i].name == '') {
									this.$message.warning('检查到您添加得组件中标题未填写，程序不允许通过，请检查');
									adopt = false;
								}
								if (datalist[i].placeholder == '') {
									this.$message.warning('检查到您添加得组件中标题信息未填写，程序不允许通过，请检查');
									adopt = false;
								}
								if (datalist[i].list) {
									if (datalist[i].list.length > 0) {
										for (let j = 0; j < datalist[i].list.length; j++) {
											if (datalist[i].list[j].value == '') {
												this.$message.warning('检查到您添加得组件中单选项或下拉选项存在添加为填写，程序不允许通过，请检查');
												adopt = false;
											}
										}
									}
								}
							}
						} else {
							datalist.map(item => {
								fromdata.push(item.domian);
							});
							for (let i = 0; i < fromdata.length; i++) {
								if (fromdata[i].name == '') {
									this.$message.warning('检查到您添加得组件中标题未填写，程序不允许通过，请检查');
									adopt = false;
								}
								if (fromdata[i].placeholder == '') {
									this.$message.warning('检查到您添加得组件中标题信息未填写，程序不允许通过，请检查');
									adopt = false;
								}
								if (fromdata[i].list) {
									if (fromdata[i].list.length > 0) {
										for (let j = 0; j < fromdata[i].list.length; j++) {
											if (fromdata[i].list[j].value == '') {
												this.$message.warning('检查到您添加得组件中单选项或下拉选项存在添加未填写，程序不允许通过，请检查');
												adopt = false;
											}
										}
									}
								}
							}
							datalist = fromdata;
						}
					}

					if (adopt) {
						this.$set(this.ruleForm, 'user_group', user_group);
						this.$set(this.ruleForm, 'team_group', team_group);
						this.$set(this.ruleForm, 'form', datalist);
						if (!this.$refs.matchs.$refs.ues.values) {
							this.$message.warning('赛事详情不能为空,请检查');
							return false;
						} else {
							this.$set(this.ruleForm, 'content', this.$refs.matchs.$refs.ues.values);
						}
						if (this.$route.query.match_id) {
							delete this.ruleForm.id;
						}
						const datacom = await this.$api.pingPongMatch(this.ruleForm);
						if (datacom) {
							this.$message.success(datacom.msg);
							this.$router.push('/pingpongball_list');
							sessionStorage.removeItem('match_time');
							sessionStorage.removeItem('is_birthday');
						}
					}
				} else {
					bus.$emit('srrtop');
				}
			});
		},
		modify(data) {
			this.$confirm(`您确定修改当前赛事信息吗?`, '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			})
				.then(() => {
					this.$set(this.ruleForm, 'state', 4);
					this.$set(this.ruleForm, 'type', 'info');
					this.$refs[data].validate(valid => {
						if (valid) {
							this.$set(this.ruleForm, 'content', this.$refs.matchs.$refs.ues.values);
							this.$nextTick(async () => {
								delete this.ruleForm.user_group;
								delete this.ruleForm.team_group;
								delete this.ruleForm.form;
								this.$set(this.ruleForm, 'content', this.$refs.matchs.$refs.ues.values);

								const datacom = await this.$api.updatepingPongMatch(this.ruleForm);
								if (datacom) {
									this.$message.success(datacom.msg);
									sessionStorage.removeItem('match_time');
									sessionStorage.removeItem('is_birthday');
									this.$router.push('/pingpongball_list');
								}
							});
						} else {
							bus.$emit('srrtop');
						}
					});
				})
				.catch(() => {});
		}
	}
};
</script>
<style scoped lang="less">
i {
	color: #3861db;
}
.bonts {
	width: 100%;
	padding: 20px 0 50px 0;
	div {
		&:nth-child(1) {
			display: flex;
			align-items: center;
			justify-content: center;
			height: 60px;
		}
	}
}
.mianall {
	clear: both;
	width: 100%;
	min-width: 1300px;
	display: flex;
	height: auto;
	overflow-x: hidden;
	align-items: flex-end;
	.minav {
		width: calc(100% - 40px);
		background: #ffffff;
		padding: 20px;
		.fruleForm {
			width: 100%;
			display: flex;
			flex-direction: column;
			align-items: center;
			padding-bottom: 50px;
			.mianitem {
				width: 90%;
			}
			.mianboont {
				width: 100%;
				border: 1px dashed #e8e8e8;
			}
			.initmian {
				width: calc(100%);
				padding: 20px 0 0 0;
				.inittip {
					padding: 20px 0 20px 40px;
					span {
						&:nth-child(1) {
							font-size: 14px;
							color: #333333;
							font-weight: bold;
						}
						&:nth-child(2) {
							color: #666666;
							font-size: 12px;
						}
					}
				}
				.initall {
					width: 100%;
					display: flex;
					justify-content: center;
					.allfonts {
						width: 80%;
					}
				}
			}
		}
	}
}
.froall {
	width: 100%;
	display: flex;
}
.froalls {
	width: 100%;
	display: flex;
	justify-content: flex-start;
	div {
		&:nth-child(1) {
			width: 20%;
			display: flex;
			padding-top: 5px;
		}
		&:nth-child(2) {
			width: 80%;
		}
	}
}
.fonsts {
	color: #666666;
	margin-left: 5px;
}
.fonsts1 {
	color: #666666;
	margin-left: 40px;
}
</style>
<style>
.el-input--small .el-input__inner {
	height: 38px !important;
	line-height: 38px !important;
}
</style>
