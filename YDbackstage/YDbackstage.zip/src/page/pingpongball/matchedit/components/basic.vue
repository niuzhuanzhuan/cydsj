<template>
	<div>
		<establishs :designate="0"/>
	</div>
</template>

<script>
	import establishs from '@/page/pingpongball/establish/pingpongball-establish.vue'
	export default{
		components:{
			establishs
		}
	}
</script>

<style>
</style>
