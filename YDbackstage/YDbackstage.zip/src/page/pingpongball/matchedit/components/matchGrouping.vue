<template>
	<div class="limst">
		<div class="inittip">
			<span>普通分组列表</span>
			<span>（点击分组可拖拽排序）</span>
		</div>
		<div class="inmiand">
			<div class="litow1">组别名称</div>
			<div class="litow1">出生日期范围</div>
			<div class="lithere">性别限制</div>
			<div class="lithere">价格(元)</div>
			<div class="lithere">名额</div>
			<div class="lithere">显示状态</div>
			<div class="lithere">报名状态</div>
			<div class="litow">操作</div>
		</div>
		<div class="incont" v-for="(item, index) in grouarr" v-dragging="{ item: item, list: grouarr, group: 'item' }" :key="index.id">
			<div class="litow1">{{ item.name }}</div>
			<div class="litow1">{{ item.age_date_start }}{{ item.age_date_start ? '~' : '' }}{{ item.age_date_end }}</div>
			<div class="lithere">{{ item.sex_text }}</div>
			<div class="lithere">{{ item.price }}</div>
			<div class="lithere">{{ item.limit }}</div>
			<div class="lithere">
				<span :class="item.is_show === 1 ? 'uses' : 'err'"><div></div></span>
				{{ item.is_show_text }}
			</div>
			<div class="lithere">
				<span :class="item.is_start === 1 ? 'uses' : 'err'"><div></div></span>
				{{ item.is_start_text }}
			</div>
			<div class="litow">
				<el-button type="text" style="font-size: 16px;" @click="gupedt(1, item)">编辑</el-button>
				<span class="link"><span class="lins"></span></span>
				<el-button type="text" style="font-size: 16px;" @click="ishide(1, item.id, item.is_show)">{{ item.is_show == 2 ? '显示该组' : '隐藏该组' }}</el-button>
				<span class="link"><span class="lins"></span></span>
				<el-button type="text" style="font-size: 16px;" @click="isopen(1, item.id, item.is_start)">{{ item.is_start == 1 ? '停止报名' : '开启报名' }}</el-button>
				<span class="link"><span class="lins"></span></span>
				<el-button type="text" style="font-size: 16px;" @click="delects(1, item)">删除</el-button>
			</div>
		</div>
		<div class="mianingtop" v-if="grouarr.length == 0"><img src="../../establish/components/img/init.png" /></div>
		<div class="mianfert">
			<div class="lingbonmt"><el-button type="primary" @click="addDomain(1)" icon="el-icon-plus" style="background-color: #3861DB;font-size: 16px;">添加分组</el-button></div>
		</div>
		<div class="imling"></div>
		<div class="inittip">
			<span>团队赛分组列表</span>
			<span>（点击分组可拖拽排序）</span>
		</div>
		<div class="inmiand">
			<div class="is8">组别名称</div>
			<div class="is8">团队名额</div>
			<div class="is10">每队成员人数</div>
			<div class="litow1">单个选手生日范围</div>
			<div class="is8">性别限制</div>
			<div class="is8">价格(元)</div>
			<div class="is8">名额</div>
			<div class="is8">显示状态</div>
			<div class="is8">报名状态</div>
			<div class="limamian">操作</div>
		</div>
		<div class="incont" v-for="(item, index) in datalist" v-dragging="{ item: item, list: datalist, group: 'item' }" :key="index">
			<div class="is8">{{ item.name }}</div>
			<div class="is8">{{ item.limit }}</div>
			<div class="minslis">{{team_limit(item.total_age_json.where1,item.total_age_json.num1)}}<br/>{{team_limit(item.total_age_json.where2,item.total_age_json.num2)}}</div>
			<div class="litow1">{{ item.age_date_start }}{{ item.age_date_start ? '~' : '' }}{{ item.age_date_end }}</div>
			<div class="is8">{{ item.sex == 0 ? '不限制' : item.sex == 1 ? '仅男性' : '仅女性' }}</div>
			<div class="is8">{{ item.price }}</div>
			<div class="is8">{{ item.limit }}</div>
			<div class="is8">
				<span :class="item.is_show == 1 ? 'uses' : 'err'"><div></div></span>
				{{ item.is_show_text }}
			</div>
			<div class="is8">
				<span :class="item.is_start == 1 ? 'uses' : 'err'"><div></div></span>
				{{ item.is_start_text }}
			</div>
			<div class="limamian">
				<el-button type="text" style="font-size: 16px;" @click="gupedt(2, item)">编辑</el-button>
				<span class="link"><span class="lins"></span></span>
				<el-button type="text" style="font-size: 16px;" @click="ishide(2, item.id, item.is_show)">{{ item.is_show == 2 ? '显示该组' : '隐藏该组' }}</el-button>
				<span class="link"><span class="lins"></span></span>
				<el-button type="text" style="font-size: 16px;" @click="isopen(2, item.id, item.is_start)">{{ item.is_start == 1 ? '停止报名' : '开启报名' }}</el-button>
				<span class="link"><span class="lins"></span></span>
				<el-button type="text" style="font-size: 16px;" @click="delects(2, item)">删除</el-button>
			</div>
		</div>
		<div class="mianingtop" v-if="datalist.length == 0"><img src="../../establish/components/img/init.png" /></div>
		<div class="mianfert">
			<div class="lingbonmt">
				<el-button type="primary" @click="addDomain(2)" icon="el-icon-plus" style="background-color: #3861DB;font-size: 16px;">添加团队分组</el-button>
			</div>
		</div>
		<el-dialog :title="title" :visible.sync="dialogVisible" :close-on-click-modal="false" width="1000px" :before-close="handleClose" :destroy-on-close="true">
			<groufrom @handleClose="handleClose" :is_birthday="is_birthday" ref="groufroms" v-show="numkey == 1" />
			<matchfrom @handleClose="handleClose" :is_birthday="is_birthday" v-show="numkey != 1" ref="matchfroms" />
		</el-dialog>
	</div>
</template>

<script>
import groufrom from './groufrom.vue';
import matchfrom from '@/page/pingpongball/establish/components/teamfrom';
export default {
	name: 'matchGrouping',
	props: {
		is_birthday: {
			type: Number,
			default: 1
		}
	},
	data() {
		return {
			numkey: 1,
			title: '',
			datalist: [],
			grouarr: [],
			dialogVisible: false
		};
	},
	components: {
		groufrom,
		matchfrom
	},
	created() {
		this.dialogVisible = true;
		this.$nextTick(() => {
			this.dialogVisible = false;
		});
		this.getteam();
	},
	mounted() {
		this.$dragging.$on('dragged', ({ value }) => {});
	},
	methods: {
		async isopen(data, val, is_start) {
			let fromdata = {};
			if (is_start == 1) {
				is_start = 2;
			} else {
				is_start = 1;
			}
			this.$set(fromdata, 'match_id', this.$route.query.match_id);
			this.$set(fromdata, 'type', 'save');
			this.$set(fromdata, 'group_type', data);
			this.$set(fromdata, 'id', val);
			this.$set(fromdata, 'is_start', is_start);
			const grouarrs = await this.$api.pingPongMatchGroup(fromdata);
			if (grouarrs) {
				this.$message.success(grouarrs.msg);
				this.getteam();
			}
		},
		async ishide(data, val, is_show) {
			let fromdata = {};
			if (is_show == 1) {
				is_show = 2;
			} else {
				is_show = 1;
			}
			this.$set(fromdata, 'match_id', this.$route.query.match_id);
			this.$set(fromdata, 'type', 'save');
			this.$set(fromdata, 'group_type', data);
			this.$set(fromdata, 'id', val);
			this.$set(fromdata, 'is_show', is_show);
			const grouarrs = await this.$api.pingPongMatchGroup(fromdata);
			if (grouarrs) {
				this.$message.success(grouarrs.msg);
				this.getteam();
			}
		},
		delects(data, val) {
			this.$confirm(`您确定要删除当前${data == 1 ? '普通分组' : '团队分组'}里组别名称为 “${val.name}” 的这条数据吗?`, '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			})
				.then(async () => {
					let froms = {};
					this.$set(froms, 'match_id', this.$route.query.match_id);
					this.$set(froms, 'type', 'delete');
					this.$set(froms, 'group_type', data);
					this.$set(froms, 'id', val.id);
					const grouarrs = await this.$api.pingPongMatchGroup(froms);
					if (grouarrs) {
						this.$message.success(grouarrs.msg);
						this.getteam();
					}
				})
				.catch(() => {});
		},
		gupedt(data, item) {
			this.numkey = data;
			if (data == 1) {
				this.title = '修改分组';
				this.$refs.groufroms.ruleForm = item;
			} else {
				this.title = '修改团队';
				this.$nextTick(() => {
					if (typeof item.total_age == 'string') {
						if (!item.total_age) {
							item.total_age = 0;
						} else {
							item.total_age = JSON.parse(item.total_age);
						}
					}

					if (typeof item.total_age_json == 'string') {
						item.total_age_json = JSON.parse(item.total_age_json);
						if (typeof item.total_age_json == 'string') {
							item.total_age_json = JSON.parse(item.total_age_json);
						}
					}
					
					if (typeof item.sex == 'string') {
						if (!item.sex) {
							item.sex = 0;
						} else {
							item.sex = JSON.parse(item.sex);
						}
					}
					// let arrs = [];
					// if (typeof item.sex_json == 'string') {
					// 	if (item.sex_json != '') {
					// 		item.sex_json = JSON.parse(item.sex_json);
					// 		arrs = item.sex_json.map(item => {
					// 			item.visible = JSON.parse(item.visible);
					// 			item.key = Number.parseInt(item.key);
					// 			item.age = item.age != '' ? Number.parseInt(item.age) : '';
					// 			item.num = item.num != '' ? Number.parseInt(item.num) : '';
					// 			return item;
					// 		});
					// 		this.$refs.matchfroms.$refs.Genders.datalists = arrs;
					// 	}
					// }
					console.log(item)
					this.$refs.matchfroms.ruleForm = item;
				});
			}
			this.dialogVisible = true;
		},
		async handleClose(data) {
			this.getteam();
			if (typeof data == undefined || typeof data == 'function') {
				this.dialogVisible = false;
				return false;
			}
			if (data) {
				if (this.numkey == 1) {
					this.$set(data, 'match_id', this.$route.query.match_id);
					this.$set(data, 'type', 'save');
					this.$set(data, 'group_type', '1');
					const grouarrs = await this.$api.pingPongMatchGroup(data);
					if (grouarrs) {
						this.$message.success(grouarrs.msg);
						this.getteam();
					}
				} else {
					this.$set(data, 'match_id', this.$route.query.match_id);
					this.$set(data, 'type', 'save');
					this.$set(data, 'group_type', '2');
					// this.$set(data, 'sex_json', this.$refs.matchfroms.$refs.Genders.datalists);
					const dataarr = await this.$api.pingPongMatchGroup(data);
					if (dataarr) {
						this.$message.success(dataarr.msg);
						this.getteam();
					}
				}
			}
			this.dialogVisible = false;
		},
		async getteam() {
			const dataarr = await this.$api.pingPongMatchGroup({ match_id: this.$route.query.match_id, type: 'list' });
			if (dataarr) {
				this.grouarr = dataarr.data.user_group;

				this.datalist = dataarr.data.team_group;
				this.datalist.forEach(res => {
					res.total_age_json = JSON.parse(res.total_age_json)
				})
			}
		},
		addDomain(item) {
			item == 1 ? (this.title = '添加分组') : (this.title = '添加团队分组');
			this.numkey = item;
			this.dialogVisible = true;
		},
		team_limit(where1,num){
			let w={
				'>':'大于',
				'>=':'大于等于',
				'=':'等于',
				'<':'小于',
				'<=':'小于等于',
			}
			if(w[where1]){
				return "【队员数】 "+w[where1]+" "+num+" 人"
			}else{
				return ''
			}

		},
	}
};
</script>

<style scoped>
.limst >>> .el-dialog__body {
	padding: 20px;
}

.limst >>> .el-dialog {
	border-radius: 10px;
}
.limst >>> .el-dialog__header {
	border-bottom: 1px dashed #e8e8e8;
}
.limst >>> .el-dialog__title {
	font-size: 14px;
	font-weight: bold;
	color: #333333;
}
</style>
<style scoped lang="less">
.err {
	width: 4px;
	height: 4px;
	padding-right: 5px;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 4px;
		height: 4px;
		background: #f52e00;
		border-radius: 50%;
	}
}
.uses {
	width: 4px;
	height: 4px;
	padding-right: 5px;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 4px;
		height: 4px;
		background: #3861db;
		border-radius: 50%;
	}
}
.link {
	width: 10px;
	height: 12px;
	display: flex;
	justify-content: center;
}
.lins {
	width: 1px;
	height: 12px;
	background: #c8c8c8;
}
.imling {
	height: 1px;
	border-bottom: 1px dashed #e8e8e8;
}
.mianfert {
	width: 100%;
	height: 70px;
	.lingbonmt {
		width: 100%;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
}
.mianingtop {
	width: 100%;
	height: 200px;
	border-bottom: 1px solid #e8e8e8;
	display: flex;
	justify-content: center;
	align-items: center;
	img {
		width: 61px;
	}
}
.inittip {
	padding: 20px 0 10px 40px;
	span {
		&:nth-child(1) {
			font-size: 14px;
			color: #333333;
			font-weight: bold;
		}
		&:nth-child(2) {
			color: #666666;
			font-size: 12px;
		}
	}
}
.limst {
	padding-top: 6px;
	width: 100%;
	border-top: 1px #e8e8e8 dashed;
}
.incont {
	width: 100%;
	height: 56px;
	display: flex;
	cursor: pointer;
	&:hover {
		background: #e6f7ff;
	}
	div {
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #999999;
		user-select: none;
	}
	.is10 {
		width: 10%;
	}
	.is9 {
		width: 9%;
	}
	.is8 {
		width: 8%;
	}
	.limamian {
		width: 19%;
	}
	.litow1 {
		width: 15%;
	}
	.litow {
		width: 25%;
	}
	.lithere {
		width: 10%;
	}
	.limafour {
		width: 15%;
	}
}
.inmiand {
	width: 100%;
	height: 56px;
	background: #fafafa;
	border-bottom: 1px solid #e8e8e8;
	display: flex;
	div {
		user-select: none;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #333333;
	}
	.limamian {
		width: 19%;
	}
	.is10 {
		width: 10%;
	}
	.is9 {
		width: 9%;
	}
	.is8 {
		width: 8%;
	}
	.litow1 {
		width: 15%;
	}
	.litow {
		width: 25%;
	}
	.lithere {
		width: 10%;
	}
	.limafour {
		width: 15%;
	}
}
</style>
