<template>
	<div class="initmian">
		<el-table
			:data="tableData"
			height="452px"
			:header-cell-style="{
				'background-color': '#fafafa',
				color: '#333333',
				padding: '16px'
			}"
		>
			<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
			
			<el-table-column prop="out_trade_no" label="提现流水号" align="center"></el-table-column>
			<el-table-column prop="create_time" label="申请时间" align="center"></el-table-column>
			<el-table-column prop="price" label="提现金额（元）" align="center"></el-table-column>
			<el-table-column prop="bank_number" label="收款账户" align="center"></el-table-column>
			<el-table-column prop="state" label="状态" align="center">
				<template slot-scope="scope"> <p>{{orderStateMap.get(scope.row.state)}} </p> </template>
			</el-table-column>
		</el-table>
		<selfPagination ref="pagination" class="pages" :total="total" @pageChange="pageChange" />
	</div>
</template>

<script>
import selfPagination from '@/components/BaseComponents/Pagination.vue';
export default {
	data() {
		return {
			tableData: [],
			total:0,
			orderStateMap:new Map([
				[1,'提现成功'],
				[2,'提现失败'],
				[4,'处理中'],
			]),
		};
	},
	components: {
		selfPagination
	},
	mounted() {
		this.$refs.pagination.goTo(1);
	},
	methods: {
		refresh(){
			this.$refs.pagination.goTo(1);
		},
		pageChange(params) {
			this.$api.price({
				type: 2,
				...params,
			}).then(res => {
				if(res.code === 1){
					this.tableData = res.data.list.data;
					this.total = res.data.list.total;
				}
			});
		}
	},
};
</script>
<style scoped>
.initmian >>> .el-table__header {
	font-size: 14px;
	font-weight: 400 !important;
}
.initmian >>> .el-table__row {
	font-size: 14px;
	color: #999999;
}
</style>
<style scoped lang="less">
.initmian {
	width: 100%;
	height: 540px;
	.pages {
		margin-top: 6px;
		display: flex;
		justify-content: flex-end;
	}
}
</style>
