<template>
	<div class="initmians">
		<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px">
			<el-form-item label="可提现总额:">{{ company.income_balance }} 元</el-form-item>
			<el-form-item label="提现金额:" prop="price">
				<el-input style="width: 40rem;" placeholder="请输入体现金额(小数限制两位)" v-model="ruleForm.price"><span slot="append">元</span></el-input>
			</el-form-item>
			<el-form-item label="到账金额:">人民币 {{ ruleForm.prices }} 元</el-form-item>
			<el-form-item label="收款账户:">
				<template>
					<div class="mianlist">
						<div class="mianitem">
							<div>公司名称</div>
							<div>{{ company.company_name }}</div>
						</div>
						<div class="mianitem">
							<div>银行账号</div>
							<div>{{ company.bank_number }}</div>
						</div>
						<div class="mianitem">
							<div>开户行信息</div>
							<div>{{ company.bank_addr }}</div>
						</div>
						<div class="mianitem">
							<div>三证合一号</div>
							<div>{{ company.business_code }}</div>
						</div>
					</div>
				</template>
			</el-form-item>
			<el-form-item label="收款联系人:" prop="user_name">
				<el-input style="width: 40rem;" placeholder="请输入收款联系人姓名" v-model="ruleForm.user_name"></el-input>
			</el-form-item>
			<el-form-item label="管理员手机号:">
				<el-input style="width: 40rem;" placeholder="管理员手机号" disabled v-model="$store.state.initfromdata.mobile"></el-input>
			</el-form-item>
			<el-form-item label="短信验证码:" prop="code">
				<el-input style="width: 40rem;" placeholder="请输入短信验证码" v-model="ruleForm.code">
					<el-button slot="append" v-if="Decision" @click="send">{{ sends }}</el-button>
					<el-button slot="append" v-else>{{ sends }}</el-button>
				</el-input>
			</el-form-item>
		</el-form>
		<div slot="footer" class="dialog-footer">
			<el-button @click="$emit('handleClose')">取 消</el-button>
			<el-button type="primary" @click="submitForm('ruleForm')">保 存</el-button>
		</div>
	</div>
</template>

<script>
import define from '@/components/define/define';
export default {
	props: ['company'],
	data() {
		let price = (rule, value, callback) => {
			if (value === '') {
				this.$set(this.ruleForm, 'prices', 0);
				callback(new Error('提现的金额不能为空'));
			} else {
				if (define.money.test(value)) {
					if (value >= 100) {
						this.$set(this.ruleForm, 'prices', value);
						callback();
					} else {
						this.$set(this.ruleForm, 'prices', 0);
						callback(new Error('提现金额必须大于等于100元'));
					}
				} else {
					callback(new Error('您输入金额有误请检查(小数限制两位)'));
				}
			}
		};
		return {
			ruleForm: { prices: 0 },
			Decision: true,
			tcler: null,
			timeskey: 60,
			sends: '发送验证码',
			rules: {
				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }],
				price: [{ validator: price, trigger: 'change' }],
				code: [{ required: true, message: '请输入短信验证码', trigger: 'blur' }],
				user_name: [{ required: true, message: '请输入收款联系人姓名', trigger: 'blur' }]
			}
		};
	},
	mounted() {},
	methods: {
		submitForm(formName) {
			this.$refs[formName].validate(async valid => {
				if (valid) {
					const datalist=await this.$api.income(this.ruleForm)
					if(datalist){
						this.$message.success(datalist.msg)
						this.$emit('onWithdraw')
					}
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		async send() {
			const datalist = await this.$api.getVerify({ mobile: this.$store.state.initfromdata.mobile });
			if (datalist) {
				this.$message.success(datalist.msg);
				this.Decision = false;
				this.tcler = setInterval(() => {
					this.timeskey--;
					this.sends = `${this.timeskey--} 秒`;
					if (this.timeskey == 0) {
						clearInterval(this.tcler);
						this.Decision = true;
						this.timeskey = 60;
						this.sends = `发送验证码`;
					}
				}, 1000);
			}
		}
	}
};
</script>
<style scoped>
.initmians >>> .el-form-item__label {
	color: #333333;
}
.dialog-footer {
	margin-top: 50px;
	border-top: 1px solid #dcdcdc;
	padding: 30px 90px;
	display: flex;
	justify-content: flex-end;
}
</style>
<style lang="less" scoped>
.mianlist {
	width: 40rem;
	border: 1px solid #dcdcdc;
	border-bottom: none;
	.mianitem {
		width: 100%;
		height: 44px;
		border-bottom: 1px solid #dcdcdc;
		display: flex;
		div {
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 14px;
			height: 100%;
			color: rgba(0, 0, 0, 0.65);
			&:nth-child(1) {
				width: 150px;
				border-right: 1px solid #dcdcdc;
			}
			&:nth-child(2) {
				width: calc(100% - 151px);
			}
		}
	}
}
.minatiltle {
	width: calc(100% - 24px);
	padding-left: 24px;
	height: 46px;
	background: rgba(238, 64, 55, 0.1);
	border: 1px solid #ee4037;
	border-radius: 6px;
	display: flex;
	align-items: center;
	justify-content: flex-start;
	color: #333333;
	font-size: 14px !important;
	opacity: 0.8;
	margin-bottom: 20px;
}
.initmians {
	width: 100%;
}
.line {
	display: flex;
	justify-content: center;
}
</style>
