<template>
	<div class="mianlist">
		<div class="miantops">
			<div class="inittop" v-if="constmian">
				<el-row :gutter="20">
					<el-col :span="12">
						<div class="linsg">
							<div class="titles">订单编号：</div>
							<el-input v-model="order_no" placeholder="请输入订单编号"></el-input>
						</div>
					</el-col>
					<el-col :span="11" :offset="1">
						<div class="linsg">
							<div class="titles">支付时间：</div>
							<el-date-picker
								style="width: calc(100% - 120px);"
								v-model="date"
								type="daterange"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
								value-format="yyyy-MM-dd HH:mm:ss"
							></el-date-picker>
						</div>
					</el-col>
				</el-row>
			</div>
			<div class="mianbot">
				<el-button type="primary" style="background-color: #3861DB;font-size: 16px;" @click="search">搜索</el-button>
				<el-button style="font-size: 16px;" @click="reset">重置</el-button>
				<div class="mianlis">
					<el-button type="text" style="font-size: 16px;" @click="constmian = !constmian">收起</el-button>
					<i class="el-icon-arrow-up" v-if="constmian"></i>
					<i class="el-icon-arrow-down" v-else></i>
				</div>
			</div>
		</div>

		<el-table
			:data="tableData"
			:height="constmian ? '280px' : '344px'"
			:header-cell-style="{
				'background-color': '#fafafa',
				color: '#333333',
				padding: '16px'
			}"
		>
			<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
			
			<el-table-column prop="out_trade_no" label="流水号" align="center"></el-table-column>
			<el-table-column prop="name" label="交易说明" align="center"></el-table-column>
			<el-table-column prop="price" label="报名费(元)" align="center"></el-table-column>
			<el-table-column prop="service_price" label="通道费" align="center"></el-table-column>
			<el-table-column prop="income_price" label="入账金额" align="center"></el-table-column>
			<el-table-column prop="create_time" label="时间" align="center"></el-table-column>
		</el-table>
		<selfPagination ref="pagination" class="pages" :total="total" @pageChange="pageChange" />
	</div>
</template>

<script>
import selfPagination from '@/components/BaseComponents/Pagination.vue';
export default {
	data() {
		return {
			order_no: '',
			date: [],
			constmian: true,
			tableData: [],
			total:0,
		};
	},
	components: {
		selfPagination
	},
	mounted() {
		this.$refs.pagination.goTo(1);
	},
	methods: {
		search(){
			this.$refs.pagination.goTo(1);
		},
		reset(){
			this.order_no = '';
			this.date = [];
			this.$refs.pagination.goTo(1);
		},
		pageChange(params) {
			this.$api.clubPrice({
				type: 1,
				...params,
				out_trade_no: this.order_no,
				start_time:this.date[0],
				end_time: this.date[1],
			}).then(res => {
				if(res.code === 1){
					this.tableData = res.data.list.data;
					this.total = res.data.list.total;
				}
			});
			
		}
	},
};
</script>
<style scoped>
.mianlist >>> .el-dialog__body {
	padding: 20px;
}
.mianlist >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}
.mianlist >>> .el-dialog {
	border-radius: 10px;
}
.mianlist >>> .el-dialog__header {
	border-bottom: 1px dashed #e8e8e8;
}
.mianlist >>> .el-dialog__title {
	font-size: 14px;
	font-weight: bold;
	color: #333333;
}
</style>
<style scoped lang="less">
.pages {
	margin-top: 6px;
	display: flex;
	justify-content: flex-end;
}
.linsg {
	display: flex;
	justify-content: flex-start;
	height: 32px;
	.titles {
		width: 120px;
		height: 100%;
		display: flex;
		align-items: center;
		color: #333333;
		font-size: 14px;
	}
}
.mianlist {
	width: 100%;
	height: 540px;
	.miantops {
		border-radius: 6px;
		background: #fbfbfb;
		border: 1px solid #dcdcdc;
		width: calc(100% - 110px);
		padding: 30px 54px 50px 54px;
		.inittop {
			width: 100%;
			height: 64px;
		}
		.mianbot {
			width: 100%;
			height: 38px;
			display: flex;
			justify-content: flex-end;
			align-items: center;
			.mianlis {
				width: 80px;
				display: flex;
				justify-content: flex-end;
				align-items: center;
				color: #3861db;
				font-size: 14px;
				.el-icon-arrow-up {
					color: #3861db;
					font-size: 14px;
				}
				.el-icon-arrow-down {
					color: #3861db;
					font-size: 14px;
				}
			}
		}
	}
}
</style>
