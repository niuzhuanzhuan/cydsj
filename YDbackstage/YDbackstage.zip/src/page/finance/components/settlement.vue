<template>
	<div class="initmian">
		<el-table
			:data="tableData"
			height="452px"
			:header-cell-style="{
				'background-color': '#fafafa',
				color: '#333333',
				padding: '16px'
			}"
		>
			<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
			
			<el-table-column prop="out_trade_no" label="结算流水号" align="center"></el-table-column>
			<el-table-column prop="name" label="结算项目" align="center"></el-table-column>
			<el-table-column prop="create_time" label="结算时间" align="center"></el-table-column>
			<el-table-column prop="price" label="结算金额（元）" align="center"></el-table-column>
			<el-table-column prop="order_num" label="结算订单数（笔）" align="center"></el-table-column>
		</el-table>
		<selfPagination ref="pagination" class="pages" :total="total" @pageChange="pageChange" />
	</div>
</template>

<script>
import selfPagination from '@/components/BaseComponents/Pagination.vue';
export default {
	data() {
		return {
			tableData: [],
			total:0,
		};
	},
	components: {
		selfPagination
	},
	mounted() {
		this.$refs.pagination.goTo(1);
	},
	methods: {
		pageChange(params) {
			this.$api.price({
				type: 3,
				...params,
			}).then(res => {
				if(res.code === 1){
					this.tableData = res.data.list.data;
					this.total = res.data.list.total;
				}
			});
		}
	},
};
</script>
<style scoped>
.initmian >>> .el-table__header {
	font-size: 14px;
}
.initmian >>> .el-table__row {
	font-size: 14px;
	color: #999999;
}
</style>
<style scoped lang="less">
.initmian {
	width: 100%;
	height: 540px;
	.pages {
		margin-top: 6px;
		display: flex;
		justify-content: flex-end;
	}
}
</style>
