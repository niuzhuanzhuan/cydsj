<template>
	<div class="allmian">
		<div class="miantop">
			<el-row :gutter="20">
				<!-- <el-col :span="12">
					<el-card shadow="hover">
						<div class="limns">
							<div class="mians">
								<div class="mianitem">
									<div class="lisnfont">账户余额</div>
									<div class="linmsgfont f40">
										<span style="font-size: 30px;">￥</span>
										{{ fromdata.company.balance }}
									</div>
								</div>
							</div>
							<div class="mians">
								<div class="mianitem">
									<div class="lisnfont">可提现余额</div>
									<div class="linmsgfont f40">
										<span style="font-size: 30px;">￥</span>
										{{ fromdata.company.income_balance }}
									</div>
								</div>
							</div>
							<div class="mians"><el-button type="primary" @click="apply" style="background-color: #3861DB;font-size: 16px;">提现申请</el-button></div>
						</div>
					</el-card>
				</el-col> -->
				<el-col :span="24">
					<el-card shadow="hover">
						<div class="limns">
							<div class="mians">
								<div class="mianitem">
									<div class="lisnfont cn">总收入</div>
									<div class="linmsgfont cn f26">
										<span style="font-size: 16px;">￥</span>
										{{ fromdata.price.total_price }}
									</div>
								</div>
							</div>
							<div class="mians">
								<div class="mianitem">
									<div class="lisnfont cn">赛事收入</div>
									<div class="linmsgfont cn f26">
										<span style="font-size: 16px;">￥</span>
										{{ fromdata.price.match_price }}
									</div>
								</div>
							</div>
							<div class="mians">
								<div class="mianitem">
									<div class="lisnfont cn">培训收入</div>
									<div class="linmsgfont cn f26">
										<span style="font-size: 16px;">￥</span>
										{{ fromdata.price.train_price }}
									</div>
								</div>
							</div>
						</div>
					</el-card>
				</el-col>
			</el-row>
		</div>
		<div class="miancont">
			<el-tabs v-model="activeName" type="card">
				<el-tab-pane label="收支明细" name="1"><income /></el-tab-pane>
				<!-- <el-tab-pane label="提现记录" name="2"><withdrawal /></el-tab-pane>
				<el-tab-pane label="结算记录" name="3"><settlement /></el-tab-pane> -->
			</el-tabs>
		</div>

		<el-dialog title="提现申请" :visible.sync="dialogVisible" :modal="false" :close-on-click-modal="false" width="890px" :before-close="handleClose" :destroy-on-close="true">
			<applyfrom @handleClose="handleClose" :company="this.fromdata.company" />
		</el-dialog>
	</div>
</template>

<script>
import income from './components/clubIncome.vue';
// import Withdrawal from './components/Withdrawal.vue';
// import settlement from './components/settlement.vue';
// import applyfrom from './components/applyfrom.vue';
export default {
	data() {
		return {
			dialogVisible: false,
			activeName: '1',
			fromdata: {
				company: {},
				price: {}
			}
		};
	},
	components: {
		income,
		// Withdrawal,
		// settlement,
		// applyfrom
	},
	created() {
		this.getdata();
	},
	watch: {
		activeName(newval, val) {
			if (newval != val) {
				this.getdata();
			}
		}
	},
	methods: {
		async getdata() {
			const datalist = await this.$api.clubPrice({ type: this.activeName });
			console.log(datalist);
			datalist && (this.fromdata = datalist.data);
			// console.log(this.fromdata);
		},
		handleClose(data) {
			if (data == '2') {
				if (this.activeName == data) {
					this.getdata();
				} else {
					this.activeName = data;
				}
			}
			this.dialogVisible = false;
		},
		apply() {
			this.dialogVisible = true;
		}
	}
};
</script>
<style scoped>
.allmian >>> .el-dialog__body {
	padding: 20px;
}

.allmian >>> .el-dialog__header {
	border-bottom: 1px solid #e8e8e8;
}
.allmian >>> .el-dialog__title {
	font-size: 14px;
	font-weight: bold;
	color: #333333;
}
.allmian >>> .el-card__body {
	padding: 0;
}
.allmian >>> .el-tabs .el-tabs__header .el-tabs__nav-scroll {
	border-bottom: 1px solid #dcdcdc;
}
.allmian >>> .el-tabs--card > .el-tabs__header .el-tabs__nav {
	border-top: none;
}
.allmian >>> .el-tabs__item.is-active {
	background: #ffffff;
	color: #3861db;
}
.allmian >>> .el-tabs__item {
	font-size: 16px;
	color: #333333;
	background: #f2f2f2;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	border-top: 1px solid #dcdcdc;
}
.cn {
	display: flex;
	justify-content: center;
	align-items: center;
}
.f26 {
	font-size: 20px;
	/* font-weight: bold; */
}
.f40 {
	font-size: 24px;
	/* font-weight: bold; */
}
</style>
<style scoped lang="less">
.allmian {
	width: 100%;
	height: 100%;
	.miancont {
		width: calc(100% - 48px);
		height: calc(100% - 280px);
		padding: 15px 24px;
	}
	.miantop {
		width: calc(100% - 48px);
		height: 210px;
		background: #f4f4f4;
		padding: 20px 24px;
		.limns {
			width: 100%;
			height: 210px;
			display: flex;
			justify-content: center;
			.mians {
				width: 30%;
				height: 100%;
				display: flex;
				justify-content: center;
				align-items: center;
				.mianitem {
					width: 100%;
					height: 100px;
					display: flex;
					flex-direction: column;
					justify-content: space-around;
					.lisnfont {
						width: 100%;
						font-size: 20px;
						font-weight: 400;
						color: #1a1717;
					}
					.linmsgfont {
						color: #ff7e05;
					}
				}
			}
		}
	}
}
</style>
