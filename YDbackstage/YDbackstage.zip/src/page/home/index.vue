<template>
	<div class="page-main">
		<!-- 顶部信息栏 -->
		<div class="top-bar">
			<div class="header-box info-box">
				<img :src="company.image" class="info-logo" />
				<div class="info-content">
					<p>{{company.company_name}}</p>
					<p>超级管理员：{{company.mobile}}</p>
				</div>
				<div class="hbox-aside">
					<el-button type="primary" @click="toFinance">财务管理</el-button>
					<el-button type="primary" @click="toClub" >俱乐部管理</el-button>
				</div>
			</div>
			<div class="header-box finance-box">
				<div class="finance-content">
					<p>账号余额</p>
					<p>￥{{company.balance}}</p>
				</div>
				<div class="finance-content">
					<p>可提现余额</p>
					<p>￥{{company.income_balance}}</p>
				</div>
				<div class="hbox-aside">
					<el-button type="primary" @click="toFinance">提现</el-button>
				</div>
			</div>
		</div>
		<!-- 中部卡片 -->
		<div class="total-card-list">
			<total-card class="total-card" :type='1' :iconType='1' title="参与赛事总人数" :count="sum.match_total_num" alt="说明" ></total-card>
			<total-card class="total-card" :type='2' :iconType='2' title="参与培训总人数" :count="sum.train_total_num" alt="说明" ></total-card>
			<total-card class="total-card" :type='3' :iconType='3' title="俱乐部数量" :count="sum.club_num" alt="说明" ></total-card>
			<total-card class="total-card" :type='4' :iconType='4' title="赛事总收取报名费" :count="'￥' + sum.match_total_price" alt="说明" ></total-card>
			<total-card class="total-card" :type='5' :iconType='5' title="培训总收取报名费" :count="'￥' + sum.train_total_price" alt="说明" ></total-card>
			<total-card class="total-card" :type='6' :iconType='6' title="俱乐部总收入" :count="'￥' + sum.club_total_price" alt="说明" ></total-card>
		</div>
		<!-- 底部统计图与消息列表 -->
		<div class="third-area">
			<div class="tarea-box">
				<div class="tarea-title">俱乐部收益统计</div>
				<div ref="stcChart" class="stc-chart" v-if="showPieChart" ></div>
				<img v-else src="@/assets/imgs/home/empty.png" class="empty-chart" />
			</div>
			<div class="tarea-box">
				<div class="tarea-title">平台消息通知</div>
				<div class="notice-list">
					<div class="notice-li" v-for="(item,index) of message" :key="index">
						<el-link class="notice-title" :underline="false">{{item.title}}</el-link>
						<p class="notice-date">{{item.create_time}}</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import totalCard from './components/totalCard.vue'
	import echarts from 'echarts'
	
	export default {
		components:{
			totalCard
		},
		data() {
			return {
				company:{
					balance: "",
					company_name: "",
					image: "",
					income_balance: 0,
					mobile: "",
				},
				sum:{
					club_num: '0',
					club_total_price: '0.00',
					match_total_num: '0',
					match_total_price: '0',
					train_total_num: '0',
					train_total_price: '0.00',
				},
				message:[],
				showPieChart:true
			}
		},
		mounted() {
			this.$api.getHome().then(res => {
				// console.log(res);
				if(res){
					const data = res.data;
					this.sum = data.sum;
					this.company = data.company;
					this.message = data.message;
					
					let pieData = data.club_price_list.map(dt => ({name:dt.club_name,value:dt.sum}));
					if(pieData.length !== 0){
						this.setChart(pieData);
					}else{
						this.showPieChart = false;
					}
				}
			})
		},
		methods:{
			/**
			 * 设置饼图
			 */
			setChart(data){
				const target = echarts.init(this.$refs.stcChart)
				target.setOption({
					legend: {
						bottom: 20,
						left: 'center',
						data: data.map(dt => dt.name)
					},
					tooltip: {
						trigger: 'item',
						formatter: '俱乐部:{b}<br/>收益:￥{c}'
					},
					series: [{
						type: 'pie',
						radius: '50%',
						center: ['50%', '50%'],
						data:data,
						grid: {
							height: 350
						},
						label: {
							position: 'outer',
							alignTo: 'none',
							bleedMargin: 5
						},
					}]
				});
			},
			// 跳转俱乐部管理
			toClub(){
				this.$router.push({path:'/clublist'});
			},
			// 跳转财务管理
			toFinance(){
				this.$router.push({path:'/financeindex'});
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	
	.page-main{
		padding: 10px 20px;
		background-color: #F4F4F4;
	}
	
	.el-button{
		background-color: #3861DB;
	}
	// 顶部信息box
	.top-bar{
		display: flex;
		justify-content: space-between;
	}
	.header-box{
		display: inline-flex;
		justify-content: flex-start;
		align-items: center;
		width: calc(50% - 5px);
		height: 160px;
		background-color: white;
		border-radius: 10px;
		padding: 10px 20px;
		
		.hbox-aside{
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;
			height: calc(100% - 20px);
			margin-left: auto;
			
			.el-button{
				margin-left: 0;
				width: 120px;
				font-size: 16px;
			}
		}
	}
	// 企业信息box
	.info-box{
		.info-logo{
			width: 92px;
			height: 92px;
			border-radius: 46px;
			margin-right: 20px;
		}
		
		.info-content{
			p{
				font-size: 24px;
				color: #1A1717;
			}
			p+p{
				font-size: 16px;
				color: #999999;
			}
		}
	}
	// 财务信息box
	.finance-box{
		.finance-content{
			width: 200px;
			height: calc(100% - 40px);
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;
			
			p{
				font-size: 20px;
				color: #1A1717;
			}
			p+p{
				font-size: 24px;
				color: #FF7E05;
			}
		}
	}
	// 总计数据 card
	.total-card-list{
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		margin-top: 10px;
		
		.total-card{
			width: calc(33% - 5px);
			margin-bottom: 10px;
		}	
	}
	// 底部chart栏
	.third-area{
		display: flex;
		justify-content: space-between;
		
		.tarea-box{
			width: calc(50% - 5px);
			height: 400px;
			background-color: white;
			border-radius: 10px;
			
			.tarea-title{
				height: 40px;
				line-height: 40px;
				margin-top: 10px;
				padding: 0 20px;
				font-size: 18px;
			}
			// 饼图
			.stc-chart{
				width: 100%;
				height: calc(100% - 50px);
			}
			// 饼图空数据
			.empty-chart{
				width: 160px;
				height: 160px;
				margin-top: 80px;
				margin-left: calc(50% - 80px);
			}
			// 通知列表
			.notice-list{
				width: 100%;
				height: calc(100% - 50px);
				padding: 10px 40px;
				overflow-y: auto;
				
				.notice-li{
					margin-bottom: 20px;
					
					.el-link{
						margin-bottom: 10px;
						font-size: 16px;
					}
					
					p{
						font-size: 12px;
						color: #999999;
					}
				}
			}
		}
	}
</style>
