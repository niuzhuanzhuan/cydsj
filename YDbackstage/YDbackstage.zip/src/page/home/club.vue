<template>
	<div class="page-main">
		<div class="top-bar">
			<div class="header-box info-box">
				<img :src="club.image" class="info-logo" />
				<div class="info-content">
					<p>{{club.club_name}}</p>
					<p>超级管理员：{{club.mobile}}</p>
				</div>
				<!-- <div class="hbox-aside">
					<el-button type="primary">财务管理</el-button>
					<el-button type="primary">俱乐部管理</el-button>
				</div> -->
			</div>
			<div class="header-box finance-box">
				<div class="finance-content">
					<p>账号总收款</p>
					<p>￥{{club.total_price}}</p>
				</div>
				<!-- <div class="finance-content">
					<p>可提现余额</p>
					<p>￥{{club.income_balance}}</p>
				</div> -->
				<!-- <div class="hbox-aside">
					<el-button type="primary">提现</el-button>
				</div> -->
			</div>
		</div>
		
		<div class="total-card-list">
			<total-card class="total-card" :type='1' 
				mini 
				title="举办赛事次数" 
				:count="sum.match_num" 
				alt="说明"
				title2="参与赛事人数"
				:count2="sum.match_total_num"
				alt2="说明"
			></total-card>
			<total-card class="total-card" :type='2' 
				mini 
				title="创建培训次数" 
				:count="sum.train_num" 
				alt="说明" 
				title2="参与培训次数"
				:count2="sum.train_total_num"
				alt2="说明"
			></total-card>
			<total-card class="total-card" :type='4' :iconType='4' title="赛事总收取报名费" :count="'￥' + sum.match_total_price" alt="说明" ></total-card>
			<total-card class="total-card" :type='6' :iconType='6' title="培训总收取报名费" :count="'￥' + sum.train_total_price" alt="说明" ></total-card>
		</div>
		
		<div class="third-area">
			<!-- 与首页不同的2行卡片 -->
			<div class="tarea-split-box">
				<div class="tsplit-box">
					<div class="tsplit-left">
						<div class="tarea-title">儿童平衡车创建赛事入口</div>
						<img src="@/assets/imgs/home/balence_car.png" />
					</div>
					<div class="tsplit-right">
						<el-button type="primary" @click="toNew">立即创建</el-button>
					</div>
				</div>
				<div class="tsplit-box">
					<div class="tsplit-left">
						<div class="tarea-title">儿童平衡车培训内容发布入口</div>
						<img src="@/assets/imgs/home/train.png" />
					</div>
					<div class="tsplit-right">
						<el-button type="primary" disabled >培训专区暂未开放</el-button>
					</div>
				</div>
			</div>
			<div class="tarea-box">
				<div class="tarea-title">平台消息通知</div>
				<div class="notice-list">
					<div class="notice-li" v-for="item of message">
						<el-link class="notice-title" :underline="false">{{item.title}}</el-link>
						<p class="notice-date">{{item.create_time}}</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import totalCard from './components/totalCard.vue'
	
	export default {
		components:{
			totalCard
		},
		data() {
			return {
				club:{
					balance: 0,
					company_name: "",
					image: "",
					income_balance: 0,
					mobile: "",
				},
				sum:{
					match_num: 0,
					match_total_num: 0,
					match_total_price: 0,
					train_num: 0,
					train_total_num: 0,
					train_total_price: "0.00",
				},
				message:[],
			}
		},
		mounted() {
			// this.setChart();
			this.$api.getClubHome().then(res => {
				console.log(res);
				const data = res.data;
				this.sum = data.sum;
				this.club = data.club;
				this.message = data.message;
			})
		},
		methods:{
			toNew(){
				this.$router.push({path:'/establish'});
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	
	.page-main{
		padding: 10px 20px;
		background-color: #F4F4F4;
	}
	.el-button{
		background-color: #3861DB;
	}
	// 顶部信息box
	.top-bar{
		display: flex;
		justify-content: space-between;
	}
	.header-box{
		display: inline-flex;
		justify-content: flex-start;
		align-items: center;
		width: calc(50% - 5px);
		height: 160px;
		background-color: white;
		border-radius: 10px;
		padding: 10px 20px;
		
		.hbox-aside{
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;
			height: calc(100% - 20px);
			margin-left: auto;
			
			.el-button{
				margin-left: 0;
				width: 120px;
				font-size: 16px;
			}
		}
	}
	// 企业信息box
	.info-box{
		.info-logo{
			width: 92px;
			height: 92px;
			border-radius: 46px;
			margin-right: 20px;
		}
		
		.info-content{
			
			p{
				font-size: 24px;
				color: #1A1717;
			}
			p+p{
				margin-top: 10px;
				font-size: 16px;
				color: #999999;
			}
		}
	}
	// 财务信息box
	.finance-box{
		justify-content: center;
		
		.finance-content{
			width: 200px;
			height: calc(100% - 40px);
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;
			
			p{
				font-size: 20px;
				color: #1A1717;
			}
			p+p{
				font-size: 24px;
				color: #FF7E05;
			}
		}
	}
	// 总计数据 card
	.total-card-list{
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		margin-top: 10px;
		
		.total-card{
			width: calc(25% - 7.5px);
			height: 200px;
			margin-bottom: 10px;
		}	
	}
	// 底部chart栏
	.third-area{
		display: flex;
		justify-content: space-between;
		
		.tarea-box{
			width: calc(50% - 5px);
			height: 400px;
			background-color: white;
			border-radius: 10px;
			
			.tarea-title{
				height: 40px;
				line-height: 40px;
				margin-top: 10px;
				padding: 0 20px;
				font-size: 18px;
			}
			// 饼图
			.stc-chart{
				width: 100%;
				height: calc(100% - 50px);
			}
			// 通知列表
			.notice-list{
				width: 100%;
				height: calc(100% - 50px);
				padding: 10px 40px;
				overflow-y: auto;
				
				.notice-li{
					margin-bottom: 20px;
					
					.el-link{
						margin-bottom: 10px;
						font-size: 16px;
					}
					
					p{
						font-size: 12px;
						color: #999999;
					}
				}
				
			}
		}
		.tarea-split-box{
			width: calc(50% - 5px);
			height: 400px;
			display: flex;
			flex-direction: column;
			justify-content: space-between;
		}
		
		.tsplit-box{
			display: flex;
			justify-content: space-between;
			align-items: stretch;
			width: 100%;
			height: 195px;
			background-color: white;
			border-radius: 10px;
			
			.tsplit-left{
				.tarea-title{
					height: 40px;
					line-height: 40px;
					margin-top: 10px;
					padding: 0 20px;
					font-size: 18px;
				}
				img{
					margin-left: 20px;
				}
			}
			.tsplit-right{
				display: inline-flex;
				align-items: center;
				padding-right: 20px;
				.el-button{
					margin-left: 0;
					min-width: 120px;
					font-size: 16px;
				}
				.el-button.is-disabled{
					background-color: #D6D6D6;
					border-color: #D6D6D6;
					color: white;
				}
			}
			
			
		}
		
	}
</style>
