<template>
	<div class="component-main" :class="'_gradient_color_'+ type">
		<!-- 简略展示 -->
		<template v-if="mini">
			<div class="title mini-title">

				<span>{{title}}</span>
				<span class="mini-count">{{count}}</span>
			</div>
			<div class="title mini-title">

				<span>{{title2}}</span>
				<span class="mini-count">{{count2}}</span>
			</div>
		</template>
		<!-- 普通展示 -->
		<template v-else>
			<div class="title">
				{{title}}
			</div>
			<div class="total-count">
				<img :src="require(`@/assets/imgs/home/home_icon_${iconType}.png`)">
				<span>{{count}}</span>
			</div>
		</template>
	</div>
</template>

<script>
	export default {
		props:{
			type:{ 
				type:Number,
				default:1,
			},
			iconType:{
				type:Number,
				default:1,
			},
			title:{ // card 标题
				type:String,
				default:'',
			},
			count:{
				type:[String,Number],
				default:'0',
			},
			mini:{
				type:Boolean,
				default:false,
			},
			// mini 模式时第二条数据
			title2:{ // card 标题
				type:String,
				default:'',
			},
			alt2:{ // card hover说明
				type:String,
				default:'',
			},
			count2:{
				type:[String,Number],
				default:'0',
			},
			
		},
	}
</script>

<style lang="less" scoped>
	// 6个渐变色数组
	@gradientColorArr:
	#81C0FD,#347DF6,
	#FBB086,#FE9B62,
	#F4BCFF,#C080FB,
	#FFA1E8,#FF84E1,
	#80D7FF,#3BC2FF,
	#FF9595,#FF6767;
	
	// 渐变色类名生成 ._gradient_color_@{i}
	.gradient_loop(@i) when (@i < 7){
		._gradient_color_@{i}{
			background-image: linear-gradient(to right, extract(@gradientColorArr, @i*2-1), extract(@gradientColorArr, @i*2));
		}
		.gradient_loop(@i + 1)
	}
	.gradient_loop(1);
	
	
	*{
		box-sizing: border-box;
	}
	
	.component-main{
		padding: 20px;
		color: white;
		border-radius: 10px;
	}
	.title{
		display: flex;
		align-items: center;
		
		font-size: 20px;
		.tip-icon{
			color: white;
			font-size: 20px !important;
		}		
	}
	.mini-title{
		height: 50%;
		
		.mini-count{
			margin-left: 30px;
			font-size: 32px;
		}
	}
	
	.total-count{
		display: flex;
		justify-content: flex-start;
		align-items: center;
		margin-top: 60px;
		
		img{
			margin-right: 20px;
		}
		span{
			font-size: 32px;
		}
	}
</style>
