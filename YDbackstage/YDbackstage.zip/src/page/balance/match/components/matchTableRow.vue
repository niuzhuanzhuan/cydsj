<!-- 赛事基本信息行组件 -->
<template>
	<div class="tb-row">
		<div class="tb-top-date">
			<span>赛事时间：{{data.match_start_time}} ~ {{data.match_end_time}}</span>
			<span>报名时间：{{data.sign_start_time}} ~ {{data.sign_end_time}}</span>
		</div>
		<!-- 赛事主要信息 -->
		<div class="tb-line">
			<div class="tb-box tb-line-head">
				<img :src="data.image" />
				<div class="tb-content">
					<p class="tb-title">{{data.title}}</p>
					<p>{{data.province}}/{{data.city}}</p>
					<p class="tb-tag">
						<span><i class="iconfont">&#xe64f;</i>{{data.view}}</span>
						<el-popover
							v-if="data.share_url !== ''"
						    placement="right"
						    width="240"
						    trigger="click"
						>
							<vue-qr :text="data.share_url" :size="240" ></vue-qr>
							<span slot="reference"><i class="iconfont">&#xe613;</i>推广赛事</span>
						</el-popover>
						
						<el-popover
							v-if="data.share_url !== ''"
						    placement="right"
						    width="240"
						    trigger="click"
						>
							<vue-qr :text="data.share_url" :size="240" ></vue-qr>
							<img slot="reference" :src="require('@/assets/imgs/match/qrcode.png')" >
						</el-popover>
						   
					</p>
				</div>
			</div>
			<div class="tb-breakLine"></div>
			<!-- 报名费 -->
			<div class="tb-box">
				<p>￥{{data.small_price}}</p>
				<p>已收报名费￥{{data.sign_total_price}}</p>
			</div>
			<div class="tb-breakLine"></div>
			<!-- 报名人数 -->
			<div class="tb-box">
				<p>{{data.total_num}}人</p>
				<p>已报名人数: {{data.sign_total_num}}人</p>
				<p class="_grey" v-if="data.is_hide_sign === 0">报名人数已隐藏</p>
			</div>
			<div class="tb-breakLine"></div>
			<!-- 赛事状态 -->
			<div class="tb-box">
				<p>{{stateMap.get(data.state)}}</p>
			</div>
			<div class="tb-breakLine"></div>
			<div class="tb-box tb-line-ctrl">
				<slot></slot>
			</div>
		</div>
	</div>
</template>

<script>
	import vueQr from 'vue-qr';
	export default {
		components:{
			vueQr
		},
		props:['data'],
		data() {
			return {
				stateMap: new Map([
					[1,'可用'],
					[2,'被拒绝'],
					[3,'被限制'],
					[4,'审核中'],
					[5,'草稿'],
					[6,'预览']
				])
			}
		},
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	
	.tb-row{
		background-color: white;
	}
	// 顶部日期
	.tb-top-date{
		display: flex;
		justify-content: space-between;
		padding: 0 20px;
		line-height: 40px;
		background-color: #FAFAFA;
		font-size: 14px;
		color: #666666;
	}
	
	.tb-line{
		height: 110px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 5px 0;
		padding: 5px 20px;
		
		// 行内信息box
		.tb-box{
			height: 100%;
			flex-grow: 1;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;
			padding: 10px 0;
			
			p{
				font-size: 14px;
				color: #666666;
				margin-bottom: 10px;
				
				&._grey{
					color: #bbbbbb;
				}
			}
			.el-link{
				font-size: 14px;
			}
		}
		.tb-breakLine{
			width: 1px;
			height: 80px;
			background-color: #E4E7ED;
		}
		// 主要信息box
		.tb-line-head{
			box-sizing: border-box;
			flex-basis: 500px;
			display: flex;
			justify-content: flex-start;
			flex-direction: row;
			padding: 0 20px 0 0;
			// 封面图
			img{
				display: inline-block;
				width: 150px;
				height: 100px;
				object-fit: contain;
			}
			.tb-content{
				width: 100%;
				height: 100%;
				display: inline-flex;
				flex-direction: column;
				padding-left: 10px;
				font-size: 14px;
				
				p{
					font-size: 14px;
					color: #999999;
					margin-bottom:5px;
				}
				
				.tb-title{
					font-size: 16px;
					color: #333333;
				}
				// 标签栏
				.tb-tag{
					width: 100%;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					span{
						display: inline-flex;
						align-items: center;
						margin-right: 20px;
						line-height: 20px;
						cursor: pointer;
						
						i{
							margin-right: 5px;
						}
					}
					
					img{
						width: 40px;
						height: 40px;
						cursor: pointer;
					}
				}
			}
		}
		.tb-line-ctrl{
			align-items: flex-end;
		}
	}
</style>
