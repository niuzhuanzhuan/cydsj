<template>
	<div class="initmians">
		<div class="minatiltle">当前赛事已发布，添加分组成功后，选手即可报名</div>
		<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="200px">
			<el-form-item label="组别名称:" prop="name"><el-input style="width: 43.75rem;" v-model="ruleForm.name"></el-input></el-form-item>

			<el-form-item label="快速生成出生日期" required>
				<div style="width: 43.75rem;">
					<el-col :span="11">
						<el-form-item prop="age_start">
							<el-select style="width: 100%;" v-model="ruleForm.age_start" @change="ageval(ruleForm.age_start)" placeholder="请选择">
								<el-option v-for="(items, index) in datainit" :key="index" :label="items.name" :value="items.name"></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="line" :span="2">至</el-col>
					<el-col :span="11">
						<el-form-item prop="age_end">
							<el-select style="width: 100%;" v-model="ruleForm.age_end" @change="age_ends(ruleForm.age_end)" placeholder="请选择">
								<el-option v-for="(items, index) in arrage_end" :key="index" :label="items.name" :value="items.name"></el-option>
							</el-select>
						</el-form-item>
					</el-col>
				</div>
			</el-form-item>

			<el-form-item label="单个选手生日范围" required>
				<div style="width: 43.75rem;">
					<el-col :span="11">
						<el-form-item prop="age_date_start">
							<el-date-picker
								type="date"
								value-format="yyyy-MM-dd"
								placeholder="请选择开始时间"
								v-model="ruleForm.age_date_start"
								style="width: 100%;"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="line" :span="2">至</el-col>
					<el-col :span="11">
						<el-form-item prop="age_date_end">
							<el-date-picker
								type="date"
								value-format="yyyy-MM-dd"
								placeholder="请选择结束时间"
								v-model="ruleForm.age_date_end"
								style="width: 100%;"
							></el-date-picker>
						</el-form-item>
					</el-col>
				</div>
			</el-form-item>

			<el-form-item label="性别限制:" prop="sex">
				<el-radio-group v-model="ruleForm.sex">
					<el-radio :label="0">不限男女</el-radio>
					<el-radio :label="1">仅限男孩</el-radio>
					<el-radio :label="2">仅限女孩</el-radio>
				</el-radio-group>
			</el-form-item>
			<el-form-item label="价格(元):" prop="price"><el-input style="width: 43.75rem;" placeholder="请输入价格" v-model="ruleForm.price"></el-input></el-form-item>
			<el-form-item label="名额:" prop="limit"><el-input style="width: 43.75rem;" placeholder="请输入名额" v-model="ruleForm.limit"></el-input></el-form-item>

			<el-form-item>
				<el-button @click="$emit('handleClose')">取 消</el-button>
				<el-button type="primary" @click="submitForm('ruleForm')">保 存</el-button>
			</el-form-item>
		</el-form>
	</div>
</template>

<script>
import * as frominit from '@/page/balance/establish/components/index';
import define from '@/components/define/define';
export default {
	name: 'groufrom',
	props: {
		is_birthday: {
			type: Number,
			default: 1
		}
	},
	data() {
		let price = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入大于0的金额(小数限制两位)'));
			} else {
				if (define.money.test(value)) {
					this.$set(this.ruleForm, 'price', value);
					callback();
				} else {
					callback(new Error('您输入金额有误请检查(小数限制两位)'));
				}
			}
		};
		let limit = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入大于0整数'));
			} else {
				if (/^[1-9]\d*$/.test(value)) {
					if (value > 0) {
						this.$set(this.ruleForm, 'limit', value);
						callback();
					} else {
						callback(new Error('请输入大于0整数'));
					}
				} else {
					callback(new Error('请输入大于0整数'));
				}
			}
		};
		return {
			datainit: [],
			arrage_end: [],
			ruleForm: {
				sex: 0
			},
			rules: {
				name: [{ required: true, message: '请输入组别名称!', trigger: 'blur' }],
				price: [{ required: true, validator: price, trigger: 'change' }],
				limit: [{ required: true, validator: limit, trigger: 'change' }],
				age_start: [{ required: true, message: '请选择开始日期!', trigger: 'blur' }],
				age_end: [{ required: true, message: '请选择结束日期!', trigger: 'blur' }],
				age_date_start: [{ required: true, message: '请选择开始时间!', trigger: 'blur' }],
				age_date_end: [{ required: true, message: '请选择结束时间!', trigger: 'blur' }]
			}
		};
	},
	mounted() {
		this.datainit = frominit.default.datainit;
		this.arrage_end = frominit.default.datainit;
	},
	methods: {
		ageval(data) {
			this.$set(this.ruleForm, 'age_end', '');
			this.$set(this.ruleForm, 'age_date_start', '');
			this.$set(this.ruleForm, 'age_date_end', '');
			this.datainit = frominit.default.datainit;
			this.arrage_end = frominit.default.datainit;
			let indexs = this.datainit.findIndex(item => item.name == data);
			let inarr = [];
			for (let i = 0; i < this.datainit.length; i++) {
				if (i > indexs) {
					inarr.push(this.arrage_end[i]);
				}
			}
			this.arrage_end = inarr;
		},
		age_ends(data) {
			if (sessionStorage['match_time']) {
				let match_time = JSON.parse(sessionStorage['match_time']);
				let starts = '';
				let endtiem = '';
				if (!!this.ruleForm.age_start) {
					this.datainit.forEach(item => {
						if (item.name === data) {
							let age_date_start = define.getPreMonthDay(define.year(match_time), item.index * 12);
							if (this.is_birthday == 1) {
								starts = define.year(define.gettate(age_date_start) + 24 * 3600 * 1000);
							} else {
								starts = age_date_start;
							}
							this.$set(this.ruleForm, 'age_date_start', starts);
						}
						if (item.name === this.ruleForm.age_start) {
							let age_date_end = define.getPreMonthDay(define.year(match_time), item.index * 12);
							if (this.is_birthday == 1) {
								endtiem = age_date_end;
							} else {
								endtiem = define.year(define.gettate(age_date_end) - 24 * 3600 * 1000);
							}
							this.$set(this.ruleForm, 'age_date_end', endtiem);
						}
					});
				}
			}
		},
		submitForm(formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					this.$emit('handleClose', this.ruleForm);
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>
<style scoped>
.initmians >>> .el-form-item__label {
	color: #333333;
	font-weight: bold;
}
</style>
<style lang="less" scoped>
.minatiltle {
	width: calc(100% - 24px);
	padding-left: 24px;
	height: 46px;
	background: rgba(238, 64, 55, 0.1);
	border: 1px solid #ee4037;
	border-radius: 6px;
	display: flex;
	align-items: center;
	justify-content: flex-start;
	color: #333333;
	font-size: 14px !important;
	opacity: 0.8;
	margin-bottom: 20px;
}
.initmians {
	width: 100%;
}
.line {
	display: flex;
	justify-content: center;
}
</style>
