<template>
	<div>
		<establishs :designate="0"/>
	</div>
</template>

<script>
	import establishs from '@/page/balance/establish/establish.vue'
	export default{
		components:{
			establishs
		}
	}
</script>

<style>
</style>
