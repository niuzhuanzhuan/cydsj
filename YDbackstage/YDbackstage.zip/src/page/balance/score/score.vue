<template>
	<div class="allmian">
		<div class="miantops">
			<div class="topinit">
				<div class="topleft">
					<el-image style="width: 106px; height: 106px" :src="datafrom.image" fit="cover"></el-image>
				</div>
				<div class="toprigth">
					<div class="reighttop">{{datafrom.title}}</div>
					<div class="rigthbonnt">
						<div class="bonnteit">{{datafrom.detail}}</div>
						<div class="bonnteit">已上传成绩分组：{{datafrom.count}}</div>
					</div>
				</div>
			</div>
		</div>
		<personal ref="personal"/>
		<team ref="team"/>
	</div>
</template>

<script>
import personal from './components/personal.vue';
import team from './components/team.vue';
export default {
	data() {
		return {
			datafrom:{}
		};
	},
	components: {
		personal,
		team
	},
	created() {
		if (this.$route.query.match_id) {
			this.getdata(this.$route.query.match_id);
		} else {
			this.$message.warning('非法操作');
			this.$router.go(-1);
		}
	},
	methods: {
		async getdata(id) {
			const datalist = await this.$api.getMatchGroupScoreData({id:id});
			datalist&&(this.datafrom=datalist.data)
			// console.log(this.datafrom)
			if(datalist.data.user_group){
				datalist.data.user_group.forEach(item=>{
					if(item.score.length>0){
						item.score.forEach(jitem=>{
							if(jitem.code!=''){
								this.$set(jitem,'show',false)
							}else{
								this.$set(jitem,'show',true)
							}
						})
					}
					if(item.custom_score.length>0){
						item.custom_score.forEach(jitem=>{
							if(jitem.code!=''){
								this.$set(jitem,'show',false)
							}else{
								this.$set(jitem,'show',true)
							}
						})
					}
				})
				this.$refs.personal.user_group=datalist.data.user_group
			}
			if(datalist.data.team_group){
				datalist.data.team_group.forEach(item=>{
					if(item.score.length>0){
						item.score.forEach(jitem=>{
							if(jitem.code!=''){
								this.$set(jitem,'show',false)
							}else{
								this.$set(jitem,'show',true)
							}
						})
					}
					if(item.custom_score.length>0){
						item.custom_score.forEach(jitem=>{
							if(jitem.code!=''){
								this.$set(jitem,'show',false)
							}else{
								this.$set(jitem,'show',true)
							}
						})
					}
				})
				this.$refs.team.team_group=datalist.data.team_group
				console.log(this.$refs.team.team_group)
			}
		}
	}
};
</script>

<style lang="less" scoped>
.allmian {
	width: 100%;
	height: 100%;
	.miantops {
		width: calc(100% - 40px);
		height: 106px;
		padding: 10px 20px;
		.topinit {
			width: 100%;
			height: 100%;
			display: flex;
			.topleft {
				width: 122px;
				height: 100%;
			}
			.toprigth {
				width: calc(100% - 122px);
				height: 100%;
				.reighttop {
					width: 100%;
					height: 45%;
					display: flex;
					align-items: center;
					font-size: 18px;
					color: #161616;
				}
				.rigthbonnt {
					width: 100%;
					height: 55%;
					display: flex;
					flex-direction: column;
					justify-content: flex-end;
					.bonnteit {
						width: 100%;
						height: 45%;
						display: flex;
						align-items: center;
						font-size: 12px;
						color: #666666;
					}
				}
			}
		}
	}
}
</style>
