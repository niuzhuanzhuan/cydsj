<template>
	<div class="personal">
		<div class="perstop">
			<div class="perleft">个人分组</div>
			<div class="hr"></div>
		</div>
		<div class="pertable">
			<div class="ings"></div>
			<div class="permian">
				<div class="minaitems">
					<div class="wids1">奖项</div>
					<div class="wids2">姓名</div>
					<div class="wids3">身份证</div>
					<div class="wids4"><div class="linf">头像</div></div>
				</div>
			</div>
			<div class="ings"></div>
		</div>
		<div class="miankey" v-if="user_group.length > 0" v-for="(jitem, jindex) in user_group" :key="jindex">
			<div class="perinit">
				<div class="initleft" @click="jitem.show = !jitem.show">
					<div class="fonst">
						{{ jitem.name }}
						<i v-if="jitem.show" class="el-icon-arrow-down"></i>
						<i v-else class="el-icon-arrow-up"></i>
					</div>
				</div>
				<div class="initbatele">
					<el-collapse-transition>
						<div v-show="jitem.show">
							<div class="initems" v-for="(item, index) in jitem.score" :key="index">
								<div class="itmins">
									<div class="wids1">第{{ item.order }}名</div>
									<div class="wids2">
										<div class="mianinput" v-if="item.show">
											<el-autocomplete
												style="margin-right: -3px;"
												popper-class="my-autocomplete"
												v-model="item.name"
												:fetch-suggestions="querySearch"
												placeholder="请输入内容"
												@select="handleSelect"
												@focus="handfocus(jitem.user, jitem.score, index, item)"
											>
												<template slot-scope="{ item }">
													<div class="name">
														<el-avatar :size="30" style="margin-right: 3px;" :src="item.avatar"></el-avatar>
														<div class="mianlinit">
															<div>{{ item.name }}</div>
															<div>{{ item.id_card }}</div>
														</div>
													</div>
												</template>
											</el-autocomplete>
											<div class="bao" @click="preservation(jitem, item, jitem.user)">保存</div>
										</div>
										<div class="mianinput" v-else>
											<div class="mianlinst">
												<div class="minli">
													<div>{{ item.name }}</div>
													<div><el-button type="text" @click="item.show = true">编辑</el-button></div>
												</div>
											</div>
										</div>
									</div>
									<div class="wids3">{{ item.code }}</div>
									<div class="wids4">
										<div class="inlimg">
											<div><el-avatar :size="46" :src="item.avatar"></el-avatar></div>
											<div
												class="miandelect "
												:style="{ display: index === jitem.score.length - 1 ? 'block' : 'none' }"
												@click="delects(jitem, jitem.score, 1)"
											>
												删除
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="bonsrt">
								<div class="wids1"><el-button type="text" @click="addDomain(jitem.score)" icon="el-icon-plus">添加名次</el-button></div>
							</div>
						</div>
					</el-collapse-transition>
				</div>
			</div>

			<div class="perbont">
				<div class="bontmian" v-for="(jtem, jindex) in jitem.custom_score" :key="jindex">
					<div class="inmiand">
						<div class="inmial"><el-input :disabled="!jtem.show" v-model="jtem.custom_name" clearable placeholder="体育精神奖（自定义）"></el-input></div>
						<div class="wids2">
							<div class="mianinput" v-if="jtem.show">
								<el-autocomplete
									style="margin-right: -3px;"
									popper-class="my-autocomplete"
									v-model="jtem.name"
									:fetch-suggestions="querySearch"
									placeholder="请输入内容"
									@select="handleSelect"
									@focus="handfocus(jitem.user, jitem.custom_score, jindex, jtem)"
								>
									<template slot-scope="{ item }">
										<div class="name">
											<el-avatar :size="30" style="margin-right: 3px;" :src="item.avatar"></el-avatar>
											<div class="mianlinit">
												<div>{{ item.name }}</div>
												<div>{{ item.id_card }}</div>
											</div>
										</div>
									</template>
								</el-autocomplete>
								<div class="bao" @click="preservation(jitem, jtem, jitem.user, -1)">保存</div>
							</div>
							<div class="mianinput" v-else>
								<div class="mianlinst">
									<div class="minli">
										<div>{{ jtem.name }}</div>
										<div><el-button type="text" @click="jtem.show = true">编辑</el-button></div>
									</div>
								</div>
							</div>
						</div>
						<div class="wids3">{{ jtem.code }}</div>
						<div class="wids4">
							<div class="inlimg">
								<div><el-avatar :size="46" :src="jtem.avatar"></el-avatar></div>
								<div
									class="miandelect"
									:style="{ display: jindex === jitem.custom_score.length - 1 ? 'block' : 'none' }"
									@click="delects(jitem, jitem.custom_score, 2)"
								>
									删除
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="bontmian">
					<div class="inmiand">
						<div class="inmial"><el-button type="text" @click="addCustom(jitem.custom_score)" icon="el-icon-plus">添加自定义奖项</el-button></div>
						<div class="wids2"></div>
						<div class="wids3"></div>
						<div class="wids4"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	data: () => ({
		show3: true,
		input: '',
		user_group: [],
		restaurants: [],
		datalist: [],
		keyindex: 0,
		fromdata: {}
	}),
	methods: {
		delects(data, constdata, score_type) {
			this.$confirm(`您确定删除当前数据信息吗?`, '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			})
				.then(async () => {
					if (constdata[constdata.length - 1].code != '') {
						const frominit = {
							id: this.$route.query.match_id,
							type: 'delete',
							user_type: 1,
							score_type: score_type,
							group_id: data.id
						};
						const datalist = await this.$api.getMatchGroupScoreData(frominit);
						if (datalist) {
							this.$message.success(datalist.msg);
							constdata.pop();
						}
					} else {
						constdata.pop();
					}
				})
				.catch(() => {});
		},
		handfocus(data, datalist, index, froams) {
			this.restaurants = data;
			this.datalist = datalist;
			this.keyindex = index;
			this.fromdata = froams;
		},
		querySearch(queryString, cb) {
			var restaurants = this.restaurants;
			var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
			// 调用 callback 返回建议列表的数据
			cb(results);
		},
		createFilter(queryString) {
			return restaurant => {
				return restaurant.name.toLowerCase().indexOf(queryString.toLowerCase()) === 0;
			};
		},
		handleSelect(item) {
			this.fromdata = item;
			this.datalist.forEach((ites, index) => {
				if (this.keyindex === index) {
					this.$set(ites, 'name', item.name);
					this.$set(ites, 'id', item.id);
				}
			});
		},
		async preservation(data, datafrom, lsitarr, meorders) {
			let { avatar, order, name, id, code, custom_name } = datafrom;
			let score_type = 1;
			const frominit = {
				type: 'save',
				user_type: 1
			};
			if (meorders == -1) {
				score_type = 2;
				if (custom_name == '') {
					this.$message.warning(`自定义体育精神奖不能为空`);
					return false;
				} else {
					this.$set(frominit, 'custom_name', custom_name);
				}
			}
			if (name == '') {
				this.$message.warning(`姓名不能为空`);
				return false;
			}
			if (code == '') {
				if (!this.fromdata.id) {
					this.$message.warning(`当前组别不存在姓名为${name}的数据`);
					return false;
				}
			}
			if (this.restaurants.length == 0) {
				this.restaurants = lsitarr;
			}
			const indata = this.restaurants.findIndex(item => item.name == name);
			if (indata == -1) {
				this.$message.warning(`当前组别不存在姓名为${name}的数据`);
				return false;
			}
			this.$set(frominit, 'id', this.$route.query.match_id);
			this.$set(frominit, 'score_type', score_type);
			this.$set(frominit, 'car_user_id', id);
			this.$set(frominit, 'order', order);
			this.$set(frominit, 'name', name);
			this.$set(frominit, 'group_id', data.id);
			const datalist = await this.$api.getMatchGroupScoreData(frominit);
			this.$set(datafrom, 'avatar', avatar ? avatar : this.fromdata.avatar);
			this.$set(datafrom, 'code', code ? code : this.fromdata.id_card);
			this.$set(datafrom, 'id', id ? id : this.fromdata.id);
			this.$set(datafrom, 'show', false);
			if (datalist) {
				this.$message.success(datalist.msg);
			}
		},
		addDomain(data) {
			data.push({
				order: data.length + 1,
				key: Date.now(),
				code: '',
				avatar: '',
				name: '',
				type: 1,
				show: true,
				custom_name: ''
			});
		},
		addCustom(data) {
			data.push({
				order: -1,
				key: Date.now(),
				code: '',
				avatar: '',
				name: '',
				type: 1,
				show: true,
				custom_name: ''
			});
		}
	}
};
</script>

<style scoped>
.wids1 > .el-button--text {
	font-size: 14px !important;
	color: #fc7a18;
}
.inmial > .el-button--text {
	font-size: 14px !important;
	color: #fc7a18;
}
.mianinput > .el-input__inner {
	margin-right: -3px !important;
	height: 32px !important;
	line-height: 32px !important;
}
</style>
<style lang="less" scoped>
.mianlinst {
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: center;
	.minli {
		width: 90%;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
}
.my-autocomplete {
	li {
		line-height: normal;
		padding: 7px;

		.name {
			text-overflow: ellipsis;
			overflow: hidden;
			display: flex;
			align-items: center;
		}
		.mianlinit {
			div {
				height: 22px;
				display: flex;
				flex-direction: column-reverse;
				justify-content: center;
				&:nth-child(1) {
					font-size: 14px;
					color: #333333;
					justify-content: flex-end;
				}
				&:nth-child(2) {
					font-size: 12px;
					color: #999999;
				}
			}
		}
	}
}

.mianinput {
	width: 233px;
	display: flex;
	.bao {
		z-index: 1;
		user-select: none;
		width: 94px;
		height: 30px;
		border: 1px solid #3861db;
		font-size: 14px;
		display: flex;
		justify-content: center;
		align-items: center;
		color: #3861db;
		cursor: pointer;
		background: #ffffff;
		&:active {
			border: 1px solid #5d6edb;
			color: #5d6edb;
		}
	}
}
.hr {
	width: 100%;
	height: calc(100% - 1px);
	border-bottom: 1px solid #dcdcdc;
}
.wids1 {
	width: 15%;
	height: 100%;
	display: flex;
	justify-content: flex-end;
	align-items: center;
}
.wids2 {
	width: 30%;
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
}
.wids3 {
	width: 36%;
	height: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
}
.wids4 {
	width: 15%;
	height: 100%;
	display: flex;
	align-items: center;
	.linf {
		width: 46px;
		height: 46px;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.inlimg {
		width: 113px;
		height: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		font-size: 14px;
		color: #ee3e35;
		.miandelect {
			cursor: pointer;
			user-select: none;
			&:active {
				color: #ee806c;
			}
		}
	}
}
.personal {
	width: calc(100% - 40px);
	padding: 20px 20px;
	.perbont {
		border-top: 1px solid #dcdcdc;
		width: 100%;
		margin-top: 20px;
		padding: 10px 0 30px 0;
		.bontmian {
			margin-top: 10px;
			width: 100%;
			height: 50px;
			display: flex;
			align-items: center;
			justify-content: center;
			.inmiand {
				width: 80%;
				height: 100%;
				align-items: center;
				display: flex;
				justify-content: space-between;
				.inmial {
					width: 15%;
					font-size: 14px;
					color: #333333;
					text-align: right;
				}
			}
		}
	}
	.miankey {
		width: 100%;
	}
	.perinit {
		width: 100%;
		display: flex;
		.initleft {
			width: 10%;
			font-size: 18px;
			color: #3861db;
			&:active {
				color: #0808db;
			}
			.fonst {
				width: 100%;
				padding: 20px 0;
				text-align: right;
				cursor: pointer;
				user-select: none;
			}
		}
		.initbatele {
			width: 80%;
			.bonsrt {
				width: 100%;
				margin-top: 10px;
			}
			.initems {
				margin-top: 10px;
				width: 100%;
				height: 50px;
				display: flex;
				align-items: center;
				.itmins {
					width: 100%;
					height: 45px;
					display: flex;
					color: #333332;
					justify-content: space-between;
				}
			}
		}
	}
	.pertable {
		width: 100%;
		height: 56px;
		background-color: #f5f5f6;
		display: flex;
		justify-content: center;
		.ings {
			width: 10%;
		}
		.permian {
			width: 80%;
			height: 100%;
			font-size: 16px;
			color: #333333;
			.minaitems {
				display: flex;
				align-items: center;
				justify-content: space-between;
				width: 100%;
				height: 100%;
			}
		}
	}
	.perstop {
		width: 100%;
		height: 43px;
		display: flex;
		margin-bottom: 20px;
		.perleft {
			width: 120px;
			height: 100%;
			background-color: #dfe5fa;
			font-size: 18px;
			color: #3861db;
			display: flex;
			justify-content: center;
			align-items: center;
			border-radius: 4px 4px 0px 0px;
		}
	}
}
</style>
