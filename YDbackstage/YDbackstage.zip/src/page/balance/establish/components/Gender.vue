<template>
	<div class="lenkey">
		<div class="listkey" v-for="(item, index) in datalists" :key="index">
			<el-select style="width: 120px;margin-right: 8px;" v-model="item.where">
				<el-option label="最少" value=">"></el-option>
				<el-option label="最多" value="<"></el-option>
				<el-option label="有且只有" value="=="></el-option>
			</el-select>
			<el-input style="width: 120px;margin-right: 8px;" placeholder="请输入" v-model.trim="item.num"></el-input>
			<div style="margin-right: 8px;">个</div>
			<el-input style="width: 120px;margin-right: 8px;" placeholder="不限制年龄" v-model.trim="item.age"></el-input>
			<div style="margin-right: 8px;">岁</div>
			<el-select style="width: 120px;margin-right: 8px;" v-model="item.sex">
				<el-option label="男生" value="1"></el-option>
				<el-option label="女生" value="0"></el-option>
				<el-option label="不限" value="2"></el-option>
			</el-select>

			<el-popover placement="top" width="160" v-model="item.visible">
				<p>这是一段内容这是一段内容确定删除吗？</p>
				<div style="text-align: right; margin: 0">
					<el-button size="mini" type="text" @click="item.visible = false">取消</el-button>
					<el-button type="primary" size="mini" @click.prevent="removeDomain(item)">确定</el-button>
				</div>
				<el-button slot="reference" v-show="datalists.length > 1" style="margin-right: 8px;height: 38px;" icon="el-icon-delete"></el-button>
			</el-popover>

			<el-button class="bonst" size="mini" @click="addmian" icon="el-icon-plus"></el-button>
		</div>
	</div>
</template>

<script>
export default {
	name:'Gender',
	props: {
		datalistkey: {
			type: Array,
			default: () => []
		}
	},
	data() {
		return {
			datalists: []
		};
	},
	watch: {
		datalists(newValue, oldValue) {
			this.$emit('update:datalistkey', newValue);
			deep: true;
		}
	},
	mounted() {
		this.datalists = this.datalistkey;
		this.addmian();
	},
	methods: {
		addmian() {
			this.datalists.push({
				where: '>',
				num: '',
				age: '',
				sex: '1',
				visible: false,
				key: Date.now()
			});
		},
		removeDomain(item) {
			var index = this.datalists.indexOf(item);
			if (index !== -1) {
				this.datalists.splice(index, 1);
			}
		}
	}
};
</script>

<style lang="less" scoped>
.lenkey {
	width: 100%;
	.listkey {
		width: 100%;
		padding: 10px 0;
		display: flex;
		.bonst {
			display: none;
		}
		&:last-child {
			.bonst {
				display: block;
			}
		}
	}
}
</style>
