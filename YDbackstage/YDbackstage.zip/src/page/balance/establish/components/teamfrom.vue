<template>
	<div class="initmians">
		<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="200px">
			<el-form-item label="组别名称" prop="name"><el-input v-model.trim="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="价格" prop="price"><el-input v-model.trim="ruleForm.price"></el-input></el-form-item>
			<el-form-item label="名额" prop="limit"><el-input v-model.trim="ruleForm.limit"></el-input></el-form-item>
			<el-form-item label="团队成员" prop="team_limit">
				<el-input v-model.trim="ruleForm.team_limit"><span slot="append">人</span></el-input>
			</el-form-item>

			<el-form-item label="快速生成出生日期" required>
				<el-col :span="11">
					<el-form-item prop="age_start">
						<el-select style="width: 350px;" v-model="ruleForm.age_start" @change="ageval(ruleForm.age_start)" placeholder="请选择">
							<el-option v-for="(items, index) in datainit" :key="index" :label="items.name" :value="items.name"></el-option>
						</el-select>
					</el-form-item>
				</el-col>
				<el-col class="line" :span="2">至</el-col>
				<el-col :span="11">
					<el-form-item prop="age_end">
						<el-select style="width: 350px;" v-model="ruleForm.age_end" @change="age_ends(ruleForm.age_end)" placeholder="请选择">
							<el-option v-for="(items, index) in arrage_end" :key="index" :label="items.name" :value="items.name"></el-option>
						</el-select>
					</el-form-item>
				</el-col>
			</el-form-item>

			<el-form-item label="单个选手生日范围" required>
				<el-col :span="11">
					<el-form-item prop="age_date_start">
						<el-date-picker type="date" value-format="yyyy-MM-dd" @change="agedatestart(ruleForm)" placeholder="请选择开始时间" v-model="ruleForm.age_date_start" style="width: 100%;"></el-date-picker>
					</el-form-item>
				</el-col>
				<el-col class="line" :span="2">至</el-col>
				<el-col :span="11">
					<el-form-item prop="age_date_end">
						<el-date-picker type="date" value-format="yyyy-MM-dd" @change="agedateend(ruleForm)" placeholder="请选择结束时间" v-model="ruleForm.age_date_end" style="width: 100%;"></el-date-picker>
					</el-form-item>
				</el-col>
			</el-form-item>

			<el-form-item label="年龄累计配置">
				<el-radio-group v-model="ruleForm.total_age">
					<el-radio :label="0">不配置</el-radio>
					<el-radio :label="1">按年累计</el-radio>
					<el-radio :label="2">按月累计</el-radio>
				</el-radio-group>
				<template v-if="ruleForm.total_age != 0">
					<div class="mianlist">
						<div class="itelis">
							<div style="margin-right: 8px;">累计年龄</div>
							<el-select style="width: 120px;margin-right: 8px;" v-model="ruleForm.total_age_json.where1">
								<el-option label="大于" value=">"></el-option>
								<el-option label="大于等于" value=">="></el-option>
								<el-option label="小于" value="<"></el-option>
								<el-option label="小于等于" value="<="></el-option>
								<el-option label="等于" value="="></el-option>
							</el-select>
							<el-input style="width: 120px;margin-right: 8px;" placeholder="请填写年龄" v-model.trim="ruleForm.total_age_json.num1"></el-input>
							<div style="margin-right: 8px;">{{ ruleForm.total_age == 1 ? '岁' : '月' }}</div>

							<el-select
								style="width: 120px;margin-right: 8px;"
								v-if="ruleForm.total_age_json.where1 == '>' || ruleForm.total_age_json.where1 == '>='"
								v-model="ruleForm.total_age_json.where2"
							>
								<el-option label="小于" value="<"></el-option>
								<el-option label="小于等于" value="<="></el-option>
							</el-select>
							<el-input
								v-if="ruleForm.total_age_json.where1 == '>' || ruleForm.total_age_json.where1 == '>='"
								style="width: 120px;margin-right: 8px;"
								placeholder="请填写年龄"
								v-model.trim="ruleForm.total_age_json.num2"
							></el-input>
							<div v-if="ruleForm.total_age_json.where1 == '>' || ruleForm.total_age_json.where1 == '>='" style="margin-right: 8px;">
								{{ ruleForm.total_age == 1 ? '岁' : '月' }}
							</div>
						</div>
					</div>
				</template>
			</el-form-item>
			<el-form-item label="性别限制">
				<el-radio-group v-model="ruleForm.sex">
					<el-radio :label="0">不限</el-radio>
					<el-radio :label="1">限制</el-radio>
				</el-radio-group>
				<template>
					<div class="litiems" v-show="ruleForm.sex == 1"><Gender ref="Genders" /></div>
				</template>
			</el-form-item>
			<el-form-item label="年龄计算截止日期" v-if="ruleForm.sex == 1" prop="user_age_end_date">
				<el-date-picker
					style="width: 760px;"
					value-format="yyyy-MM-dd"
					v-model="ruleForm.user_age_end_date"
					type="date"
					placeholder="请选择年龄计算截止日期(一般为赛事开始日期)"
				></el-date-picker>
			</el-form-item>
			<el-form-item>
				<el-button @click="$emit('handleClose')">取 消</el-button>
				<el-button type="primary" @click="submitForm('ruleForm')">保 存</el-button>
			</el-form-item>
		</el-form>
	</div>
</template>

<script>
import * as frominit from './index';
import Gender from './Gender.vue';
import define from '@/components/define/define';
export default {
	name: 'teamfrom',
	props: {
		is_birthday: {
			type: Number,
			default: 1
		}
	},
	data() {
		let price = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入大于0的金额(小数限制两位)'));
			} else {
				if (define.money.test(value)) {
					this.$set(this.ruleForm, 'price', value);
					callback();
				} else {
					callback(new Error('您输入金额有误请检查(小数限制两位)'));
				}
			}
		};
		let limit = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入大于0整数'));
			} else {
				if (/^[1-9]\d*$/.test(value)) {
					if (value > 0) {
						this.$set(this.ruleForm, 'limit', value);
						callback();
					} else {
						callback(new Error('请输入大于0整数'));
					}
				} else {
					callback(new Error('请输入大于0整数'));
				}
			}
		};
		let team_limit = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入大于1整数'));
			} else {
				if (/^[1-9]\d*$/.test(value)) {
					if (value > 1) {
						this.$set(this.ruleForm, 'team_limit', value);
						callback();
					} else {
						callback(new Error('请输入大于1的整数'));
					}
				} else {
					callback(new Error('请输入大于1的整数'));
				}
			}
		};
		return {
			ruleForm: {
				key: Date.now(),
				visible: false,
				sex: 0,
				total_age: 0,
				total_age_json: {
					where1: '>',
					num1: '',
					where2: '<',
					num2: '',
					type: 0
				},
				sex_json: []
			},
			datainit: [],
			arrage_end: [],
			rules: {
				name: [{ required: true, message: '请输入组别名称!', trigger: 'blur' }],
				price: [{ required: true, validator: price, trigger: 'change' }],
				limit: [{ required: true, validator: limit, trigger: 'change' }],
				age_start: [{ required: true, message: '请选择开始日期!', trigger: 'change' }],
				age_end: [{ required: true, message: '请选择结束日期!', trigger: 'change' }],
				team_limit: [{ required: true, validator: team_limit, trigger: 'blur' }],
				age_date_start: [{ required: true, message: '请选择开始时间!', trigger: 'blur' }],
				age_date_end: [{ required: true, message: '请选择结束时间!', trigger: 'blur' }],
				user_age_end_date: [{ required: true, message: '请选择年龄计算截止日期!', trigger: 'blur' }]
			}
		};
	},
	mounted() {
		this.datainit = frominit.default.datainit;
		this.arrage_end = frominit.default.datainit;
	},
	components: {
		Gender
	},
	methods: {
		agedatestart(data) {
			if (data.age_date_end != '') {
				let age_date_start = this.gettate(data.age_date_start);
				let age_date_end = this.gettate(data.age_date_end);
				if (age_date_start > +age_date_end) {
					this.$message.warning(`开始时间不能大于等于结束时间请检查`);
					this.$set(data, 'age_date_start', '');
				}
			}
		},
		agedateend(data) {
			if (data.age_date_start != '') {
				let age_date_start = this.gettate(data.age_date_start);
				let age_date_end = this.gettate(data.age_date_end);
				if (age_date_start >= age_date_end) {
					this.$message.warning(`结束时间不能小于等于开始时间请检查`);
					this.$set(data, 'age_date_end', '');
				}
			}
		},
		gettate(data) {
			let datas = new Date(data);
			let times = datas.getTime();
			return times;
		},
		ageval(data) {
			this.$set(this.ruleForm, 'age_end', '');
			this.$set(this.ruleForm, 'age_date_start', '');
			this.$set(this.ruleForm, 'age_date_end', '');
			this.datainit = frominit.default.datainit;
			this.arrage_end = frominit.default.datainit;
			let indexs = this.datainit.findIndex(item => item.name == data);
			let inarr = [];
			for (let i = 0; i < this.datainit.length; i++) {
				if (i > indexs) {
					inarr.push(this.arrage_end[i]);
				}
			}
			this.arrage_end = inarr;
		},
		age_ends(data) {
			if (sessionStorage['match_time']) {
				let match_time = JSON.parse(sessionStorage['match_time']);
				let starts = '';
				let endtiem = '';
				if (!!this.ruleForm.age_start) {
					this.datainit.forEach(item => {
						if (item.name == data) {
							let age_date_start = define.getPreMonthDay(define.year(match_time), item.index * 12);
							if (this.is_birthday == 1) {
								starts = define.year(define.gettate(age_date_start) + 24 * 3600 * 1000);
							} else {
								starts = age_date_start;
							}
							this.$set(this.ruleForm, 'age_date_start', starts);
						}
						if (item.name == this.ruleForm.age_start) {
							let age_date_end = define.getPreMonthDay(define.year(match_time), item.index * 12);
							if (this.is_birthday == 1) {
								endtiem = age_date_end;
							} else {
								endtiem = define.year(define.gettate(age_date_end) - 24 * 3600 * 1000);
							}

							this.$set(this.ruleForm, 'age_date_end', endtiem);
						}
					});
				}
			}
		},
		submitForm(formName) {
			let { sex, total_age, total_age_json } = this.ruleForm;
			if(typeof total_age_json=="string"){
				total_age_json=JSON.parse(total_age_json)
			}
			let init = true;
			this.$refs[formName].validate(valid => {
				if (valid) {
					if (total_age != 0) {
						total_age_json.type = total_age;
						if (total_age_json.where1 == '>' || total_age_json.where1 == '>=') {
							if (!total_age_json.num1 || !total_age_json.num2) {
								this.$message.error('检测到您选择的年龄累计配置有未填写项，不允许通过');
								return false;
							}
						} else {
							delete total_age_json.where2;
							delete total_age_json.num2;
							if (!total_age_json.num1) {
								this.$message.error('检测到您选择的年龄累计配置有未填写项，不允许通过');
								return false;
							}
						}
					} else {
						for (let item in total_age_json) {
							total_age_json[item] = '';
						}
					}
					if (sex != 0) {
						this.ruleForm.sex_json = this.$refs.Genders.datalists;
						if (this.ruleForm.sex_json.length > 0) {
							this.ruleForm.sex_json.map(item => {
								if (item.num == '') {
									init = false;
								}
							});
						}
					}else{
						delete this.ruleForm.user_age_end_date
					}
					if (!init) {
						this.$message.error('检测到您选择的性别限制有未填写项，不允许通过');
						return false;
					}
					this.$emit('handleClose', this.ruleForm);
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>

<style lang="less" scoped>
.initmians {
	width: 100%;
}
.line {
	display: flex;
	justify-content: center;
}
.mianlist {
	width: 100%;
	height: 100px;
	display: flex;
	align-items: center;
	.itelis {
		width: 100%;
		height: 50px;
		display: flex;
	}
}
.litiems {
	width: 100%;
	padding: 10px 0;
}
</style>
