<template>
	<div class="conmian">
		<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px">
			<el-form-item label="主办方logo:" prop="image">
				<image-uploader :width="84" :height="84" :limit="['75*75']" :size="1" title="LOGO" square="提示：建议尺寸75*75，图片小于1M" :imageUrl.sync="ruleForm.image"></image-uploader>
			</el-form-item>
			<el-form-item label="主办方封面:" prop="bg_image">
				<image-uploader :width="400" :height="200"
				 :limit="['200*400']"
				 title="LOGO" square="提示：建议尺寸200*400，图片小于4M" :imageUrl.sync="ruleForm.bg_image"></image-uploader>
			</el-form-item>
			<el-form-item label="主办方名称:" prop="club_name">
				<el-input class="demo-ruleForm" v-model="ruleForm.club_name" placeholder="请输入主办方名称"></el-input>
			</el-form-item>
			<el-form-item label="一句话简介:" prop="desc">
				<el-input class="demo-ruleForm" type="textarea" rows="6" placeholder="请输入一句话简介" v-model="ruleForm.desc"></el-input>
			</el-form-item>

			<el-form-item label="主办方地址:" prop="addr"><el-input class="demo-ruleForm" v-model="ruleForm.addr" placeholder="点击设置主办方地址"></el-input></el-form-item>
			<el-form-item label="联系手机号:" prop="phone">
				<el-input class="demo-ruleForm" v-model="ruleForm.phone" type="text" :maxlength="11" :show-word-limit="true" placeholder="请输入联系手机号"></el-input>
			</el-form-item>
			<el-form-item label="客服微信号:" prop="wechat"><el-input class="demo-ruleForm" v-model="ruleForm.wechat" placeholder="请输入客服微信号"></el-input></el-form-item>
			<el-form-item label="公众号:" prop="wechat_app"><el-input class="demo-ruleForm" v-model="ruleForm.wechat_app" placeholder="请输入公众号"></el-input></el-form-item>
			<el-form-item label="品牌详细介绍" prop="content"><ue ref="ues" :value.sync="ruleForm.content" :height="600" /></el-form-item>
			<el-form-item>
				<el-button type="primary" @click.stop="onSubmit">立即创建</el-button>
				<el-button @click.stop="reset">重置</el-button>
			</el-form-item>
		</el-form>
	</div>
</template>

<script>
import ue from '@/components/common/ueditor.vue';
import upload from '@/components/custom/uploadimage.vue';
import imageUploader from '@/components/BaseComponents/imageUploader.vue';
import Bus from '@/components/common/bus';
import define from '@/components/define/define';
export default {
	data() {
		let phone = (rule, value, callback) => {
			if (!value) {
				callback(new Error('请输入赛事咨询电话!'));
			} else {
				let isPhone = /^([0-9]{3,4}-)?[0-9]{7,8}$/;
				if (define.phone.test(value) || isPhone.test(value)) {
					callback();
				} else {
					callback(new Error('请输入正确的电话号码!'));
				}
			}
		};
		return {
			imageUrl: require('../imgae/banner.jpg'),
			ruleForm: {},
			rules: {
				image: [{ required: true, message: '请上传俱乐部logo', trigger: 'blur' }],
				club_name: [{ required: true, message: '请输入俱乐部名称', trigger: 'blur' }],
				bg_image: [{ required: true, message: '请上传封面', trigger: 'blur' }],
				desc: [{ required: true, message: '请输入简介', trigger: 'blur' }],
				addr: [{ required: true, message: '请输入地址', trigger: 'blur' }],
				phone: [{ required: true, validator: phone, trigger: 'change' }],
				wechat: [{ required: true, message: '请输入联系微信号', trigger: 'blur' }],
				wechat_app: [{ required: true, message: '请输入微信公众号', trigger: 'blur' }],
				content: [{ required: true, message: '请输入品牌介绍', trigger: 'blur' }]
			}
		};
	},
	components: {
		ue,
		upload,
		imageUploader
	},
	mounted() {
		this.getdata();
	},
	methods: {
		async getdata() {
			const datalist = await this.$api.getClubDetail();
			if (datalist) {
				this.ruleForm = datalist.data;
				this.$nextTick(() => {
					this.$refs.ues.values = this.ruleForm.content;
				});
			}
		},
		onSubmit() {
			this.$refs['ruleForm'].validate(valid => {
				if (valid) {
					this.$api
						.saveClubInfo(this.ruleForm)
						.then(res => {
							this.$alert(res.msg, '温馨提示', {
								confirmButtonText: '确定',
								callback: action => {
									this.$message({
										type: 'info',
										message: res.msg
									});
								}
							});
						})
						.catch(err => {
							console.log(err);
						});
				} else {
					this.$message.error('数据校验失败，请检查输入的信息是否正确！');
				}
			});
		},
		reset() {
			this.ruleForm = {};
		}
	},
	watch: {
		ruleForm: {
			handler(newruleForm, oldruleForm) {
				Bus.$emit('toLeftAll', newruleForm);
			},
			immediate: true,
			deep: true
		}
	}
};
</script>
<style scoped lang="less">
.conmian {
	width: 90%;
	padding-left: 8%;
	.demo-ruleForm {
		width: 660px;
	}
}
</style>
<style>
.el-input--small .el-input__inner {
	height: 38px !important;
	line-height: 38px !important;
}
</style>
