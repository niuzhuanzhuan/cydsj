<template>
	<div class="contentall">
		<div class="contentop">
			<img src="../imgae/poentop.png" />
			<div class="contmian">
				<el-image style="height: 100%" :src="formData.bg_image?formData.bg_image:url"></el-image>
				<div class="folats">
					<div class="folatmian">
						<div class="images">
							<div class="logons"><img style="background: 50%" :src="formData.image?formData.image:require('../imgae/logo.png')" /></div>
						</div>
						<div class="titlemian">{{formData.club_name}}</div>
					</div>
				</div>
			</div>
			<div class="conall">
				<div class="miantitle">品牌介绍</div>
				<div class="mianlincont">{{formData.desc}}</div>
			</div>
			<div class="conall">
				<div class="miantitle">联系方式</div>
				<div class="mianlincont2">{{formData.phone}}</div>
			</div>
			<div class="conall">
				<div class="miantitle">联系地址</div>
				<div class="mianlincont2">{{formData.addr}}</div>
			</div>
			<div class="conall">
				<div class="mianinit">
					<div>
						<div></div>
						<div>微信客服</div>
					</div>
					<div>{{formData.wechat}}</div>
				</div>
				<div class="mianinit">
					<div>
						<div></div>
						<div>公众号</div>
					</div>
					<div>{{formData.wechat_app}}</div>
				</div>
			</div>
			<div class="conall">
				<div class="miantitle">品牌详情</div>
				<div class="mianlincont1" id="content"  v-html="formData.content"></div>
			</div>

			<div class="conall">
				<div class="miantitle">赛事信息</div>
				<div class="mianlincont3"></div>
			</div>
		</div>
	</div>
</template>

<script>
import Bus from "@/components/common/bus";
export default {
	props: {
		imgae: {
			type: String,
			default: require('../imgae/banner.jpg')
		}
	},
	data() {
		return {
			url: this.imgae,
			formData:{
				image:'',	//string	俱乐部logo
				club_name:'',	//string	俱乐部名称
				bg_image:'',	//string	封面
				desc:'',	//string	简介 没有传空
				addr:'',	//string	地址 没有传空
				phone:'',	//string	手机联系手机
				wechat:'',	//string	微信号 没有传空
				wechat_app:'',	//string	公众号 没有就传空
				content:'',	//string	品牌介绍 没有就传空
			}
		};
	},
	created() {
		Bus.$on('toLeftAll',data=>this.dealWithRight(data))
	},
	methods:{
			dealWithRight(data){
				this.formData=data;
			}
	}
};
</script>
<style>
	#content{
		overflow:hidden;

	}
	#content img{
		width: 100%;
	}

</style>
<style scoped lang="less">
@co33: #333333;
@coF4: #f4f4f4;
@fs14: 14px;
.contentall {
	width: 100%;
	height: 100%;
	.contentop {
		border: 1px solid #e1e1e1;
		img {
			display: block;
		}
		.contmian {
			width: 100%;
			height: 176px;
			background: #f4f4f4;
			position: relative;
			.folats {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
				.folatmian {
					width: 100%;
					height: 60%;
					.images {
						width: 100%;
						height: 70%;
						display: flex;
						align-items: center;
						justify-content: center;
						.logons {
							width: 76px;
							height: 4.75rem;
							background: #ffffff;
							border-radius: 50%;
							display: flex;
							align-items: center;
							justify-content: center;
							img {
								display: block;
								width: 60px;
							}
						}
					}
					.titlemian {
						width: 100%;
						height: 30%;
						display: flex;
						align-items: center;
						justify-content: center;
						font-size: @fs14;
						color: #ffffff;
					}
				}
			}
		}
		.conall {
			width: 94%;
			padding: 2% 3% 3% 3%;
			.miantitle {
				height: 30px;
				color: @co33;
				font-size: @fs14;
			}
			.mianinit {
				height: 30px;
				color: @co33;
				font-size: @fs14;
				display: flex;
				justify-content: space-between;
			}
			.mianlincont {
				background: @coF4;
				min-height: 40px;
				padding: 2px 1%;
			}
			.mianlincont1 {
				background: @coF4;
				min-height: 50px;
				padding: 2px 1%;
			}

			.mianlincont2 {
				background: @coF4;
				min-height: 26px;
				padding: 2px 1%;
			}
			.mianlincont3 {
				background: @coF4;
				min-height: 110px;
				padding: 2px 1%;
			}
		}
	}
}
</style>
