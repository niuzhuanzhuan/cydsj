<template>
	<div class="mianall">
		<div class="minav">
			<div class="minavleft">
				<leftall/>
			</div>
			<div class="minrigth">
				<rigthall/>
			</div>
		</div>
	</div>
</template>

<script>
import leftall from './components/leftall.vue';
import rigthall from './components/rigthall.vue';
export default {
	components: {
		leftall,
		rigthall
	}
};
</script>
<style scoped lang="less">
.mianall {
	width: 100%;
	display: flex;
	align-items: flex-end;
	.minav {
		width: calc(100% - 20px);
		padding-left: 20px;
		height: calc(100% - 20px);
		background: #ffffff;
		padding-top: 20px;
		display: flex;
		.minavleft {
			width: 352px;
			height: 100%;
		}
		.minrigth {
			width: calc(100% - 352px);
		}
	}
}
</style>
