<template>
	<div class="page-main">
		<el-form class="cert-form" ref="certForm" :model="formData" label-position="right" label-width="140px" status-icon>
			<div class="form-area">
				<el-form-item label="企业logo:" prop="image" :error="msgArr.image" :rules="[{ required: true, message: '请上传企业logo', trigger: 'valid' }]">
					<image-uploader
						:width="84"
						:height="84"
						title="LOGO"
						square="提示：建议尺寸400*400，图片小于2M"
						:limit="['400*400']"
						:size="2"
						:imageUrl.sync="formData.image"
					></image-uploader>
				</el-form-item>
				<el-form-item label="联系电话:" prop="manage" :error="msgArr.manage" :rules="[{ required: true, trigger: 'change', validator: phones }]">
					<el-input v-model="formData.manage" placeholder="请输入联系人电话号码"></el-input>
				</el-form-item>
				<el-form-item label="营业执照:" prop="business_image" :error="msgArr.business_image" :rules="[{ required: true, message: '请上传营业执照', trigger: 'valid' }]">
					<image-uploader
						:width="112"
						:height="146"
						title="营业执照"
						square="提示：请上传营业执照，需年检章齐全，当年注册除外，并保证图片清晰、无反光等"
						:imageUrl.sync="formData.business_image"
					></image-uploader>
				</el-form-item>
				<el-form-item label="注册号:" prop="business_code" :error="msgArr.business_code" :rules="[{ required: true, message: '企业注册号不能为空', trigger: 'valid' }]">
					<el-input v-model="formData.business_code" placeholder="请输入请输入注册号"></el-input>
				</el-form-item>
				<el-form-item label="企业名称:" prop="company_name" :error="msgArr.company_name" :rules="[{ required: true, message: '企业名称不能为空', trigger: 'valid' }]">
					<el-input v-model="formData.company_name" placeholder="请输入企业名称"></el-input>
				</el-form-item>
				<el-form-item label="注册地址:" prop="business_addr" :error="msgArr.business_addr" :rules="[{ required: true, message: '企业注册地址不能为空', trigger: 'valid' }]">
					<el-input v-model="formData.business_addr" placeholder="请输入注册地址"></el-input>
				</el-form-item>
				<el-form-item
					prop="business_user_name"
					:error="msgArr.business_user_name"
					:rules="[{ required: true, message: '经营者姓名/法定代表人不能为空', trigger: 'valid' }]"
				>
					<span slot="label" class="spec-label">经营者姓名/法定代表人:</span>
					<template>
						<el-input v-model="formData.business_user_name" placeholder="请输入经营者姓名/法定代表人"></el-input>
					</template>
				</el-form-item>
				<el-form-item
					label="营业期限:"
					prop="business_start_time"
					:error="business_time_err_msg"
					:rules="[{ required: true, message: '营业期限不能为空', trigger: 'valid' }]"
				>
					<el-date-picker
						class="form-date-picker"
						v-model="formData.business_start_time"
						type="date"
						value-format="yyyy-MM-dd"
						placeholder="请选择营业开始日期"
					></el-date-picker>
					<el-date-picker
						class="form-date-picker"
						v-model="formData.business_end_time"
						:disabled="business_long_date"
						type="date"
						value-format="yyyy-MM-dd"
						placeholder="请选择营业结束日期"
					></el-date-picker>
					<el-checkbox v-model="business_long_date">长期</el-checkbox>
				</el-form-item>
			</div>
			<el-divider content-position="left" class="divider-line">法人信息</el-divider>
			<div class="form-area">
				<p class="form-tip">
					<i class="el-icon-warning-outline"></i>
					提示：请上传法人身份证/护照
				</p>
				<el-form-item label="证件类型:" :error="msgArr.id_card_type">
					<el-radio-group class="form-radio" v-model="formData.id_card_type">
						<el-radio label="中国大陆居民-身份证">中国大陆居民-身份证</el-radio>
						<el-radio label="中国香港居民-来往内地通行证">中国香港居民-来往内地通行证</el-radio>
						<el-radio label="中国澳门居民-来往内地通行证">中国澳门居民-来往内地通行证</el-radio>
						<el-radio label="中国台湾居民-来往大陆通行证">中国台湾居民-来往大陆通行证</el-radio>
						<el-radio label="其他国家或地区居民-护照">其他国家或地区居民-护照</el-radio>
					</el-radio-group>
				</el-form-item>
				<el-form-item
					label="身份证/护照:"
					prop="id_card_positive"
					:error="id_card_err_msg"
					:rules="[{ required: true, validator: idCardValid, message: '请上传身份证正反面', trigger: 'valid' }]"
				>
					<image-uploader class="form-inline-uploader" :width="140" :height="94" title="身份证/护照 正面" :imageUrl.sync="formData.id_card_positive"></image-uploader>
					<image-uploader :width="140" :height="94" title="身份证/护照 反面" :imageUrl.sync="formData.id_card_back"></image-uploader>
				</el-form-item>
				<el-form-item label="证件号码:" prop="id_card" :error="msgArr.id_card" :rules="[{ required: true, message: '证件号码不能为空', trigger: 'valid' }]">
					<el-input v-model="formData.id_card" placeholder="请输入证件号码"></el-input>
				</el-form-item>
				<el-form-item
					label="证件持有人姓名:"
					prop="id_card_name"
					:error="msgArr.id_card_name"
					:rules="[{ required: true, message: '证件持有人姓名不能为空', trigger: 'valid' }]"
				>
					<el-input v-model="formData.id_card_name" placeholder="请输入证件持有人姓名"></el-input>
				</el-form-item>
				<el-form-item
					label="证件有效期:"
					prop="id_card_start_time"
					:error="id_card_time_err_msg"
					:rules="[{ required: true, message: '证件有效期不能为空', trigger: 'valid' }]"
				>
					<el-date-picker
						class="form-date-picker"
						v-model="formData.id_card_start_time"
						type="date"
						value-format="yyyy-MM-dd"
						placeholder="请选择证件有效开始日期"
					></el-date-picker>
					<el-date-picker
						class="form-date-picker"
						v-model="formData.id_card_end_time"
						:disabled="idCard_long_date"
						type="date"
						value-format="yyyy-MM-dd"
						placeholder="请选择证件有效结束日期"
					></el-date-picker>
					<el-checkbox v-model="idCard_long_date">长期</el-checkbox>
				</el-form-item>
				<el-form-item label="是否为收益所有人:" :error="msgArr.is_price_user">
					<el-radio-group class="form-radio" v-model="formData.is_price_user">
						<el-radio label="1">是</el-radio>
						<el-radio label="2">
							<i class="form-icon el-icon-question"></i>
							否，非法定代表人/个体户经营者
						</el-radio>
					</el-radio-group>
				</el-form-item>
			</div>
			<el-divider content-position="left" class="divider-line">结算账户</el-divider>
			<div class="form-area">
				<p class="form-tip">
					<i class="el-icon-warning-outline"></i>
					你是企业，请务必填写开户名为商户名称的对公银行账户
				</p>
				<el-form-item label="账户类型:">对公账户</el-form-item>
				<el-form-item label="开户银行:" prop="bank_name" :error="msgArr.bank_name" :rules="[{ required: true, message: '开户银行不能为空', trigger: 'valid' }]">
					<el-select v-model="formData.bank_name" filterable placeholder="请选择开户银行">
						<el-option v-for="(item, index) in bank" :key="index" :label="item.name" :value="item.id"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="开户支行:" prop="bank_addr" :error="msgArr.bank_addr" :rules="[{ required: true, message: '开户支行详细名称不能为空', trigger: 'valid' }]">
					<el-input v-model="formData.bank_addr" placeholder="请输入开户支行详细名称"></el-input>
				</el-form-item>
				<el-form-item label="银行账号:" prop="bank_number" :error="msgArr.bank_number" :rules="[{ required: true, message: '银行账号不能为空', trigger: 'valid' }]">
					<el-input v-model="formData.bank_number" placeholder="请输入银行账号"></el-input>
				</el-form-item>
			</div>
			<div class="form-area"><el-button class="submit-btn" @click="submit">提交认证</el-button></div>
		</el-form>
	</div>
</template>

<script>
import imageUploader from '@/components/BaseComponents/imageUploader.vue';
import bank from './components/bank.js';
import define from '@/components/define/define';
export default {
	components: {
		imageUploader
	},
	data() {
		return {
			bank: bank.bank,
			formData: {
				image: '',
				company_name: '',
				manage: '',
				business_image: '',
				business_code: '',
				business_addr: '',
				business_start_time: '',
				business_end_time: '',
				business_user_name: '',
				id_card_type: '中国大陆居民-身份证',
				id_card_positive: '',
				id_card_back: '',
				id_card: '',
				id_card_name: '',
				id_card_start_time: '',
				id_card_end_time: '',
				is_price_user: '1',
				bank_name: '',
				bank_addr: '',
				bank_number: ''
			},
			msgArr: {}
		};
	},
	watch: {
		'formData.business_image'(newval, val) {
			if (newval != val || newval != '') {
				setTimeout(() => {
					this.distinguish('business', newval);
				}, 500);
			}
		},
		'formData.id_card_positive'(newval, val) {
			if (newval != val || newval != '') {
				if (this.formData.id_card_type == '中国大陆居民-身份证') {
					setTimeout(() => {
						this.distinguish('id_card', newval);
					}, 500);
				}
			}
		},
		'formData.id_card_back'(newval, val) {
			if (newval != val || newval != '') {
				if (this.formData.id_card_type == '中国大陆居民-身份证') {
					setTimeout(() => {
						this.distinguish('id_card', newval);
					}, 500);
				}
			}
		}
	},
	computed: {
		// 营业执照 期限是否长期
		business_long_date: {
			get: function() {
				return this.formData.business_end_time === null;
			},
			set: function(newValue) {
				this.formData.business_end_time = newValue ? null : '';
			}
		},
		// 证件 期限是否长期
		idCard_long_date: {
			get: function() {
				return this.formData.id_card_end_time === null;
			},
			set: function(newValue) {
				this.formData.id_card_end_time = newValue ? null : '';
			}
		},
		// 营业执照有效期 错误信息
		business_time_err_msg: {
			get: function() {
				let msg = [];
				if (this.msgArr.business_start_time) {
					msg.push(this.msgArr.business_start_time);
				}
				if (this.msgArr.business_end_time) {
					msg.push(this.msgArr.business_end_time);
				}
				return msg.join(',');
			}
		},
		// 身份证正反面 错误信息
		id_card_err_msg: {
			get: function() {
				let msg = [];
				if (this.msgArr.id_card_positive) {
					msg.push(this.msgArr.id_card_positive);
				}
				if (this.msgArr.id_card_back) {
					msg.push(this.msgArr.id_card_back);
				}
				return msg.join(',');
			}
		},
		// 身份证有效期 错误信息
		id_card_time_err_msg: {
			get: function() {
				let msg = [];
				if (this.msgArr.id_card_start_time) {
					msg.push(this.msgArr.id_card_start_time);
				}
				if (this.msgArr.id_card_end_time) {
					msg.push(this.msgArr.id_card_end_time);
				}
				return msg.join(',');
			}
		}
	},
	mounted() {
		// 处理回填数据
		this.$api.getCompanyAuth().then(res => {
			if (res.data.state !== 2 && res.data.state !== 8) {
				this.$message({ message: '已经提交企业认证，请等待审核', type: 'warning' });
				this.$router.replace('/certificationindex');
				return;
			}
			// 只有审核失败才进行数据回填操作
			if (res.data.state === 2) {
				this.refillData = res.data;
				const msgArr = [];
				// 分离出回填数据与错误信息
				const errorData = Object.entries(res.data)
					.map(([key, value]) => {
						if (typeof value === 'object') {
							msgArr.push([key, value.msg]);
							return [key, value.value];
						}
					})
					.filter(dt => dt !== undefined);

				this.msgArr = Object.fromEntries(msgArr);
				// console.log(this.msgArr);
				const tempErrorData = Object.fromEntries(errorData);
				// 预先处理结束日期字段
				tempErrorData.business_end_time = tempErrorData.business_end_time === '0' ? null : tempErrorData.business_end_time;
				tempErrorData.id_card_end_time = tempErrorData.id_card_end_time === '0' ? null : tempErrorData.id_card_end_time;
				this.formData = tempErrorData;
			}
		});
	},
	methods: {
		async distinguish(data, image) {
			const fromdata = {};
			if (data == 'business') {
				this.$set(fromdata, 'type', data);
				this.$set(fromdata, 'image_url', image);
				const datalist = await this.$api.getOcrInfo(fromdata);
				if (datalist) {
					let faose = true;
					delete datalist.data.words_result['实收资本'];
					delete datalist.data.words_result['注册资本'];
					delete datalist.data.words_result['登记机关'];
					delete datalist.data.words_result['组成形式'];
					delete datalist.data.words_result['类型'];
					delete datalist.data.words_result['证件编号'];
					delete datalist.data.words_result['税务登记号'];
					delete datalist.data.words_result['经营范围'];
					for (let item in datalist.data.words_result) {
						if (datalist.data.words_result[item].words == '无') {
							datalist.data.words_result[item].words = '';
							faose = false;
						}
					}
					if (faose == false) {
						this.$message.warning({
							message: '您上传的营业执照部分信息无法识别，请手动输入相关信息',
							duration: 5000
						});
					}
					this.$set(this.formData, 'business_code', datalist.data.words_result['社会信用代码'].words);
					this.$set(this.formData, 'company_name', datalist.data.words_result['单位名称'].words);
					this.$set(this.formData, 'business_addr', datalist.data.words_result['地址'].words);
					this.$set(this.formData, 'business_user_name', datalist.data.words_result['法人'].words);
					this.$set(this.formData, 'business_start_time', this.sliceinit(datalist.data.words_result['成立日期'].words));
					if (datalist.data.words_result['有效期'].words == '长期') {
						this.business_long_date = true;
					} else if (datalist.data.words_result['有效期'].words == '无') {
						this.$set(this.formData, 'business_end_time', '');
					} else {
						this.$set(this.formData, 'business_end_time', this.sliceinit(datalist.data.words_result['有效期'].words));
					}
				}
			} else {
				this.$set(fromdata, 'type', data);
				this.$set(fromdata, 'image_url', image);
				const datalist = await this.$api.getOcrInfo(fromdata);
				if (datalist) {
					if (datalist.data.words_result.length != 0) {
						if (datalist.data.words_result['公民身份号码']) {
							this.$set(this.formData, 'id_card', datalist.data.words_result['公民身份号码'].words);
						}
						if (datalist.data.words_result['姓名']) {
							this.$set(this.formData, 'id_card_name', datalist.data.words_result['姓名'].words);
						}
						if (datalist.data.words_result['签发日期']) {
							let initmian = datalist.data.words_result['签发日期'].words;
							let inse = '';
							inse += initmian.slice(0, 4) + '-' + initmian.slice(4, 6) + '-' + initmian.slice(6, 8);
							this.$set(this.formData, 'id_card_start_time', inse);
						}
						if (datalist.data.words_result['失效日期']) {
							if (datalist.data.words_result['失效日期'].words == '长期') {
								this.idCard_long_date = true;
							} else {
								let initmian = datalist.data.words_result['失效日期'].words;
								let inse = '';
								inse += initmian.slice(0, 4) + '-' + initmian.slice(4, 6) + '-' + initmian.slice(6, 8);
								this.$set(this.formData, 'id_card_end_time', inse);
							}
						}
					} else {
						this.$message.warning({
							message: '您上传的身份证信息无法识别，请手动输入相关信息',
							duration: 5000
						});
					}
				}
			}
		},
		sliceinit(data) {
			let insetd = '';
			let reg = new RegExp('[\\u4E00-\\u9FFF]+', 'g');
			for (let var1 in data) {
				if (reg.test(data[var1])) {
					insetd += '-';
				} else {
					insetd += data[var1];
				}
			}
			return (insetd = insetd.slice(0, insetd.length - 1));
		},
		// 提交数据
		submit() {
			this.$refs['certForm'].validate(valid => {
				if (valid) {
					this.$api.companyAuth(this.formData).then(res => {
						if (res.code === 1) {
							this.$router.replace('/certificationindex');
						} else {
							console.log(res);
						}
					});
				} else {
					this.$message({ message: '请完整填写必要信息', type: 'warning' });
				}
			});
		},
		// 身份证正反面校验规则
		idCardValid(rules, value, cb) {
			let { id_card_back } = this.formData;
			if (!value || !id_card_back) {
				return cb(new Error('请上传身份证正反面!'));
			}
			return cb();
		},
		phones(rule, value, callback) {
			if (!value) {
				return callback(new Error('企业联系人电话号码不能为空!'));
			} else {
				let isPhone = /^([0-9]{3,4}-)?[0-9]{7,8}$/;
				if (define.phone.test(value) || isPhone.test(value)) {
					return callback();
				} else {
					return callback(new Error('请输入正确的电话号码!'));
				}
			}
		}
	}
};
</script>

<style scoped>
.cert-form >>> .el-divider__text {
	font-weight: bold;
}
</style>

<style lang="less" scoped>
.cert-form {
	padding: 20px 0 40px;

	.form-area {
		width: 820px;
		margin: 0 auto;
	}
	// 过长label的特殊样式
	.spec-label {
		width: 74px;
		display: inline-block;
		line-height: 16px;
	}
	// 表单内提示语
	.form-tip {
		margin: 20px 0;
		font-size: 12px;
		color: #999999;

		i {
			margin-right: 5px;
			color: #3861db;
		}
	}
	.form-mini-tip {
		margin: 0;
		font-size: 12px;
		color: #999999;
	}
	// 单选
	.form-radio {
		line-height: 32px;

		.form-icon {
			border-radius: 14px;
			color: white;
			background-color: #3861db;
			font-size: 14px !important;
		}
	}
	// 日期选择
	.form-date-picker {
		margin-right: 20px;
	}
	// 下拉框
	.form-select {
		width: 100%;
	}
	// 行内下拉框
	.form-mini-select {
		width: 200px;
		margin-right: 20px;
	}
	// 行内输入框
	.form-mini-input {
		width: 240px;
	}
	// 单行多个上传
	.form-inline-uploader {
		margin-right: 20px;
	}
	.submit-btn {
		width: 160px;
		margin-left: calc(50% - 60px);
		background-color: #3861db;
		color: white;
		font-size: 16px;
	}
}
</style>
