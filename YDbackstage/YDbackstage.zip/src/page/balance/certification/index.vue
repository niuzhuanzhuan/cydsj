<template>
	<div class="page-main">
		<tip-enter :status="status"></tip-enter>
	</div>
</template>

<script>
	import tipEnter from './components/tipEnter.vue'
	
	export default {
		components:{
			tipEnter,
		},
		data() {
			return {
				status:0,
			}
		},
		mounted() {
			// 处理回填数据
			this.$api.getCompanyAuth().then(res => {
				// console.log(res);
				if(res.code === 1){
					const state = res.data.state;
					if(state === 8){
						this.status = 0;
						return ;
					} else if(state === 4){
						this.status = 1;
						return ;
					}else if(state === 2){
						this.status = 2;
					}else{
						this.$message.success("您当前审核状态已通过,请您重新登陆")
						setTimeout(()=>{
							this.$router.replace('/Login');
						},1000)
					}
				}
			})
		},
		methods:{
			
		}
	}
</script>

<style scoped>
	.page-main{
		background-color: white;
		width: 100%;
		height: 100%;
	}
</style>
