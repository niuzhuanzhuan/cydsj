<template>
	<div class="component-main">
		<img :src="require(`@/assets/imgs/certification/certification_${status}.png`)" />
		<div class="tip-title">{{titleEnum[status]}}</div>
		<div class="tip-content">
			<template v-if="status === 0">
				<p>需准备材料：1：企业营业执照 2：法人身份证图片</p>
				<div class="_button" @click="toSubmit">去认证</div>
			</template>
			<template v-else-if="status === 1">
				<p>恭喜您已经成功提交了永动力平台企业认证资料，审核时间大概3-5个工作日，审核成功会用短信通知您！</p>
			</template>
			<template v-else>
				<p>抱歉，您的认证资料<span class="_red">审核未通过</span>，请仔细检查您的审核资料可 <span class="_link" @click="toSubmit">重新认证</span></p>
			</template>
		</div>
	</div>
</template>

<script>
	export default {
		props:{
			// 认证状态
			status:{
				type:Number,
				default:0,
			}
		},
		data() {
			return {
				titleEnum: ['企业认证','提交完成','认证失败'],
			}
		},
		methods:{
			// 跳转认证提交页面
			toSubmit(){
				this.$router.push({path:'/certification/submit'});
			}
		}
	}
</script>

<style lang="less" scoped>
	.component-main{
		display: flex;
		flex-direction: column;
		align-items: center;
		margin: 0 auto;
		padding-top: 200px;
		width: 400px;
		color: #333333;
		
		.tip-title{
			font-size: 18px;
			margin: 20px 0;
			font-weight: bold;
		}
		.tip-content{
			width: 100%;
			
			p{
				text-align: center;
				font-size: 12px;
			}
			
			._red{
				color: #FF3131;
			}
			._link{
				color: #3861DB;
				cursor: pointer;
				
				&:hover{
					text-decoration: underline;
				}
			}
			
			._button{
				width: 100%;
				height: 40px;
				line-height: 40px;
				margin-top: 20px;
				border-radius: 4px;
				color: white;
				background-color: #3861DB;
				text-align: center;
				cursor: pointer;
				transition: background-color .3s;
				
				&:hover{
					background-color: #3f70f8;
				}
			}
		}
		
	}
</style>
