<template>
	<div class="component-main">
		<div class="type-icon-bar">
			<svg class="icon type-icon" aria-hidden="true">
			    <use xlink:href="#el-icon-addednan"></use>
			</svg>
			<svg class="icon type-icon" aria-hidden="true">
			    <use xlink:href="#el-icon-addednv"></use>
			</svg>
		</div>
		<div class="type-per-bar">
			<div class="type-per-body type-per-handle" :style="{width:sexPer + '%'}" >
				<span>男</span>
				<span>{{sexPer}}%</span>
			</div>
			<div class="type-per-body">
				<span>{{100 - sexPer }}%</span>
				<span>女</span>
			</div>
		</div>
		<div class="type-process-bar">
			<div class="type-process-body" :style="{width:sexPer + '%'}"></div>
		</div>
		<div class="type-count-bar">
			<span>{{this.boy}}人</span>
			<span>{{this.girl}}人</span>
		</div>
	</div>
</template>

<script>
	export default {
		props:{
			boy:{ 
				type:Number,
				default:0,
			},
			girl:{
				type:Number,
				default: 0,
			}
		},
		computed:{
			// 百分比
			sexPer:function(){
				if(this.boy === 0 && this.girl === 0){
					return 50;
				}
				if(this.boy === 0){
					return 0;
				}
				if(this.girl === 0){
					return 100;
				}
				return (this.boy / (this.boy + this.girl) * 100 ).toFixed(0);
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	.icon {
		width: 1em; 
		height: 1em;
		vertical-align: -0.15em;
		fill: currentColor;
		overflow: hidden;
	}
	
	.component-main{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	// 图标
	.type-icon-bar{
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 80%;
		
		.type-icon{
			font-size: 80px;
		}
	}
	// 百分比数字
	.type-per-bar{
		display: flex;
		width: 80%;
		
		.type-per-body{
			flex-grow: 1;
			min-width: 80px;
			padding: 0 30px 0 5px;
			display: inline-flex;
			justify-content: space-between;
			align-items: center;
			color: #FF6B98;
		}
		.type-per-handle{
			padding: 0 5px 0 30px;
			flex-grow: 0;
			color: #79B4FF;
		}
	}
	// 百分比进度条
	.type-process-bar{
		position: relative;
		width: 80%;
		height: 8px;
		margin: 10px 0;
		border-radius: 4px;
		background-color: #FF6B98;
		
		.type-process-body{
			position: absolute;
			top: 0;
			left: 0;
			max-width: 99%;
			height: 8px;
			border-radius: 4px ;
			background-color: #79B4FF;
		}
	}
	// 实际数字
	.type-count-bar{
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 80%;
		padding: 0 26px;
		
		span{
			color: #FF6B98;
			
			&:first-of-type{
				color: #79B4FF;
			}
		}
	}
</style>
