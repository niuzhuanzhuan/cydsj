<template>
	<div class="total-box">
		<p class="box-label">
			<!-- <el-tooltip class="item" effect="dark" :content="alt" >
			      <i class="el-icon-question"></i>
			</el-tooltip> -->
			{{label}}
		</p>
		<p class="box-content"><slot>0</slot></p>
	</div>
</template>

<script>
	export default {
		props:{
			label:{
				type:String,
			},
			alt:{
				type:String,
			}
		}
	}
</script>

<style lang="less" scoped>
	.total-box{
		flex-grow: 1;
		padding-left: 20px;
		border-right: solid 1px #E4E7ED;
		
		&:last-of-type{
			border: none;
		}
		
		.box-label{
			font-size: 12px;
			color: #999999;
			i{
				font-size: 12px !important;
				color: #3861DB;
			}
		}
		.box-content{
			font-size: 16px;
			color: #333333;
			
			span{
				font-size: 14px;
				color: #999999;
			}
		}
	}
</style>
