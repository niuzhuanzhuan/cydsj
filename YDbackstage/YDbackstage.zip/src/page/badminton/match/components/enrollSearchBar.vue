<template>
	<div class="component-main">
		<div class="search-form">
			<div class="search-field">
				<span class="search-label">订单编号:</span>
				<el-input v-model="searchData.out_trade_no" size="mini" placeholder="请输入订单编号"></el-input>
			</div>
			<div class="search-field">
				<span class="search-label">参赛者姓名:</span>
				<el-input v-model="searchData.user_name" size="mini" placeholder="请输入参赛者姓名"></el-input>
			</div>
			<div class="search-field">
				<span class="search-label">参赛者性别:</span>
				<el-select v-model="searchData.sex" size="mini" placeholder="请选择参赛者性别">
					<el-option label="男" value="1"></el-option>
					<el-option label="女" value="2"></el-option>
				</el-select>
			</div>
			<div class="search-field">
				<span class="search-label">参赛者证件号码:</span>
				<el-input v-model="searchData.id_card" size="mini" placeholder="请输入参赛者证件号码"></el-input>
			</div>
			<div class="search-field">
				<span class="search-label">手机号:</span>
				<el-input v-model="searchData.phone" size="mini" placeholder="请输入手机号"></el-input>
			</div>
			<div class="search-field">
				<span class="search-label">订单状态:</span>
				<el-select v-model="searchData.state" size="mini" placeholder="请选择订单状态">
					<el-option label="报名成功" value="1"></el-option>
					<el-option label="退款中" value="6"></el-option>
					<el-option label="退款成功" value="7"></el-option>
					<el-option label="退款失败" value="8"></el-option>
				</el-select>
			</div>
		</div>
		<div class="search-ctrl">
			<el-button class="search-btn" type="primary" size="mini" @click="search">搜索</el-button>
			<el-button size="mini" @click="reset">重置</el-button>
		</div>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				searchData:{
					out_trade_no:'',
					user_name:'',
					sex:'',
					id_card:'',
					phone:'',
					state:'',
				}
			}
		},
		methods:{
			search(){
				this.$emit('search',this.searchData);
			},
			
			reset(){
				this.searchData = {
					out_trade_no:'',
					user_name:'',
					sex:'',
					id_card:'',
					phone:'',
					state:'',
				};
				this.$emit('search',this.searchData);
			}
		}
	}
</script>

<style lang="less" scoped>
	.component-main{
		padding: 20px;
		background-color: #FBFBFB;
		border: solid 1px #E8E8E8;
	}
	
	.search-form{
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		
		.search-field{
			display: inline-flex;
			align-items: center;
			width: 33.3%;
			margin-bottom: 10px;
			
			.search-label{
				flex-basis: 150px;
				margin-right: 10px;
				text-align: right;
				font-size: 14px;
			}
		}
	}
	.search-ctrl{
		text-align: right;
		
		.search-btn{
			background-color: #3861DB;
		}
	}
	
</style>
