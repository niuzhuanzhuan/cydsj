<template>
	<div class="page-main">
		<img v-if="listData.length === 0" class="table-empty" src="@/assets/imgs/empty_table.png" />
		<div v-else class="insurance-box" v-for="(item,index) of listData" :key="index">
			<!-- <div class="insurance-tag">{{item.name}}</div> -->
			<div class="insurance-tag">羽毛球</div>
			<img :src="item.image" class="insu-cover">
			<div class="insu-content">
				<p class="insu-title">{{item.title}}</p>
				<p class="insu-sub-title"><span v-if="item.date">保障期限：{{item.date}}</span><span v-if="item.age">承保年龄：{{item.age}}</span><span v-if="item.red_value !== ''" class="_red">★{{item.red_value}}</span></p>
				<div class="insu-info">
					<div class="insu-list">
						<p v-for="(pot,jindex) of item.detail" :key="jindex">{{pot.name}}：{{pot.value}}</p>
					</div>
					<div class="insu-path">
						<p class="insu-price">￥{{item.price}}<span>/天</span></p> 
						<el-button type="primary" class="goto-btn" @click="toLink(item)">我要投保</el-button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	
	export default {
		data() {
			return {
				listData: [],
			}
		},
		created() {
			const query = this.$route.query;
			let play_type = query.play_type !== undefined ? query.play_type : 1
			this.$api.getInsurance({play_type:play_type}).then(res => {
				// console.log(res);
				if(res.code === 1){
					this.listData = res.data;
				}
			})
		},
		methods:{
			toLink(item){
				window.open(item.url);
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	.page-main{
		width: 100%;
		min-height: 100%;
		padding: 20px;
		background-color: #F4F4F4;
	}
	.table-empty{
		margin: 20px 0;
		margin-left: calc(50% - 30px);
	}
	
	.insurance-box{
		position: relative;
		display: flex;
		justify-content: space-between;
		width: 100%;
		background-color: white;
		margin-bottom: 20px;
		
		&:last-child{
			margin-bottom: 0;
		}
		// 左上标签
		.insurance-tag{
			position: absolute;
			left: 0;
			top: 20px;
			height: 30px;
			line-height: 30px;
			padding:0 10px 0 20px;
			font-size: 14px;
			color: white;
			background: url(../../../assets/imgs/tag.png) no-repeat;
			background-size: 100% 30px;
		}
		// 封面
		.insu-cover{
			width: 480px;
			height: 270px;
		}
		// 标题
		.insu-content{
			width: calc(100% - 480px);
			height: 270px;
			padding: 20px;
			
			.insu-title{
				font-size: 20px;
				line-height: 30px;
				color: #333333;
			}
			.insu-sub-title{
				margin: 10px 0;
				font-size: 14px;
				line-height: 20px;
				color: #999999;
				span{
					margin-right: 10px;
				}
				._red{
					color: #FF4F4F;
				}
			}
		}
		// 列表项
		.insu-info{
			height: calc(100% - 70px);
			display: flex;
			justify-content: stretch;
			align-items: stretch;
			
			.insu-list{
				flex-grow: 2;
				display: inline-flex;
				flex-wrap: wrap;
				flex-direction: column;
				justify-content: flex-start;
				align-items: flex-start;
				font-size: 14px;
				
				p{
					line-height: 24px;
				}
			}
			// 右侧价格按钮
			.insu-path{
				flex-basis: 240px;
				display: inline-flex;
				flex-direction: column;
				justify-content: flex-end;
				align-items: center;
				
				.insu-price{
					font-size: 30px;
					color: #3861DB;
					span{
						font-size: 14px;
					}
				}
				.goto-btn{
					background-color: #3861DB;
					width: 160px;
					font-size: 20px;
					margin-top: 20px;
				}
			}
			
		}
	}
</style>
