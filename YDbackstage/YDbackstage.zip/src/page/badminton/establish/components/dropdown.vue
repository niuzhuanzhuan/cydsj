<template>
	<div class="miaconst">
		<div class="mianinit">
			<i class="el-icon-fork-spoon"></i>
			<el-checkbox v-model="domian.must">必填</el-checkbox>
			<el-input placeholder="标题" v-model="domian.name" class="mininput"></el-input>
			<el-input placeholder="可在此填写标题信息" v-model="domian.placeholder" class="mininput1"></el-input>
			<el-popover placement="bottom" width="160" v-model="visible">
				<p>确认删除该组件？</p>
				<div style="text-align: right; margin: 0">
					<el-button size="mini" type="text" @click="visible = false">取消</el-button>
					<el-button type="primary" size="mini" @click="determine">确定</el-button>
				</div>
				<i class="el-icon-delete" slot="reference"></i>
			</el-popover>
		</div>
		<div class="g-title">下拉选项列表</div>
		<div class="titlemians">
			<div class="itemindex" v-for="(item, index) in domian.list" :key="index">
				<el-input placeholder="选项名称" v-model="item.value" class="minintkey"></el-input>
				<el-popover placement="bottom" width="160" v-model="item.visible">
					<p>确认删除该组件？</p>
					<div style="text-align: right; margin: 0">
						<el-button size="mini" type="text" @click="item.visible = false">取消</el-button>
						<el-button type="primary" size="mini" @click="removeDomain(item)">确定</el-button>
					</div>
					<i class="el-icon-delete" slot="reference"></i>
				</el-popover>
			</div>
			<div class="itemindex"><el-button class="mianbonts" icon="el-icon-plus" @click="addDomain"></el-button></div>
		</div>
	</div>
</template>

<script>
export default {
	name:"dropdown",
	props:{
		fromkey:{
			type:Number,
			default:0
		},
		sign:{
			type:String,
			default:''
		}
	},
	data() {
		return {
			visible: false,
			indexkey:0,
			domian:{
				type:"select",
				sign:this.sign,
				list:[],
				must:false,
				placeholder:'',
				content:''
			},
		};
	},
	mounted() {
		this.indexkey=this.fromkey
	},
	methods:{
		determine(){
			this.$emit('control',this.indexkey)
		},
		addDomain() {
			this.domian.list.push({
				visible:false,
				value:'',
				key: Date.now()
			});
		},
		removeDomain(item) {
			var index = this.domian.list.indexOf(item);
			if (index !== -1) {
				this.domian.list.splice(index, 1);
			}
		}
	}
};
</script>
<style scoped>
* >>> .el-input--small .el-input__inner {
	height: 32px !important;
	line-height: 32px !important;
}
</style>
<style lang="less" scoped>
.g-title {
	font-size: 16px;
	color: #222;
	margin-top: 12px;
	margin-left: 76px;
}
.el-icon-delete {
	margin-left: 8px;
	cursor: pointer;
	&:hover {
		color: #409eff;
	}
}
.titlemians {
	margin-top: 12px;
	margin-left: 76px;
	display: flex;
	flex-direction: row;
	flex-wrap: wrap;
	.itemindex {
		width: 122px;
		margin-right: 8px;
		height: 40px;
		display: flex;
		.mianbonts {
			width: 32px;
			height: 32px;
			display: flex;
			justify-content: center;
			align-items: center;
		}
		.minintkey {
			width: 100px;
			margin-right: 8px;
		}
		.el-icon-delete {
			line-height: 32px;
		}
	}
}
.miaconst {
	width: 100%;
	padding: 24px 0;
	border-bottom: 1px solid #e5e5e5;
	cursor: pointer;
	&:hover {
		background: #e6f7ff;
	}
	.mianinit {
		width: 100%;
		display: flex;
		align-items: center;
		i {
			margin-right: 8px;
		}
		.mininput {
			margin-left: 8px;
			width: 150px;
		}
		.mininput1 {
			margin-left: 8px;
			width: 300px;
		}
	}
}
</style>
