<template>
	<div class="initmian">
		<div class="inittip">
			<span>赛事详情</span>
			<span>
				<el-popover placement="bottom-start" v-model="visible" width="532" trigger="click">
					<div class="toptitle">导入文章</div>
					<div class="mianlist">请输入微信公众号的网页地址：</div>
					<div class="mianiuptu"><el-input v-model="url" placeholder="请输入文章链接"></el-input></div>
					<div class="mianiuptus">
						<el-button type="primary" @click="determine">确定</el-button>
						<el-button @click="visible = false">取消</el-button>
					</div>
					<el-button slot="reference" type="primary" style="background-color: #3861DB;font-size: 16px;">快速导入文章</el-button>
				</el-popover>
			</span>
		</div>
		<div class="consts">
			<div class="mianue"><ue ref="ues" :height="750" /></div>
		</div>
	</div>
</template>

<script>
import ue from '@/components/common/ueditor.vue';
export default {
	name:'match',
	data() {
		return {
			visible: false,
			url: ''
		};
	},
	components: {
		ue
	},
	methods: {
		async determine() {
			if (this.url=="") {
				this.$message.error('链接不能为空');
				return false;
			}
			var reg = /^([hH][tT]{2}[pP]:\/\/|[hH][tT]{2}[pP][sS]:\/\/)(([A-Za-z0-9-~]+)\.)+([A-Za-z0-9-~\/])+$/;
			if (!reg.test(this.url)) {
				this.$message.error('您当前输入不是以http://https://开头，或者不是网址！');
				return false;
			}
			this.visible=false
			const datalist = await this.$api.getContent({ url: this.url });
			if (datalist) {
				this.$nextTick(() => {
					this.$refs.ues.values = datalist.data;
				});
			}
		}
	}
};
</script>

<style lang="less" scoped>
.toptitle {
	min-width: 177px;
	margin: 0;
	padding: 5px 16px 4px;
	color: rgba(0, 0, 0, 0.85);
	font-weight: 500;
	border-bottom: 1px solid #e8e8e8;
}
.mianlist {
	padding: 12px 16px;
	color: rgba(0, 0, 0, 0.65);
}
.mianiuptu {
	padding: 0 16px;
}
.mianiuptus {
	padding: 12px 16px;
}
.initmian {
	width: 100%;
	min-width: 1300px;
	.inittip {
		padding: 20px 0 20px 40px;
		span {
			&:nth-child(1) {
				font-size: 14px;
				color: #333333;
				font-weight: bold;
			}
			&:nth-child(2) {
				margin-left: 30px;
			}
		}
	}
	.consts {
		width: calc(100% - 125px);
		padding: 5px 0 25px 125px;
		.mianue {
			width: 100%;
		}
	}
}
</style>
