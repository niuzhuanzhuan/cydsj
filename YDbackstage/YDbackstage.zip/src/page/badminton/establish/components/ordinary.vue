<template>
	<div class="initmian">
		<div class="inmiand">
			<div class="litow">组别名称</div>
			<div class="litow">快速生成日期（可选）</div>
			<div class="lithere">出生日期（开始）</div>
			<div class="lithere">出生日期（结束）</div>
			<div class="limafour">性别限制</div>
			<div class="limafour">价格（元）</div>
			<div class="limafour">名额</div>
		</div>
		<div class="minanoe">
			<div class="proinst">
				<div class="mianpro">批量设置：</div>
				<div class="mianpro">
					<div class="mianlig"><el-input v-model="price" show-word-limit placeholder="价格20000以内"></el-input></div>
				</div>
				<div class="mianpro">
					<div class="mianlig">
						<div class="miirgth"><el-input v-model.number="limit" maxlength="4" show-word-limit placeholder="名额" autocomplete="off"></el-input></div>
						<div style="width: 30%;"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="incont" v-for="(item, index) in datalist" :key="index" v-dragging="{ item: item, list: datalist, group: 'item' }">
			<div class="litow">
				<div><el-input v-model="item.name" placeholder="分组名"></el-input></div>
			</div>
			<div class="litow">
				<div>
					<el-select v-model="item.age_start" @change="ageval(item, item.age_start)">
						<el-option v-for="(items, jindex) in item.datainit" :key="jindex" :label="items.name" :value="items.name"></el-option>
					</el-select>
					<span style="padding: 0 5px;">至</span>
					<el-select v-model="item.age_end" @change="age_ends(item, item.age_end, item.age_start)">
						<el-option v-for="(items, kindex) in item.arrage_end" :key="kindex" :label="items.name" :value="items.name"></el-option>
					</el-select>
				</div>
			</div>
			<div class="lithere">
				<div><el-date-picker type="date" value-format="yyyy-MM-dd" v-model="item.age_date_start" placeholder="出生日期(开始)"></el-date-picker></div>
			</div>
			<div class="lithere">
				<div><el-date-picker type="date" value-format="yyyy-MM-dd" v-model="item.age_date_end" placeholder="出生日期(结束)"></el-date-picker></div>
			</div>
			<div class="limafour">
				<div>
					<el-select v-model="item.sex" placeholder="请选择性别">
						<el-option label="男" :value="1"></el-option>
						<el-option label="女" :value="2"></el-option>
						<el-option label="不限" :value="0"></el-option>
					</el-select>
				</div>
			</div>
			<div class="limafour">
				<div><el-input v-model="item.price" placeholder="价格20000以内"></el-input></div>
			</div>
			<div class="limafour">
				<div>
					<div class="mianlig">
						<div class="miirgth"><el-input maxlength="4" show-word-limit v-model="item.limit" placeholder="名额"></el-input></div>
						<div style="width: 30%;"><el-button type="text" style="font-size: 18px;" icon="el-icon-delete" @click.prevent="removeDomain(item)"></el-button></div>
					</div>
				</div>
			</div>
		</div>
		<div class="mianfert">
			<div class="lingbonmt"><el-button type="primary" @click="addDomain" icon="el-icon-plus" style="background-color: #3861DB;font-size: 16px;">添加分组</el-button></div>
			<div class="fonsts">
				<i class="el-icon-warning-outline"></i>
				报名开始前3小时内不能修改已创建分组的价格和名额；报名开始前3小时内不能删除已创建的分组；报名截止前可以随时增加新的分组信息。
			</div>
		</div>
	</div>
</template>

<script>
import * as frominit from './index';
import define from '@/components/define/define';
export default {
	name: 'ordinary',
	props: {
		is_birthday: {
			type: Number,
			default: 1
		}
	},
	data() {
		return {
			datalist: [],
			limit: '',
			price: '',
			ids: 1,
			datainit: [],
			arrage_end: [],
			birth: 1
		};
	},
	watch: {
		is_birthday(newval) {
			this.birth = newval;
		},
		limit(newval, val) {
			this.datalist.map(item => {
				item.limit = newval;
			});
		},
		price(newval) {
			this.price = newval.replace(/\D/g, '');
			this.price = this.price <= 20000 ? this.price : this.price.substring(0, 1) == 1 ? this.price.substring(0, 5) : this.price.substring(0, 4);
			if (this.price <= 20000) {
				this.datalist.map(item => {
					item.price = newval;
				});
			}
		}
	},
	methods: {
		ageval(iteminits, data) {
			this.$set(iteminits, 'age_end', '');
			this.$set(iteminits, 'age_date_start', '');
			this.$set(iteminits, 'age_date_end', '');
			let indexs = iteminits.datainit.findIndex(item => item.name == data);
			let inarr = [];
			for (let i = 0; i < iteminits.datainit.length; i++) {
				if (i > indexs) {
					inarr.push(iteminits.datainit[i]);
				}
			}
			iteminits.arrage_end = inarr;
		},
		age_ends(iteminits, data, age_start) {
			if (sessionStorage['match_time']) {
				let match_time = JSON.parse(sessionStorage['match_time']);
				let starts = '';
				let endtiem = '';
				if (age_start) {
					iteminits.datainit.forEach(item => {
						if (item.name === age_start) {
							let age_date_start = define.getPreMonthDay(define.year(match_time), item.index*12);
							if (this.is_birthday == 1) {
								starts = age_date_start;
							} else {
								starts = define.year(define.gettate(age_date_start) - 24 * 3600 * 1000);
							}
							this.$set(iteminits, 'age_date_end', starts);
						}
						if (item.name === data) {
							let age_date_end = define.getPreMonthDay(define.year(match_time), item.index * 12);
							if (this.is_birthday == 1) {
								endtiem = define.year(define.gettate(age_date_end) + 24 * 3600 * 1000);
							} else {
								endtiem = age_date_end;
							}
							this.$set(iteminits, 'age_date_start', endtiem);
						}
					});
				}
			}
		},
		addDomain() {
			this.ids += 1;
			let limitnum = this.limit == '' ? '' : this.limit;
			let pricenum = '';
			if (this.price != '') {
				pricenum = this.price;
			}
			this.datalist.push({
				name: '',
				price: pricenum,
				limit: limitnum,
				age_date_start: '',
				age_date_end: '',
				age_start: '',
				age_end: '',
				sex: 0,
				datainit: frominit.default.datainit,
				arrage_end: frominit.default.datainit,
				key: Date.now()
			});
		},
		removeDomain(item) {
			var index = this.datalist.indexOf(item);
			if (index !== -1) {
				this.datalist.splice(index, 1);
			}
		}
	},
	mounted() {
		this.$dragging.$on('dragged', ({ value }) => {
			if (this.ids != 1) {
				console.log(value);
			}
		});
	}
};
</script>

<style lang="less" scoped>
i {
	color: #3861db;
	padding-right: 10px;
}
.mianlig {
	width: 90%;
	display: flex;
	.miirgth {
		width: 70%;
	}
}
.mianfert {
	width: 100%;
	height: 200px;
	.lingbonmt {
		width: 100%;
		height: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.fonsts {
		width: 100%;
		height: 50%;
		display: flex;
		justify-content: center;
		font-size: 14px;
		color: #333333;
		i {
			font-size: 16px;
			line-height: 20px;
		}
	}
}
.initmian {
	width: 100%;
	min-width: 1300px;
	.minanoe {
		width: 100%;
		height: 56px;
		display: flex;
		justify-content: flex-end;
		.proinst {
			width: 30%;
			height: 100%;
			display: flex;
			justify-content: space-around;
			.mianpro {
				width: 34%;
				height: 100%;
				display: flex;
				align-items: center;
				color: #333333;
				&:nth-child(3) {
					width: 33%;
				}
				&:nth-child(1) {
					justify-content: flex-end;
				}
			}
		}
	}
	.incont {
		width: 100%;
		height: 56px;
		display: flex;
		cursor: pointer;
		&:hover {
			background: #e6f7ff;
		}
		div {
			height: 100%;
			display: flex;
			align-items: center;
			color: #333333;
		}
		.litow {
			width: 20%;
			div {
				width: 90%;
			}
		}
		.lithere {
			width: 15%;
			div {
				width: 90%;
			}
		}
		.limafour {
			width: 10%;
			div {
				width: 96%;
			}
		}
	}
	.inmiand {
		width: 100%;
		height: 56px;
		background: #fafafa;
		border-bottom: 1px solid #e8e8e8;
		display: flex;
		div {
			height: 100%;
			display: flex;
			align-items: center;
			color: #333333;
		}
		.litow {
			padding-left: 20px;
			width: calc(20% - 20px);
		}
		.lithere {
			width: 15%;
		}
		.limafour {
			width: 10%;
		}
	}
}
</style>
