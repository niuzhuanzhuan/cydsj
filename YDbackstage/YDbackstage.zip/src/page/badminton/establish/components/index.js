const ESTAs={
	datainit:[
		{
			name: '1岁',
			index:1
		},
		{
			name: '1岁半',
			index:1.5
		},
		{
			name: '2岁',
			index:2
		},
		{
			name: '2岁半',
			index:2.5
		},
		{
			name: '3岁',
			index:3
		},
		{
			name: '3岁半',
			index:3.5
		},
		{
			name: '4岁',
			index:4
		},
		{
			name: '4岁半',
			index:4.5
		},
		{
			name: '5岁',
			index:5
		},
		{
			name: '5岁半',
			index:5.5
		},
		{
			name: '6岁',
			index:6
		},
		{
			name: '6岁半',
			index:6.5
		},
		{
			name: '7岁',
			index:7
		},
		{
			name: '7岁半',
			index:7.5
		},
		{
			name: '8岁',
			index:8
		},
		{
			name: '8岁半',
			index:8.5
		},
		{
			name: '9岁',
			index:9
		},
		{
			name: '9岁半',
			index:9.5
		},
		{
			name: '10岁',
			index:10
		},
		{
			name: '10岁半',
			index:10.5
		},
		{
			name: '11岁',
			index:11
		},
		{
			name: '11岁半',
			index:11.5
		},
		{
			name: '12岁',
			index:12
		},
		{
			name: '12岁半',
			index:12.5
		}
	]
}
export default ESTAs