<template>
	<div class="miaconst">
		<div class="mianinit">
			<i class="el-icon-fork-spoon"></i>
			<el-checkbox v-model="domian.must">必填</el-checkbox>
			<el-input placeholder="标题" v-model="domian.name" class="mininput"></el-input>
			<el-popover placement="bottom" width="160" v-model="visible">
				<p>确认删除该组件？</p>
				<div style="text-align: right; margin: 0">
					<el-button size="mini" type="text" @click="visible = false">取消</el-button>
					<el-button type="primary" size="mini" @click="determine">确定</el-button>
				</div>
				<i class="el-icon-delete" slot="reference"></i>
			</el-popover>
		</div>
	</div>
</template>

<script>
export default {
	name:'uploads',
	props:{
		fromkey:{
			type:Number,
			default:0
		},
		sign:{
			type:String,
			default:''
		}
	},
	data() {
		return {
			visible: false,
			indexkey:0,
			domian:{
				type:'image',
				sign:this.sign,
				must:false,
				name:'',
				content:''
			}
		};
	},
	mounted() {
		this.indexkey=this.fromkey
	},
	methods:{
		determine(){
			this.$emit('control',this.indexkey)
		},
	}
};
</script>
<style scoped>
	*>>>.el-input--small .el-input__inner {
	    height: 32px !important;
	    line-height: 32px !important;
	}
</style>
<style lang="less" scoped>
.miaconst {
	width: 100%;
	padding: 24px 0;
	border-bottom: 1px solid #e5e5e5;
	cursor: pointer;
	&:hover {
		background: #e6f7ff;
	}
	.mianinit {
		width: 100%;
		height: 32px;
		display: flex;
		align-items: center;
		i {
			margin-right: 8px;
		}
		.mininput {
			margin-left: 8px;
			width: 150px;
		}
		.mininput1 {
			margin-left: 8px;
			width: 300px;
		}
		.el-icon-delete {
			margin-left: 8px;
			cursor: pointer;
			&:hover {
				color: #409eff;
			}
		}
	}
}
</style>
