<template>
	<div class="conten">
		<el-tabs v-model="activeName" type="card" @tab-click="handleClick(activeName)">
			<el-tab-pane label="基本信息修改" name="basic"><basic /></el-tab-pane>
			<el-tab-pane label="赛事分组修改" name="second"><match-grouping :is_birthday="is_birthday" /></el-tab-pane>
			<el-tab-pane label="报名表单修改" name="third">
				<signup ref="signups" />
				<div class="bonst"><el-button type="primary" @click="modify">确认修改</el-button></div>
			</el-tab-pane>
			<el-tab-pane label="兼报优惠" name="fourth"><discount /></el-tab-pane>
			<el-tab-pane label="分组报名依赖配置" name="signup"><grouping ref="grouping" /></el-tab-pane>
		</el-tabs>
	</div>
</template>

<script>
import basic from './components/basic.vue';
import grouping from './components/grouping.vue';
import matchGrouping from './components/matchGrouping.vue';
import signup from '@/page/badminton/establish/components/signup';
import Discount from './components/Discount.vue';
import { mapActions } from 'vuex';
export default {
	name: 'matchedit',
	data() {
		return {
			activeName: 'basic',
			is_birthday:1
		};
	},
	components: {
		basic,
		signup,
		grouping,
		matchGrouping,
		Discount
	},
	methods: {
		...mapActions(['set_matchfrom']),
		handleClick(val) {
			if(!!sessionStorage['is_birthday']){
				this.is_birthday=JSON.parse(sessionStorage['is_birthday'])
			}
			if (val == 'third') {
				this.$nextTick(() => {
					this.$refs.signups.getsiunp();
				});
			} else if (val == 'signup') {
				this.$nextTick(() => {
					this.$refs.grouping.getdata();
				});
			}
		},
		async modify() {
			let froms = {};
			// form
			this.$set(froms, 'id', this.$route.query.match_id);
			let listarr = this.$refs.signups.$refs.miandata.map(item => item.domian);
			for (let i = 0; i < listarr.length; i++) {
				if (listarr[i].name == '') {
					this.$message.warning('检查到您添加得组件中标题未填写，程序不允许通过，请检查');
					return false;
				}
				if (listarr[i].placeholder == '') {
					this.$message.warning('检查到您添加得组件中标题信息未填写，程序不允许通过，请检查');
					return false;
				}
				if (listarr[i].list) {
					if (listarr[i].list.length > 0) {
						for (let j = 0; j < listarr[i].list.length; j++) {
							if (listarr[i].list[j].value == '') {
								this.$message.warning('检查到您添加得组件中单选项或下拉选项存在添加为填写，程序不允许通过，请检查');
								return false;
							}
						}
					}
				}
			}
			this.$set(froms, 'form', listarr);
			this.$set(froms, 'type', 'form');
			const datalist = await this.$api.updateBadmintonMatch(froms);
			if (datalist) {
				this.set_matchfrom(listarr);
				this.$message.success(datalist.msg);
			}
		}
	}
};
</script>
<style scoped>
.conten >>> .el-tabs .el-tabs__header .el-tabs__nav-scroll {
	border-bottom: 1px solid #dcdcdc;
}
.conten >>> .el-tabs--card > .el-tabs__header .el-tabs__nav {
	border-top: none;
}
.conten >>> .el-tabs__item.is-active {
	background: #ffffff;
	color: #3861db;
}
.conten >>> .el-tabs__item {
	font-size: 16px;
	color: #333333;
	background: #f2f2f2;
	/* border-radius: 4px; */
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	border-top: 1px solid #dcdcdc;
	/* border: 1px solid #E4E7ED;
	border-left: none;
	border-bottom: none;
	border-top: none; */
}
</style>
<style scoped lang="less">
.conten {
	width: calc(100% - 48px);
	padding: 15px 24px;
}
.bonst {
	width: 100%;
	height: 80px;
	display: flex;
	justify-content: center;
	align-items: center;
}
</style>
