<template>
	<div class="limst">
		<div class="miantilte">
			<span>分组报名依赖配置</span>
			<span>（此配置作用于对某些组别报名有限制，例如：需先报名"个人组"后才可报名"Open组"等此类需求。）</span>
		</div>
		<el-table
			:data="tableData"
			style="width: 100%"
			:header-cell-style="{
				'background-color': '#fafafa',
				color: '#333333',
				padding: '16px'
			}"
		>
			<el-table-column fixed prop="name" label="分组名称" align="center"></el-table-column>
			<el-table-column prop="is_show_text" label="显示状态" align="center">
				<template slot-scope="scope">
					<div style="display: flex;justify-content: center;align-items: center;">
						<div :class="scope.row.is_show === 1 ? 'uses' : 'err'"><div></div></div>
						{{ scope.row.is_show_text }}
					</div>
				</template>
			</el-table-column>
			<el-table-column prop="is_start_text" label="报名状态" align="center">
				<template slot-scope="scope">
					<div style="display: flex;justify-content: center;align-items: center;">
						<div :class="scope.row.is_start === 1 ? 'uses' : 'err'"><div></div></div>
						{{ scope.row.is_start_text }}
					</div>
				</template>
			</el-table-column>
			<el-table-column prop="group_id_text" label="配置状态" align="center">
				<template slot-scope="scope">
					<div style="display: flex;justify-content: center;align-items: center;">
						<div :class="scope.row.group_id === 1 ? 'uses' : 'err'"><div></div></div>
						{{ scope.row.group_id_text }}
					</div>
				</template>
			</el-table-column>
			<el-table-column fixed="right" label="操作" align="center">
				<template slot-scope="scope">
					<el-button type="text" @click.native.prevent="dispose(scope.row)" style="font-size: 14px;" size="small">配置</el-button>
				</template>
			</el-table-column>
		</el-table>

		<el-dialog title="配置" :visible.sync="dialogVisible" :close-on-click-modal="false"  :before-close="handleClose" width="1100px">
			<div class="minatiltle">
				<i class="el-icon-question"></i>
				说明：如全部未勾选，参赛者只要符合"{{ValidateForm.group_name}}"要求的就可报名；勾选后，参赛者成功报名任何一勾选的分组后，才能报名"{{ValidateForm.group_name}}"
			</div>
			<div style="padding: 20px 0;width: 1100px;">
				<el-form :model="ValidateForm" ref="ValidateForm" label-width="150px" class="demo-ruleForm">
					<el-form-item label="分组名称:" required>
						{{ ValidateForm.group_name }}
						<template>
							<el-checkbox-group v-model="arrlist">
								<el-checkbox v-for="(item, index) in ValidateForm.group_list" :label="item.name" :key="index">{{ item.name }}</el-checkbox>
							</el-checkbox-group>
						</template>
					</el-form-item>
				</el-form>
			</div>
			<div slot="footer" class="dialog-footer">
				<div class="limian">
					<el-button @click="handleClose">取 消</el-button>
					<el-button type="primary" @click="determine">确 定</el-button>
				</div>
			</div>
		</el-dialog>
	</div>
</template>

<script>
export default {
	name:'grouping',
	data() {
		return {
			dialogVisible: false,
			tableData: [],
			arrlist: [],
			ValidateForm: {
				group_list: []
			}
		};
	},
	mounted() {},
	methods: {
		handleClose(){
			this.dialogVisible=false
			this.arrlist=[]
		},
		async dispose(data) {
			const datalist = await this.$api.badmintonMatchGroupRely({
				id: data.id,
				match_id: this.$route.query.match_id,
				type: 'detail'
			});
			if (datalist) {
				this.ValidateForm = datalist.data;
				this.$set(this.ValidateForm, 'id', data.id);
				this.$set(this.ValidateForm, 'group_id', data.group_id);
				if(this.ValidateForm.group_list.length>0){
					this.ValidateForm.group_list.map(item=>{
						if(item.is_checked==true){
							this.arrlist.push(item.name)
						}
					})
				}
				this.dialogVisible = true;
			}
		},
		async determine() {
			let group_id = [];
			if (this.ValidateForm.group_list.length > 0) {
				this.ValidateForm.group_list.map(item => {
					this.arrlist.map(jtem => {
						if (jtem == item.name) {
							group_id.push(item.id);
						}
					});
				});
			}
			
			const datalist = await this.$api.badmintonMatchGroupRely({
				match_id: this.$route.query.match_id,
				group_id: group_id,
				type: 'save',
				id: this.ValidateForm.id
			});
			if (datalist) {
				this.$message.success(datalist.msg);
				this.getdata();
				this.dialogVisible = false;
				this.arrlist = [];
			}
		},
		async getdata() {
			const datalist = await this.$api.badmintonMatchGroupRely({
				match_id: this.$route.query.match_id,
				type: 'list'
			});
			if (datalist) {
				this.tableData = datalist.data;
			}
		}
	}
};
</script>

<style scoped>
.limst >>> .el-dialog__body {
	padding: 20px;
}
.limst >>> .el-dialog__wrapper {
	display: flex;
	align-items: center;
}
.limst >>> .el-dialog {
	border-radius: 10px;
}
.limst >>> .el-dialog__header {
	border-bottom: 1px dashed #e8e8e8;
}
.limst >>> .el-dialog__title {
	font-size: 14px;
	font-weight: bold;
	color: #333333;
}
.limst >>> .el-table__header {
	font-size: 14px;
}
.limst >>> .el-table__row {
	font-size: 14px;
}
</style>
<style scoped lang="less">
.dialog-footer {
	width: 100%;
	display: flex;
	justify-content: center;
	.limian {
		width: 20%;
		display: flex;
		justify-content: space-between;
	}
}
.err {
	height: 100%;
	padding-right: 5px;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 4px;
		height: 4px;
		background: #f52e00;
		border-radius: 50%;
	}
}
.uses {
	height: 100%;
	padding-right: 5px;
	display: flex;
	justify-content: center;
	align-items: center;
	div {
		width: 4px;
		height: 4px;
		background: #3861db;
		border-radius: 50%;
	}
}
.minatiltle {
	width: 100%;
	height: 46px;
	background: rgba(238, 64, 55, 0.1);
	border: 1px solid #ee4037;
	border-radius: 6px;
	display: flex;
	align-items: center;
	justify-content: center;
	color: #444242;
	font-size: 14px !important;
	opacity: 0.8;
	i {
		color: #3861db;
		margin-right: 6px;
		font-size: 16px !important;
	}
}
.limst {
	padding-top: 6px;
	width: 100%;
	border-top: 1px #e8e8e8 dashed;
}
.miantilte {
	margin-bottom: 8px;
	padding-top: 24px;
	padding-left: 22px;
	span {
		font-size: 14px;
		color: #333333;
		&:nth-child(1) {
			font-weight: bold;
		}
		&:nth-child(2) {
			color: #707070;
		}
	}
}
</style>
