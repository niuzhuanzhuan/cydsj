<template>
	<div class="initmians">
		<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="300px">
			<el-form-item label="分组名称:" prop="name"><el-input style="width: 20rem;margin-left: 50px;" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="原价:" prop="name"><el-input style="width: 20rem;margin-left: 50px;" placeholder="请输入价格" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="成功报名以下任意勾选组别:" prop="name"><el-input style="width: 20rem;margin-left: 50px;" placeholder="请输入名额" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="折扣后最终需付金额:" prop="name"><el-input style="width: 20rem;margin-left: 50px;" placeholder="请输入名额" v-model="ruleForm.name"></el-input></el-form-item>

			<el-form-item>
				<el-button @click="$emit('handleClose')">取 消</el-button>
				<el-button type="primary" @click="submitForm('ruleForm')">保 存</el-button>
			</el-form-item>
		</el-form>
	</div>
</template>

<script>
export default {
	name:'Disfrom',
	data() {
		return {
			ruleForm: {},
			rules: {
				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }]
			}
		};
	},
	mounted() {},
	methods: {
		submitForm(formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					alert('submit!');
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>
<style scoped>
.initmians >>> .el-form-item__label {
	color: #333333;
	font-weight: bold;
}
</style>
<style lang="less" scoped>
.minatiltle {
	width: calc(100% - 24px);
	padding-left: 24px;
	height: 46px;
	background: rgba(238, 64, 55, 0.1);
	border: 1px solid #ee4037;
	border-radius: 6px;
	display: flex;
	align-items: center;
	justify-content: flex-start;
	color: #333333;
	font-size: 14px !important;
	opacity: 0.8;
	margin-bottom: 20px;
}
.initmians {
	width: 100%;
}
.line {
	display: flex;
	justify-content: center;
}
</style>
