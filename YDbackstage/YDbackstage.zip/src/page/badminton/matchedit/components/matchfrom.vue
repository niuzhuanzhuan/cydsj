<template>
	<div class="initmians">
		<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="200px">
			<el-form-item label="组别名称" prop="name"><el-input style="width: 43.75rem;" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="价格" prop="name"><el-input style="width: 43.75rem;" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="名额" prop="name"><el-input style="width: 43.75rem;" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="团队成员" prop="name"><el-input style="width: 43.75rem;" v-model="ruleForm.name"></el-input></el-form-item>

			<el-form-item label="快速生成出生日期" required>
				<div style="width: 43.75rem;">
					<el-col :span="11">
						<el-form-item prop="date1">
							<el-select style="width: 320px;" v-model="ruleForm.value" placeholder="请选择">
								<!-- <el-option
							      v-for="item in options"
							      :key="item.value"
							      :label="item.label"
							      :value="item.value">
							    </el-option> -->
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="line" :span="2">至</el-col>
					<el-col :span="11">
						<el-form-item prop="date2">
							<el-select style="width: 320px;" v-model="ruleForm.value" placeholder="请选择">
								<!-- <el-option
							      v-for="item in options"
							      :key="item.value"
							      :label="item.label"
							      :value="item.value">
							    </el-option> -->
							</el-select>
						</el-form-item>
					</el-col>
				</div>
			</el-form-item>

			<el-form-item label="单个选手生日范围" required>
				<div style="width: 43.75rem;">
					<el-col :span="11">
						<el-form-item prop="date1"><el-date-picker type="date" placeholder="选择日期" v-model="ruleForm.date1" style="width: 320px;"></el-date-picker></el-form-item>
					</el-col>
					<el-col class="line" :span="2">至</el-col>
					<el-col :span="11">
						<el-form-item prop="date2"><el-time-picker placeholder="选择时间" v-model="ruleForm.date2" style="width: 320px"></el-time-picker></el-form-item>
					</el-col>
				</div>
			</el-form-item>

			<el-form-item label="年龄累计配置" prop="resource">
				<el-radio-group v-model="ruleForm.resource">
					<el-radio label="不配置"></el-radio>
					<el-radio label="按年累计"></el-radio>
					<el-radio label="按月累计"></el-radio>
				</el-radio-group>
			</el-form-item>
			<el-form-item label="性别限制" prop="resource">
				<el-radio-group v-model="ruleForm.resource">
					<el-radio label="不限"></el-radio>
					<el-radio label="限制"></el-radio>
				</el-radio-group>
			</el-form-item>
			<el-form-item>
				<el-button @click="$emit('handleClose')">取 消</el-button>
				<el-button type="primary" @click="submitForm('ruleForm')">保 存</el-button>
			</el-form-item>
		</el-form>
	</div>
</template>

<script>
export default {
	name:'matchfrom',
	data() {
		return {
			ruleForm: {},
			rules: {
				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }]
			}
		};
	},
	mounted() {},
	methods: {
		submitForm(formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					alert('submit!');
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		}
	}
};
</script>
<style scoped>
.initmians >>> .el-form-item__label {
	color: #333333;
	font-weight: bold;
}
</style>
<style lang="less" scoped>
.minatiltle {
	width: calc(100% - 24px);
	padding-left: 24px;
	height: 46px;
	background: rgba(238, 64, 55, 0.2);
	border: 1px solid #ee4037;
	border-radius: 6px;
	display: flex;
	align-items: center;
	justify-content: flex-start;
	color: #333333;
	font-size: 14px !important;
	opacity: 0.8;
	margin-bottom: 20px;
}
.initmians {
	width: 100%;
}
.line {
	display: flex;
	justify-content: center;
}
</style>
