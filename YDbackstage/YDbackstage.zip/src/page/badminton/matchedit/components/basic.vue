<template>
	<div>
		<establishs :designate="0"/>
	</div>
</template>

<script>
	import establishs from '@/page/badminton/establish/badminton-establish.vue'
	export default{
		components:{
			establishs
		}
	}
</script>

<style>
</style>
