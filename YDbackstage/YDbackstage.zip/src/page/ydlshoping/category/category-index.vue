<template>
    <div class="main">
        
        <!-- 按钮 -->
        <el-button 
            type="primary" 
            size="medium" 
            @click="dialogVisible = true, showForm = 1, form = {}, dialogTitle = '添加分类'" 
        >添加分类</el-button>

        <!-- 列表 -->
        <el-table
            class="table"
            :data="tableData"
            size="medium"
            row-key="id"
            lazy
            :load="load"
            :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
            :highlight-current-row='true'
            >

            <el-table-column
                prop="id"
                label="分类ID"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="name"
                label="分类名"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="type"
                label="上级分类"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="number"
                label="包含商品数"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="level"
                label="分类级别"
                align="center"
                >
            </el-table-column>

            <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="edit(scope.row)">编辑</el-button>
                </template>
            </el-table-column>

        </el-table>

        <!-- 添加\编辑 弹窗 -->
        <el-dialog
            class="dialog"
            :title="dialogTitle"
            :visible.sync="dialogVisible"
            width="30%">

            <el-form class="ruleForm" :model="form" :rules="rules" ref="ruleForm" >

                <el-form-item label="分类ID:" :label-width="formLabelWidth" v-if="showForm == 2">
                    {{ form.id }}
                </el-form-item>

                <el-form-item label="分类名:" :label-width="formLabelWidth" prop="name" >
                    <el-input v-model="form.name" placeholder="请输入分类名" style="width : 65%"></el-input>
                </el-form-item>

                <el-form-item label="上级分类:" :label-width="formLabelWidth" prop="type" >
                    <el-select v-model="form.type" placeholder="请选分类" style="width : 65%">
                        <el-option v-for="(item,index) in sort" :key="index" :label="item.key" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item label="包含商品数:" :label-width="formLabelWidth" v-if="showForm == 2">
                    {{ form.number }}
                </el-form-item>

                <el-form-item label="分类级别:" :label-width="formLabelWidth" v-if="showForm == 2">
                    {{ form.level }}
                </el-form-item>

                <el-form-item class="button">
                    <el-button @click="dialogVisible = false" style="margin-right: 40px;">取消</el-button>
                    <el-button type="primary" @click="submitForm('ruleForm')">保存</el-button>
                </el-form-item>
                
            </el-form>
        </el-dialog>

    </div>
</template>

<script>
    export default {
        data() {
            return {

                dialogVisible : false,
                dialogTitle : '添加分类',
                formLabelWidth : '100px',
                // 判断是 添加 还是 编辑
                showForm : 1,

                // 列表数据
                tableData : [
                    {
                        id : '1234567',
                        name : '哇哈哈',
                        type : '饮品',
                        number : '10',
                        level : '1',
                        children : [
                            {
                                id : '123456722',
                                name : '哇哈哈',
                                type : '饮品',
                                number : '10',
                                level : '1',
                            },
                            {
                                id : '12345672',
                                name : '哇哈哈',
                                type : '饮品',
                                number : '10',
                                level : '1',
                            },
                            {
                                id : '12345673',
                                name : '哇哈哈',
                                type : '饮品',
                                number : '10',
                                level : '1',
                            },
                        ]
                    },
                    {
                        id : '12345672',
                        name : '哇哈哈',
                        type : '饮品',
                        number : '10',
                        level : '2',
                    },
                    {
                        id : '12345673',
                        name : '哇哈哈',
                        type : '饮品',
                        number : '10',
                        level : '3',
                    },
                    {
                        id : '12345674',
                        name : '哇哈哈',
                        type : '饮品',
                        number : '10',
                        level : '4',
                    },
                ],

                // 下拉框数据
                sort : [
                    {
                        key : '顶级',
                        value : 1,
                    },
                    {
                        key : '一级',
                        value : 2,
                    },
                    {
                        key : '二级',
                        value : 3,
                    },
                    {
                        key : '三级',
                        value : 4,
                    },
                ],

                // 编辑和添加数据
                form : {
                    name : '',
                    type : '',
                    number : '',
                    level : '',
                },

                // 验证
                rules: {
                    name: [
                        { required: true, message: '请输入分类名', trigger: 'blur' }
                    ],
                    type: [
                        { required: true, message: '请选分类', trigger: 'blur'  }
                    ],
                }
            }
        },
        mounted () {
            ;
        },
        methods: {

            // 弹窗保存按钮
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        
                        

                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },

            // 编辑按钮
            edit(item){
                this.form = item
                this.dialogVisible = true
                this.dialogTitle = '编辑分类'
                this.showForm = 2
            }
            
        },
    }
</script>

<style lang="less" >
    .main{
        padding: 20px;
    }

    .table{
        width: 100%;
        margin-top: 30px;
    }

    .el-dialog{
        border-radius: 8px;
    }

    .dialog{
        .button{
            margin: 0 auto;
            text-align: center;
            margin-top: 40px;
        }
    }
</style>