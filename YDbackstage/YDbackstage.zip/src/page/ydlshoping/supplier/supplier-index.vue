<template>
    <div class="main">
        
        <!-- 按钮 -->
        <el-button 
            type="primary" 
            size="medium" 
            @click="dialogVisible = true, form = {}, dialogTitle = '添加', showForm = 1" 
        >添加供应商</el-button>

        <!-- 列表 -->
        <el-table
            class="table"
            :data="tableData"
            size="medium"
            :highlight-current-row='true'
            >

            <el-table-column
                prop="id"
                label="供应商ID"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="name"
                label="供应商名称"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="number1"
                label="纳税人识别号"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="bankName1"
                label="对公账户开户行"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="number2"
                label="对公账户号"
                align="center"
                >
            </el-table-column>

            <el-table-column
                prop="bankName2"
                label="对公账户名"
                align="center"
                >
            </el-table-column>

            <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="edit(scope.row)">编辑</el-button>
                    <span class="line">|</span>
                    <el-button type="text" size="small" style="color:#FF3E2F" @click="del(scope.row)">删除</el-button>
                </template>
            </el-table-column>

        </el-table>

        <!-- 添加\编辑 弹窗 -->
        <el-dialog
            class="dialog"
            :title="dialogTitle"
            :visible.sync="dialogVisible"
            width="40%">

            <el-form class="ruleForm" :model="form" :rules="rules" ref="ruleForm" >

                <el-form-item label="供应商ID:" :label-width="formLabelWidth" v-if="showForm == 2">
                    {{ form.id }}
                </el-form-item>

                <el-form-item label="供应商名称:" :label-width="formLabelWidth" prop="name">
                    <el-input v-model="form.name" placeholder="请输入供应商名称" style="width : 70%"></el-input>
                </el-form-item>

                <el-form-item label="纳税人识别号:" :label-width="formLabelWidth" prop="number1">
                    <el-input v-model="form.number1" placeholder="请输入识别号" style="width : 70%"></el-input>
                </el-form-item>

                <el-form-item label="对公账户开户行:" :label-width="formLabelWidth" prop="bankName1">
                    <el-input v-model="form.bankName1" placeholder="请输入开户行" style="width : 70%"></el-input>
                </el-form-item>

                <el-form-item label="对公账户号:" :label-width="formLabelWidth" prop="number2">
                    <el-input v-model="form.number2" placeholder="请输入对公账户号" style="width : 70%"></el-input>
                </el-form-item>

                <el-form-item label="对公账户名:" :label-width="formLabelWidth" prop="bankName2">
                    <el-input v-model="form.bankName2" placeholder="请输入对公账户名" style="width : 70%"></el-input>
                </el-form-item>

                <el-form-item class="button">
                    <el-button @click="dialogVisible = false" style="margin-right: 40px;">取消</el-button>
                    <el-button type="primary" @click="submitForm('ruleForm')">保存</el-button>
                </el-form-item>
                
            </el-form>
        </el-dialog>

        <div class="paging">
            <el-pagination
                background
                layout="prev, pager, next"
                :total="total"
                @current-change="handleCurrentChange"
                >
            </el-pagination>
        </div>

    </div>
</template>

<script>
    export default {
        data() {
            return {

                dialogVisible : false,
                dialogTitle : '添加',
                formLabelWidth : '150px',
                showForm : 1,

                // 设置分页
                total : 50,

                // 列表数据
                tableData : [
                    {
                        id : '1234567',
                        name : '供应商名字',
                        number1 : '12345678910',
                        bankName1 : '中国工商银行XX支行',
                        number2 : '134815354564',
                        bankName2 : '账户名',
                    },
                ],

                // 编辑和添加数据
                form : {
                    id : '',
                    name : '',
                    number1 : '',
                    bankName1 : '',
                    number2 : '',
                    bankName2 : '',
                },

                // 验证
                rules: {
                    name: [{ required: true, message: '请输入供应商名称', trigger: 'blur' }],
                    number1: [{ required: true, message: '请输入纳税人识别号', trigger: 'blur'  }],
                    bankName1: [{ required: true, message: '请输入对公账户开户行', trigger: 'blur'  }],
                    number2: [{ required: true, message: '请输入对公账户号', trigger: 'blur'  }],
                    bankName2: [{ required: true, message: '请输入对公账户名', trigger: 'blur'  }],
                },
            }
        },
        mounted () {
            ;
        },
        methods: {

            // 弹窗保存按钮
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        
                        

                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },

            // 编辑按钮
            edit(item){
                this.form = item
                this.dialogVisible = true
                this.dialogTitle = '编辑'
                this.showForm = 2
            },
            
            // 删除按钮
            del(item){

            },

            handleCurrentChange(item){
                console.log('当前第：' + item + ' 页')
            },
        },
    }
</script>

<style lang="less" >
    .main{
        padding: 20px;
    }

    // 列表
    .table{
        width: 100%;
        margin-top: 30px;

        .line{
            padding: 0 10px;
            color: #999999;
        }
    }

    // 弹窗
    .el-dialog{
        border-radius: 8px;
    }

    // 弹窗
    .dialog{
        .button{
            margin: 0 auto;
            text-align: center;
            margin-top: 40px;
        }
    }

    // 分页
    .paging{
        display: flex;
        position: fixed;
        bottom: 20px;
        right: 20px;
    }
</style>