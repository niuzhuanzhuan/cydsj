<template>
    <div>
        品牌
    </div>
</template>

<script>
    export default {
        data() {
            return {
                key: '',
            }
        },
        mounted () {
            ;
        },
        methods: {
            name() {
                
            }
        },
    }
</script>

<style lang="less" scoped>

</style>