<template>
	<div class="balisr">
		<el-form :model="ruleForm" :rules="rules" label-width="90px" ref="ruleForm">
			<template>
				<div class="miantil">基本信息</div>
			</template>
			<el-form-item label="商品名:" prop="name"><el-input style="width: 48.125rem;" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="商品简介:" prop="name">
				<el-input style="width: 48.125rem;" type="textarea" :autosize="{ minRows: 8, maxRows: 20 }" placeholder="请输入内容" v-model="ruleForm.textarea2"></el-input>
			</el-form-item>
			<el-form-item label="商品货号:" prop="name"><el-input style="width: 48.125rem;" v-model="ruleForm.name"></el-input></el-form-item>
			<el-form-item label="SPU编号:" prop="name">
				<div class="mianlist">
					<div>42510554</div>
					<div class="linske">保存后自动生成</div>
				</div>
			</el-form-item>
			<el-form-item label="商品图" prop="name">
				<el-upload
					action="https://jsonplaceholder.typicode.com/posts/"
					list-type="picture-card"
					:on-preview="handlePictureCardPreview"
					:on-success="handleAvatarSuccess"
					:on-remove="handleRemove"
				>
					<i class="el-icon-plus plus"></i>
				</el-upload>
				<span class="liams">建议尺寸：800*800像素 可以拖拽图片调整顺序</span>
				<el-dialog :visible.sync="dialogVisible"><img width="100%" :src="dialogImageUrl" alt="" /></el-dialog>
			</el-form-item>
			<el-form-item label="商品分类:" prop="name">
				<template>
					<div class="mianinit">
						<div class="frims">
							<div class="mials" v-for="(item, index) in listdata" :key="index">
								<el-select v-model="ruleForm.region" clearable style="width: 244px;margin-right: 10px;" placeholder="一级分类">
									<el-option label="区域一" value="shanghai"></el-option>
									<el-option label="区域二" value="beijing"></el-option>
								</el-select>
								<el-select v-model="ruleForm.region" clearable style="width: 244px;margin-right: 10px;" placeholder="二级分类">
									<el-option label="区域一" value="shanghai"></el-option>
									<el-option label="区域二" value="beijing"></el-option>
								</el-select>
								<el-select v-model="ruleForm.region" clearable style="width: 244px;margin-right: 10px;" placeholder="三级分类">
									<el-option label="区域一" value="shanghai"></el-option>
									<el-option label="区域二" value="beijing"></el-option>
								</el-select>
								<el-button type="text" v-if="listdata.length != 1">
									<i class="el-icon-delete"></i>
									删除分类
								</el-button>
								<el-button type="text" v-if="listdata.length == 1">
									<i class="el-icon-plus"></i>
									继续添加
								</el-button>
							</div>
							<el-button class="lismt" v-if="listdata.length != 1" type="text">
								<i class="el-icon-plus"></i>
								继续添加
							</el-button>
						</div>
					</div>
				</template>
			</el-form-item>
			<el-form-item label="供应商:" prop="name">
				<el-select v-model="ruleForm.region" clearable style="width: 244px;margin-right: 10px;" placeholder="二级分类">
					<el-option label="区域一" value="shanghai"></el-option>
					<el-option label="区域二" value="beijing"></el-option>
				</el-select>
			</el-form-item>
			<el-form-item label="品牌:" prop="name">
				<el-select v-model="ruleForm.region" clearable style="width: 244px;margin-right: 10px;" placeholder="二级分类">
					<el-option label="区域一" value="shanghai"></el-option>
					<el-option label="区域二" value="beijing"></el-option>
				</el-select>
			</el-form-item>
			<el-form-item label="标签:" prop="name">
				<template>
					<div class="itemsl">
						<span class="listll" v-for="(item, index) in 5">
							<i class="el-icon-remove remove"></i>
							扶贫产品
						</span>
					</div>
					<div>
						<el-input style="width: 244px;margin-right: 10px;" v-model="input" placeholder="请输入添加分类名称"></el-input>
						<el-button type="text">
							<i class="el-icon-plus"></i>
							继续添加
						</el-button>
						<span class="wens">温馨提示：鼠标移上添加标签即可操作标签</span>
					</div>
				</template>
			</el-form-item>
			<template>
				<div class="lisnt">
					<div class="lihr"></div>
				</div>
			</template>
			<el-form-item><el-button type="primary" @click="submitForm('ruleForm')">保存并下一步</el-button></el-form-item>
		</el-form>
	</div>
</template>

<script>
export default {
	data() {
		return {
			input: '',
			ruleForm: {},
			rules: {},
			dialogVisible: false,
			dialogImageUrl: '',
			listdata: [1, 3]
		};
	},
	methods: {
		handleRemove(file, fileList) {
			console.log(fileList);
		},
		handleAvatarSuccess(res, file) {
			console.log(file);
		},
		handlePictureCardPreview(file) {
			this.dialogImageUrl = file.url;
			this.dialogVisible = true;
		}
	}
};
</script>

<style>
	.lisnt{
		width: 100%;
		height: 80px;
		display: flex;
		align-items: center;
	}
.el-upload--picture-card {
	width: 106px;
	height: 106px;
	line-height: 155px;
	background-color: #e1e1e1;
}
.el-upload-list--picture-card .el-upload-list__item {
	width: 106px;
	height: 106px;
}
.plus {
	color: #ffffff !important;
	font-size: 80px !important;
}
.liams {
	font-size: 12px;
	color: #999999;
}
</style>

<style lang="less">
.itemsl {
	width: 300px;
	padding: 0 0 10px 0;
	display: flex;
	flex-wrap: wrap;
	.listll {
		padding: 5px 10px;
		background: #f5f5f5;
		color: #333333;
		font-size: 14px;
		border-radius: 5px;
		margin-right: 5px;
		position: relative;
		margin-top: 5px;
		&:hover {
			.remove {
				display: block;
			}
		}
		.remove {
			position: absolute;
			top: -5px;
			right: -5px;
			color: #c0c0c0;
			display: none;
			cursor: pointer;
		}
	}
}
.wens {
	font-size: 12px;
	color: #999999;
	margin-left: 10px;
}
.mianinit {
	width: 830px;
	.frims {
		position: relative;
		.mials {
			width: 830px;
			display: flex;
			margin-bottom: 10px;
		}
		.lismt {
			position: absolute;
			right: -70px;
			bottom: 0;
		}
	}
}
.balisr {
	width: 100%;
	padding: 10px 0;
	.miantil {
		font-size: 14px;
		font-weight: bold;
		color: #333333;
		padding: 5px 0;
	}
	.mianlist {
		display: flex;
		color: #333333;
		.linske {
			margin-left: 5px;
			color: #999999;
			font-size: 14px;
		}
	}
}
</style>
