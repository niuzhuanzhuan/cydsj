<template>
	<div class="addmian">
		<div class="miantitle">
			<div :class="actimian == 1 ? 'active' : ''" @click="actimian = 1">
				<div>编辑基本信息</div>
				<div class="lint"></div>
			</div>
			<div :class="actimian == 2 ? 'mal active' : 'mal'" @click="actimian = 2">
				编辑商品详情
				<div class="lint"></div>
			</div>
		</div>
		<div class="lihr"></div>
		
		<basic/>
		
	</div>
</template>

<script>
	import basic from './shopingadd/basic.vue'
export default {
	data() {
		return {
			actimian: 1
		};
	},
	components: {
		basic
	}
};
</script>

<style lang="less">
@f3: #333333;
.lihr{
	margin-top: 10px;
	width: 100%;
	border-top: 1px dashed #E8E8E8;
}
.active {
	color: #3861db;
	display: flex;
	flex-direction: column;
	align-items: center;
	.lint {
		margin-top: 5px;
		width: 60%;
		height: 2px;
		background: #3861db;
	}
}
.mal {
	margin-left: 100px;
}
.addmian {
	width: 100%;
	height: calc(100% - 20px);
	padding: 0 0 20px 0;
	.miantitle {
		width: calc(100% - 84px);
		padding: 10px 42px;
		background: #fafafa;
		display: flex;
		color: @f3;
		font-size: 14px;
		font-weight: bold;
		div {
			user-select: none;
			cursor: pointer;
		}
	}
}
</style>
