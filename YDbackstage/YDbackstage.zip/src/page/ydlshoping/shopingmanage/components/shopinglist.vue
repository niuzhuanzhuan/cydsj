<template>
	<div class="splist">
		<div class="fromli">
			<el-form :model="ruleForm" :rules="rules" ref="ruleForm" class="froms" label-width="100px">
				<el-form-item label="商品名称:" prop="name" style="width: calc(50% - 10px);"><el-input v-model="ruleForm.name"></el-input></el-form-item>
				<el-form-item label="上架时间:" prop="name" style="width: calc(50% - 10px);">
					<el-col :span="11">
						<el-form-item prop="date1"><el-date-picker type="date" placeholder="选择日期" v-model="ruleForm.date1" style="width: 100%;"></el-date-picker></el-form-item>
					</el-col>
					<el-col class="line" :span="2">-</el-col>
					<el-col :span="11">
						<el-form-item prop="date2"><el-time-picker placeholder="选择时间" v-model="ruleForm.date2" style="width: 100%;"></el-time-picker></el-form-item>
					</el-col>
				</el-form-item>
				<el-form-item label="货号:" prop="name" style="width: calc(50% - 10px);"><el-input v-model="ruleForm.name"></el-input></el-form-item>
				<el-form-item label="sku号:" prop="name" style="width: calc(50% - 10px);"><el-input v-model="ruleForm.name"></el-input></el-form-item>
				<el-form-item label="商品分类:" prop="region" style="width: calc(50% - 10px);">
					<el-select v-model="ruleForm.region" style="width: 100%" clearable placeholder="所有">
						<el-option label="区域一" value="shanghai"></el-option>
						<el-option label="区域二" value="beijing"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="货架状态:" prop="region" style="width: calc(50% - 10px);">
					<el-select v-model="ruleForm.region" style="width: 100%" clearable placeholder="所有">
						<el-option label="区域一" value="shanghai"></el-option>
						<el-option label="区域二" value="beijing"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="供应商:" prop="region" style="width: calc(50% - 10px);">
					<el-select v-model="ruleForm.region" style="width: 100%" clearable placeholder="所有">
						<el-option label="区域一" value="shanghai"></el-option>
						<el-option label="区域二" value="beijing"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="所属商城:" prop="region" style="width: calc(50% - 10px);">
					<el-select v-model="ruleForm.region" style="width: 100%" clearable placeholder="所有">
						<el-option label="区域一" value="shanghai"></el-option>
						<el-option label="区域二" value="beijing"></el-option>
					</el-select>
				</el-form-item>
				<template>
					<div class="mianbont">
						<div class="lins">
							<el-button>筛 选</el-button>
							<el-button>导 出</el-button>
							<el-button type="primary">查看已生成报表</el-button>
						</div>
					</div>
				</template>
			</el-form>
		</div>
		<div class="tatles">
			<div class="miantilte">
				批量管理：
				<el-button size="mini">下架</el-button>
			</div>
			<el-table
				:data="tableData"
				height="300px"
				:header-cell-style="{
					'background-color': '#fafafa',
					color: '#333333',
					padding: '10px'
				}"
			>
				<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
				<el-table-column type="selection" align="center" width="55"></el-table-column>
				<el-table-column prop="out_trade_no" label="商品ID" align="center"></el-table-column>
				<el-table-column prop="name" label="商品名" align="center"></el-table-column>
				<el-table-column prop="price" label="货号" align="center"></el-table-column>
				<el-table-column prop="service_price" label="所属分类" align="center"></el-table-column>
				<el-table-column prop="income_price" label="库存" align="center"></el-table-column>
				<el-table-column prop="create_time" label="货架状态" align="center"></el-table-column>
				<el-table-column prop="create_time" label="月销量" align="center"></el-table-column>
				<el-table-column label="操作" align="center">
					<template slot-scope="scope">
						<el-button type="text" size="small">编辑</el-button>
						<el-divider direction="vertical"></el-divider>
						<el-button type="text" size="small">下架</el-button>
					</template>
				</el-table-column>
			</el-table>
			<selfPagination ref="pagination" class="pages" :total="total" @pageChange="pageChange" />
		</div>
	</div>
</template>

<script>
import selfPagination from '@/components/BaseComponents/Pagination.vue';
export default {
	data() {
		return {
			total: 0,
			ruleForm: {},
			tableData: [],
			rules: {}
		};
	},
	created() {},
	components: {
		selfPagination
	},
	methods: {
		pageChange(params) {}
	}
};
</script>

<style lang="less">
.line {
	display: flex;
	justify-content: center;
}
.froms {
	display: flex;
	flex-wrap: wrap;
}
.mianbont {
	width: 100%;
	height: 100px;
	display: flex;
	justify-content: center;
	.lins {
		width: 30%;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: space-around;
	}
}
.miantilte {
	margin-bottom: 5px;
	color: #333333;
	font-size: 16px;
}
.pages {
	display: flex;
	justify-content: flex-end;
	margin-top: 6px;
}
.fromli {
	width: calc(100% - 2px);
	height: 318px;
	border: 1px solid #dcdcdc;
	background: #fafafa;
	padding: 20px 0;
}
.tatles {
	margin-top: 20px;
	width: 100%;
	height: 370px;
}
</style>
