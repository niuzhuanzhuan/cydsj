<template>
	<div class="mian">
		<el-tabs v-model="activeName" type="card">
			<el-tab-pane label="商品列表" name="1">
				<shopinglist />
			</el-tab-pane>
			<el-tab-pane label="新建商品" name="2">
				<shopingadd/>
			</el-tab-pane>
		</el-tabs>
	</div>
</template>

<script>
import shopinglist from './components/shopinglist';
import shopingadd from './components/shopingadd';
export default {
	name: 'shopingmanage',
	data() {
		return {
			activeName: '2'
		};
	},
	components: {
		shopinglist,
		shopingadd
	}
};
</script>

<style scoped>
.mian >>> .el-card__body {
	padding: 0;
}
.mian >>> .el-tabs .el-tabs__header .el-tabs__nav-scroll {
	border-bottom: 1px solid #dcdcdc;
}
.mian >>> .el-tabs--card > .el-tabs__header .el-tabs__nav {
	border-top: none;
}
.mian >>> .el-tabs__item.is-active {
	background: #ffffff;
	color: #3861db;
}
.mian >>> .el-tabs__item {
	font-size: 16px;
	color: #333333;
	background: #f2f2f2;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	border-top: 1px solid #dcdcdc;
}
</style>
<style scoped lang="less">
.mian {
	width: calc(100% - 40px);
	height: calc(100% - 40px);
	padding: 20px;
}
</style>
