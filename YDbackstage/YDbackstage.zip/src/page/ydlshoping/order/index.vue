<template>
	<div class="page-main">
		<el-tabs type="card">
		  <el-tab-pane label="订单概况">
			  
		  </el-tab-pane>
		  <el-tab-pane label="所有订单" lazy>所有订单</el-tab-pane>
		  <el-tab-pane label="退换货" lazy>退换货</el-tab-pane>
		</el-tabs>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style lang="less" scoped>
	
</style>
