<template>
	<div class="initmian">
		<div class="inittip">
			<span>团队赛分组列表</span>
			<span>（点击分组可拖拽排序）</span>
		</div>
		<div class="inmiand">
<!--			<div>组别名称</div>
			<div>团队成员人数</div>
			<div>单个选手生日范围</div>
			<div>年龄累计配置</div>
			<div>性别限制</div>
			<div>价格（元）</div>
			<div>操作</div>-->
			<div>组别名称</div>
			<div>价格类型</div>
			<div>报名费</div>
			<div>团队名额</div>
			<div>每队成员人数</div>
			<div>年龄限制</div>
			<div>选手生日范围</div>
			<div>性别</div>
			<div>操作</div>


		</div>
		<div class="itemns">
			<div class="froitem" v-for="(items, index) in datalist" v-dragging="{ item: items, list: datalist, group: 'items' }" :key="index">
				<div class="minslis">{{ items.name }}</div>
				<div class="minslis">{{ items.price_type==1?'团队单价':'团队总价' }}</div>
				<div class="minslis">{{ items.price }}</div>
				<div class="minslis">{{ items.limit }}</div>
				<div class="minslis">{{team_limit(items.team_limit_json.where1,items.team_limit_json.num1)}}<br/>{{team_limit(items.team_limit_json.where2,items.team_limit_json.num2)}}</div>
				<div class="minslis">{{ items.age_start }}~{{ items.age_end }}</div>
				<div class="minslis">{{ items.age_date_start }}{{ items.age_date_start ? '~' : '' }}{{ items.age_date_end }}</div>
				<div class="minslis">{{ items.sex == 0 ? '不限制' : items.sex == 1?'仅限男':'仅限女' }}</div>
				<div class="minslis">
					<div class="mians">
						<a @click="tremedit(items)">编辑</a>
						<el-divider direction="vertical"></el-divider>
						<el-popover placement="bottom" width="160" v-model="items.visible">
							<p>确认删除该组件？</p>
							<div style="text-align: right; margin: 0">
								<el-button size="mini" type="text" @click="items.visible = false">取消</el-button>
								<el-button type="primary" size="mini" @click="removeDomain(items)">确定</el-button>
							</div>
							<a slot="reference">删除</a>
						</el-popover>
					</div>
				</div>
			</div>
		</div>
		<div class="mianingtop" v-if="datalist.length == 0"><img src="./img/init.png" /></div>
		<div class="mianboont"><el-button type="primary" icon="el-icon-plus" @click="adds" style="background-color: #3861DB;font-size: 16px;">添加团队分组</el-button></div>
		<el-dialog :title="titles" :visible.sync="dialogVisible" :close-on-click-modal="false" width="1000px" :modal="false" :before-close="handleClose" :destroy-on-close="true">
			<teamfrom @handleClose="handleClose" :is_birthday="is_birthday" ref="teamfroms" />
		</el-dialog>
	</div>
</template>

<script>
import teamfrom from './football-create-teamfrom';
export default {
	name: 'football-create-team',
	props: {
		is_birthday: {
			type: Number,
			default: 1
		}
	},
	data() {
		return {
			dialogVisible: false,
			datalist: [],
			titles: '添加团队分组',
			innum: 1
		};
	},
	components: {
		teamfrom
	},
	methods: {
		tremedit(data) {
			this.$nextTick(() => {
/*				if (typeof data.total_age == 'string') {
					if (!data.total_age) {
						data.total_age = 0;
					} else {
						data.total_age = JSON.parse(data.total_age);
					}
				}
				if (typeof data.total_age_json == 'string') {
					data.total_age_json = JSON.parse(data.total_age_json);
				}*/
				if (typeof data.sex == 'string') {
					if (!data.sex) {
						data.sex = 0;
					} else {
						data.sex = JSON.parse(data.sex);
					}
				}
				let arrs = [];
				/*if (typeof data.sex_json == 'string') {
					if (data.sex_json != '') {
						data.sex_json = JSON.parse(data.sex_json);
						arrs = data.sex_json.map(item => {
							item.visible = JSON.parse(item.visible);
							item.key = Number.parseInt(item.key);
							item.age = item.age != '' ? Number.parseInt(item.age) : '';
							item.num = item.num != '' ? Number.parseInt(item.num) : '';
							return item;
						});
						this.$refs.teamfroms.$refs.Genders.datalists = arrs;
					}
				}*/
				this.$refs.teamfroms.ruleForm = data;
				this.titles = '修改团队分组';
				this.dialogVisible = true;
			});
		},
		adds() {
			this.titles = '添加团队分组';
			this.dialogVisible = true;
		},
		team_limit(where1,num){
			let w={
				'>':'大于',
				'>=':'大于等于',
				'=':'等于',
				'<':'小于',
				'<=':'小于等于',
			}
			if(w[where1]){
				return "【队员数】 "+w[where1]+" "+num
			}else{
				return ''
			}

		},
		handleClose(data) {
			if (data && data.key) {
				if (this.datalist.length === 0) {
					this.datalist.push(data);
				} else {
					let key = this.datalist.findIndex(item => item.key === data.key);
					if (key !== -1) {
						this.datalist[key] = data;
					} else {
						this.datalist.push(data);
					}
				}
			}
			this.dialogVisible = false;
		},
		removeDomain(item) {
			var index = this.datalist.indexOf(item);
			if (index !== -1) {
				this.datalist.splice(index, 1);
			}
		}
	},
	mounted() {
		this.dialogVisible=true
		this.$nextTick(()=>{
			this.dialogVisible=false
		})
		this.$dragging.$on('dragged', ({ value }) => {});
	},


};
</script>

<style lang="less" scoped>
.initmian {
	width: 100%;
	min-width: 1300px;
	.mianboont {
		width: 100%;
		height: 140px;
		border-bottom: 1px dashed #e8e8e8;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.mianingtop {
		width: 100%;
		height: 210px;
		border-bottom: 1px solid #e8e8e8;
		display: flex;
		justify-content: center;
		align-items: center;
		img {
			width: 61px;
		}
	}
	.itemns {
		width: 100%;
		height: auto;
		.froitem {
			width: 100%;
			height: 56px;
			border-bottom: 1px solid #e8e8e8;
			display: flex;
			&:hover {
				background: #e6f7ff;
			}
			.minslis {
				width: 20%;
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
				color: rgba(0, 0, 0, 0.65);
				font-size: 14px;
				user-select: none;
				cursor: pointer;
				.mians {
					width: 100%;
					display: flex;
					height: 100%;
					display: flex;
					align-items: center;
					justify-content: center;
					a {
						cursor: pointer;
						color: #1890ff;
						text-decoration: none;
						background-color: transparent;
						outline: none;
						transition: color 0.3s;
						user-select: none;
						&:hover {
							color: #1890ff59;
						}
					}
				}
			}
		}
	}
	.inmiand {
		width: 100%;
		height: 56px;
		background: #fafafa;
		border-bottom: 1px solid #e8e8e8;
		display: flex;
		div {
			width: 20%;
			height: 100%;
			display: flex;
			align-items: center;
			justify-content: center;
			color: #333333;
		}
	}
	.inittip {
		padding: 20px 0 20px 40px;
		span {
			&:nth-child(1) {
				font-size: 14px;
				color: #333333;
				font-weight: bold;
			}
			&:nth-child(2) {
				color: #666666;
				font-size: 12px;
			}
		}
	}
}
</style>
