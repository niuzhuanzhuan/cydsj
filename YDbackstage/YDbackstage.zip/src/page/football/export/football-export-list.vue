<template>
	<div class="page-main">
		<el-alert
			v-once
			title="您的每次导出都将自动生成加密临时文件保存至永动力服务器，有效期7天，过期后将失效无法再次下载，下载的历史记录长期有效"
			type="warning"
			:closable="false"
			show-icon>
		</el-alert>
		
		<el-table
		  	class="export-table"
		  	:data="tableData"
		  	border
		  	:header-cell-style="{'background-color':'#FAFAFA'}"
		>
			<img slot="empty" style="margin-top: 20px;" src="@/assets/imgs/empty_table.png" />
			
			<el-table-column fixed prop="title" label="文件标题" width="150" align="center"></el-table-column>
			<el-table-column prop="down_type" label="导出类型" align="center"></el-table-column>
			<el-table-column prop="size" label="文件大小(KB)" align="center"></el-table-column>
			<el-table-column prop="state_text" label="状态" align="center">
				<template slot-scope="scope">
					<p>
						<!-- <el-tooltip effect="dark" content="说明" >
							  <i class="el-icon-warning-outline table-icon"></i>
						</el-tooltip> -->
						{{ scope.row.state_text }}
					</p>
				</template>
			</el-table-column>
			<el-table-column prop="create_time" label="导出时间" align="center"></el-table-column>
			<el-table-column prop="end_time" label="过期时间" align="center"></el-table-column>
			<el-table-column fixed="right" label="下载" width="200" align="center">
				<template slot-scope="scope">
					<el-button type="text" size="small" @click="download(scope.row)" >下载</el-button>
					<span>|</span>
					<el-popover
						placement="bottom"
						width="200"
						trigger="click"
					>
						<p style="color: red;"><i class="el-icon-warning-outline table-icon"></i>请妥善保管解压密码</p>
						<p>解压密码：{{scope.row.password}}</p>
						<el-button slot="reference" type="text" size="small">解压密码</el-button>
					</el-popover>
					
					<span>|</span>
					<el-popconfirm
					  title="确定要重新生成吗？"
					  @onConfirm="remakeFile(scope.row)"
					>
						<el-button slot="reference" type="text" size="small">重新生成</el-button>
					</el-popconfirm>
				</template>
			</el-table-column>
		</el-table>
		<self-pagination ref="pagination" class="page-bar" :total="exportTotal" @pageChange="pageChange"></self-pagination>
	</div>
</template>

<script>
	import selfPagination from '@/components/BaseComponents/Pagination.vue'
	
	export default {
		components:{
			selfPagination
		},
		data(){
			return{
				tableData:[],
				exportTotal:0,
			}
		},
		mounted() {
			this.$refs.pagination.goTo(1);
		},
		methods:{
			pageChange(params){
				this.$api.getFootballExportList({
					...params
				}).then(res => {
					// console.log(res);
					this.tableData = res.data.data
					this.exportTotal = res.data.total;
				});
			},
			download(item){
				this.$api.getFootballExportUrl({id:item.id}).then(res => {
					if(res.code === 1){
						window.open(res.data.file);
					}
				})
			},
			// 重新生成文件
			remakeFile(item){
				this.$api.getFootballExportFile({match_id:item.match_id}).then(res => {
					// console.log(res);
					if(res.code === 1){
						this.$message({message: '重新生成成功',type: 'success'});
						this.$refs.pagination.refresh();
					}
				})
			}
		}
	}
</script>

<style lang="less" scoped>
	*{
		box-sizing: border-box;
	}
	.page-main{
		min-height: 100%;
		padding: 20px;
		background-color: white;
	}
	.el-button{
		color: #3861DB;
	}
	
	.export-table{
		margin: 20px 0 10px;
		
		.table-icon{
			font-size: 14px;
			color: blue;
		}
	}
</style>
