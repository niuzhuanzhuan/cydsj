<template>
	<div>
		<establishs :designate="0"/>
	</div>
</template>

<script>
	import establishs from '../../create/football-create.vue'
	export default{
		components:{
			establishs
		}
	}
</script>

<style>
</style>
