const mutations = {
	gettoken: (state, data) => {
		state.initfromdata = data;
	},
	setmatch: (state, data) => {
		state.match = data;
	},
	setmatchfrom: (state, data) => {
		state.match.form = data;
	},
	setmapkey: (state, data) => {
		state.mapkey = data;
	},
}
export default mutations
