/*保存在vuex同时,也保存在sessionStorage里面,页面关闭同时清空*/
const actions = {
	token_get(state, data = '') {
		state.commit('gettoken', data)
		sessionStorage['initfromdata'] = JSON.stringify(data)
	},
	set_match(state,data={}){
		state.commit('setmatch', data)
	},
	set_matchfrom(state,data=[]){
		state.commit('setmatchfrom', data)
	},
	set_mapkey(state,data={}){
		state.commit('setmapkey', data)
	}
}
export default actions
