const state = {
	initfromdata:{},
	match:{},
	mapkey:{}
}
export default state
