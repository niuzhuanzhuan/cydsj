import router from '@/router';
const getters = {
	
}
export default getters
