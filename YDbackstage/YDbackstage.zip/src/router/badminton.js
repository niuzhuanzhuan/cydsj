const childarrs = [{
		path: '/badminton_establish',
		name: 'badminton_establish',
		component: resolve => require(['@/page/badminton/establish/badminton-establish'], resolve),
		meta: {
			title: '羽毛球创建赛事'
		}
	},
	{
		path: '/badminton_list',
		name: 'badminton_list',
		component: resolve => require(['@/page/badminton/match/badminton-match-list.vue'], resolve),
		meta: {
			title: '羽毛球赛事列表'
		}
	},
	{
		path: '/badminton_matchinfo',
		name: '/badminton_matchinfo',
		component: resolve => require(['@/page/badminton/match/badminton-match-info.vue'], resolve),
		meta: {
			title: '羽毛球赛事管理'
		}
	},
	{
		path: '/badminton_export',
		component: resolve => require(['@/page/badminton/export/badminton-export-list.vue'], resolve),
		meta: {
			title: '羽毛球导出管理'
		}
	},
	{
		path: '/badminton_insure',
		name: 'badminton_insure',
		component: resolve => require(['@/page/badminton/insurance/badminton-insurance-index.vue'], resolve),
		meta: {
			title: '羽毛球在线投保'
		},
	},
	{
		path: '/badminton_edit',
		name: 'badminton_edit',
		component: resolve => require(['@/page/badminton/matchedit/badminton-matchedit'], resolve),
		meta: {
			title: '羽毛球编辑赛事'
		}
	},
]

export default {
	childarrs
}
