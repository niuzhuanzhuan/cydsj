const childarrs = [{
		path: '/football_establish',
		name: 'football_establish',
		component: resolve => require(['@/page/football/create/football-create'],resolve),
		meta: {
			title: '足球创建赛事'
		}
	},
	{
		path: '/football_list',
		name: 'football_list',
		component: resolve => require(['@/page/football/match/football-match-list.vue'], resolve),
		meta: {
			title: '足球赛事列表'
		}
	},
	{
		path: '/football_match_info',
		component: resolve => require(['@/page/football/match/football-match-info.vue'], resolve),
		meta: {
			title: '足球赛事管理'
		}
	},
	{
		path: '/football_export',
		component: resolve => require(['@/page/football/export/football-export-list.vue'], resolve),
		meta: {
			title: '足球导出管理'
		}
	},
	{
		path: '/football_insure',
		name: 'football_insure',
		component: resolve => require(['@/page/football/insurance/football-insurance-index.vue'], resolve),
		meta: {
			title: '足球在线投保'
		},
	},
	{
		path: '/football_match_edit',
		name: 'football_edit',
		component: resolve => require(['@/page/football/matchedit/football-match-edit'], resolve),
		meta: {
			title: '足球编辑赛事'
		}
	},
]

export default {
	childarrs
}
