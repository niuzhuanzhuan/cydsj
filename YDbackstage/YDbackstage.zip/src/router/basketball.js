const childarrs = [{
	path: '/basketball_establish',
	name: 'basketball_establish',
	component: resolve => require(['@/page/basketball/create/basketball-create'],resolve),
	meta: {
		title: '篮球创建赛事'
	}
},
	{
		path: '/basketball_list',
		name: 'basketball_list',
		component: resolve => require(['@/page/basketball/match/basketball-match-list.vue'], resolve),
		meta: {
			title: '篮球赛事列表'
		}
	},
	{
		path: '/basketball_match_info',
		component: resolve => require(['@/page/basketball/match/basketball-match-info.vue'], resolve),
		meta: {
			title: '篮球赛事管理'
		}
	},
	{
		path: '/basketball_export',
		component: resolve => require(['@/page/basketball/export/basketball-export-list.vue'], resolve),
		meta: {
			title: '篮球导出管理'
		}
	},
	{
		path: '/basketball_insure',
		name: 'basketball_insure',
		component: resolve => require(['@/page/basketball/insurance/basketball-insurance-index.vue'], resolve),
		meta: {
			title: '篮球在线投保'
		},
	},
	{
		path: '/basketball_match_edit',
		name: 'basketball_edit',
		component: resolve => require(['@/page/basketball/matchedit/basketball-match-edit'], resolve),
		meta: {
			title: '篮球编辑赛事'
		}
	},
]

export default {
	childarrs
}
