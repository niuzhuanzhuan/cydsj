import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)
//解决路由重复
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
	return originalPush.call(this, location).catch(err => err)
}

import balance from './balance.js'
import pingpongball from './pingpongball.js'
import sanda from './sanda.js'
import football from './football.js'
import badminton from './badminton.js'
import basketball from './basketball.js'

import ydlshopping from './ydlshopping.js'


const childalist = [
	...balance.childarrs,
	...pingpongball.childarrs,
	...sanda.childarrs,
	...football.childarrs,
	...badminton.childarrs,
	...basketball.childarrs,
	...ydlshopping.routers
];

const routes = [{
		path: '/',
		redirect: '/homeindex'
	},
	{
		path: '/home',
		component: resolve => require(['@/components/common/Home.vue'], resolve),
		meta: {
			title: '自述文件'
		},
		children: childalist
	}, {
		path: '*',
		redirect: '/404'
	},
	{
		path: '/Login',
		name: 'Login',
		component: resolve => require(['../components/page/Login.vue'], resolve)
	},
]



const router = new VueRouter({
	routes
})

export default router
