const routers = [{
		path: '/order',
		name: 'Order',
		component: resolve => require(['@/page/ydlshoping/order/order'], resolve),
		meta: {
			title: '订单管理'
		},
	},
	{
		path: '/category_list',
		name: 'Category',
		component: resolve => require(['@/page/ydlshoping/category/category-index'], resolve),
		meta: {
			title: '品类管理'
		},
	},
	{
		path: '/brand_list',
		name: 'Brand',
		component: resolve => require(['@/page/ydlshoping/brand/brand-index'], resolve),
		meta: {
			title: '品牌管理'
		},
	},
	{
		path: '/supplier_list',
		name: 'Supplier',
		component: resolve => require(['@/page/ydlshoping/supplier/supplier-index'], resolve),
		meta: {
			title: '供应商管理'
		},
	},
	{
	path: '/shopingmanage',
	name: 'shopingmanage',
	component: resolve => require(['@/page/ydlshoping/shopingmanage/shopingmanage'], resolve),
	meta: {
		title: '商品管理'
	}
}
]

export default {
	routers
}