const childarrs = [{
		path: '/sanda_establish',
		name: 'sanda_establish',
		component: resolve => require(['@/page/sanda/establish/establish'], resolve),
		meta: {
			title: '散打创建赛事'
		}
	},
	{
		path: '/sanda_list',
		name: 'sanda_list',
		component: resolve => require(['@/page/sanda/match/list.vue'], resolve),
		meta: {
			title: '散打赛事列表'
		}
	},
	{
		path: '/sanda_matchinfo',
		component: resolve => require(['@/page/sanda/match/info.vue'], resolve),
		meta: {
			title: '散打赛事管理'
		}
	},
	{
		path: '/sanda_export',
		component: resolve => require(['@/page/sanda/export/list.vue'], resolve),
		meta: {
			title: '散打导出管理'
		}
	},
	{
		path: '/sanda_insure',
		name: 'sanda_insure',
		component: resolve => require(['@/page/sanda/insurance/index.vue'], resolve),
		meta: {
			title: '散打在线投保'
		},
	},
	{
		path: '/sanda_edit',
		name: 'sanda_edit',
		component: resolve => require(['@/page/sanda/matchedit/matchedit'], resolve),
		meta: {
			title: '散打编辑赛事'
		}
	},
]

export default {
	childarrs
}
