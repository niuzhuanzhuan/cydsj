const childarrs = [{
		path: '/pingpongball_establish',
		name: 'pingpongball_establish',
		component: resolve => require(['@/page/pingpongball/establish/pingpongball-establish'], resolve),
		meta: {
			title: '乒乓球创建赛事'
		}
	},
	{
		path: '/pingpongball_list',
		name: 'pingpongball_list',
		component: resolve => require(['@/page/pingpongball/match/pingpongball-match-list.vue'], resolve),
		meta: {
			title: '乒乓球赛事列表'
		}
	},
	{
		path: '/pingpongball_info',
		name: 'pingpongball_info',
		component: resolve => require(['@/page/pingpongball/match/pingpongball-match-info.vue'], resolve),
		meta: {
			title: '乒乓球赛事管理'
		}
	},
	{
		path: '/pingpongball_export',
		component: resolve => require(['@/page/pingpongball/export/pingpongball-export-list.vue'], resolve),
		meta: {
			title: '乒乓球导出管理'
		}
	},
	{
		path: '/pingpongball_insure',
		name: 'pingpongball_insure',
		component: resolve => require(['@/page/pingpongball/insurance/pingpongball-index.vue'], resolve),
		meta: {
			title: '乒乓球在线投保'
		},
	},
	{
		path: '/pingpongball_edit',
		name: 'pingpongball_edit',
		component: resolve => require(['@/page/pingpongball/matchedit/pingpongball-matchedit'], resolve),
		meta: {
			title: '乒乓球编辑赛事'
		}
	},
]

export default {
	childarrs
}
