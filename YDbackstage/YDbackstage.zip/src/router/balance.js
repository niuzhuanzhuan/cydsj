const childarrs = [{
		path: '/dashboard',
		component: resolve => require(['@/components/page/Dashboard'], resolve),
		meta: {
			title: '首页'
		},
	}, {
		path: '/hostinformation',
		component: resolve => require(['@/page/balance/hostinformation'], resolve),
		meta: {
			title: '主办方基本信息'
		}
	},
	{
		path: '/establish',
		name: 'establish',
		component: resolve => require(['@/page/balance/establish/establish'], resolve),
		meta: {
			title: '创建赛事'
		}
	},
	{
		path: '/404',
		component: resolve => require(['@/components/page/404.vue'], resolve),
		meta: {
			title: '404'
		}
	}, {
		path: '/homeindex',
		component: resolve => require(['@/page/home/index.vue'], resolve),
		meta: {
			title: '首页'
		}
	}, {
		path: '/homeclub',
		component: resolve => require(['@/page/home/club.vue'], resolve),
		meta: {
			title: '首页'
		}
	}, {
		path: '/matchlist',
		component: resolve => require(['@/page/balance/match/list.vue'], resolve),
		meta: {
			title: '赛事列表'
		}
	}, {
		path: '/match/info',
		component: resolve => require(['@/page/balance/match/info.vue'], resolve),
		meta: {
			title: '赛事管理'
		}
	}, {
		path: '/exportlist',
		component: resolve => require(['@/page/balance/export/list.vue'], resolve),
		meta: {
			title: '导出管理'
		}
	}, {
		path: '/clublist',
		component: resolve => require(['@/page/club/list.vue'], resolve),
		meta: {
			title: '俱乐部管理'
		}
	}, {
		path: '/club/edit',
		name: 'clubEdit',
		component: resolve => require(['@/page/club/edit.vue'], resolve),
		meta: {
			title: '编辑俱乐部'
		}
	}, {
		path: '/certificationindex',
		component: resolve => require(['@/page/balance/certification/index.vue'], resolve),
		meta: {
			title: '企业认证'
		}
	}, {
		path: '/certification/submit',
		component: resolve => require(['@/page/balance/certification/submit.vue'], resolve),
		meta: {
			title: '提交企业认证'
		}
	}, {
		path: '/account',
		component: resolve => require(['@/page/account/index.vue'], resolve),
		meta: {
			title: '账户管理'
		}
	}, {
		path: '/account/change',
		name: 'accountChange',
		component: resolve => require(['@/page/account/change.vue'], resolve),
		meta: {
			title: '更改管理员'
		}
	}, {
		path: '/insurance',
		name: 'insurance',
		component: resolve => require(['@/page/balance/insurance/index.vue'], resolve),
		meta: {
			title: '在线投保'
		}
	},
	{
		path: '/financeindex',
		component: resolve => require(['@/page/finance/index'], resolve),
		meta: {
			title: '财务管理'
		}
	}, {
		path: '/financeclub',
		component: resolve => require(['@/page/finance/club'], resolve),
		meta: {
			title: '财务管理'
		}
	},
	{
		path: '/matchedit',
		component: resolve => require(['@/page/balance/matchedit/matchedit'], resolve),
		meta: {
			title: '编辑赛事'
		}
	},
	{
		path: '/score',
		component: resolve => require(['@/page/balance/score/score'], resolve),
		meta: {
			title: '成绩录入'
		}
	},
]

export default {
	childarrs
}
